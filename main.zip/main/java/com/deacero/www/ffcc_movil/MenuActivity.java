package com.deacero.www.ffcc_movil;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.ModuloDisenoServicio.DisenoServicioActivity;
import com.deacero.www.ffcc_movil.ModuloDisenoServicio.TablaEquipoRequerido;
import com.deacero.www.ffcc_movil.ModuloEstatusCarros.ConsultaEstatusCarroActivity;
import com.deacero.www.ffcc_movil.ModuloFacturacion.ConsultaFacturacionActivity;
import com.deacero.www.ffcc_movil.ModuloInspeccionMancomunada.InspeccionMancomunadaActivity;
import com.deacero.www.ffcc_movil.ModuloInspeccionSalida.InspeccionSalidaActivity;
import com.deacero.www.ffcc_movil.ModuloLoteoUnidades.AddLoteoUnidadActivity;
import com.deacero.www.ffcc_movil.ModuloLoteoUnidades.LoteoUnidadesActivity;
import com.deacero.www.ffcc_movil.ModuloMttoAutonomo.OTMttoActivity;
import com.deacero.www.ffcc_movil.ModuloServicioColocacion.RegistroColocacionServicioActivity;
import com.deacero.www.ffcc_movil.ModuloServicioRetiro.ServicioRetiroActivity;
import com.deacero.www.ffcc_movil.metodos.AuthenticationWS;
import com.deacero.www.ffcc_movil.metodos.AuthenticationWS2;
import com.deacero.www.ffcc_movil.metodos.GetCarrosColocadosWS;
import com.deacero.www.ffcc_movil.metodos.GetCarrosWS;
import com.deacero.www.ffcc_movil.metodos.GetCatViaWS;
import com.deacero.www.ffcc_movil.metodos.GetCfgEvaluacionRetiroWS;
import com.deacero.www.ffcc_movil.metodos.GetCfgInspeccionDetWS;
import com.deacero.www.ffcc_movil.metodos.GetCfgLoteoMaterialWS;
import com.deacero.www.ffcc_movil.metodos.GetCfgLoteoUnidadWS;
import com.deacero.www.ffcc_movil.metodos.GetCfgSolicitudServicioWS;
import com.deacero.www.ffcc_movil.metodos.GetClienteInternoWS;
import com.deacero.www.ffcc_movil.metodos.GetDimensionRechazoWS;
import com.deacero.www.ffcc_movil.metodos.GetEquipoWS;
import com.deacero.www.ffcc_movil.metodos.GetTipoUnidadWS;
import com.deacero.www.ffcc_movil.metodos.GetTurnoWS;
import com.deacero.www.ffcc_movil.metodos.Internet;
import com.deacero.www.ffcc_movil.metodos.PostColocacionWS;
import com.deacero.www.ffcc_movil.metodos.PostDisenoWS;
import com.deacero.www.ffcc_movil.metodos.PostEvalaucionRetiroWS;
import com.deacero.www.ffcc_movil.metodos.PostInspeccionWS;
import com.deacero.www.ffcc_movil.metodos.PostLoteoWS;
import com.deacero.www.ffcc_movil.metodos.PostRetiroWS;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MenuActivity extends AppCompatActivity implements View.OnClickListener {
    BDFFCCMovil objBD; //hace la conexión
    private Cursor c;
    private DrawerLayout dl;
    private ActionBarDrawerToggle t;
    private NavigationView nv;
    private TextView viewNominaUsuario;
    private String nombreUsuario=".",  token="", Password="", DireccionMAC="", diaFormateado,mesFormateado, Fecha="", idUsuario, ClaEmpleado, NombreUsuarioLogueado, ClaUbicacionLogin,  loginUserName;
    private String[] Ventana;
    private Toast toast;
    private TextView EdTxtFecha;
    private ImageButton imgBtnCalendario;
    private static final String CERO = "0";
    //private static final String BARRA = "/";
    private static final String GUION = "-";
    private final Calendar calendario = Calendar.getInstance();
    private int yy = calendario.get(Calendar.YEAR);
    private int mm = calendario.get(Calendar.MONTH);
    private int dd = calendario.get(Calendar.DAY_OF_MONTH);
    private DatePickerDialog datePicker;
    private int mesActual;

    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    private Date date = new Date();
    private int FILAS, COLUMNAS = 0; // Filas y columnas de nuestra tabla
    private TableLayout mytabla; // Layout donde se pintará la tabla
    private ArrayList<String> valorescabecera = new ArrayList<String>();
    private ArrayList<String> elementos = new ArrayList<String>();
    private Button btnRecargarTabla;
    private Intent inspeccionmancomunada, inspeccionsalida, loteounidades, disenoservicio, servicioColocacion, servicioRetiro, fact, otmtto, estcarro;
    private Internet internet;
    private TablaEquipoRequerido tabla;
    //obj serv comunicacion api
    private GetCatViaWS WSVia;
    private GetClienteInternoWS WSClienteInterno;
    private GetCfgInspeccionDetWS WSCFGIns;
    private GetCarrosWS WSCarros;
    private GetDimensionRechazoWS WSDimensionRechazo;
    private GetTipoUnidadWS WSTipoUnidad;
    private GetCfgLoteoUnidadWS WSCfgLoteoUnidad;
    private GetCfgLoteoMaterialWS WSCfgLoteoMaterial;
    private GetCfgEvaluacionRetiroWS WSCfgEvaluacionRetSRV;
    private GetCfgSolicitudServicioWS WSCfgSolServ;
    private GetTurnoWS WSGetTurno;
    private GetCarrosColocadosWS WSCarrosColocadosSRV;
    private GetEquipoWS WSGetEquipo;
    private AuthenticationWS2 AuthWS;
    private  View header;
    private  MenuItem estCarro, otmttom, facturacion;
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        dl = (DrawerLayout)findViewById(R.id.activity_menu);
        t = new ActionBarDrawerToggle(this, dl,R.string.Open, R.string.Close);
        idUsuario = getIntent().getExtras().getString("idUsuario");//SERIA ClaUsuarioMod
        ClaEmpleado = getIntent().getExtras().getString("ClaEmpleado");//SERIA ClaEmpleado
        NombreUsuarioLogueado = getIntent().getExtras().getString("NombreUsuario");///NombreUsuario
        loginUserName = getIntent().getExtras().getString("loginUserName");//usuario
        //final String Contrasena = getIntent().getExtras().getString("Contrasena");
        ClaUbicacionLogin = getIntent().getExtras().getString("ClaUbicacion");//Ubicacion de la tableta
        DireccionMAC = getIntent().getExtras().getString("DireccionMAC");

        EdTxtFecha = (TextView) findViewById(R.id.edTxtFecha);
        imgBtnCalendario = (ImageButton) findViewById(R.id.imgBtnCalendar);
        btnRecargarTabla = (Button) findViewById(R.id.btnRecargarTabla);
        mytabla = (TableLayout) findViewById(R.id.TablaEquipoRequerido);

        Fecha = dateFormat.format(date);
        EdTxtFecha.setText(Fecha);
        imgBtnCalendario.setOnClickListener(this);
        btnRecargarTabla.setOnClickListener(this);

        dl.addDrawerListener(t);
        t.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //base datos
        objBD = new BDFFCCMovil(this);
        nv = (NavigationView)findViewById(R.id.nv);
        header = nv.getHeaderView(0);
        estCarro = nv.getMenu().findItem(R.id.estcarro);
        otmttom = nv.getMenu().findItem(R.id.otmtto);
        facturacion = nv.getMenu().findItem(R.id.facturacion);
        if("22".equals(ClaUbicacionLogin)){
            estCarro.setVisible(false);
            otmttom.setVisible(false);
            facturacion.setVisible(false);
        }

        viewNominaUsuario = (TextView) header.findViewById(R.id.textNominaUsuario);
        c = objBD.getUserXLoginUser(loginUserName);
        if (c.moveToFirst()) {
            nombreUsuario = c.getString(3);
            token = c.getString(8);///
        }
        c.close();
        objBD.close();
        //INTERNET
        internet = new Internet(getApplicationContext());
        if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
            WSVia = new GetCatViaWS(MenuActivity.this, token, getString(R.string.IpGetCatVia), ClaUbicacionLogin);
            WSVia.execute("");
        }else{
            if (toast!= null) { toast.cancel(); }
            toast = Toast.makeText(getApplicationContext(),"No Hay Conexión a internet. (VIA)", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }
        if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
            WSClienteInterno = new GetClienteInternoWS(MenuActivity.this,token,getString(R.string.IpGetClienteInterno),ClaUbicacionLogin);
            WSClienteInterno.execute("");
        }else{
            if (toast!= null) { toast.cancel(); }
            toast = Toast.makeText(getApplicationContext(),"No Hay Conexión a internet. (CI)", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }
        if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
            WSCFGIns = new GetCfgInspeccionDetWS(MenuActivity.this,token,getString(R.string.IpGetCfgInspeccionDet),ClaUbicacionLogin);
            WSCFGIns.execute("");
        }else{
            if (toast!= null) { toast.cancel(); }
            toast = Toast.makeText(getApplicationContext(),"No Hay Conexión a internet. (CfgIns)", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }
        if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
            WSCarros = new GetCarrosWS(MenuActivity.this,token,getString(R.string.IpGetCarros),ClaUbicacionLogin,DireccionMAC);
            WSCarros.execute("");
        }else{
            if (toast!= null) { toast.cancel(); }
            toast = Toast.makeText(getApplicationContext(),"No Hay Conexión a internet. (Carros)", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }
        if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
            WSDimensionRechazo = new GetDimensionRechazoWS(MenuActivity.this,token,getString(R.string.IpGetDimensionRechazo),ClaUbicacionLogin);
            WSDimensionRechazo.execute("");
        }else{
            if (toast!= null) { toast.cancel(); }
            toast = Toast.makeText(getApplicationContext(),"No Hay Conexión a internet. (Carros)", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }
        if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
            WSTipoUnidad = new GetTipoUnidadWS(MenuActivity.this,token,getString(R.string.IpGetTipoUnidad),ClaUbicacionLogin);
            WSTipoUnidad.execute("");
        }else{
            if (toast!= null) { toast.cancel(); }
            toast = Toast.makeText(getApplicationContext(),"No Hay Conexión a internet. (Carros)", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }
        if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
            WSCfgLoteoUnidad = new GetCfgLoteoUnidadWS(MenuActivity.this,token,getString(R.string.IpGetCfgLoteoUnidad),ClaUbicacionLogin);
            WSCfgLoteoUnidad.execute("");
        }else{
            if (toast!= null) { toast.cancel(); }
            toast = Toast.makeText(getApplicationContext(),"No Hay Conexión a internet. (Carros)", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }
        if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
            WSCfgLoteoMaterial = new GetCfgLoteoMaterialWS(MenuActivity.this,token,getString(R.string.IpGetCfgLoteoMaterial),ClaUbicacionLogin);
            WSCfgLoteoMaterial.execute("");
        }else{
            if (toast!= null) { toast.cancel(); }
            toast = Toast.makeText(getApplicationContext(),"No Hay Conexión a internet. (Carros)", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }
        if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
            WSCfgEvaluacionRetSRV = new GetCfgEvaluacionRetiroWS(MenuActivity.this,token,getString(R.string.IpGetCfgEvaluacionRetiro),ClaUbicacionLogin);
            WSCfgEvaluacionRetSRV.execute("");
        }else{
            if (toast!= null) { toast.cancel(); }
            toast = Toast.makeText(getApplicationContext(),"No Hay Conexión a internet. (Carros)", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }
        if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
            WSCfgSolServ = new GetCfgSolicitudServicioWS(MenuActivity.this,token,getString(R.string.IpGetCfgSolicitudServicio),ClaUbicacionLogin, EdTxtFecha.getText().toString(), btnRecargarTabla,"SI",""+DireccionMAC,""+idUsuario);
            WSCfgSolServ.execute("");
        }else{
            if (toast!= null) { toast.cancel(); }
            toast = Toast.makeText(getApplicationContext(),"No Hay Conexión a internet. (Carros)", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }
        if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
            WSCarrosColocadosSRV = new GetCarrosColocadosWS(MenuActivity.this,token,getString(R.string.IpGetColocacionDiseno),ClaUbicacionLogin, Fecha);
            WSCarrosColocadosSRV.execute("");
        }else{
            if (toast!= null) { toast.cancel(); }
            toast = Toast.makeText(getApplicationContext(),"No Hay Conexión a internet. (Carros)", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }

        if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
            WSGetTurno = new GetTurnoWS(MenuActivity.this,token,getString(R.string.IpGetTurnos),ClaUbicacionLogin);
            WSGetTurno.execute("");
        }else{
            if (toast!= null) { toast.cancel(); }
            toast = Toast.makeText(getApplicationContext(),"No Hay Conexión a internet. (Turnos)", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }
        if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
            WSGetEquipo = new GetEquipoWS(MenuActivity.this,token,getString(R.string.IpGetEquipos),ClaUbicacionLogin);
            WSGetEquipo.execute("");
        }else{
            if (toast!= null) { toast.cancel(); }
            toast = Toast.makeText(getApplicationContext(),"No Hay Conexión a internet. (Equipos)", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }

        //--------------SERVICIOS POST
        /*if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
            PostInspeccionWS WSSendInspeccion = new PostInspeccionWS(MenuActivity.this, token, getString(R.string.IpPostInspeccionCarro), ClaUbicacionLogin, idUsuario, DireccionMAC);
            WSSendInspeccion.execute("");
        }else {
            if (toast!= null) { toast.cancel(); }
            toast = Toast.makeText(getApplicationContext(),"No Hay Conexión a internet. (inspeccionP)", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }*/
        /*if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
        PostLoteoWS WSSendLoteo = new PostLoteoWS(MenuActivity.this,token,getString(R.string.IpPostLoteo),ClaUbicacionLogin,idUsuario,DireccionMAC);
        WSSendLoteo.execute("");
        }else {
            if (toast!= null) { toast.cancel(); }
            toast = Toast.makeText(getApplicationContext(),"No Hay Conexión a internet. (loteoP)", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }*/
           /* if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
        PostDisenoWS WSSendDiseno = new PostDisenoWS(MenuActivity.this,token,getString(R.string.IpPostColocacion),ClaUbicacionLogin,idUsuario,DireccionMAC);
        WSSendDiseno.execute("");
            }else {
                if (toast!= null) { toast.cancel(); }
                toast = Toast.makeText(getApplicationContext(),"No Hay Conexión a internet. (disenoP)", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }*/
             /*   if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
        PostColocacionWS WSSendColocacion = new PostColocacionWS(MenuActivity.this,token,getString(R.string.IpPostColocacion),ClaUbicacionLogin,idUsuario,DireccionMAC);
        WSSendColocacion.execute("");
                }else {
                    if (toast!= null) { toast.cancel(); }
                    toast = Toast.makeText(getApplicationContext(),"No Hay Conexión a internet. (colocacionP)", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }*/
                    /*if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
        PostRetiroWS WSSendRetiro = new PostRetiroWS(MenuActivity.this,token,getString(R.string.IpPostRetiro),ClaUbicacionLogin,idUsuario,DireccionMAC);
        WSSendRetiro.execute("");
                    }else {
                        if (toast!= null) { toast.cancel(); }
                        toast = Toast.makeText(getApplicationContext(),"No Hay Conexión a internet. (retiroP)", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                    }*/
                  /*  if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
        PostEvalaucionRetiroWS WSSendEvalRetiro = new PostEvalaucionRetiroWS(MenuActivity.this,token,getString(R.string.IpPostEvaluacionRetiro),ClaUbicacionLogin,idUsuario,DireccionMAC);
        WSSendEvalRetiro.execute("");
                     }else {
                        if (toast!= null) { toast.cancel(); }
                        toast = Toast.makeText(getApplicationContext(),"No Hay Conexión a internet. (evaluacionP)", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                     }*/
        ///end  test WS
        viewNominaUsuario.setText(nombreUsuario);
        nv.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                switch(item.getItemId())
                {
                    case R.id.inspeccionmancomunada:
                        inspeccionmancomunada = new Intent(getApplicationContext(),InspeccionMancomunadaActivity.class);
                        inspeccionmancomunada.putExtra("idUsuario",idUsuario);//ClaUsuarioMod
                        inspeccionmancomunada.putExtra("ClaEmpleado",ClaEmpleado);//Clave del empleado, la misma que el login
                        inspeccionmancomunada.putExtra("loginUserName",loginUserName);//Usuario
                        inspeccionmancomunada.putExtra("token",token);
                        inspeccionmancomunada.putExtra("ClaUbicacion",ClaUbicacionLogin);
                        inspeccionmancomunada.putExtra("DireccionMAC",DireccionMAC);
                        startActivity(inspeccionmancomunada);
                        break;
                    case R.id.inspeccionsalida:
                        inspeccionsalida = new Intent(getApplicationContext(), InspeccionSalidaActivity.class);
                        inspeccionsalida.putExtra("idUsuario",idUsuario);//ClaUsuarioMod
                        inspeccionsalida.putExtra("ClaEmpleado",ClaEmpleado);//Clave del empleado, la misma que el login
                        inspeccionsalida.putExtra("loginUserName",loginUserName);//Usuario
                        inspeccionsalida.putExtra("token",token);
                        inspeccionsalida.putExtra("ClaUbicacion",ClaUbicacionLogin);
                        inspeccionsalida.putExtra("DireccionMAC",DireccionMAC);
                        startActivity(inspeccionsalida);
                        break;
                    case R.id.loteounidades:
                        loteounidades = new Intent(getApplicationContext(), AddLoteoUnidadActivity.class);
                        loteounidades.putExtra("idUsuario",idUsuario);//ClaUsuarioMod
                        loteounidades.putExtra("ClaEmpleado",ClaEmpleado);//Clave del empleado, la misma que el login
                        loteounidades.putExtra("loginUserName",loginUserName);//Usuario
                        loteounidades.putExtra("token",token);
                        loteounidades.putExtra("ClaUbicacion",ClaUbicacionLogin);
                        loteounidades.putExtra("DireccionMAC",DireccionMAC);
                        startActivity(loteounidades);
                        break;
                    case R.id.designservicio:
                        disenoservicio = new Intent(getApplicationContext(),DisenoServicioActivity.class);
                        disenoservicio.putExtra("idUsuario",idUsuario);//ClaUsuarioMod
                        disenoservicio.putExtra("ClaEmpleado",ClaEmpleado);//Clave del empleado, la misma que el login
                        disenoservicio.putExtra("loginUserName",loginUserName);//Usuario
                        disenoservicio.putExtra("token",token);
                        disenoservicio.putExtra("ClaUbicacion",ClaUbicacionLogin);
                        disenoservicio.putExtra("DireccionMAC",DireccionMAC);
                        startActivity(disenoservicio);
                        break;
                    case R.id.serviciocolocacion:
                        servicioColocacion = new Intent(getApplicationContext(),RegistroColocacionServicioActivity.class);
                        servicioColocacion.putExtra("idUsuario",idUsuario);//ClaUsuarioMod
                        servicioColocacion.putExtra("ClaEmpleado",ClaEmpleado);//Clave del empleado, la misma que el login
                        servicioColocacion.putExtra("loginUserName",loginUserName);//Usuario
                        servicioColocacion.putExtra("token",token);
                        servicioColocacion.putExtra("ClaUbicacion",ClaUbicacionLogin);
                        servicioColocacion.putExtra("DireccionMAC",DireccionMAC);
                        startActivity(servicioColocacion);
                        break;
                    case R.id.retirocliinterno:
                        servicioRetiro = new Intent(getApplicationContext(),ServicioRetiroActivity.class);
                        servicioRetiro.putExtra("idUsuario",idUsuario);//ClaUsuarioMod
                        servicioRetiro.putExtra("ClaEmpleado",ClaEmpleado);//Clave del empleado, la misma que el login
                        servicioRetiro.putExtra("loginUserName",loginUserName);//Usuario
                        servicioRetiro.putExtra("token",token);
                        servicioRetiro.putExtra("ClaUbicacion",ClaUbicacionLogin);
                        servicioRetiro.putExtra("DireccionMAC",DireccionMAC);
                        startActivity(servicioRetiro);
                        break;
                    case R.id.facturacion:
                        fact = new Intent(getApplicationContext(), ConsultaFacturacionActivity.class);
                        fact.putExtra("idUsuario",idUsuario);//ClaUsuarioMod
                        fact.putExtra("ClaEmpleado",ClaEmpleado);//Clave del empleado, la misma que el login
                        fact.putExtra("loginUserName",loginUserName);//Usuario
                        fact.putExtra("token",token);
                        fact.putExtra("ClaUbicacion",ClaUbicacionLogin);
                        fact.putExtra("DireccionMAC",DireccionMAC);
                        startActivity(fact);
                        break;
                    case R.id.otmtto:
                        otmtto = new Intent(getApplicationContext(), OTMttoActivity.class);
                        otmtto.putExtra("idUsuario",idUsuario);//ClaUsuarioMod
                        otmtto.putExtra("ClaEmpleado",ClaEmpleado);//Clave del empleado, la misma que el login
                        otmtto.putExtra("loginUserName",loginUserName);//Usuario
                        otmtto.putExtra("token",token);
                        otmtto.putExtra("ClaUbicacion",ClaUbicacionLogin);
                        otmtto.putExtra("DireccionMAC",DireccionMAC);
                        startActivity(otmtto);
                        break;
                    case R.id.estcarro:
                        estcarro = new Intent(getApplicationContext(), ConsultaEstatusCarroActivity.class);
                        estcarro.putExtra("idUsuario",idUsuario);//ClaUsuarioMod
                        estcarro.putExtra("ClaEmpleado",ClaEmpleado);//Clave del empleado, la misma que el login
                        estcarro.putExtra("loginUserName",loginUserName);//Usuario
                        estcarro.putExtra("token",token);
                        estcarro.putExtra("ClaUbicacion",ClaUbicacionLogin);
                        estcarro.putExtra("DireccionMAC",DireccionMAC);
                        startActivity(estcarro);
                        break;
                    case R.id.salirsistema:
                        new AlertDialog.Builder(MenuActivity.this, R.style.CustomDialogTheme)
                                .setTitle("Confirmar Salida")
                                .setMessage("¿Estas seguro de cerrar la aplicación?")
                                .setPositiveButton("SI", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Intent salida=new Intent(Intent.ACTION_MAIN); //Llamando a la activity principal
                                        finish();
                                        System.exit(0);
                                    }
                                })
                                .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                    }
                                })
                                .show();
                        break;
                    default:
                        break;
                }
                return true;
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(t.onOptionsItemSelected(item))
            return true;
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.imgBtnCalendar:
                datePicker = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        mesActual = monthOfYear + 1;
                        diaFormateado = (dayOfMonth < 10)? CERO + String.valueOf(dayOfMonth):String.valueOf(dayOfMonth);
                        mesFormateado = (mesActual < 10)? CERO + String.valueOf(mesActual):String.valueOf(mesActual);
                        EdTxtFecha.setText(year + GUION + mesFormateado + GUION + diaFormateado);
                            c = objBD.getUserXLoginUser(loginUserName);
                            if(c.getCount()>0){
                                c.moveToFirst();
                                Password = c.getString(4);
                            }
                            c.close();
                            AuthWS = new AuthenticationWS2(MenuActivity.this,getString(R.string.ip_authentication),loginUserName,Password,DireccionMAC,"0");
                            AuthWS.execute("");
                            c = objBD.getUserXLoginUser(loginUserName);
                            if(c.getCount()>0){
                                c.moveToFirst();
                                token = c.getString(8);
                            }
                            c.close();
                            objBD.close();
                            WSCfgSolServ = new GetCfgSolicitudServicioWS(MenuActivity.this,token,getString(R.string.IpGetCfgSolicitudServicio),ClaUbicacionLogin, EdTxtFecha.getText().toString(), btnRecargarTabla,"SI",""+DireccionMAC,""+idUsuario);
                            WSCfgSolServ.execute(""); //recargarTabla();
                    }
                }, yy, mm, dd);
                datePicker.show();
                break;
            case R.id.btnRecargarTabla:
                recargarTabla();
                break;
        }
    }

    public void recargarTabla(){
        mytabla.removeAllViews();
        valorescabecera.clear();
        elementos.clear();
        valorescabecera.add(" Cliente/Nave ");
        valorescabecera.add(" Ventana ");
        valorescabecera.add(" Estatus ");
        tabla = new TablaEquipoRequerido(MenuActivity.this, mytabla);
        tabla.agregarCabecera(valorescabecera);
        c = objBD.getSolicitudes(ClaUbicacionLogin, EdTxtFecha.getText().toString()+"T00:00:00","1");
        c.moveToFirst();
        if(c.getCount()>0){
            for (int i = 0; i < c.getCount(); i++) {///se pintan los renglones
                Ventana = c.getString(5).split("T");
                elementos.add(c.getString(7).replace("null", "").replace("", ""));//cliente
                elementos.add(Ventana[1]);//ventana
                elementos.add(c.getString(10));//Estatus
                tabla.agregarFilaTabla(elementos);
                elementos.clear();
                c.moveToNext();
            }
        }else{
            if (toast!= null) { toast.cancel(); }
            toast = Toast.makeText(getApplicationContext(),"No hay servicios programados para la fecha "+ EdTxtFecha.getText().toString(), Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
        }
        c.close();
        objBD.close();
    }
}
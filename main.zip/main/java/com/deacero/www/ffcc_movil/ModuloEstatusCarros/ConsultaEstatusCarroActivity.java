package com.deacero.www.ffcc_movil.ModuloEstatusCarros;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.R;
import com.deacero.www.ffcc_movil.metodos.AuthenticationWS2;
import com.deacero.www.ffcc_movil.metodos.GetEstatusCarrosWS;
import com.deacero.www.ffcc_movil.metodos.GetFacturacionWS;

import java.util.ArrayList;

public class ConsultaEstatusCarroActivity extends AppCompatActivity implements View.OnClickListener {
    ///////BD
    BDFFCCMovil objBD= new BDFFCCMovil(this); //hace la conexión
    private Cursor c;
    public ArrayList<EstatusCarro> listEstCar = new ArrayList<EstatusCarro>();
    public RecyclerView recyclerEstCarro;
    public EstatusCarroAdapter adp = new EstatusCarroAdapter(listEstCar);

    //DATOS SESSION USUARIO
    private String idUsuario,ClaEmpleado,NombreUsuario,loginUserName, ClaUbicacionLogin, MAC, token, Password;
    private Toast toast;
    private EditText editTextPlaca;
    public ImageButton imgBtnSearch;

    private String DirIp="";
    private GetEstatusCarrosWS EstCar;
    private AuthenticationWS2 AuthWS;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.consulta_estatus_carro_activity);
        //vars
        idUsuario = getIntent().getExtras().getString("idUsuario");
        ClaEmpleado = getIntent().getExtras().getString("ClaEmpleado");
        NombreUsuario = getIntent().getExtras().getString("NombreUsuario");
        loginUserName = getIntent().getExtras().getString("loginUserName");
        ClaUbicacionLogin = getIntent().getExtras().getString("ClaUbicacion");
        token = getIntent().getExtras().getString("token");
        MAC = getIntent().getExtras().getString("DireccionMAC");
        recyclerEstCarro =(RecyclerView)findViewById(R.id.recyclerEstatusCarro);
        recyclerEstCarro.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        editTextPlaca = (EditText) findViewById(R.id.txtPlacaEst);
        imgBtnSearch = (ImageButton) findViewById(R.id.imgBuscarPlaca);
        imgBtnSearch.setOnClickListener(this);
        recyclerEstCarro.setAdapter(adp);
    }
    
    @Override
    public void onRestart() {
        super.onRestart(); 
    }
    
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.imgBuscarPlaca:
                        if(editTextPlaca.getText().length()>=2) {
                            recyclerEstCarro.removeAllViewsInLayout();
                            listEstCar.clear();
                            c = objBD.getUserXLoginUser(loginUserName);
                            if (c.getCount() > 0) {
                                c.moveToFirst();
                                Password = c.getString(4);
                            }
                            c.close();
                            AuthWS = new AuthenticationWS2(ConsultaEstatusCarroActivity.this, getString(R.string.ip_authentication), loginUserName, Password, MAC, "0");
                            AuthWS.execute("");
                            c = objBD.getUserXLoginUser(loginUserName);
                            if (c.getCount() > 0) {
                                c.moveToFirst();
                                token = c.getString(8);
                            }
                            c.close();
                            objBD.close();
                            EstCar = new GetEstatusCarrosWS(ConsultaEstatusCarroActivity.this, token, getString(R.string.IpGetEstCarros), ClaUbicacionLogin, ""+editTextPlaca.getText().toString(), listEstCar, adp);
                            EstCar.execute();
                            recyclerEstCarro.setAdapter(adp);
                        } else{
                            if (toast!= null) { toast.cancel(); }
                            toast = Toast.makeText(getApplicationContext(),"Ingrese al menos 2 carácteres.", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                        }
                break;
        }
    }
}
package com.deacero.www.ffcc_movil.ModuloEstatusCarros;

public class EstatusCarro {
    private String Placa, Destino;

    public EstatusCarro(String placa, String destino) {
        Placa = placa;
        Destino = destino;
    }


    public String getPlaca() {
        return Placa;
    }

    public void setPlaca(String placa) {
        Placa = placa;
    }

    public String getDestino() {
        return Destino;
    }

    public void setDestino(String destino) {
        Destino = destino;
    }
}
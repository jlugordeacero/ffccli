package com.deacero.www.ffcc_movil.ModuloEstatusCarros;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.deacero.www.ffcc_movil.R;

import java.util.ArrayList;

public class EstatusCarroAdapter extends RecyclerView.Adapter<EstatusCarroAdapter.ViewHolderEstatusCarro>{

    private ArrayList<EstatusCarro> listaEstCar;

    public EstatusCarroAdapter(ArrayList<EstatusCarro> listaEstCar) {
        this.listaEstCar = listaEstCar;
    }

    @NonNull
    @Override
    public ViewHolderEstatusCarro onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list_estatuscarro,null,false);
        return new ViewHolderEstatusCarro(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolderEstatusCarro ViewHoldeFactura, final int i) {
        ViewHoldeFactura.Placa.setText(listaEstCar.get(i).getPlaca());
        ViewHoldeFactura.txtEstatus.setText(listaEstCar.get(i).getDestino());
    }

    @Override
    public int getItemCount() {
        return listaEstCar.size();
    }

    public class ViewHolderEstatusCarro extends RecyclerView.ViewHolder  {
        TextView Placa, txtEstatus;

        public ViewHolderEstatusCarro(@NonNull View itemView) {
            super(itemView);
            Placa=(TextView) itemView.findViewById(R.id.txtPlaca);
            txtEstatus=(TextView) itemView.findViewById(R.id.txtEstatus);
        }
    }
}

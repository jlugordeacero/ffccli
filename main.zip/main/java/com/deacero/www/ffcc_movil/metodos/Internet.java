package com.deacero.www.ffcc_movil.metodos;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.util.Log;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.NetworkInterface;
import java.net.URL;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Internet  {

    private Context mContext;
    private static ConnectivityManager manager;
    private static boolean isConnected;
    private static NetworkInfo activeNetwork;
    private static ConnectivityManager cm;

    //determina la conexión a internet
    public Internet(Context MyContext){
        this.mContext = MyContext;
    }

    public Context getmContext() {
        return mContext;
    }

    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static boolean compruebaConexion(Context context) {
        boolean connected = false;
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
        if (networkInfo != null) {
            Log.e("MenuActivity", ""+networkInfo.getState().toString());
            if (networkInfo.getState() == NetworkInfo.State.CONNECTED) {
               /* if(isOnlineNet()==true){
                    connected = true;
                }else{
                    connected = false;
                }*/

                cm =
                        (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);

                activeNetwork = cm.getActiveNetworkInfo();
                isConnected = activeNetwork != null &&
                        activeNetwork.isConnectedOrConnecting();

                System.out.println("isConnected: "+isConnected);
                connected = isConnected;
                return connected;
            } else {
                Log.e("MenuActivity", "DISCONNECTED");
                connected = false;
                return connected ;
            }
        }
        return connected;
    }

    public static boolean pingURL(String url, int timeout) {
        url = url.replaceFirst("^https", "http"); // Otherwise an exception may be thrown on invalid SSL certificates.

        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
            connection.setConnectTimeout(timeout);
            connection.setReadTimeout(timeout);
            connection.setRequestMethod("HEAD");
            int responseCode = connection.getResponseCode();
            return (200 <= responseCode && responseCode <= 399);
        } catch (IOException exception) {
            return false;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static Boolean isOnlineNet() {
        try {
            Process p = java.lang.Runtime.getRuntime().exec("/system/bin/ping -c 1 8.8.8.8");
            //p.waitFor(5, TimeUnit.SECONDS);
            p.wait(500000);
            p.destroy();
            int val           =p.waitFor();
            boolean reachable = (val == 0);
            Log.e("REAC ",""+reachable);
            return reachable;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return false;
    }

    @NonNull
    public static String getMacAddress() {
        try {
            List<NetworkInterface> all = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface nif : all) {
                if (!nif.getName().equalsIgnoreCase("wlan0")) continue;
                byte[] macBytes = nif.getHardwareAddress();
                if (macBytes == null) {
                    return "";
                }
                StringBuilder res1 = new StringBuilder();
                for (byte b : macBytes) {
                    res1.append(Integer.toHexString(b & 0xFF) + ":");
                }
                if (res1.length() > 0) {
                    res1.deleteCharAt(res1.length() - 1);
                }
                return res1.toString();
                //return "68:5a:cf:10:f6:14";
            }
        } catch (Exception ex) {
            Log.e("Error", ex.getMessage());
        }
        return "";
    }
}
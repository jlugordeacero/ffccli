package com.deacero.www.ffcc_movil.metodos;

import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.util.Log;

import com.deacero.www.ffcc_movil.BDFFCCMovil;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.LinkedList;
import java.util.List;

import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class PostDisenoWS extends AsyncTask<String, String, String> {
    //BD
    BDFFCCMovil objBD;
    Cursor c2,c3;
    //constantes
    Context mContext;
    String Token, DirIp, ClaUbicacion, ClaUsuario, MAC;

    public PostDisenoWS(Context MyContext, String MyToken, String MyDirIp, String MyClaUbicacion, String MyClaUsuario, String MyMAC) {
        this.mContext = MyContext;
        this.Token = MyToken;
        this.DirIp = MyDirIp;
        this.ClaUbicacion = MyClaUbicacion;
        this.ClaUsuario = MyClaUsuario;
        this.MAC = MyMAC;
    }

    public  String getMAC(){ return  MAC;}

    public void setMAC(String mac){ MAC = mac;}

    public  String getClaUsuario(){ return  ClaUsuario;}

    public void setClaUsuario(String claUsuario){ ClaUsuario = claUsuario;}

    public String getClaUbicacion() {
        return ClaUbicacion;
    }

    public void setClaUbicacion(String claUbicacion) {
        ClaUbicacion = claUbicacion;
    }

    public Context getmContext() {
        return mContext;
    }

    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }

    public String getDirIp() {
        return DirIp;
    }

    public void setDirIp(String dirIp) {
        DirIp = dirIp;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... Strings) {
        objBD = new BDFFCCMovil(mContext.getApplicationContext()); //hace la conexión
       // HttpClient httpclient = new DefaultHttpClient();
        HttpClient httpclient;
        String version = Build.VERSION.RELEASE;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            // versiones con android 6.0 o superior
            httpclient = new DefaultHttpClient();
        } else{
            boolean disableSsl=true;
            SSLConnectionSocketFactory sslSocketFactory;
            if (disableSsl) {
                SSLContext ctx;
                try {
                    X509TrustManager x509TrustManager = new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }
                    };
                    ctx = SSLContext.getInstance("TLS");
                    ctx.init(new KeyManager[0], new TrustManager[]{x509TrustManager}, new SecureRandom());
                } catch (NoSuchAlgorithmException | KeyManagementException e) {
                    throw new SecurityException(e);
                }
                sslSocketFactory = new SSLConnectionSocketFactory(
                        ctx,
                        SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER
                );
            } else {
                sslSocketFactory = SSLConnectionSocketFactory.getSocketFactory();
            }
            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", PlainConnectionSocketFactory.getSocketFactory())
                    .register("https", sslSocketFactory)
                    .build();

            httpclient = HttpClientBuilder.create()
                    .setConnectionManager(new PoolingHttpClientConnectionManager(registry))
                    .build();

        }
        //httpclient.getParams().setParameter("http.socket.timeout", new Integer(15000));
        httpclient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
        try {
            if (!DirIp.endsWith("?"))
                DirIp += "?";
            List<NameValuePair> paramsURL = new LinkedList<NameValuePair>();
            paramsURL.add(new BasicNameValuePair("ClaUbicacion", getClaUbicacion()));
            String paramString = URLEncodedUtils.format(paramsURL, "utf-8");
            DirIp += paramString;
            //Log.e("DIRIP.>",""+getDirIp());
            HttpPost httppost = new HttpPost(getDirIp());
            //httppost.setHeader("content-type", "application/json");
            //httppost.addHeader("Authorization", getToken());///add token
            int y;
            c2 = objBD.getColocacionesDiseno("1");///a 1 porque se enviaran todas las que seas iguales a 2 diseño terminado y ya no se envian
            c2.moveToFirst();

            System.out.println("COUNT ************************** "+c2.getCount());
            if(c2.getCount()>0){
            // Log.e("SERVICE ->","--"+c2.getCount());
            JSONArray FinalArray = new JSONArray();
            for (y = 0; y < c2.getCount(); y++) {
                //Log.e("POST Col->", "--" + c2.getString(0) + "--" + c2.getString(2) + "--" + c2.getString(3));
                JSONObject jsonObject = new JSONObject();
                JSONArray detalleArray = new JSONArray();
                jsonObject.put("IdTraCarroColocado", c2.getString(0));
                jsonObject.put("IdTraSolicitudServicio", c2.getString(1));
                jsonObject.put("ClaUbicacion", c2.getString(2));
                jsonObject.put("ClaConfServicios", c2.getString(3));
                jsonObject.put("ClaConfVentana", c2.getString(4));
                jsonObject.put("EstatusColocacion", "2");//c2.getString(6)
                //  System.out.println("ESTATUS COLOCACION ----"+c2.getString(6));
                jsonObject.put("FechaConfirmaColocacion", ""+c2.getString(7).replace("T"," "));//c2.getString(7)

                // Log.e("fechaINi ",""+c2.getString(8));
                if (c2.getString(8) == null || ("null").equals(c2.getString(8))) {
                    jsonObject.put("HoraInicial", "2018-02-10 11:55:20");
                } else {
                    jsonObject.put("HoraInicial", c2.getString(8).replace("T"," "));
                }
                if (c2.getString(9) == null || ("null").equals(c2.getString(9))) {
                    jsonObject.put("HoraFinal", "2018-02-10 11:55:20");
                } else {
                    jsonObject.put("HoraFinal", c2.getString(9).replace("T", " "));
                }


                jsonObject.put("ClaUsuarioColoco", c2.getString(11));

                if (c2.getString(10) == null || ("null").equals(c2.getString(10))) {
                    jsonObject.put("IdTraCarroColocadoBD", "-1");
                } else {
                    jsonObject.put("IdTraCarroColocadoBD", c2.getString(10));
                }
                jsonObject.put("NombrePcMod", c2.getString(5));
                jsonObject.put("ClaUsuarioMod", getClaUsuario());

                c3 = objBD.getColocacionesDet(c2.getString(0), c2.getString(2));
                c3.moveToFirst();
                int x;
                for (x = 0; x < c3.getCount(); x++) {
                    JSONObject detailObject = new JSONObject();
                    detailObject.put("ClaUbicacion", c3.getString(8));
                    detailObject.put("IdTraCarroColocadoDet", c3.getString(0));
                    detailObject.put("IdTraCarroColocado", c3.getString(1));
                    detailObject.put("IdControlUnidad", c3.getString(4));
                    detailObject.put("ClaCarro", c3.getString(5));
                    detailObject.put("PlacaCarro", c3.getString(6));

                    if (c3.getString(3) == null || ("null").equals(c3.getString(2))) {
                        detailObject.put("EsVacio", "0");
                    } else {
                        detailObject.put("EsVacio", c3.getString(2));
                    }
                    if (c3.getString(3) == null || ("null").equals(c3.getString(3))) {
                        detailObject.put("EsTapa", "0");
                    } else {
                        detailObject.put("EsTapa", c3.getString(3));
                    }

                    detailObject.put("NombrePcMod", getMAC());
                    detailObject.put("ClaUsuarioMod", getClaUsuario());
                    detalleArray.put(detailObject);
                    c3.moveToNext();
                }
                jsonObject.put("Detalle", detalleArray);
                c3.close();
                objBD.close();
                FinalArray.put(jsonObject);
                c2.moveToNext();
            }
            c2.close();
            objBD.close();
            Log.e("FINAL-> ", "" + FinalArray.toString());
            StringEntity se = new StringEntity(FinalArray.toString(),"UTF-8");
            // StringEntity se = new StringEntity("");
            se.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
            httppost.addHeader("Authorization", getToken());///add token
            httppost.setEntity(se);
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity ent = response.getEntity();//obtenemos respuesta
            String respuesta = EntityUtils.toString(ent);

            //Log.e("Respuesta :",respuesta);
            JSONArray arrayResp = new JSONArray(respuesta);///falta act los id de las colocaciones
            Log.e("Respuesta:", arrayResp.toString());
            /*Checking response */
            if (response != null) {
                //InputStream in = response.getEntity().getContent(); //Get the data in the entity
                for (int n = 0; n < arrayResp.length(); n++) {
                    String valor = arrayResp.getString(n);
                    //Log.e("--",valor);
                    valor = valor.replace(";", ":");
                    //Log.e("Valor: ",""+valor);
                    String[] separated = valor.split(":");
                    Log.e("DISEÑO--", "Success " + separated[0] + " idColocacionSQLITE: " + separated[1] + " IDCOLOCASQLSERVER: " + separated[2]);
                    if (separated[0].equals("Succes")) {
                        Log.e("entra", "");
                        ///siempre y cuando el estatus anterior sea 1 se actualizara a etatus 2
                        objBD.updateEstatusColocacion("" + separated[1], "2");//seteo a  porque ya no se enviaran
                        System.out.println("SQL SERVER ID ******** "+separated[2]);
                        objBD.updateIDColocacionSQLServer("" + separated[1], "" + separated[2]);//
                    }
                }
            }
            //Log.e("response: "+in);
        }
            return "succcess";
        } catch (ClientProtocolException ex) {
            return "" + ex.toString();
        } catch (IOException e) {
            //e.printStackTrace();
            return "" + e.toString();
        } catch (JSONException e2) {
            //e.printStackTrace();
            return e2.toString();
        } catch (Exception e3) {
            //e.printStackTrace();
            return e3.toString();
        } finally {
            httpclient.getConnectionManager().shutdown();
        }
        //return "no atrapo exception";
    }

    @Override
    protected void onPostExecute(String result) {
        Log.e("RESULTADO POST Dis", "" + result);
        if(result.equals("succcess")){

        }else {
            AlertDialog.Builder dialogg = new AlertDialog.Builder(getmContext());
            dialogg.setTitle("Notificación Diseño");
            dialogg.setMessage(""+result);
            dialogg.setCancelable(false);
            dialogg.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dialogo1.dismiss();
                }
            });
            dialogg.show();

        }
    }

}

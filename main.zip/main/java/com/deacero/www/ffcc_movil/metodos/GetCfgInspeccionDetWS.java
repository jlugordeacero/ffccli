package com.deacero.www.ffcc_movil.metodos;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.util.Log;

import com.deacero.www.ffcc_movil.BDFFCCMovil;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.LinkedList;
import java.util.List;

import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class GetCfgInspeccionDetWS extends AsyncTask<String, String, String> {
    //BD
    BDFFCCMovil objBD;
    private Cursor c;
    //constantes
    private Context mContext;
    private String Token, DirIp, ClaUbicacion;

    private  String IdConfigInspeccion, IdConfigInspeccionDet, ClaUbicacion2, NomConfigInspeccionDet, RechazaCarro, PuedeReutilizar, Orden,EsTapa, BajaLogica,ClaTipoInspeccion;
    private Integer totalrows;

    ProgressDialog dialogo;

    public GetCfgInspeccionDetWS(Context MyContext, String MyToken, String MyDirIp, String MyClaUbicacion){
        this.mContext = MyContext;
        this.Token = MyToken;
        this.DirIp = MyDirIp;
        this.ClaUbicacion = MyClaUbicacion;
    }

    public String getClaUbicacion() {
        return ClaUbicacion;
    }

    public void setClaUbicacion(String claUbicacion) {
        ClaUbicacion = claUbicacion;
    }

    public Context getmContext() {
        return mContext;
    }

    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }

    public String getDirIp() {
        return DirIp;
    }

    public void setDirIp(String dirIp) {
        DirIp = dirIp;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        dialogo = new ProgressDialog(getmContext());
        dialogo.setMessage("Cargando información Cfg. Inspeccion...");
        dialogo.show();
    }

    @Override
    protected String doInBackground(String... strings) {
        objBD = new BDFFCCMovil(mContext.getApplicationContext()); //hace la conexión
        //HttpClient httpclient = new DefaultHttpClient();
        HttpClient httpclient;
        String version = Build.VERSION.RELEASE;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M){
            // versiones con android 6.0 o superior
            httpclient = new DefaultHttpClient();
        } else{
            boolean disableSsl=true;
            SSLConnectionSocketFactory sslSocketFactory;
            if (disableSsl) {
                SSLContext ctx;
                try {
                    X509TrustManager x509TrustManager = new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }
                    };
                    ctx = SSLContext.getInstance("TLS");
                    ctx.init(new KeyManager[0], new TrustManager[]{x509TrustManager}, new SecureRandom());
                } catch (NoSuchAlgorithmException | KeyManagementException e) {
                    throw new SecurityException(e);
                }
                sslSocketFactory = new SSLConnectionSocketFactory(
                        ctx,
                        SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER
                );
            } else {
                sslSocketFactory = SSLConnectionSocketFactory.getSocketFactory();
            }
            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", PlainConnectionSocketFactory.getSocketFactory())
                    .register("https", sslSocketFactory)
                    .build();

            httpclient = HttpClientBuilder.create()
                    .setConnectionManager(new PoolingHttpClientConnectionManager(registry))
                    .build();

        }
        //httpclient.getParams().setParameter("http.socket.timeout", new Integer(6000));
        httpclient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
        try  {
                    if(!DirIp.endsWith("?"))
                        DirIp += "?";
                    List<NameValuePair> paramsURL = new LinkedList<NameValuePair>();
                    paramsURL.add(new BasicNameValuePair("ClaUbicacion",getClaUbicacion()));
                    String paramString = URLEncodedUtils.format(paramsURL, "utf-8");
                    DirIp += paramString;
                   // Log.e("DIRIP.>",""+getDirIp());
                    HttpGet objGet = new HttpGet(getDirIp());
                    objGet.setHeader("content-type", "application/json");
                    objGet.addHeader("Authorization",getToken());///add token
                  //  Log.e("TokenVIA->",""+getToken());
                    HttpResponse res = httpclient.execute(objGet);
                    String respWS = EntityUtils.toString(res.getEntity(),"UTF-8");
                   // Log.e("respWS-VIA->",""+respWS);
                    JSONArray respJSON = new JSONArray(respWS);

                    //variables

                    for (int i = 0; i < respJSON.length(); i++) {
                        //Log.e("ENTRA FOR->", "--------------------");
                        JSONObject objJSON = respJSON.getJSONObject(i);
                        //registros obtenidos
                        IdConfigInspeccion = objJSON.getString("IdConfigInspeccion");
                        IdConfigInspeccionDet = objJSON.getString("IdConfigInspeccionDet");
                        ClaUbicacion = objJSON.getString("ClaUbicacion");
                        NomConfigInspeccionDet = objJSON.getString("NomConfigInspeccionDet");
                        RechazaCarro = objJSON.getString("RechazaCarro");
                        PuedeReutilizar = objJSON.getString("PuedeReutilizar");
                        Orden = objJSON.getString("Orden");
                        EsTapa = objJSON.getString("EsTapa");
                        BajaLogica = objJSON.getString("BajaLogica");

                        ClaTipoInspeccion = objJSON.getString("ClaTipoInspeccion");

                        c = objBD.getCatConfigInspeccionDet(ClaUbicacion,IdConfigInspeccionDet,IdConfigInspeccion);
                        totalrows = c.getCount();

                        if (totalrows > 0) {//update
                            //Log.e("UPD cfgInspec->","....");
                            //System.out.println("INSERT "+" IdConfigInspeccion "+IdConfigInspeccion+" IdConfigInspeccionDet "+IdConfigInspeccionDet+" ClaTipoInspeccion "+ClaTipoInspeccion);
                            objBD.UpdateCatConfigInspeccionDet(IdConfigInspeccionDet,IdConfigInspeccion,ClaUbicacion,NomConfigInspeccionDet,RechazaCarro,PuedeReutilizar,Orden,BajaLogica,ClaTipoInspeccion);
                        } else {//insert
                            //Log.e("INS cfgInspec->","....");
                            //System.out.println("INSERT "+" IdConfigInspeccion "+IdConfigInspeccion+" IdConfigInspeccionDet "+IdConfigInspeccionDet+" ClaTipoInspeccion "+ClaTipoInspeccion);
                            objBD.InsertCatConfigInspeccionDet(IdConfigInspeccionDet,IdConfigInspeccion,ClaUbicacion,NomConfigInspeccionDet,RechazaCarro,PuedeReutilizar,Orden,BajaLogica,ClaTipoInspeccion);
                        }
                        c.close();
                        objBD.CloseDB();
                    }

                    return "succcess";
                }catch(ClientProtocolException ex){
                    return ""+ex.toString();
                } catch (IOException e) {
                    //e.printStackTrace();
                    return ""+e.toString();
                } catch (JSONException e) {
                    //e.printStackTrace();
                    return ""+e.toString();
                }finally {
                    httpclient.getConnectionManager().shutdown();
                }
    }

    @Override
    protected void onPostExecute(String result){
        Log.e("RESULTADO CFGins",""+result);
        try {
            dialogo.dismiss();
        }catch (IllegalArgumentException ex){
            System.out.println("DIALOGO EXC cfgins: "+ ex.toString());
        }
        if(result.equals("succcess")){

        }else {
            AlertDialog.Builder dialogg = new AlertDialog.Builder(getmContext());
            dialogg.setTitle("Notificación Cfg Inspeccion");
            dialogg.setMessage(""+result);
            dialogg.setCancelable(false);
            dialogg.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dialogo1.dismiss();
                }
            });
           // dialogg.show();

        }
    }
}


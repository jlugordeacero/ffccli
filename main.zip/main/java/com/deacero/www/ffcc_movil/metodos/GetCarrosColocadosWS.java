package com.deacero.www.ffcc_movil.metodos;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.util.Log;

import com.deacero.www.ffcc_movil.BDFFCCMovil;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.LinkedList;
import java.util.List;

import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class GetCarrosColocadosWS extends AsyncTask<String, String, String> {
    //BD
    BDFFCCMovil objBD;
    Cursor c, c2;
    //constantes
    Context mContext;
    String Token, DirIp, ClaUbicacion, Fecha;

    private String IdTraCarroColocadoSqlServer,IdTraSolicitudServicio,ClaUbicacion2,EstatusColocacion,FechaConfirmaColocacion,HoraInicial,HoraFinal,ClaUsuarioColoco,NombrePcMod,ClaUsuarioMod,Detalle;
    private Integer totalrows;

    public GetCarrosColocadosWS(Context MyContext, String MyToken, String MyDirIp, String MyClaUbicacion, String MyFecha){
        this.mContext = MyContext;
        this.Token = MyToken;
        this.DirIp = MyDirIp;
        this.ClaUbicacion = MyClaUbicacion;
        this.Fecha = MyFecha;
    }

    public String getFecha() { return Fecha; }

    public void setFecha(String fecha) {     Fecha = fecha;   }

    public String getClaUbicacion() {
        return ClaUbicacion;
    }

    public void setClaUbicacion(String claUbicacion) {
        ClaUbicacion = claUbicacion;
    }

    public Context getmContext() {
        return mContext;
    }

    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }

    public String getDirIp() {
        return DirIp;
    }

    public void setDirIp(String dirIp) {
        DirIp = dirIp;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... strings) {
        objBD = new BDFFCCMovil(mContext.getApplicationContext()); //hace la conexión
        //HttpClient httpclient = new DefaultHttpClient();
        HttpClient httpclient;
        String version = Build.VERSION.RELEASE;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M){
            // versiones con android 6.0 o superior
            httpclient = new DefaultHttpClient();
        } else{
            boolean disableSsl=true;
            SSLConnectionSocketFactory sslSocketFactory;
            if (disableSsl) {
                SSLContext ctx;
                try {
                    X509TrustManager x509TrustManager = new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }
                    };
                    ctx = SSLContext.getInstance("TLS");
                    ctx.init(new KeyManager[0], new TrustManager[]{x509TrustManager}, new SecureRandom());
                } catch (NoSuchAlgorithmException | KeyManagementException e) {
                    throw new SecurityException(e);
                }
                sslSocketFactory = new SSLConnectionSocketFactory(
                        ctx,
                        SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER
                );
            } else {
                sslSocketFactory = SSLConnectionSocketFactory.getSocketFactory();
            }
            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", PlainConnectionSocketFactory.getSocketFactory())
                    .register("https", sslSocketFactory)
                    .build();

            httpclient = HttpClientBuilder.create()
                    .setConnectionManager(new PoolingHttpClientConnectionManager(registry))
                    .build();

        }
        //httpclient.getParams().setParameter("http.socket.timeout", new Integer(10000));
        httpclient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
        try  {
                    if(!DirIp.endsWith("?"))
                        DirIp += "?";
                    List<NameValuePair> paramsURL = new LinkedList<NameValuePair>();
                    paramsURL.add(new BasicNameValuePair("ClaUbicacion",getClaUbicacion()));
                    paramsURL.add(new BasicNameValuePair("fecha",getFecha()));
                    String paramString = URLEncodedUtils.format(paramsURL, "utf-8");
                    DirIp += paramString;
                    //Log.e("DIRIP.>",""+getDirIp());
                    HttpGet objGet = new HttpGet(getDirIp());
                    objGet.setHeader("content-type", "application/json");
                    objGet.addHeader("Authorization",getToken());///add token
                   // Log.e("Tokendimension->",""+getToken());
                    HttpResponse res = httpclient.execute(objGet);
                    String respWS = EntityUtils.toString(res.getEntity(),"UTF-8");
                    Log.e("respWS-getCOLOC->",""+respWS);
                    JSONArray respJSON = new JSONArray(respWS);
                    //variables


                    for (int i = 0; i < respJSON.length(); i++) {
                        JSONObject objJSON = respJSON.getJSONObject(i);
                        //registros obtenidos
                        IdTraCarroColocadoSqlServer = objJSON.getString("IdTraCarroColocado");
                        IdTraSolicitudServicio = objJSON.getString("IdTraSolicitudServicio");
                        ClaUbicacion = objJSON.getString("ClaUbicacion");
                        EstatusColocacion = objJSON.getString("EstatusColocacion");
                        FechaConfirmaColocacion = objJSON.getString("FechaConfirmaColocacion");
                        HoraInicial = objJSON.getString("HoraInicial");
                        HoraFinal = objJSON.getString("HoraFinal");
                        //ClaUsuarioColoco = objJSON.getString("ClaUsuarioColoco");
                        NombrePcMod = objJSON.getString("NombrePcMod");
                        ClaUsuarioMod = objJSON.getString("ClaUsuarioMod");

                        Detalle = objJSON.getString("Detalle");
                        System.out.println("ClaUbicacion "+ClaUbicacion+" IdTraSolicitudServicio " +IdTraSolicitudServicio);
                        c = objBD.getColocacionesAPI(ClaUbicacion,IdTraSolicitudServicio);
                        ////valida si existe el idtrasolicitud servicio si existe hace el proceso
                        System.out.println("SERVICIO  "+IdTraSolicitudServicio+ "  EXISTE "+objBD.ExisteServicioVentana(ClaUbicacion,IdTraSolicitudServicio));
                        if(objBD.ExisteServicioVentana(ClaUbicacion,IdTraSolicitudServicio)>0){
                            System.out.println("EXISTE IdTraSolicitudServicio **** "+IdTraSolicitudServicio);
                            if(("2").equals(EstatusColocacion)) {//se valida que sean colocaciones terminadas estas son la de estatus 2 // diseños terminados
                                if (c.getCount() > 0) {
                                    c.moveToFirst();
                                    Log.e(" IF2----------------", " " + EstatusColocacion);
                                    //esto lo comente porque si add placas nuevas y vuelves a sincronizar el servicio elimina las placas y deja solo las que
                                    //has agregado mediante el post del diseño
                                    /*JSONArray array = new JSONArray(Detalle);
                                   // String ClaCarroColocadoSQLite = objBD.getMax_FfccCarrosColocadosSQLite(IdTraCarroColocado);
                                    objBD.EliminaColocacionDetAPI(c.getString(0), ClaUbicacion);
                                    objBD.UpdateIDSqlServerColcacion(""+c.getString(0),ClaUbicacion,""+IdTraCarroColocadoSqlServer,"2");
                                    for (int x = 0; x < array.length(); x++) {
                                        JSONObject row = array.getJSONObject(x);
                                        System.out.println("ClaCarroColocado: " + c.getString(0) + " -- " + row.getString("IdTraCarroColocadoDet") + " -- " + row.getString("ClaUbicacion") + " -- "
                                                + row.getString("IdControlUnidad") + " -- " + row.getString("ClaCarro") + " -- " + row.getString("PlacaCarro") + " -- " + row.getString("EsTapa") + " -- " + row.getString("EsVacio") + " -- " + row.getString("NombrePcMod") + " -- " + row.getString("ClaUsuarioMod"));
                                        objBD.InsertColocacionDetAPI(c.getString(0), row.getString("IdTraCarroColocadoDet"), row.getString("ClaUbicacion"), row.getString("IdControlUnidad"), row.getString("ClaCarro"), row.getString("PlacaCarro"), row.getString("EsTapa"), row.getString("EsVacio"), row.getString("NombrePcMod"), row.getString("ClaUsuarioMod"));
                                    }
                                    objBD.ActualizaEstatusDisenoServicio2("1",""+IdTraSolicitudServicio, ""+ClaUbicacion);*/
                                } else {
                                    String ClaCarroColocadoSqlite = objBD.getMax_FfccCarrosColocados();
                                    objBD.InsertColocacionAPI(ClaCarroColocadoSqlite, IdTraSolicitudServicio, ClaUbicacion, NombrePcMod, "2", "null", "null", "null", IdTraCarroColocadoSqlServer, ClaUsuarioMod);
                                    Log.e(" ELSE2----------------"," "+EstatusColocacion);
                                    JSONArray array = new JSONArray(Detalle);
                                    //elimina detalle y add detalle  //obtener el ClaCarroColocado en base al ClaCarroColocadodel servidor
                                    String ClaCarroColocadoSQLite = objBD.getMax_FfccCarrosColocadosSQLite(IdTraCarroColocadoSqlServer);
                                    objBD.EliminaColocacionDetAPI(ClaCarroColocadoSQLite, ClaUbicacion);
                                    for (int x = 0; x < array.length(); x++) {
                                        JSONObject row = array.getJSONObject(x);
                                        //ClaCarroColocado del get es el del servidor
                                        System.out.println("detalle 2 ***********");
                                        //String ClaCarroColocadoDet = objBD.getMax_FfccCarrosColocadosDet();
                                        objBD.InsertColocacionDetAPI(ClaCarroColocadoSqlite, row.getString("IdTraCarroColocadoDet"), row.getString("ClaUbicacion"), row.getString("IdControlUnidad"), row.getString("ClaCarro"), row.getString("PlacaCarro"), row.getString("EsTapa"), row.getString("EsVacio"), row.getString("NombrePcMod"), row.getString("ClaUsuarioMod"));
                                    }
                                    objBD.ActualizaEstatusDisenoServicio2("1",""+IdTraSolicitudServicio, ""+ClaUbicacion);
                                }
                            }



                            if(("3").equals(EstatusColocacion)) {//se valida que sean colocaciones terminadas estas son la de estatus 3
                                if (c.getCount() > 0) {////actualiza colocacion
                                    c.moveToFirst();
                                    Log.e(" IF-----------------", " " + EstatusColocacion);
                                    //si ya existe este retiro no se hace nada por las placas que se pudieran agregar desde la tablet
                                    //o seria acomodar que las placas que se agregaron se eliminen de tracontrolunidad de la tablet para poderlas agregar de nuevo

                                   /* JSONArray array = new JSONArray(Detalle);
                                    // String ClaCarroColocadoSQLite = objBD.getMax_FfccCarrosColocadosSQLite(IdTraCarroColocado);
                                    objBD.EliminaColocacionDetAPI(c.getString(0), ClaUbicacion);
                                    objBD.UpdateIDSqlServerColcacion(""+c.getString(0),ClaUbicacion,""+IdTraCarroColocadoSqlServer,"4");//seteo a  4 el estatus para que ya no se envie
                                    for (int x = 0; x < array.length(); x++) {
                                        JSONObject row = array.getJSONObject(x);
                                        System.out.println("ClaCarroColocado: " + c.getString(0) + " -- " + row.getString("IdTraCarroColocadoDet") + " -- " + row.getString("ClaUbicacion") + " -- "
                                                + row.getString("IdControlUnidad") + " -- " + row.getString("ClaCarro") + " -- " + row.getString("PlacaCarro") + " -- " + row.getString("EsTapa") + " -- " + row.getString("EsVacio") + " -- " + row.getString("NombrePcMod") + " -- " + row.getString("ClaUsuarioMod"));
                                        objBD.InsertColocacionDetAPI(c.getString(0), row.getString("IdTraCarroColocadoDet"), row.getString("ClaUbicacion"), row.getString("IdControlUnidad"), row.getString("ClaCarro"), row.getString("PlacaCarro"), row.getString("EsTapa"), row.getString("EsVacio"), row.getString("NombrePcMod"), row.getString("ClaUsuarioMod"));
                                    }
                                    objBD.ActualizaEstatusDisenoServicio2("1",""+IdTraSolicitudServicio, ""+ClaUbicacion);


                                    //generar el retiroclienteinterno
                                   // String IdRetiroClienteInterno = objBD.getMax_FFCCTraRetiroClienteInterno();//retorna el ultimo IDRet de la tabla +1

                                    //objBD.INSERT_FfccRetiroCliente(""+IdRetiroClienteInterno,""+ClaUbicacion,""+c.getString(0),""+c.getString(10),""+c.getString(11),""+c.getString(5));

                                    String ClaCarroColocadoSQLite = objBD.getMax_FfccCarrosColocadosSQLite(IdTraCarroColocadoSqlServer);
                                    objBD.CopiarColocacionTOClienteInterno2(""+ClaCarroColocadoSQLite,""+ClaUbicacion,""+IdTraCarroColocadoSqlServer);

                                        */
                                } else { ///inserta colocacion
                                    String ClaCarroColocadoSqlite = objBD.getMax_FfccCarrosColocados();
                                    objBD.InsertColocacionAPI(ClaCarroColocadoSqlite, IdTraSolicitudServicio, ClaUbicacion, NombrePcMod, "4", FechaConfirmaColocacion, HoraInicial, HoraFinal, IdTraCarroColocadoSqlServer, ClaUsuarioMod);
                                    Log.e(" ELSE-----------------"," "+EstatusColocacion);
                                    JSONArray array = new JSONArray(Detalle);
                                    //elimina detalle y add detalle  //obtener el ClaCarroColocado en base al ClaCarroColocadodel servidor
                                    String ClaCarroColocadoSQLite = objBD.getMax_FfccCarrosColocadosSQLite(IdTraCarroColocadoSqlServer);
                                    objBD.EliminaColocacionDetAPI(ClaCarroColocadoSQLite, ClaUbicacion);
                                    for (int x = 0; x < array.length(); x++) {
                                        JSONObject row = array.getJSONObject(x);
                                        //ClaCarroColocado del get es el del servidor
                                        System.out.println("detalle 2 ***********");
                                        String ClaCarroColocadoDet = objBD.getMax_FfccCarrosColocadosDet();
                                        objBD.InsertColocacionDetAPI(ClaCarroColocadoSqlite, row.getString("IdTraCarroColocadoDet"), row.getString("ClaUbicacion"), row.getString("IdControlUnidad"), row.getString("ClaCarro"), row.getString("PlacaCarro"), row.getString("EsTapa"), row.getString("EsVacio"), row.getString("NombrePcMod"), row.getString("ClaUsuarioMod"));
                                    }
                                    objBD.ActualizaEstatusDisenoServicio2("1",""+IdTraSolicitudServicio, ""+ClaUbicacion);


                                    //generar el retiro cliente interno

                                    objBD.CopiarColocacionTOClienteInterno2(""+ClaCarroColocadoSqlite,""+ClaUbicacion,""+IdTraCarroColocadoSqlServer);

                                }
                            }


                        }
                        c.close();
                        objBD.CloseDB();

                    }
                    return "succcess";
                }catch(ClientProtocolException ex){
                    return ""+ex.toString();
                } catch (IOException e) {
                    return ""+e.toString();
                } catch (JSONException e) {
                    return ""+e.toString();
                }finally {
                    httpclient.getConnectionManager().shutdown();
                }
    }

    @Override
    protected void onPostExecute(String result){
        Log.e("RESULTADO GET ColRet ",""+result);
        if(result.equals("succcess")){

        }else {
            AlertDialog.Builder dialogg = new AlertDialog.Builder(getmContext());
            dialogg.setTitle("Notificación Get Colocados");
            dialogg.setMessage(""+result);
            dialogg.setCancelable(false);
            dialogg.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dialogo1.dismiss();
                }
            });
           // dialogg.show();

        }
    }
}


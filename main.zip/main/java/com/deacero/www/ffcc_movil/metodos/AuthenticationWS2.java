package com.deacero.www.ffcc_movil.metodos;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.util.Base64;
import android.util.Log;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.MenuActivity;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.security.KeyManagementException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class AuthenticationWS2 extends AsyncTask<String, String, String> {
    //BD
    BDFFCCMovil objBD;
    private Cursor c;
    //variables
    private Context mContext;
    private String DirIP, Usuario, Password, MAC, ClaUbicacion;
    private String version, keyToken, TokensinComillas;

    public static final String LLAVE_ENCRIPTAR = "deacero";
    private HttpClient httpclient;
    private HttpPost httppost;
    private List<NameValuePair> paramss;
    private HttpResponse resp;
    private HttpEntity ent;
    private String[] TokenPos;
    private JSONObject arr;
    private int StatusCode=0;

    public AuthenticationWS2(Context MyContext, String Ip, String usu, String pass, String MyMAC, String MyClaUbicacion){
        this.mContext = MyContext;
        this.DirIP = Ip;
        this.Usuario = usu;
        this.Password = pass;
        this.MAC = MyMAC;
        this.ClaUbicacion = MyClaUbicacion;
    }

    public String getMAC() {
        return MAC;
    }
    public void setMAC(String MAC) {
        this.MAC = MAC;
    }
    public String getClaUbicacion() {
        return ClaUbicacion;
    }
    public void setClaUbicacion(String claUbicacion) {
        ClaUbicacion = claUbicacion;
    }
    public Context getmContext() {
        return mContext;
    }
    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }
    public String getDirIP() {
        return DirIP;
    }
    public void setDirIP(String dirIP) {
        DirIP = dirIP;
    }
    public String getUsuario() {
        return Usuario;
    }
    public void setUsuario(String usuario) {
        Usuario = usuario;
    }
    public String getPassword() {
        return Password;
    }
    public void setPassword(String password) {
        Password = password;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    public String encriptar(String texto) {
        String secretKey = LLAVE_ENCRIPTAR; //llave para encriptar datos
        String base64EncryptedString = "";
        try {
            MessageDigest md = MessageDigest.getInstance("SHA256");
            byte[] digestOfPassword = md.digest(secretKey.getBytes("utf-8"));
            byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);
            SecretKey key = new SecretKeySpec(keyBytes, "DESede");
            Cipher cipher = Cipher.getInstance("DESede");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] plainTextBytes = texto.getBytes("utf-8");
            byte[] buf = cipher.doFinal(plainTextBytes);
            byte[] base64Bytes = Base64.encode(buf, Base64.DEFAULT);
            base64EncryptedString = new String(base64Bytes);

        } catch (Exception ex) {
        }
        return base64EncryptedString;
    }

    public String desencriptar(String textoEncriptado) {
        String secretKey = LLAVE_ENCRIPTAR; //llave para desenciptar datos
        String base64EncryptedString = "";
        try {
            byte[] message = Base64.decode(textoEncriptado.getBytes("utf-8"), Base64.DEFAULT);
            MessageDigest md = MessageDigest.getInstance("SHA256");
            byte[] digestOfPassword = md.digest(secretKey.getBytes("utf-8"));
            byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);
            SecretKey key = new SecretKeySpec(keyBytes, "DESede");
            Cipher decipher = Cipher.getInstance("DESede");
            decipher.init(Cipher.DECRYPT_MODE, key);
            byte[] plainText = decipher.doFinal(message);
            base64EncryptedString = new String(plainText, "UTF-8");
        } catch (Exception ex) {
            Log.e("ex: ", "" + ex.toString());
        }
        return base64EncryptedString;
    }

    @Override
    protected String doInBackground(String... params) {
         version = Build.VERSION.RELEASE;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M){// versiones con android 6.0 o superior
            httpclient = new DefaultHttpClient();
        } else{
            boolean disableSsl=true;
            SSLConnectionSocketFactory sslSocketFactory;
            if (disableSsl) {
                SSLContext ctx;
                try {
                    X509TrustManager x509TrustManager = new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }
                    };
                    ctx = SSLContext.getInstance("TLS");
                    ctx.init(new KeyManager[0], new TrustManager[]{x509TrustManager}, new SecureRandom());
                } catch (NoSuchAlgorithmException | KeyManagementException e) {
                    throw new SecurityException(e);
                }
                sslSocketFactory = new SSLConnectionSocketFactory(
                        ctx,
                        SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER
                );
            } else {
                sslSocketFactory = SSLConnectionSocketFactory.getSocketFactory();
            }
            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", PlainConnectionSocketFactory.getSocketFactory())
                    .register("https", sslSocketFactory)
                    .build();
            httpclient = HttpClientBuilder.create()
                    .setConnectionManager(new PoolingHttpClientConnectionManager(registry))
                    .build();
        }

       // httpclient.getParams().setParameter("http.socket.timeout", new Integer(50000));
        httpclient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
        try{
            httppost = new HttpPost(getDirIP());
            paramss = new ArrayList<NameValuePair>();
            paramss.add(new BasicNameValuePair("User", getUsuario()));
            paramss.add(new BasicNameValuePair("Password", desencriptar(Password)));
            paramss.add(new BasicNameValuePair("DireccionMac", getMAC()));
            httppost.setEntity(new UrlEncodedFormEntity(paramss));
            resp = httpclient.execute(httppost);
            StatusCode = resp.getStatusLine().getStatusCode();

            ent = resp.getEntity();//obtenemos respuesta
            keyToken = EntityUtils.toString(ent,"UTF-8");
            //System.out.println("KEYTOKEN : "+keyToken.toString());
            arr = new JSONObject(keyToken);
            if(StatusCode == HttpsURLConnection.HTTP_OK){
                objBD = new BDFFCCMovil(mContext.getApplicationContext()); //hace la conexión
                System.out.println("NUEVO TOKEN ***************************** " +arr.get("Key").toString());
                objBD.updateUserMovilToken(""+Usuario, ""+arr.get("Key").toString(),""+arr.get("ClaUbicacion").toString());
                objBD.CloseDB();
                return "succcess";//---retornando este msg se manda al menu
            }else {
                return "No se pudo actualizar token. \n" +
                        arr.get("Message").toString();
           }
        }catch (SQLiteException e){
            return "-Mensaje: "+keyToken+"\nExcepción: "+e.toString()+"\nStatusCode: "+String.valueOf(StatusCode);
        }catch (JSONException e){
            return "--Mensaje: "+keyToken+"\nExcepción: "+e.toString()+"\nStatusCode: "+String.valueOf(StatusCode);
        }catch(Exception e) {
            return "--Mensaje: " + keyToken + " \n Excepcion" +e.toString()+"\nStatusCode: "+String.valueOf(StatusCode);
        }finally {
            httpclient.getConnectionManager().shutdown();
        }
    }

    @Override
    protected void onPostExecute(String result) {
        if(result.equals("succcess")){
        }else {
            AlertDialog.Builder dialogg = new AlertDialog.Builder(getmContext());
            dialogg.setTitle("Notificación");
            dialogg.setMessage(""+result);
            dialogg.setCancelable(false);
            dialogg.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dialogo1.dismiss();
                }
            });
        }
    }

}

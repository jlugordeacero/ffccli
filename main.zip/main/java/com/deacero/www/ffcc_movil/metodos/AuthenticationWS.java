package com.deacero.www.ffcc_movil.metodos;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.util.Base64;
import android.widget.Button;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.MenuActivity;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.security.KeyManagementException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class AuthenticationWS extends AsyncTask<String, String, String> {
    //BD
    BDFFCCMovil objBD;
    Cursor c;
    //variables
    private Context mContext;
    private String DirIP, Usuario, Password, MAC, ClaUbicacion, DirIpGet;
    ProgressDialog dialogo;
    private Integer totalrows;
    public static final String LLAVE_ENCRIPTAR = "deacero";
    private HttpClient httpclient;
    private HttpPost httppost;
    private HttpResponse resp, res;
    private HttpEntity ent;
    private HttpGet objGet;
    private String version, keyToken,  url, paramString, respWS;
    private List<NameValuePair> paramss,paramsURL;
    private String[] TokenPos;
    private JSONArray respJSON;
    private JSONObject objJSON, arr;
    private AlertDialog.Builder dialogg;
    Button mUserSignInButton;
    private int StatusCode=0;
    public AuthenticationWS(Context MyContext, String Ip, String usu, String pass, String MyMAC, String MyClaUbicacion, String dirIpGet,Button mUserSignInButton ){
        this.mContext = MyContext;
        this.DirIP = Ip;
        this.Usuario = usu;
        this.Password = pass;
        this.MAC = MyMAC;
        this.ClaUbicacion = MyClaUbicacion;
        this.DirIpGet = dirIpGet;
        this.mUserSignInButton = mUserSignInButton;
    }

    public String getDirIpGet() {
        return DirIpGet;
    }
    public void setDirIpGet(String dirIpGet) {
        this.DirIpGet = dirIpGet;
    }
    public String getMAC() {
        return MAC;
    }
    public void setMAC(String MAC) {
        this.MAC = MAC;
    }
    public String getClaUbicacion() {
        return ClaUbicacion;
    }
    public void setClaUbicacion(String claUbicacion) {
        ClaUbicacion = claUbicacion;
    }
    public Context getmContext() {
        return mContext;
    }
    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }
    public String getDirIP() {
        return DirIP;
    }
    public void setDirIP(String dirIP) {
        DirIP = dirIP;
    }
    public String getUsuario() {
        return Usuario;
    }
    public void setUsuario(String usuario) {
        Usuario = usuario;
    }
    public String getPassword() {
        return Password;
    }
    public void setPassword(String password) {
        Password = password;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        dialogo = new ProgressDialog(getmContext());
        dialogo.setMessage("Validando información...");
        dialogo.show();
        dialogo.setCanceledOnTouchOutside(false);
        dialogo.setCancelable(false);
    }

    public String encriptar(String texto) {
        String secretKey = LLAVE_ENCRIPTAR; //llave para encriptar datos
        String base64EncryptedString = "";
        try {
            MessageDigest md = MessageDigest.getInstance("SHA256");
            byte[] digestOfPassword = md.digest(secretKey.getBytes("utf-8"));
            byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);
            SecretKey key = new SecretKeySpec(keyBytes, "DESede");
            Cipher cipher = Cipher.getInstance("DESede");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] plainTextBytes = texto.getBytes("utf-8");
            byte[] buf = cipher.doFinal(plainTextBytes);
            byte[] base64Bytes = Base64.encode(buf, Base64.DEFAULT);
            base64EncryptedString = new String(base64Bytes);
        } catch (Exception ex) {
        }
        return base64EncryptedString;
    }

    public String desencriptar(String textoEncriptado) {
        String secretKey = LLAVE_ENCRIPTAR; //llave para desenciptar datos
        String base64EncryptedString = "";
        try {
            byte[] message = Base64.decode(textoEncriptado.getBytes("utf-8"), Base64.DEFAULT);
            MessageDigest md = MessageDigest.getInstance("SHA256");
            byte[] digestOfPassword = md.digest(secretKey.getBytes("utf-8"));
            byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);
            SecretKey key = new SecretKeySpec(keyBytes, "DESede");
            Cipher decipher = Cipher.getInstance("DESede");
            decipher.init(Cipher.DECRYPT_MODE, key);
            byte[] plainText = decipher.doFinal(message);
            base64EncryptedString = new String(plainText, "UTF-8");
        } catch (Exception ex) {
        }
        return base64EncryptedString;
    }

    @Override
    protected String doInBackground(String... params) {
        version = Build.VERSION.RELEASE;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M){ // versiones con android 6.0 o superior
            httpclient = new DefaultHttpClient();
        } else{
            boolean disableSsl=true;
            SSLConnectionSocketFactory sslSocketFactory;
            if (disableSsl) {
                SSLContext ctx;
                try {
                    X509TrustManager x509TrustManager = new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }
                    };
                    ctx = SSLContext.getInstance("TLS");
                    ctx.init(new KeyManager[0], new TrustManager[]{x509TrustManager}, new SecureRandom());
                } catch (NoSuchAlgorithmException | KeyManagementException e) {
                    throw new SecurityException(e);
                }
                sslSocketFactory = new SSLConnectionSocketFactory( ctx, SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER );
            } else {
                sslSocketFactory = SSLConnectionSocketFactory.getSocketFactory();
            }
            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", PlainConnectionSocketFactory.getSocketFactory())
                    .register("https", sslSocketFactory)
                    .build();
            httpclient = HttpClientBuilder.create()
                    .setConnectionManager(new PoolingHttpClientConnectionManager(registry))
                    .build();
        }
        //httpclient.getParams().setParameter("http.socket.timeout", new Integer(50000));
        httpclient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
        try{
            httppost = new HttpPost(getDirIP());
            paramss = new ArrayList<NameValuePair>();
            paramss.add(new BasicNameValuePair("User", getUsuario()));
            paramss.add(new BasicNameValuePair("Password", getPassword()));
            paramss.add(new BasicNameValuePair("DireccionMac", getMAC()));
            System.out.println("getUsuario(): "+getUsuario()+ " getPassword(): "+" getMAC(): "+getMAC());
            httppost.setEntity(new UrlEncodedFormEntity(paramss));

            resp = httpclient.execute(httppost);
            StatusCode = resp.getStatusLine().getStatusCode();

                ent = resp.getEntity();//obtenemos respuesta

                keyToken = EntityUtils.toString(ent,"UTF-8");
                //System.out.println("KEYTOKEN : "+keyToken.toString());
                arr = new JSONObject(keyToken);
                if(StatusCode == HttpsURLConnection.HTTP_OK){
                    try  {
                        objBD = new BDFFCCMovil(mContext.getApplicationContext()); //hace la conexión
                        url = getDirIpGet();
                        if(!url.endsWith("?")) {
                            url += "?";
                        }
                        paramsURL = new LinkedList<NameValuePair>();
                        paramsURL.add(new BasicNameValuePair("ClaUbicacion", arr.get("ClaUbicacion").toString()));
                        paramString = URLEncodedUtils.format(paramsURL, "utf-8");
                        url += paramString;
                        objGet = new HttpGet(url);
                        objGet.setHeader("content-type", "application/json");
                        objGet.addHeader("Authorization",arr.get("Key").toString());///add token
                        setClaUbicacion(arr.get("ClaUbicacion").toString());
                        res = httpclient.execute(objGet);
                        respWS = EntityUtils.toString(res.getEntity(),"UTF-8");
                        respJSON = new JSONArray(respWS);
                        for (int i = 0; i < respJSON.length(); i++) {
                            objJSON = respJSON.getJSONObject(i);
                            c = objBD.getUserXLoginUser(objJSON.getString("loginUserName"));
                            totalrows = c.getCount();
                            if (totalrows > 0) {
                                objBD.updateUserMovil(objJSON.getString("ClaEmpleado"), objJSON.getString("NombreUsuario"), encriptar(objJSON.getString("Contraseña")), objJSON.getString("Email"), objJSON.getString("loginUserName"), arr.get("Key").toString());
                            } else {
                                objBD.insertUserMovil(objJSON.getString("ClaUbicacion"), objJSON.getString("idUsuario"), objJSON.getString("ClaEmpleado"), objJSON.getString("NombreUsuario"), encriptar(objJSON.getString("Contraseña")), objJSON.getString("Email"), objJSON.getString("loginUserName"), objJSON.getString("BajaLogica"), arr.get("Key").toString());
                            }
                            c.close();
                            objBD.CloseDB();
                        }
                        return "succcess";//---retornando este msg se manda al menu
                    }catch (JSONException e){
                        return "-Mensaje: "+respWS+"\nExcepción: "+e.toString()+"\nStatusCode: "+String.valueOf(StatusCode);
                    }catch (SQLiteException e){
                        return "-Mensaje: "+respWS+"\nExcepción: "+e.toString()+"\nStatusCode: "+String.valueOf(StatusCode);
                    }catch(ClientProtocolException e){
                        return "-Mensaje: "+respWS+"\nExcepción: "+e.toString()+"\nStatusCode: "+String.valueOf(StatusCode);
                    }finally {
                        httpclient.getConnectionManager().shutdown();
                    }
                }else {
                    return "No fue posible iniciar sesión. \n" +
                            arr.get("Message").toString();
               }
           /* }else{
                return "Mensaje: "+respWS+"\nStatusCode: "+String.valueOf(StatusCode);
            }*/
        } catch (JSONException e){
            return "1-Mensaje: "+resp+"\nExcepción: "+e.toString()+"\nStatusCode: "+String.valueOf(StatusCode);
        } catch(Exception e) {
            return "2-Mensaje: "+resp+"\nExcepción: "+e.toString()+"\nStatusCode: "+String.valueOf(StatusCode);
        } finally {
            httpclient.getConnectionManager().shutdown();
        }
    }

    @Override
    protected void onPostExecute(String result) {
        if(result.equals("succcess")){
            mUserSignInButton.setEnabled(false);
            c = objBD.getUserXLoginUser(getUsuario());
            c.moveToFirst();
            Intent intmenu = new Intent(getmContext().getApplicationContext(), MenuActivity.class);
            if(c.getCount()>0) {
                intmenu.putExtra("idUsuario", c.getString(1));//SERIA ClaUsuarioMod
                intmenu.putExtra("ClaEmpleado", c.getString(2));///NombreUsuario
                intmenu.putExtra("NombreUsuario", c.getString(3));///NombreUsuario
                intmenu.putExtra("loginUserName", getUsuario());//usuario ingresado desde pantalla
                //intmenu.putExtra("Contrasena", getPassword());//password ingresado desde pantalla
                intmenu.putExtra("ClaUbicacion", getClaUbicacion());//Ubicacion de la tableta
                intmenu.putExtra("DireccionMAC", getMAC());//MAC
            }
            c.close();
            objBD.close();
            mContext.startActivity(intmenu);
            try {
                dialogo.dismiss();
            }catch (IllegalArgumentException ex) {
                System.out.println("DIALOGO EXC login: " + ex.toString());
            }
        }else {
            try {
                dialogo.dismiss();
            }catch (IllegalArgumentException ex){
                System.out.println("DIALOGO EXC login: "+ ex.toString());
            }
            dialogg = new AlertDialog.Builder(getmContext());
            dialogg.setTitle("Notificación Login");
            dialogg.setMessage(""+result);
            dialogg.setCancelable(false);
            dialogg.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dialogo1.dismiss();
                }
            });
            dialogg.show();
        }
    }
}
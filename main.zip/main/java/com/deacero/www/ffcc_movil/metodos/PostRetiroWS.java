package com.deacero.www.ffcc_movil.metodos;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.util.Log;

import com.deacero.www.ffcc_movil.BDFFCCMovil;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.LinkedList;
import java.util.List;

import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class PostRetiroWS extends AsyncTask<String, String, String> {
    //BD
    BDFFCCMovil objBD;
    Cursor c2,c3;
    //constantes
    Context mContext;
    String Token, DirIp, ClaUbicacion, ClaUsuario, MAC;
    ProgressDialog dialogo;
    private HttpClient httpclient;
    private String version, paramString, respuesta, valor;
    private List<NameValuePair> paramsURL;
    private HttpPost httppost;
    private int y,x;
    private JSONArray FinalArray, detalleArray, arrayResp;
    private JSONObject jsonObject, detailObject;
    private StringEntity se;
    private HttpResponse response;
    private HttpEntity ent;
    private String[] separated;

    public PostRetiroWS(Context MyContext, String MyToken, String MyDirIp, String MyClaUbicacion, String MyClaUsuario, String MyMAC) {
        this.mContext = MyContext;
        this.Token = MyToken;
        this.DirIp = MyDirIp;
        this.ClaUbicacion = MyClaUbicacion;
        this.ClaUsuario = MyClaUsuario;
        this.MAC = MyMAC;
    }

    public  String getMAC(){ return  MAC;}
    public void setMAC(String mac){ MAC = mac;}
    public  String getClaUsuario(){ return  ClaUsuario;}
    public void setClaUsuario(String claUsuario){ ClaUsuario = claUsuario;}
    public String getClaUbicacion() {
        return ClaUbicacion;
    }
    public void setClaUbicacion(String claUbicacion) {
        ClaUbicacion = claUbicacion;
    }
    public Context getmContext() {
        return mContext;
    }
    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }
    public String getToken() {
        return Token;
    }
    public void setToken(String token) {
        Token = token;
    }
    public String getDirIp() {
        return DirIp;
    }
    public void setDirIp(String dirIp) {
        DirIp = dirIp;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        dialogo = new ProgressDialog(getmContext());
        dialogo.setMessage("Enviando información Retiros...");
        dialogo.show();
        dialogo.setCanceledOnTouchOutside(false);
        dialogo.setCancelable(false);
    }

    @Override
    protected String doInBackground(String... Strings) {
        objBD = new BDFFCCMovil(mContext.getApplicationContext()); //hace la conexión
        version = Build.VERSION.RELEASE;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M){ // versiones con android 6.0 o superior
            httpclient = new DefaultHttpClient();
        } else{
            boolean disableSsl=true;
            SSLConnectionSocketFactory sslSocketFactory;
            if (disableSsl) {
                SSLContext ctx;
                try {
                    X509TrustManager x509TrustManager = new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }
                    };
                    ctx = SSLContext.getInstance("TLS");
                    ctx.init(new KeyManager[0], new TrustManager[]{x509TrustManager}, new SecureRandom());
                } catch (NoSuchAlgorithmException | KeyManagementException e) {
                    throw new SecurityException(e);
                }
                sslSocketFactory = new SSLConnectionSocketFactory(
                        ctx,
                        SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER
                );
            } else {
                sslSocketFactory = SSLConnectionSocketFactory.getSocketFactory();
            }
            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", PlainConnectionSocketFactory.getSocketFactory())
                    .register("https", sslSocketFactory)
                    .build();
            httpclient = HttpClientBuilder.create()
                    .setConnectionManager(new PoolingHttpClientConnectionManager(registry))
                    .build();
        }
        //httpclient.getParams().setParameter("http.socket.timeout", new Integer(20000));
        httpclient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
        try {
            if (!DirIp.endsWith("?")) {
                DirIp += "?";
            }
            paramsURL = new LinkedList<NameValuePair>();
            paramsURL.add(new BasicNameValuePair("ClaUbicacion", getClaUbicacion()));
            paramString = URLEncodedUtils.format(paramsURL, "utf-8");
            DirIp += paramString;
            httppost = new HttpPost(getDirIp());
            c2 = objBD.getRetirosAPI("1");///a 1 porque se enviaran todos los retiros que hayan terminado
            c2.moveToFirst();
            if(c2.getCount()>0){
            FinalArray = new JSONArray();
            for (y = 0; y < c2.getCount(); y++) {
                jsonObject = new JSONObject();
                detalleArray = new JSONArray();
                jsonObject.put("IdRetiroClienteInterno", c2.getString(0));
                jsonObject.put("ClaUbicacion", c2.getString(1));
                jsonObject.put("IdTraCarroColocado", c2.getString(6));//este ya seria el del servidor
                jsonObject.put("FechaRetiro", c2.getString(5).replace("T", " "));
                jsonObject.put("NombrePcMod", c2.getString(8));
                jsonObject.put("ClaUsuarioMod", c2.getString(7));
                c3 = objBD.getRetirosDetAPI(c2.getString(0), c2.getString(1));
                c3.moveToFirst();
                for (x = 0; x < c3.getCount(); x++) {
                    detailObject = new JSONObject();
                    detailObject.put("ClaUbicacion", c3.getString(1));
                    detailObject.put("IdRetiroClienteInternoDet", c3.getString(0));
                    detailObject.put("IdRetiroClienteInterno", c3.getString(2));
                    detailObject.put("ClaUbicacionRetiroClienteInterno", c3.getString(1));
                    detailObject.put("ClaCarro", c3.getString(5));
                    detailObject.put("PlacaCarro", c3.getString(6));
                    detailObject.put("EsTapa", c3.getString(3));
                    detailObject.put("EsVacio", c3.getString(4));
                    detailObject.put("FechaUltimaMod", c3.getString(7).replace("T", " "));
                    detailObject.put("NombrePcMod", getMAC());
                    detailObject.put("ClaUsuarioMod", c2.getString(7));
                    detalleArray.put(detailObject);
                    c3.moveToNext();
                }
                jsonObject.put("Detalle", detalleArray);
                c3.close();
                objBD.close();
                FinalArray.put(jsonObject);
                c2.moveToNext();
            }
            c2.close();
            objBD.close();
            se = new StringEntity(FinalArray.toString(),"UTF-8");
            se.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
            httppost.addHeader("Authorization", getToken());///add token
            httppost.setEntity(se);
            response = httpclient.execute(httppost);
            ent = response.getEntity();//obtenemos respuesta
            respuesta = EntityUtils.toString(ent);
            arrayResp = new JSONArray(respuesta);///falta act los id de las colocaciones
            if (response != null) {
                for (int n = 0; n < arrayResp.length(); n++) {
                    valor = arrayResp.getString(n);
                    valor = valor.replace(";", ":");
                    separated = valor.split(":");
                    if ("SUCCES".equals(separated[0])) {
                        objBD.updateEstatusRetiro("" + separated[1], getClaUbicacion(), "2",""+ separated[2]);//se setea a 2 porque ha sido guardado y no se enviara
                    }
                }
            }
        }
            return "succcess";
        } catch (ClientProtocolException e) {
            return "Mensaje: "+respuesta+"\n Excepción: " + e.toString();
        } catch (IOException e) {
            return "Mensaje: "+respuesta+"\n Excepción: " + e.toString();
        } catch (JSONException e) {
            return "Mensaje: "+respuesta+"\n Excepción: " + e.toString();
        } catch (Exception e) {
            return "Mensaje: "+respuesta+"\n Excepción: " + e.toString();
        } finally {
            httpclient.getConnectionManager().shutdown();
        }
    }

    @Override
    protected void onPostExecute(String result) {
        try {
            dialogo.dismiss();
        }catch (IllegalArgumentException ex){
            System.out.println("DIALOGO EXC ret: "+ ex.toString());
        }
        if(result.equals("succcess")){

        }else {
            AlertDialog.Builder dialogg = new AlertDialog.Builder(getmContext());
            dialogg.setTitle("Notificación Retiro");
            dialogg.setMessage(""+result);
            dialogg.setCancelable(false);
            dialogg.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dialogo1.dismiss();
                }
            });
            dialogg.show();
        }
    }

}
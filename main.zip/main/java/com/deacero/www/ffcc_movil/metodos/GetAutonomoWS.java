package com.deacero.www.ffcc_movil.metodos;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.widget.ImageButton;

import com.deacero.www.ffcc_movil.BDFFCCMovil;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.LinkedList;
import java.util.List;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class GetAutonomoWS extends AsyncTask<String, String, String> {
    //BD
    BDFFCCMovil objBD;
    private Cursor c;
    //constantes
    private Context mContext;
    private String Token, DirIp, ClaUbicacion, fechaOT, claTurno, claEquipo, DirIPUpdOtTablet, respuestaPost, valorReal = "";
    private ProgressDialog dialogo;
    private HttpClient httpclient, httpclientPOST;
    private String version, paramString, respWS, paramStringPost;
    private List<NameValuePair> paramsURL, paramsURLPost;
    private HttpGet objGet;
    private HttpPost httppost;
    private HttpResponse res,  responsePOST;
    private JSONArray respJSON, ArrayPOST, arrayRespCliente, arrayResp;
    private JSONObject objJSON, jsonObjectPOST;
    AlertDialog.Builder dialogg;
    private StringEntity se;
    private HttpEntity ent;
    ImageButton ibBuscar;
    String valor;
    String[] separated;

    public GetAutonomoWS(Context MyContext, String MyToken, String MyDirIp, String MyClaUbicacion, String FechaOT, String ClaTurno, String ClaEquipo, String IPUpdOtTablet,ImageButton btnBuscar){
        this.mContext = MyContext;
        this.Token = MyToken;
        this.DirIp = MyDirIp;
        this.ClaUbicacion = MyClaUbicacion;
        this.fechaOT = FechaOT;
        this.claTurno = ClaTurno;
        this.claEquipo = ClaEquipo;
        this.DirIPUpdOtTablet = IPUpdOtTablet;
        ibBuscar = btnBuscar;
    }

    public String getclaEquipo() {
        return claEquipo;
    }
    public void setclaEquipo(String claEquipo) {
        this.claEquipo = claEquipo;
    }
    public String getclaTurno() {
        return claTurno;
    }
    public void setclaTurno(String claTurno) {
        this.claTurno = claTurno;
    }
    public String getfechaOT() {
        return fechaOT;
    }
    public void setfechaOT(String fechaOT) {
        this.fechaOT = fechaOT;
    }
    public String getClaUbicacion() {
        return ClaUbicacion;
    }
    public void setClaUbicacion(String claUbicacion) {
        ClaUbicacion = claUbicacion;
    }
    public Context getmContext() {
        return mContext;
    }
    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }
    public String getToken() {
        return Token;
    }
    public void setToken(String token) {
        Token = token;
    }
    public String getDirIp() {
        return DirIp;
    }
    public void setDirIp(String dirIp) {
        DirIp = dirIp;
    }
    public String getDirIPUpdOtTablet() {
        return DirIPUpdOtTablet;
    }
    public void setDirIPUpdOtTablet(String dirIPUpdOtTablet) {
        DirIPUpdOtTablet = dirIPUpdOtTablet;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        dialogo = new ProgressDialog(getmContext());
        dialogo.setMessage("Obteniendo Información...");
        dialogo.show();
        dialogo.setCanceledOnTouchOutside(false);
        dialogo.setCancelable(false);
    }

    @Override
    protected String doInBackground(String... strings) {
        version = Build.VERSION.RELEASE;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {// versiones con android 6.0 o superior
            httpclient = new DefaultHttpClient();
        } else {
            boolean disableSsl = true;
            SSLConnectionSocketFactory sslSocketFactory;
            if (disableSsl) {
                SSLContext ctx;
                try {
                    X509TrustManager x509TrustManager = new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }
                    };
                    ctx = SSLContext.getInstance("TLS");
                    ctx.init(new KeyManager[0], new TrustManager[]{x509TrustManager}, new SecureRandom());
                } catch (NoSuchAlgorithmException | KeyManagementException e) {
                    throw new SecurityException(e);
                }
                sslSocketFactory = new SSLConnectionSocketFactory(
                        ctx,
                        SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER
                );
            } else {
                sslSocketFactory = SSLConnectionSocketFactory.getSocketFactory();
            }
            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", PlainConnectionSocketFactory.getSocketFactory())
                    .register("https", sslSocketFactory)
                    .build();
            httpclient = HttpClientBuilder.create()
                    .setConnectionManager(new PoolingHttpClientConnectionManager(registry))
                    .build();
        }
        objBD = new BDFFCCMovil(mContext.getApplicationContext()); //hace la conexión
        //httpclient.getParams().setParameter("http.socket.timeout", new Integer(50000));
        httpclient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
        try {
            System.out.println("getfechaOT() " + getfechaOT());

            ArrayPOST = new JSONArray();//FALTA LLENAR ESTE ARRAY es para las otdescargadas en tablet
            if (!DirIp.endsWith("?")) {
                DirIp += "?";
            }
            System.out.println("fecha "+getfechaOT() +" " );
            paramsURL = new LinkedList<NameValuePair>();
            paramsURL.add(new BasicNameValuePair("ClaUbicacion", getClaUbicacion()));
            paramsURL.add(new BasicNameValuePair("fecha", getfechaOT()));//getfechaOT()//"2019-10-14"
            paramsURL.add(new BasicNameValuePair("ClaEquipo", getclaEquipo()));//getclaEquipo()//"305"
            paramsURL.add(new BasicNameValuePair("ClaTurno", getclaTurno()));//getclaTurno()//null  3

            paramString = URLEncodedUtils.format(paramsURL, "utf-8");
            DirIp += paramString;
            objGet = new HttpGet(DirIp);
            objGet.setHeader("content-type", "application/json");
            objGet.addHeader("Authorization", getToken());///add token
            res = httpclient.execute(objGet);
            respWS = EntityUtils.toString(res.getEntity(), "UTF-8");
            System.out.println("res.getStatusLine().getStatusCode() "+res.getStatusLine().getStatusCode());
            if(res.getStatusLine().getStatusCode()==200) {
                respJSON = new JSONArray(respWS);
                if (respJSON.length() == 0) {
                    return "Respuesta Vacia. \n Causas:\n1-No se encontraron OT. \n2-La OT se encuentra en proceso. \n ";
                } else {
                    //ELIMINA LA OT
                    objBD.DeleteOT(""+getfechaOT()+"T00:00:00",
                            ""+getclaTurno(),
                            ""+getclaEquipo());

                    for (int i = 0; i < respJSON.length(); i++) {
                        objJSON = respJSON.getJSONObject(i);

                        c = objBD.getOT(objJSON.getString("IdOt"), objJSON.getString("ClaActividad"));

                        if (c.getCount() > 0) {//No actualizo nada
                            /*objBD.UpdateOT(objJSON.getString("IdOt"),
                                    objJSON.getString("Fecha"),
                                    objJSON.getString("ClaEquipo"),
                                    objJSON.getString("ClaveEquipo"),
                                    objJSON.getString("ClaSistema"),
                                    objJSON.getString("NomSistema"),
                                    objJSON.getString("ClaSubsistema"),
                                    objJSON.getString("NomSubsistema"),
                                    objJSON.getString("ClaActividad"),
                                    objJSON.getString("ClaActividadPaso"),
                                    objJSON.getString("NomActividad"),
                                    objJSON.getString("EsRealizada"),
                                    objJSON.getString("TiempoEstimado"),
                                    objJSON.getString("TiempoRealHrs"),
                                    objJSON.getString("RecursoAsignado"),
                                    objJSON.getString("ClaVariable"),
                                    objJSON.getString("NomVariable"),
                                    objJSON.getString("NomUnidadMedidaVariable"),
                                    objJSON.getString("ValorEstandar"),
                                    objJSON.getString("ValorMinimo"),
                                    objJSON.getString("ValorMaximo"),
                                    objJSON.getString("ValorReal"),
                                    objJSON.getString("ClaReferenciaCumple"),
                                    objJSON.getString("NomReferenciaCumple"),
                                    objJSON.getString("ClaOpcionFija"),
                                    objJSON.getString("NomOpcionFija"),
                                    objJSON.getString("Referencia"),
                                    objJSON.getString("ClaTipoVariable"),
                                    objJSON.getString("ValorEstandar1"),
                                    objJSON.getString("ClaTurno"));*/
                        } else {
                            ArrayPOST.put(objJSON.getString("IdOt"));

                            System.out.println("OT INSERT "+objJSON.getString("IdOt"));
                            if("2".equals(objJSON.getString("ClaTipoVariable"))){
                                valorReal= objJSON.getString("ClaReferenciaCumple");
                            }else{
                                valorReal = objJSON.getString("ValorReal");
                            }
                            objBD.InsertOT(objJSON.getString("IdOt"),
                                    objJSON.getString("Fecha"),
                                    objJSON.getString("ClaEquipo"),
                                    objJSON.getString("ClaveEquipo"),
                                    objJSON.getString("ClaSistema"),
                                    objJSON.getString("NomSistema"),
                                    objJSON.getString("ClaSubsistema"),
                                    objJSON.getString("NomSubsistema"),
                                    objJSON.getString("ClaActividad"),
                                    objJSON.getString("ClaActividadPaso"),
                                    objJSON.getString("NomActividad"),
                                    objJSON.getString("EsRealizada"),
                                    objJSON.getString("TiempoEstimado"),
                                    objJSON.getString("TiempoRealHrs"),
                                    objJSON.getString("RecursoAsignado"),
                                    objJSON.getString("ClaVariable"),
                                    objJSON.getString("NomVariable"),
                                    objJSON.getString("NomUnidadMedidaVariable"),
                                    //"15",
                                    //"10",
                                   // "20",
                                    objJSON.getString("ValorEstandar"),
                                    objJSON.getString("ValorMinimo"),
                                    objJSON.getString("ValorMaximo"),
                                    ""+valorReal             ,

                                    objJSON.getString("ClaReferenciaCumple"),
                                    objJSON.getString("NomReferenciaCumple"),
                                    objJSON.getString("ClaOpcionFija"),
                                    objJSON.getString("NomOpcionFija"),
                                    objJSON.getString("Referencia"),
                                    //"1",
                                    objJSON.getString("ClaTipoVariable"),
                                    objJSON.getString("ValorEstandar1"),
                                    objJSON.getString("ClaTurno"),
                                    "1");
                        }
                        c.close();
                        objBD.CloseDB();
                    }

                    //INCLUIR PROCESO PARA ACTUALIZAR OT EN TABLET
                    if (!DirIPUpdOtTablet.endsWith("?")) {
                        DirIPUpdOtTablet += "?";
                    }
                    paramsURLPost = new LinkedList<NameValuePair>();
                    paramsURLPost.add(new BasicNameValuePair("ClaUbicacion",getClaUbicacion()));
                    paramStringPost = URLEncodedUtils.format(paramsURLPost, "utf-8");
                    DirIPUpdOtTablet += paramStringPost;
                    System.out.println("DirIp:_ "+getDirIPUpdOtTablet());



                    System.out.println("ArrayPOST.toString(): "+ArrayPOST.toString());
                    se = new StringEntity(ArrayPOST.toString(),"UTF-8");
                    se.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
                    httppost = new HttpPost(getDirIPUpdOtTablet());
                    httppost.addHeader("Authorization", getToken());///add token
                    httppost.setEntity(se);
                    responsePOST = httpclient.execute(httppost);
                    ent = responsePOST.getEntity();//obtenemos respuesta
                    respWS = "";//inicializo la variable para almacenar la nueva respuesta del nuevo clientePOST
                    respWS = EntityUtils.toString(responsePOST.getEntity(), "UTF-8");
                    Log.e("RespPOST:",respWS);
                    System.out.println("res.getStatusLine().getStatusCode() "+res.getStatusLine().getStatusCode());
                    arrayResp = new JSONArray(respWS);
                    if(res.getStatusLine().getStatusCode()==200) {
                        for (int n=0;n<arrayResp.length();n++) {
                            valor = arrayResp.getString(n);
                            separated = valor.split("_");
                            if ("SUCCESS".equals(separated[0])) {
                                return "Success";
                            } else {
                                return "Respuesta: No se actualizo correctamente DescargadaTablet. \n" + respWS;
                            }
                        }
                        return "Success";
                    }else{
                        return "No hay respuesta correcta POST.- Código Estatus:"+res.getStatusLine().getStatusCode()+"\n Intente Nuevamente.";
                    }
                }
                //return "Success";
            }else{
                return "No hay respuesta correcta.- Código Estatus:"+res.getStatusLine().getStatusCode()+"\n Intente Nuevamente.";
            }
        } catch (ClientProtocolException e) {
            return "Mensaje: " +respWS+"\n Excepción: " + e.toString();
        } catch (IOException e) {
            return "Mensaje: " +respWS+"\n Excepción: " + e.toString();
        } catch (JSONException e) {
            return "Mensaje: " +respWS+"\n Excepción: " + e.toString();
        } finally {
            httpclient.getConnectionManager().shutdown();
        }
    }

    @Override
    protected void onPostExecute(String result){
        Log.e("OT MTTO ", result);
        try {
            dialogo.dismiss();
        }catch (IllegalArgumentException ex){
            System.out.println("DIALOGO EXC Autonomo: "+ ex.toString());
        }
        if(result.equals("Success")){
            ibBuscar.callOnClick();
            dialogg = new AlertDialog.Builder(getmContext());
            dialogg.setTitle("Notificación OT");
            dialogg.setMessage("Descarga Exitosa.");
            dialogg.setCancelable(false);
            dialogg.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dialogo1.dismiss();
                }
            });
            dialogg.show();
        }else {
            dialogg = new AlertDialog.Builder(getmContext());
            dialogg.setTitle("Notificación OT-");
            dialogg.setMessage("" + result);
            dialogg.setCancelable(false);
            dialogg.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dialogo1.dismiss();
                }
            });
            dialogg.show();
        }
    }
}
package com.deacero.www.ffcc_movil.metodos;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.Image;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.util.Base64;
import android.util.Log;
import android.widget.ImageButton;

import com.deacero.www.ffcc_movil.BDFFCCMovil;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class PostOtAutonomaWS extends AsyncTask<String, String, String> {
    //BD
    BDFFCCMovil objBD;
    ImageResizer objImg;
    Cursor c, c2,c3;
    //constantes
    Context mContext;
    String Token, DirIp, ClaUbicacion, ClaUsuario, MAC;
    ProgressDialog dialogo;

    private HttpClient httpclient;
    private String version, respuesta, valor, fechaOT, claTurno, claEquipo;
    private int y;
    private HttpPost httppost;
    private JSONArray FinalArray, fotoArray, detalleArray,detalleFotoFinal, arrayResp;
    private JSONObject jsonObject, fotoObjectDetalle, detailObject;
    private StringEntity se;
    private HttpResponse response;
    private HttpEntity ent;
    private String[] separated;

    ImageButton ibBuscarOT;

    public PostOtAutonomaWS(Context MyContext, String MyToken, String MyDirIp, String MyClaUbicacion, String MyClaUsuario, String MyMAC, ImageButton btnBuscarOT, String FechaOT, String ClaEquipo, String ClaTurno) {
        this.mContext = MyContext;
        this.Token = MyToken;
        this.DirIp = MyDirIp;
        this.ClaUbicacion = MyClaUbicacion;
        this.ClaUsuario = MyClaUsuario;
        this.MAC = MyMAC;
        ibBuscarOT = btnBuscarOT;
        this.fechaOT = FechaOT;
        this.claTurno = ClaTurno;
        this.claEquipo = ClaEquipo;
    }

    public String getFechaOT() { return fechaOT; }
    public void setFechaOT(String fechaOT) {this.fechaOT = fechaOT; }
    public String getClaTurno() { return claTurno; }
    public void setClaTurno(String claTurno) {        this.claTurno = claTurno;    }
    public String getClaEquipo() {        return claEquipo;    }
    public void setClaEquipo(String claEquipo) {        this.claEquipo = claEquipo;    }
    public  String getMAC(){ return  MAC;}
    public void setMAC(String mac){ MAC = mac;}
    public  String getClaUsuario(){ return  ClaUsuario;}
    public void setClaUsuario(String claUsuario){ ClaUsuario = claUsuario;}
    public String getClaUbicacion() {
        return ClaUbicacion;
    }
    public void setClaUbicacion(String claUbicacion) {
        ClaUbicacion = claUbicacion;
    }
    public Context getmContext() {
        return mContext;
    }
    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }
    public String getToken() {
        return Token;
    }
    public void setToken(String token) {
        Token = token;
    }
    public String getDirIp() {
        return DirIp;
    }
    public void setDirIp(String dirIp) {
        DirIp = dirIp;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        dialogo = new ProgressDialog(getmContext());
        dialogo.setMessage("Enviando información Ot...");
        dialogo.show();
        dialogo.setCanceledOnTouchOutside(false);
        dialogo.setCancelable(false);
    }

    @Override
    protected String doInBackground(String... Strings) {
        objBD = new BDFFCCMovil(mContext.getApplicationContext()); //hace la conexión
        objImg = new ImageResizer();
        version = Build.VERSION.RELEASE;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){// versiones con android 6.0 o superior
            httpclient = new DefaultHttpClient();
        } else{
            boolean disableSsl=true;
            SSLConnectionSocketFactory sslSocketFactory;
            if (disableSsl) {
                SSLContext ctx;
                try {
                    X509TrustManager x509TrustManager = new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }
                    };
                    ctx = SSLContext.getInstance("TLS");
                    ctx.init(new KeyManager[0], new TrustManager[]{x509TrustManager}, new SecureRandom());
                } catch (NoSuchAlgorithmException | KeyManagementException e) {
                    throw new SecurityException(e);
                }
                sslSocketFactory = new SSLConnectionSocketFactory(
                        ctx,
                        SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER
                );
            } else {
                sslSocketFactory = SSLConnectionSocketFactory.getSocketFactory();
            }
            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", PlainConnectionSocketFactory.getSocketFactory())
                    .register("https", sslSocketFactory)
                    .build();
            httpclient = HttpClientBuilder.create()
                    .setConnectionManager(new PoolingHttpClientConnectionManager(registry))
                    .build();
        }
       // httpclient.getParams().setParameter("http.socket.timeout", new Integer(20000));
        httpclient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
        try {
           // c2 = objBD.getOTRealizada("1");//a 1 porque no esta en proceso, a 2 esta en proceso
           // System.out.println("POST-OT "+""+getClaTurno()+"-"+getClaEquipo()+"-"+getFechaOT()+"T00:00:00");
            c2 = objBD.getOTIndividualPost(""+getClaTurno(),""+getClaEquipo(),""+getFechaOT()+"T00:00:00");//a 1 porque no esta en proceso, a 2 esta en proceso
            c2.moveToFirst();            //va a act a 3 cuando se haya registrado con success
            if(c2.getCount()>0){
                httppost = new HttpPost(getDirIp());
                FinalArray = new JSONArray();
                for (y = 0; y < c2.getCount(); y++) {

                    jsonObject = new JSONObject();
                    jsonObject.put("ClaUbicacion", getClaUbicacion());
                    jsonObject.put("IdOt", c2.getString(0));
                    jsonObject.put("ClaEquipo", c2.getString(2));
                    jsonObject.put("ClaSistema", c2.getString(4));
                    jsonObject.put("ClaSubsistema", c2.getString(6));
                    jsonObject.put("ClaActividad", c2.getString(8));
                    jsonObject.put("ClaActividadPaso", c2.getString(9));
                    jsonObject.put("EsRealizada", c2.getString(11));
                    jsonObject.put("ClaVariable", c2.getString(15));
                    jsonObject.put("ClaTipoVariable", c2.getString(27));

                    jsonObject.put("ValorReal", c2.getString(21)+".0");
                  //  System.out.println("TESTT "+c2.getString(21)+".0");
                    jsonObject.put("GeneraDerivasaSN", ""+ c2.getString(31));
                    jsonObject.put("ClaActividadD","");
                    jsonObject.put("NombrePcMod", ""+getMAC());
                    jsonObject.put("ClaUsuarioMod", getClaUsuario());//ClaUsuario para Pruebas =2924303  getClaUsuario()
                                                                    //necesitas ese para poder guardar la ot
                    objBD.close();
                    FinalArray.put(jsonObject);
                    c2.moveToNext();
                }
                c2.close();
                objBD.close();
                //Log.e("FINAL-> ", "" + FinalArray.toString());
                se = new StringEntity(FinalArray.toString(),"UTF-8");
                se.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
                httppost.addHeader("Authorization", getToken());///add token
                httppost.setEntity(se);
                response = httpclient.execute(httppost);
                ent = response.getEntity();//obtenemos respuesta
                respuesta = EntityUtils.toString(ent);
             //   Log.e("Respuesta0:",respuesta.toString());
                arrayResp = new JSONArray(respuesta);
                if (response != null && arrayResp.length() > 0 ) {
                    System.out.println("arrayResp.length() "+arrayResp.length());
                    for (int n=0;n<arrayResp.length();n++){//for (int n=arrayResp.length()-1;n<arrayResp.length();n++){
                        valor = arrayResp.getString(n);
                        //valor = valor.replace(";",":");
                        separated = valor.split("_");
                        if(separated[0].equals("SUCCES")){//es el IdInspeccionCarro de la tablet
                           // System.out.println("OT "+separated[1] + " ACT "+separated[2]+ " PASO "+separated[3]+" EST "+separated[4]);
                            objBD.updateOTEstatusIndi(""+separated[1],""+separated[2],""+separated[3],""+separated[4]);
                            if("3".equals(separated[4])){//elemento final ot cerrada Estatus=3
                                //act todas las ot a 3
                          //      System.out.println("OT "+separated[1] + " ACT "+separated[2]+ " PASO "+separated[3]+" EST "+separated[4]);
                                objBD.updateOTEstatus(""+separated[1],""+separated[4]);
                                //elimina la ot de tablet
                                objBD.updateOTDelete(""+separated[1]);
                            }
                            objBD.close();
                        }else if(separated[0].equals("ERROR")){
                            respuesta = " "+separated[4];
                        }
                    }
                    return "succcess";
                }
                else{
                    return  "Respuesta: No regreso respuesta el servicio.";
                }
            }
            return "succcess";
        } catch (ClientProtocolException e) {
            return "Respuesta: " +respuesta+" \nExcepción: " + e.toString() +"\n";
        } catch (IOException e) {
            return "Respuesta: " +respuesta+" \nExcepción: " + e.toString() +"\n";
        } catch (JSONException e) {
            return "Respuesta: " +respuesta+" \nExcepción: " + e.toString() +"\n";
        } catch (Exception e) {
            return "Respuesta: " +respuesta+" \nExcepción: " + e.toString() +"\n";
        } finally {
            httpclient.getConnectionManager().shutdown();
        }
    }

    @Override
    protected void onPostExecute(String result) {
      //  Log.e("RESULTADO POST OT..", "" + result);
        try {
            dialogo.dismiss();
        }catch (IllegalArgumentException ex){
            System.out.println("DIALOGO EXC ot: "+ ex.toString());
        }
        if(result.equals("succcess")){
            ibBuscarOT.callOnClick();
            AlertDialog.Builder dialogg = new AlertDialog.Builder(getmContext());
            dialogg.setTitle("Notificación_S OT");
            dialogg.setMessage("Envio Exitoso.\nRecuerda que tienes que tener realizadas todas las actividades para poder cerrar la OT.");
            dialogg.setCancelable(false);
            dialogg.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dialogo1.dismiss();
                }
            });
            dialogg.show();
        }else {
            AlertDialog.Builder dialogg = new AlertDialog.Builder(getmContext());
            dialogg.setTitle("Notificación_S OT-");
            dialogg.setMessage(""+result);
            dialogg.setCancelable(false);
            dialogg.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dialogo1.dismiss();
                }
            });
            dialogg.show();
//            dialogg.show();Respuesta0
        }
    }

}

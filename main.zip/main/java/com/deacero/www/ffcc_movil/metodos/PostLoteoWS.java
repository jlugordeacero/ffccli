package com.deacero.www.ffcc_movil.metodos;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.widget.Button;

import com.deacero.www.ffcc_movil.BDFFCCMovil;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class PostLoteoWS extends AsyncTask<String, String, String> {
    //BD
    BDFFCCMovil objBD;
    Cursor c, c2,c3;
    //constantes
    Context mContext;
    String Token, DirIp, ClaUbicacion, ClaUsuario, MAC;
    String Encabezado;
    ProgressDialog dialogo;

    private HttpClient httpclient;
    private  String version, ejecuta;
    private HttpPost httppost;
    private int y,x;
    private JSONArray FinalArray, detalleArray, arrayResp;
    private JSONObject jsonObject,detailObject;
    private Button btnConsulta;

    public PostLoteoWS(Context MyContext, String MyToken, String MyDirIp, String MyClaUbicacion, String MyClaUsuario, String MyMAC, Button btnConsultaLoteo, String Ejecuta) {
        this.mContext = MyContext;
        this.Token = MyToken;
        this.DirIp = MyDirIp;
        this.ClaUbicacion = MyClaUbicacion;
        this.ClaUsuario = MyClaUsuario;
        this.MAC = MyMAC;
        this.btnConsulta = btnConsultaLoteo;
        this.ejecuta = Ejecuta;
    }

    public  String getMAC(){ return  MAC;}
    public void setMAC(String mac){ MAC = mac;}
    public  String getClaUsuario(){ return  ClaUsuario;}
    public void setClaUsuario(String claUsuario){ ClaUsuario = claUsuario;}
    public String getClaUbicacion() {
        return ClaUbicacion;
    }
    public void setClaUbicacion(String claUbicacion) {
        ClaUbicacion = claUbicacion;
    }
    public Context getmContext() {
        return mContext;
    }
    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }
    public String getToken() {
        return Token;
    }
    public void setToken(String token) {
        Token = token;
    }
    public String getDirIp() {
        return DirIp;
    }
    public void setDirIp(String dirIp) {
        DirIp = dirIp;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        dialogo = new ProgressDialog(getmContext());
        dialogo.setMessage("Enviando información Loteos...");
        dialogo.show();
        dialogo.setCanceledOnTouchOutside(false);
        dialogo.setCancelable(false);
    }

    @Override
    protected String doInBackground(String... Strings) {
        objBD = new BDFFCCMovil(mContext.getApplicationContext()); //hace la conexión
        version = Build.VERSION.RELEASE;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M){// versiones con android 6.0 o superior
            httpclient = new DefaultHttpClient();
        } else{
            boolean disableSsl=true;
            SSLConnectionSocketFactory sslSocketFactory;
            if (disableSsl) {
                SSLContext ctx;
                try {
                    X509TrustManager x509TrustManager = new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }
                    };
                    ctx = SSLContext.getInstance("TLS");
                    ctx.init(new KeyManager[0], new TrustManager[]{x509TrustManager}, new SecureRandom());
                } catch (NoSuchAlgorithmException | KeyManagementException e) {
                    throw new SecurityException(e);
                }
                sslSocketFactory = new SSLConnectionSocketFactory(
                        ctx,
                        SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER
                );
            } else {
                sslSocketFactory = SSLConnectionSocketFactory.getSocketFactory();
            }
            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", PlainConnectionSocketFactory.getSocketFactory())
                    .register("https", sslSocketFactory)
                    .build();

            httpclient = HttpClientBuilder.create()
                    .setConnectionManager(new PoolingHttpClientConnectionManager(registry))
                    .build();

        }
       // httpclient.getParams().setParameter("http.socket.timeout", new Integer(30000));
        httpclient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
        try {
            httppost = new HttpPost(getDirIp());
            c2 = objBD.getLoteoUnidadEncAPI(ClaUbicacion,"1");//DEFAULT 0-> No loteo,  1->Termino el Loteo y esta listo para ser enviado API, 2->se envio correctamente
            c2.moveToFirst();
            if(c2.getCount()>0) {
                FinalArray = new JSONArray();
                for (y = 0; y < c2.getCount(); y++) {
                    jsonObject = new JSONObject();
                    detalleArray = new JSONArray();
                    jsonObject.put("IdLoteoUnidadEnc", "" + c2.getString(0));
                    jsonObject.put("ClaUbicacion", "" + c2.getString(1));
                    jsonObject.put("ClaViaOrigen", "" + c2.getString(2));
                    jsonObject.put("FechaLoteo", "" + c2.getString(3));
                    jsonObject.put("Hora", "" + c2.getString(9));
                    jsonObject.put("DireccionMAC", "" + c2.getString(4));
                    jsonObject.put("NombrePcMod", "" + c2.getString(6));
                    jsonObject.put("ClaUsuarioMod", "" + c2.getString(7));
                    c3 = objBD.getLoteoUnidadDetAPI(c2.getString(0), "0");
                    c3.moveToFirst();
                    for (x = 0; x < c3.getCount(); x++) {
                        detailObject = new JSONObject();
                        detailObject.put("ClaUbicacion", "" + c2.getString(1));
                        detailObject.put("IdLoteoUnidadEnc", "" + c3.getString(0));
                        detailObject.put("IdLoteoUnidadDet", "" + c3.getString(1));
                        detailObject.put("ClaCarro", "" + c3.getString(3));
                        detailObject.put("Placa", "" + c3.getString(4));
                        detailObject.put("EsCargado", "" + c3.getString(5));
                        detailObject.put("ClaTipoMaterial", "" + c3.getString(6));
                        detailObject.put("NombrePcMod", "" + c3.getString(8));
                        detailObject.put("ClaUsuarioMod", "" + c2.getString(7));//c3.getString(9)
                        detailObject.put("ClaViaDestino", "" + c3.getString(2));
                        detalleArray.put(detailObject);
                        c3.moveToNext();
                    }
                    jsonObject.put("Detalle", detalleArray);
                    c3.close();
                    FinalArray.put(jsonObject);
                    c2.moveToNext();
                }
                c2.close();
                System.out.println("JSON: "+FinalArray);
                StringEntity se = new StringEntity(FinalArray.toString(),"UTF-8");
                se.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
                httppost.addHeader("Authorization", getToken());///add token
                httppost.setEntity(se);
                HttpResponse response = httpclient.execute(httppost);
                HttpEntity ent = response.getEntity();//obtenemos respuesta
                String respuesta = EntityUtils.toString(ent);
                String respuesta2 = respuesta.replace("\\", "");
                System.out.println("RESPUESTA: "+respuesta);
                arrayResp = new JSONArray(respuesta2);
                if (response != null) {
                    for (int n = 0; n < arrayResp.length(); n++) {
                        String valor = arrayResp.getString(n);
                        String valor2 = valor.replace(";", ":");
                        String[] separated = valor2.split(":");
                        Encabezado = separated[1];
                        if ("SuccesEnc".equals(separated[0])) {
                            objBD.updateEstatusLoteoEnc(""+separated[1], "2", ClaUbicacion);//se setea a 2 porque ha sido enviado correctamente
                        } else if ("SuccessDet".equals(separated[0])) {
                            objBD.updateEstatusLoteoDet("" + Encabezado, "" + separated[1], "1");//para el detalle se tea a 1 porque ha sido guardado
                        }
                        //falta codigo para limpiar tabla de enc y det de loteo
                    }
                }
            }
            objBD.close();
            return "succcess";
        } catch (ClientProtocolException ex) {
            return "" + ex.toString();
        } catch (IOException e1) {
            return "" + e1.toString();
        } catch (JSONException e2) {
            return  e2.toString();
        } catch (Exception e3) {
            return e3.toString();
        } finally {
            httpclient.getConnectionManager().shutdown();
        }
    }

    @Override
    protected void onPostExecute(String result) {
        try {
            dialogo.dismiss();
        }catch (IllegalArgumentException ex){
            System.out.println("DIALOGO EXC lot: "+ ex.toString());
        }dialogo.dismiss();
        if(result.equals("succcess")){
            AlertDialog.Builder dialogg = new AlertDialog.Builder(getmContext());
            dialogg.setTitle("Notificación Loteo");
            dialogg.setMessage("Envio de datos exitoso.");
            dialogg.setCancelable(false);
            dialogg.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dialogo1.dismiss();
                }
            });
            dialogg.show();
        }else {
            AlertDialog.Builder dialogg = new AlertDialog.Builder(getmContext());
            dialogg.setTitle("Notificación Loteo");
            dialogg.setMessage(""+result);
            dialogg.setCancelable(false);
            dialogg.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dialogo1.dismiss();
                }
            });
            dialogg.show();
        }
        if("SI".equals(ejecuta)){
            btnConsulta.callOnClick();
        }
    }
}
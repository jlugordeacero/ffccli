package com.deacero.www.ffcc_movil.metodos;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.widget.Button;
import com.deacero.www.ffcc_movil.BDFFCCMovil;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.LinkedList;
import java.util.List;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class GetCfgSolicitudServicioWS extends AsyncTask<String, String, String> {
    //BD
    BDFFCCMovil objBD;
    private Cursor c, c2;
    //constantes
    private Context mContext;
    private String Token, DirIp, ClaUbicacion, Fecha, MAC, ClaUsuario;
    private String FechaCaptura, ClaConfVentana, ClaConfServicios, IdTraSolicitudServicio, ClaUbicacion3,ClaClienteInterno,ClaVia,EsCarga,BajaLogica,Duracion,Unidad,Hora,HoraRegistro,Detalle;
    private String ClaUbicacion2, IdTraSolicitudServicio2, IdTraSolicitudServicioDet, ClaTipoUnidad, Cantidad, TapasRequeridas, NomMaterial="",IdColocacion="0",IdRetiro="0", ejecutaBtn;
    private Integer totalrows;
    private Button btnRecargarTabla;
    ProgressDialog dialogo;
    private HttpClient httpclient;
    private String version, paramString, respWS;
    private List<NameValuePair> paramsURL;
    private HttpGet objGet;
    private HttpResponse res;
    private JSONArray respJSON, array;
    private JSONObject objJSON, row;

    public GetCfgSolicitudServicioWS(Context MyContext, String MyToken, String MyDirIp, String MyClaUbicacion, String MyFecha, Button btnRecargarTabla, String EjecutaBtn, String MAC, String ClaUsuario){
        this.mContext = MyContext;
        this.Token = MyToken;
        this.DirIp = MyDirIp;
        this.ClaUbicacion = MyClaUbicacion;
        this.Fecha = MyFecha;
        this.btnRecargarTabla = btnRecargarTabla;
        this.ejecutaBtn = EjecutaBtn;
        this.MAC = MAC;
        this.ClaUsuario = ClaUsuario;
    }

    public String getFecha() { return Fecha; }

    public void setFecha(String fecha) {     Fecha = fecha;   }

    public String getClaUbicacion() {
        return ClaUbicacion;
    }

    public void setClaUbicacion(String claUbicacion) {
        ClaUbicacion = claUbicacion;
    }

    public Context getmContext() {
        return mContext;
    }

    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }

    public String getDirIp() {
        return DirIp;
    }

    public void setDirIp(String dirIp) {
        DirIp = dirIp;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        dialogo = new ProgressDialog(getmContext());
        dialogo.setMessage("Cargando información .....");
        dialogo.show();
        dialogo.setCanceledOnTouchOutside(false);
        dialogo.setCancelable(false);
    }

    @Override
    protected String doInBackground(String... strings) {
        objBD = new BDFFCCMovil(mContext.getApplicationContext()); //hace la conexión
        version = Build.VERSION.RELEASE;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M){
            // versiones con android 6.0 o superior
            httpclient = new DefaultHttpClient();
        } else{
            boolean disableSsl=true;
            SSLConnectionSocketFactory sslSocketFactory;
            if (disableSsl) {
                SSLContext ctx;
                try {
                    X509TrustManager x509TrustManager = new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }
                    };
                    ctx = SSLContext.getInstance("TLS");
                    ctx.init(new KeyManager[0], new TrustManager[]{x509TrustManager}, new SecureRandom());
                } catch (NoSuchAlgorithmException | KeyManagementException e) {
                    throw new SecurityException(e);
                }
                sslSocketFactory = new SSLConnectionSocketFactory(
                        ctx,
                        SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER
                );
            } else {
                sslSocketFactory = SSLConnectionSocketFactory.getSocketFactory();
            }
            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", PlainConnectionSocketFactory.getSocketFactory())
                    .register("https", sslSocketFactory)
                    .build();

            httpclient = HttpClientBuilder.create()
                    .setConnectionManager(new PoolingHttpClientConnectionManager(registry))
                    .build();

        }
        //httpclient.getParams().setParameter("http.socket.timeout", new Integer(10000));
        httpclient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
        try  {
                    if(!DirIp.endsWith("?"))
                        DirIp += "?";
                    paramsURL = new LinkedList<NameValuePair>();
                    paramsURL.add(new BasicNameValuePair("ClaUbicacion",getClaUbicacion()));
                    paramsURL.add(new BasicNameValuePair("fecha",getFecha()));
                    paramString = URLEncodedUtils.format(paramsURL, "utf-8");
                    DirIp += paramString;
                    objGet = new HttpGet(getDirIp());
                    objGet.setHeader("content-type", "application/json");
                    objGet.addHeader("Authorization",getToken());///add token
                    res = httpclient.execute(objGet);
                    respWS = EntityUtils.toString(res.getEntity(),"UTF-8");
                    respJSON = new JSONArray(respWS);
                    //variables
                    for (int i = 0; i < respJSON.length(); i++) {
                        objJSON = respJSON.getJSONObject(i);
                        ClaUbicacion = objJSON.getString("ClaUbicacion");
                        IdTraSolicitudServicio = objJSON.getString("IdTraSolicitudServicio");
                        ClaConfServicios = objJSON.getString("ClaConfServicios");
                        ClaConfVentana = objJSON.getString("ClaConfVentana");
                        FechaCaptura = objJSON.getString("FechaCaptura");
                        ClaClienteInterno = objJSON.getString("ClaClienteInterno");
                        ClaVia = objJSON.getString("ClaVia");
                        EsCarga = objJSON.getString("EsCarga");
                        BajaLogica = objJSON.getString("BajaLogica");
                        Duracion = objJSON.getString("Duracion");
                        Unidad = objJSON.getString("Unidad");
                        Hora = objJSON.getString("Hora");
                        HoraRegistro = objJSON.getString("HoraRegistro");
                        IdColocacion=objJSON.getString("IdColocacion");
                        IdRetiro=objJSON.getString("IdRetiro");
                        Detalle = objJSON.getString("Detalle");
                        c = objBD.getCapturasServicio(ClaUbicacion,IdTraSolicitudServicio);
                        if(c.getCount() > 0){//Si existe el servicio
                            objBD.UpdateCapturasServicio(ClaConfServicios, ClaConfVentana,ClaVia,Duracion,Unidad,Hora,HoraRegistro,FechaCaptura,ClaClienteInterno,EsCarga,BajaLogica,IdTraSolicitudServicio,ClaUbicacion,IdColocacion,IdRetiro);
                            objBD.DeleteCapturasServicioDet(IdTraSolicitudServicio);//agregue esta linea
                            array = new JSONArray(Detalle);
                            for (int x = 0; x < array.length(); x++) {
                                row = array.getJSONObject(x);
                                objBD.InsertCapturasServicioDet(""+row.getString("IdTraSolicitudServicio"),
                                        ""+row.getString("IdTraSolicitudServicioDet"),
                                        ""+row.getString("ClaTipoUnidad"),
                                        ""+row.getString("Cantidad"),
                                        ""+row.getString("TapasRequeridas"),
                                        ""+row.getString("ClaUbicacion"),
                                        ""+row.getString("NombreMaterial"));
                            }
                        }else{//si no existe el servicio
                            objBD.InsertCapturasServicio(FechaCaptura, ClaConfVentana, ClaConfServicios, IdTraSolicitudServicio, ClaUbicacion, ClaClienteInterno, ClaVia, Duracion, Unidad, Hora, HoraRegistro, EsCarga, BajaLogica,IdColocacion,IdRetiro);
                            array = new JSONArray(Detalle);
                            objBD.DeleteCapturasServicioDet(IdTraSolicitudServicio);//agregue esta linea
                            for (int x = 0; x < array.length(); x++) {
                                row = array.getJSONObject(x);
                                objBD.InsertCapturasServicioDet(""+row.getString("IdTraSolicitudServicio"),
                                        ""+row.getString("IdTraSolicitudServicioDet"),
                                        ""+row.getString("ClaTipoUnidad"),
                                        ""+row.getString("Cantidad"),
                                        ""+row.getString("TapasRequeridas"),
                                        ""+row.getString("ClaUbicacion"),
                                        ""+row.getString("NombreMaterial"));
                            }

                            objBD.ADD_FfccCarrosColocados(objBD.getMax_FfccCarrosColocados(),
                                    IdTraSolicitudServicio,
                                    ClaUbicacion,
                                    ClaConfServicios,
                                    ClaConfVentana,
                                    ""+MAC,
                                    "2",
                                    ""+ClaUsuario);
                        }
                        c.close();
                        objBD.CloseDB();
                    }
                    return "succcess";
                }catch(ClientProtocolException ex){
                    return ""+ex.toString();
                } catch (IOException e) {
                    return ""+e.toString();
                } catch (JSONException e) {
                    return ""+e.toString();
                }finally {
                    httpclient.getConnectionManager().shutdown();
                }
    }

    @Override
    protected void onPostExecute(String result){
        try {
            dialogo.dismiss();
        }catch (IllegalArgumentException ex){
            System.out.println("DIALOGO EXC sal: "+ ex.toString());
        }
        if(result.equals("succcess")){
        }else {
            AlertDialog.Builder dialogg = new AlertDialog.Builder(getmContext());
            dialogg.setTitle("Notificación Solicitud Servicio");
            dialogg.setMessage(""+result);
            dialogg.setCancelable(false);
            dialogg.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dialogo1.dismiss();
                }
            });
//            dialogg.show();
        }
        if("SI".equals(ejecutaBtn)){
            btnRecargarTabla.callOnClick();
        }
    }
}
package com.deacero.www.ffcc_movil.metodos;

import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.util.Log;

import com.deacero.www.ffcc_movil.BDFFCCMovil;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.LinkedList;
import java.util.List;

import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class GetTipoMaterialWS extends AsyncTask<String, String, String> {
    //BD
    BDFFCCMovil objBD;
    private Cursor c;
    //constantes
    private Context mContext;
    private String Token, DirIp, ClaUbicacion;

    private String ClaTipoMaterial,NombreTipoMaterial;
    private Integer totalrows;

    public GetTipoMaterialWS(Context MyContext, String MyToken, String MyDirIp, String MyClaUbicacion){
        this.mContext = MyContext;
        this.Token = MyToken;
        this.DirIp = MyDirIp;
        this.ClaUbicacion = MyClaUbicacion;
    }

    public String getClaUbicacion() {
        return ClaUbicacion;
    }

    public void setClaUbicacion(String claUbicacion) {
        ClaUbicacion = claUbicacion;
    }

    public Context getmContext() {
        return mContext;
    }

    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }

    public String getDirIp() {
        return DirIp;
    }

    public void setDirIp(String dirIp) {
        DirIp = dirIp;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... strings) {
        objBD = new BDFFCCMovil(mContext.getApplicationContext()); //hace la conexión
        //HttpClient httpclient = new DefaultHttpClient();
        HttpClient httpclient;
        String version = Build.VERSION.RELEASE;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M){
            // versiones con android 6.0 o superior
            httpclient = new DefaultHttpClient();
        } else{
            boolean disableSsl=true;
            SSLConnectionSocketFactory sslSocketFactory;
            if (disableSsl) {
                SSLContext ctx;
                try {
                    X509TrustManager x509TrustManager = new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }
                    };
                    ctx = SSLContext.getInstance("TLS");
                    ctx.init(new KeyManager[0], new TrustManager[]{x509TrustManager}, new SecureRandom());
                } catch (NoSuchAlgorithmException | KeyManagementException e) {
                    throw new SecurityException(e);
                }
                sslSocketFactory = new SSLConnectionSocketFactory(
                        ctx,
                        SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER
                );
            } else {
                sslSocketFactory = SSLConnectionSocketFactory.getSocketFactory();
            }
            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", PlainConnectionSocketFactory.getSocketFactory())
                    .register("https", sslSocketFactory)
                    .build();

            httpclient = HttpClientBuilder.create()
                    .setConnectionManager(new PoolingHttpClientConnectionManager(registry))
                    .build();

        }
        //httpclient.getParams().setParameter("http.socket.timeout", new Integer(5000));
        httpclient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
        try  {
                    if(!DirIp.endsWith("?"))
                        DirIp += "?";
                    List<NameValuePair> paramsURL = new LinkedList<NameValuePair>();
                    paramsURL.add(new BasicNameValuePair("ClaUbicacion",getClaUbicacion()));
                    String paramString = URLEncodedUtils.format(paramsURL, "utf-8");
                    DirIp += paramString;
                    //Log.e("DIRIP.>",""+getDirIp());
                    HttpGet objGet = new HttpGet(getDirIp());
                    objGet.setHeader("content-type", "application/json");
                    objGet.addHeader("Authorization",getToken());///add token
                    //Log.e("TokenTmat->",""+getToken());
                    HttpResponse res = httpclient.execute(objGet);
                    String respWS = EntityUtils.toString(res.getEntity(),"UTF-8");
                    //Log.e("respWS-Tmat->",""+respWS);
                    JSONArray respJSON = new JSONArray(respWS);
                    //variables
                    // vista con todos los carros FfccCatCarroVw
                   /*  String FfccCatTipoMaterialVw = "CREATE TABLE FfccCatTipoMaterialVw (ClaTipoMaterial INTEGER ," +
            "NombreTipoMaterial VARCHAR(50))";*/


                    for (int i = 0; i < respJSON.length(); i++) {
                        //Log.e("ENTRA FOR->", "--------------------");
                        JSONObject objJSON = respJSON.getJSONObject(i);
                        //registros obtenidos
                        ClaTipoMaterial = objJSON.getString("ClaTipoMaterial");
                        NombreTipoMaterial = objJSON.getString("NombreTipoMaterial");

                        c = objBD.getTipoMaterial(ClaTipoMaterial);
                        totalrows = c.getCount();
                        if (totalrows > 0) {//update
                            //Log.e("UPD Material->","....");
                            objBD.UpdateTipoMaterial(ClaTipoMaterial,NombreTipoMaterial);
                        } else {//insert
                            //Log.e("INS Material->","....");
                            objBD.InsertTipoMaterial(ClaTipoMaterial,NombreTipoMaterial);
                        }
                        c.close();
                        objBD.CloseDB();
                    }
                    return "succcess";
                }catch(ClientProtocolException ex){
                    return ""+ex.toString();
                } catch (IOException e) {
                    e.printStackTrace();
                    return ""+e.toString();
                } catch (JSONException e) {
                    e.printStackTrace();
                    return ""+e.toString();
                }finally {
                    httpclient.getConnectionManager().shutdown();
                }
    }

    @Override
    protected void onPostExecute(String result){
        Log.e("RESULTADO TipoMat",""+result);
        if(result.equals("succcess")){

        }else {
            AlertDialog.Builder dialogg = new AlertDialog.Builder(getmContext());
            dialogg.setTitle("Notificación Tipo Material");
            dialogg.setMessage(""+result);
            dialogg.setCancelable(false);
            dialogg.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dialogo1.dismiss();
                }
            });
            dialogg.show();

        }
    }
}


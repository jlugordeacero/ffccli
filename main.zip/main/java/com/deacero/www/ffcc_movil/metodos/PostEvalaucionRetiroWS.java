package com.deacero.www.ffcc_movil.metodos;

import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.util.Log;

import com.deacero.www.ffcc_movil.BDFFCCMovil;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.LinkedList;
import java.util.List;

import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class PostEvalaucionRetiroWS extends AsyncTask<String, String, String> {
    //BD
    BDFFCCMovil objBD;
    Cursor c2,c3,c4;
    //constantes
    Context mContext;
    String Token, DirIp, ClaUbicacion, ClaUsuario, MAC;

    public PostEvalaucionRetiroWS(Context MyContext, String MyToken, String MyDirIp, String MyClaUbicacion, String MyClaUsuario, String MyMAC) {
        this.mContext = MyContext;
        this.Token = MyToken;
        this.DirIp = MyDirIp;
        this.ClaUbicacion = MyClaUbicacion;
        this.ClaUsuario = MyClaUsuario;
        this.MAC = MyMAC;
    }

    public  String getMAC(){ return  MAC;}

    public void setMAC(String mac){ MAC = mac;}

    public  String getClaUsuario(){ return  ClaUsuario;}

    public void setClaUsuario(String claUsuario){ ClaUsuario = claUsuario;}

    public String getClaUbicacion() {
        return ClaUbicacion;
    }

    public void setClaUbicacion(String claUbicacion) {
        ClaUbicacion = claUbicacion;
    }

    public Context getmContext() {
        return mContext;
    }

    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }

    public String getDirIp() {
        return DirIp;
    }

    public void setDirIp(String dirIp) {
        DirIp = dirIp;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... Strings) {
        objBD = new BDFFCCMovil(mContext.getApplicationContext()); //hace la conexión
       // HttpClient httpclient = new DefaultHttpClient();
        HttpClient httpclient;
        String version = Build.VERSION.RELEASE;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M){
            // versiones con android 6.0 o superior
            httpclient = new DefaultHttpClient();
        } else{
            boolean disableSsl=true;
            SSLConnectionSocketFactory sslSocketFactory;
            if (disableSsl) {
                SSLContext ctx;
                try {
                    X509TrustManager x509TrustManager = new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }
                    };
                    ctx = SSLContext.getInstance("TLS");
                    ctx.init(new KeyManager[0], new TrustManager[]{x509TrustManager}, new SecureRandom());
                } catch (NoSuchAlgorithmException | KeyManagementException e) {
                    throw new SecurityException(e);
                }
                sslSocketFactory = new SSLConnectionSocketFactory(
                        ctx,
                        SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER
                );
            } else {
                sslSocketFactory = SSLConnectionSocketFactory.getSocketFactory();
            }
            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", PlainConnectionSocketFactory.getSocketFactory())
                    .register("https", sslSocketFactory)
                    .build();

            httpclient = HttpClientBuilder.create()
                    .setConnectionManager(new PoolingHttpClientConnectionManager(registry))
                    .build();

        }
       // httpclient.getParams().setParameter("http.socket.timeout", new Integer(15000));
        httpclient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
        try {
            if (!DirIp.endsWith("?"))
                DirIp += "?";
            List<NameValuePair> paramsURL = new LinkedList<NameValuePair>();
            paramsURL.add(new BasicNameValuePair("ClaUbicacion", getClaUbicacion()));
            String paramString = URLEncodedUtils.format(paramsURL, "utf-8");
            DirIp += paramString;
            HttpPost httppost = new HttpPost(getDirIp());
            int y;
            c2 = objBD.getEvaluacionRetirosAPI("1");///a 1 porque se enviaran todos los retiros que hayan terminado
            c2.moveToFirst();
            if(c2.getCount()>0){
            JSONArray FinalArray = new JSONArray();
            for (y = 0; y < c2.getCount(); y++) {
                JSONObject jsonObject = new JSONObject();
                JSONArray detalleArray = new JSONArray();

                jsonObject.put("ClaUbicacion", c2.getString(0));
                jsonObject.put("IdTraEvaluacionRetiroCI", c2.getString(1));
                jsonObject.put("IdRetiroClienteInterno", objBD.getIdColocacionSQLserverRetiro(c2.getString(0),c2.getString(2)));//este ya seria el del servidor
                jsonObject.put("Fecha", c2.getString(3));
                jsonObject.put("ClaUsuarioMod", c2.getString(6));
                jsonObject.put("NombrePcMod", c2.getString(7));

                c3 = objBD.getEvaluacionRetirosDetAPI(c2.getString(1), c2.getString(0));
                c3.moveToFirst();
                int x;
                for (x = 0; x < c3.getCount(); x++) {
                    JSONObject detailObject = new JSONObject();
                    detailObject.put("ClaUbicacion", c3.getString(0));
                    detailObject.put("IdEvaluacionRetiroCIDet", c3.getString(1));
                    detailObject.put("IdEvaluacionRetiroCI", c3.getString(2));
                    detailObject.put("IdCfgEvaluacionRetiroDet", c3.getString(3));
                    detailObject.put("Valor", c3.getString(4));
                    detailObject.put("NombrePcMod", getMAC());
                    detailObject.put("ClaUsuarioMod",c2.getString(6));//c3.getString(6)
                    detalleArray.put(detailObject);
                    c3.moveToNext();
                }
                jsonObject.put("Detalle", detalleArray);
                c3.close();
                objBD.close();
                FinalArray.put(jsonObject);
                c2.moveToNext();
            }
            c2.close();
            objBD.close();
            Log.e("FINAL-> ", "" + FinalArray.toString());
            StringEntity se = new StringEntity(FinalArray.toString(),"UTF-8");
            // StringEntity se = new StringEntity("");
            se.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
            httppost.addHeader("Authorization", getToken());///add token
            httppost.setEntity(se);
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity ent = response.getEntity();//obtenemos respuesta
            String respuesta = EntityUtils.toString(ent);

            Log.e("Respuesta :", respuesta);
            JSONArray arrayResp = new JSONArray(respuesta);///falta act los id de las colocaciones
            Log.e("Respuesta  --:", arrayResp.toString());
            /*Checking response */
            if (response != null) {
                for (int n = 0; n < arrayResp.length(); n++) {
                    String valor = arrayResp.getString(n);
                    valor = valor.replace(";", ":");
                    String[] separated = valor.split(":");
                    if (separated[0].equals("SUCCES")) {
                        //regresa el idretirosqlserver  en base a ese tengo que buscarlo  y upd
                       /* Log.e("entra", separated[0]+" ID RETIRO Sqlite "+ separated[1]);*/
                       // String idRetiroSqlite = objBD.getIdSQLiteRetiro(getClaUbicacion(),""+separated[1]);
                       // Log.e("entra", separated[0]+" ID RETIRO sqlite "+ idRetiroSqlite);
                        objBD.updateEstatusEvalaucionRetiro("" + separated[1], "2");//se setea a 2 porque ha sido guardado y no se enviara

                        String idRetiroSqlite = objBD.getIdRetiroSQLite(getClaUbicacion(),""+separated[1]);
                        ///act estatus para no mostrar en el recycler
                        objBD.updateEstatusRetiro2("" + idRetiroSqlite, getClaUbicacion(), "3");//se setea a 3 para no mostrar en recyler
                        ///add codigo para limpiar las tablas,  DELETE

                    }
                }
            }
        }
            //Log.e("response: "+in);
            return "succcess";
        } catch (ClientProtocolException ex) {
            return "" + ex.toString();
        } catch (IOException e) {
            //e.printStackTrace();
            return "" + e.toString();
        } catch (JSONException e2) {
            //e.printStackTrace();
            return e2.toString();
        } catch (Exception e3) {
            //e.printStackTrace();
            return  e3.toString();
        } finally {
            httpclient.getConnectionManager().shutdown();
        }
        //return "no atrapo exception";
    }

    @Override
    protected void onPostExecute(String result) {
        Log.e("RESULTADO POST evalret", "" + result);
        if(result.equals("succcess")){

        }else {
            AlertDialog.Builder dialogg = new AlertDialog.Builder(getmContext());
            dialogg.setTitle("Notificación Evaluacion Retiro");
            dialogg.setMessage(""+result);
            dialogg.setCancelable(false);
            dialogg.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dialogo1.dismiss();
                }
            });
         //   dialogg.show();

        }
    }

}
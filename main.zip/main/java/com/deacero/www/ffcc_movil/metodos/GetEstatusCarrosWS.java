package com.deacero.www.ffcc_movil.metodos;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Build;
import android.util.Log;

import com.deacero.www.ffcc_movil.ModuloEstatusCarros.EstatusCarro;
import com.deacero.www.ffcc_movil.ModuloEstatusCarros.EstatusCarroAdapter;
import com.deacero.www.ffcc_movil.ModuloFacturacion.Facturacion;
import com.deacero.www.ffcc_movil.ModuloFacturacion.FacturacionAdapter;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class GetEstatusCarrosWS extends AsyncTask<String, String, String> {

    //constantes
    private Context mContext;
    private String Token, DirIp, ClaUbicacion, numManiobra;
    ArrayList<EstatusCarro> listEstCar;
    EstatusCarroAdapter adp ;
    ProgressDialog dialogo;
    private JSONObject objJSON;
    private JSONArray respJSON;
    private Internet internet;
    private HttpClient httpclient;
    private String version, paramString,respWS;
    private List<NameValuePair> paramsURL;
    private HttpGet objGet;
    private HttpResponse res;
    public GetEstatusCarrosWS(Context MyContext, String MyToken, String MyDirIp, String MyClaUbicacion, String NumMan, ArrayList<EstatusCarro> listEstCar, EstatusCarroAdapter adp){
        this.mContext = MyContext;
        this.Token = MyToken;
        this.DirIp = MyDirIp;
        this.ClaUbicacion = MyClaUbicacion;
        this.numManiobra = NumMan;
        this.listEstCar = listEstCar;
        this.adp = adp;
    }

    public String getNumManiobra() {
        return numManiobra;
    }

    public void setNumManiobra(String numManiobra) {
        this.numManiobra = numManiobra;
    }

    public String getClaUbicacion() {
        return ClaUbicacion;
    }

    public void setClaUbicacion(String claUbicacion) {
        ClaUbicacion = claUbicacion;
    }

    public Context getmContext() {
        return mContext;
    }

    public void setmContext(Context mContext) {
        this.mContext = mContext;
    }

    public String getToken() {
        return Token;
    }

    public void setToken(String token) {
        Token = token;
    }

    public String getDirIp() {
        return DirIp;
    }

    public void setDirIp(String dirIp) {
        DirIp = dirIp;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        dialogo = new ProgressDialog(getmContext());
        dialogo.setMessage("Obteniendo Información...");
        dialogo.show();
        dialogo.setCanceledOnTouchOutside(false);
        dialogo.setCancelable(false);
    }

    @Override
    protected String doInBackground(String... strings) {
        internet = new Internet(getmContext());
        version = Build.VERSION.RELEASE;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            // versiones con android 6.0 o superior
            httpclient = new DefaultHttpClient();
        } else {
            boolean disableSsl = true;
            SSLConnectionSocketFactory sslSocketFactory;
            if (disableSsl) {
                SSLContext ctx;
                try {
                    X509TrustManager x509TrustManager = new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                        }
                        @Override
                        public X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }
                    };
                    ctx = SSLContext.getInstance("TLS");
                    ctx.init(new KeyManager[0], new TrustManager[]{x509TrustManager}, new SecureRandom());
                } catch (NoSuchAlgorithmException | KeyManagementException e) {
                    throw new SecurityException(e);
                }
                sslSocketFactory = new SSLConnectionSocketFactory(
                        ctx,
                        SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER
                );
            } else {
                sslSocketFactory = SSLConnectionSocketFactory.getSocketFactory();
            }
            Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
                    .register("http", PlainConnectionSocketFactory.getSocketFactory())
                    .register("https", sslSocketFactory)
                    .build();
            httpclient = HttpClientBuilder.create()
                    .setConnectionManager(new PoolingHttpClientConnectionManager(registry))
                    .build();
        }
        //httpclient.getParams().setParameter("http.socket.timeout", new Integer(100000));
        httpclient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
        try {
            if (!DirIp.endsWith("?"))
                DirIp += "?";
            paramsURL = new LinkedList<NameValuePair>();
            paramsURL.add(new BasicNameValuePair("ClaUbicacion", getClaUbicacion()));
            paramsURL.add(new BasicNameValuePair("PlacaCarro", getNumManiobra()));
            paramString = URLEncodedUtils.format(paramsURL, "utf-8");
            DirIp += paramString;
            objGet = new HttpGet(DirIp);
            objGet.setHeader("content-type", "application/json");
            objGet.addHeader("Authorization", getToken());///add token
            res = httpclient.execute(objGet);
            respWS = EntityUtils.toString(res.getEntity(), "UTF-8");
            respJSON = new JSONArray(respWS);

            if(respJSON.length()==0){
                listEstCar.add(new EstatusCarro("No se encontraron coincidencias con:  "+getNumManiobra()+"  " , "" ));
            }
            for (int i = 0; i < respJSON.length(); i++) {
                objJSON = respJSON.getJSONObject(i);
                listEstCar.add(new EstatusCarro("Placa: " + objJSON.getString("PlacaCarro"), " Estatus: " +objJSON.getString("Estatus")));
            }
            return "Success";
        } catch (ClientProtocolException ex) {
            //Log.e("CP: ", "" + ex.toString());
            return "" + ex.toString();
        } catch (IOException e) {
            //Log.e("IO: ", "" + e.toString());
            return "" + e.toString();
        } catch (JSONException e) {
            //Log.e("JSON: ", "" + e.toString());
            return "" + e.toString();
        } finally {
            httpclient.getConnectionManager().shutdown();
        }
    }

    @Override
    protected void onPostExecute(String result){
        try {
            dialogo.dismiss();
        }catch (IllegalArgumentException ex){
            System.out.println("DIALOGO EXC fact: "+ ex.toString());
        }
         /*   AlertDialog.Builder dialogg = new AlertDialog.Builder(getmContext());
            dialogg.setTitle("Información Consultada");
            dialogg.setMessage(""+result);
            dialogg.setCancelable(false);
            dialogg.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialogo1, int id) {
                    dialogo1.dismiss();
                }
            });*/

        //publishProgress(result);
        adp.notifyDataSetChanged();
    }
}


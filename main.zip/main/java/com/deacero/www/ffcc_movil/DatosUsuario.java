package com.deacero.www.ffcc_movil;

public class DatosUsuario {
    private static String NombrePcMod;
    private static String ClaUsuarioMod;

    public DatosUsuario(String nombrePcMod, String claUsuarioMod) {
        NombrePcMod = nombrePcMod;
        ClaUsuarioMod = claUsuarioMod;
    }

    public String getNombrePcMod() {
        return NombrePcMod;
    }

    public void setNombrePcMod(String nombrePcMod) {
        NombrePcMod = nombrePcMod;
    }

    public String getClaUsuarioMod() {
        return ClaUsuarioMod;
    }

    public void setClaUsuarioMod(String claUsuarioMod) {
        ClaUsuarioMod = claUsuarioMod;
    }
}

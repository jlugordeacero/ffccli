package com.deacero.www.ffcc_movil.ModuloInspeccionMancomunada;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.ModuloLoteoUnidades.AddLoteoUnidadActivity;
import com.deacero.www.ffcc_movil.ModuloLoteoUnidades.LoteoUnidadAdapter;
import com.deacero.www.ffcc_movil.ModuloLoteoUnidades.LoteoUnidadVO;
import com.deacero.www.ffcc_movil.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class DetalleFotosActivity extends AppCompatActivity  {
    ///////BD
    BDFFCCMovil objBD= new BDFFCCMovil(this); //hace la conexión
    private Cursor c;



    private List<String> listId = new ArrayList<String>();//almaceno los claVias
    private List<String> listNames = new ArrayList<String>();//para almacenar los NomVia
    //DATOS SESSION USUARIO
    private String idUsuario,ClaEmpleado,loginUserName,token,DireccionMAC,ClaUbicacionLogin, idInspeccion, idInspeccionCfgDet;
    private GridView mGridV;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inspeccion_foto_previa);

        //vars
        idUsuario = getIntent().getExtras().getString("idUsuario");//ClaUsuarioMod
        ClaEmpleado = getIntent().getExtras().getString("ClaEmpleado");//Clave del empleado, la misma que el login
        loginUserName = getIntent().getExtras().getString("loginUserName");//Usuario
        token = getIntent().getExtras().getString("token");
        DireccionMAC = getIntent().getExtras().getString("DireccionMAC");
        ClaUbicacionLogin = getIntent().getExtras().getString("ClaUbicacion");
        idInspeccion = getIntent().getExtras().getString("idInspeccion");
        idInspeccionCfgDet = getIntent().getExtras().getString("idInspeccionCfgDet");

        mGridV = (GridView) findViewById(R.id.gridFoto);


       //Log.e("ID ",""+idInspeccion);
        c = objBD.getImagenesInspeccion(idInspeccion,idInspeccionCfgDet);
        if(c.getCount()>0) {
            c.moveToFirst();
            for (int i = 0; i < c.getCount(); i++) {
                if (c.getString(2) != null) {
                    Log.e("RUTA-->", "-->" + c.getString(2));
                    listId.add(c.getString(0));
                    listNames.add(c.getString(2));
                }
                c.moveToNext();
            }
        }
        c.close();
        objBD.CloseDB();
        mGridV.setAdapter(new ImageAdapter(getApplicationContext(),idInspeccion, listNames,listId));
    }

    public class ImageAdapter extends BaseAdapter implements OnClickListener {
        // Contexto de la aplicación
        private Context mContext;
        private String mInspeccion;
        private List<String> mlistNames = new ArrayList<String>();
        private List<String> mlistId = new ArrayList<String>();

        public ImageAdapter(Context c, String Inspeccion, List<String> Lista, List<String> ListaIds) {
            mContext = c;
            mInspeccion = Inspeccion;
            mlistNames = Lista;
            mlistId = ListaIds;
        }
        public String getList(int position){
            return mlistNames.get(position);
        }
        public String getListIds(int position){
            return mlistId.get(position);
        }
        public int getCount() {
            return mlistNames.size();
        }
        public Object getItem(int position) {
            return null;
        }
        public long getItemId(int position) {
            return 0;
        }

        public View getView(final int position, final View convertView, final ViewGroup parent) {
            final ImageView imageView;
            if (convertView == null) {
                imageView = new ImageView(mContext);
                imageView.setLayoutParams(new GridView.LayoutParams(620,620));
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            } else {
                imageView = (ImageView) convertView;
            }
            Uri imageUri2 = Uri.parse(getList(position));
            File file2 = new File(imageUri2.getPath());
            InputStream ims = null;
            if (file2.exists()) {
                try {
                    ims = new FileInputStream(file2);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                imageView.setId(position);
                imageView.setImageBitmap(BitmapFactory.decodeStream(ims));
                imageView.setOnClickListener(this);
            }
            return imageView;
        }


        @Override
        public void onClick(final View v) {
            final AlertDialog.Builder builder = new AlertDialog.Builder(DetalleFotosActivity.this);
            builder.setIcon(R.drawable.notify_dialog);
            builder.setTitle("¿Estas seguro de eliminar la imagen?");
            builder.setMessage("Acepta si deseas hacerlo.");
            builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                private Context context;
                @Override
                public void onClick(DialogInterface dialogInterface, int position) {
                        if(objBD.DeleteImgInspeccion(idInspeccion, mlistId.get(v.getId()))){
                            mlistId.remove(v.getId());
                            mlistNames.remove(v.getId());

                            notifyDataSetChanged();
                            Toast.makeText(DetalleFotosActivity.this,"La imagen se elimino satisfactoriamente.",Toast.LENGTH_LONG).show();
                        }
                        objBD.close();
                }
            });
            builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                }
            });
            builder.show();
        }
    }

}

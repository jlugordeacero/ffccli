package com.deacero.www.ffcc_movil.ModuloInspeccionMancomunada;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.Html;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.MenuActivity;
import com.deacero.www.ffcc_movil.R;
import com.deacero.www.ffcc_movil.metodos.AuthenticationWS2;
import com.deacero.www.ffcc_movil.metodos.GetCarrosWS;
import com.deacero.www.ffcc_movil.metodos.PostInspeccionWS;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class InspeccionMancomunadaActivity extends AppCompatActivity {
    ///////BD
    BDFFCCMovil objBD= new BDFFCCMovil(this); //hace la conexión
    private Cursor c, c2, c3;
    private ArrayList<SituadoVO> listSituado = new ArrayList<SituadoVO>();;
    private ArrayList<AddSituadoVO> listAddSituado = new ArrayList<AddSituadoVO>();;
    private RecyclerView recyclerSituados;
    private String respuesta;

    //DATOS SESSION USUARIO
    private String idUsuario,ClaEmpleado,NombreUsuario,loginUserName, ClaUbicacionLogin, MAC, token, Password;
    private Toast toast;
    private EditText editTextPlaca;
    private ImageButton imgBotonAdd;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inspeccion_mancomunada_activity);
        idUsuario = getIntent().getExtras().getString("idUsuario");
        ClaEmpleado = getIntent().getExtras().getString("ClaEmpleado");
        NombreUsuario = getIntent().getExtras().getString("NombreUsuario");
        loginUserName = getIntent().getExtras().getString("loginUserName");
        ClaUbicacionLogin = getIntent().getExtras().getString("ClaUbicacion");
        token = getIntent().getExtras().getString("token");
        MAC = getIntent().getExtras().getString("DireccionMAC");
        //System.out.println("MAC INSPECCION "+MAC);
        recyclerSituados =(RecyclerView)findViewById(R.id.recyclersituados);
        editTextPlaca = (EditText) findViewById(R.id.txtSearchPlaca);
        editTextPlaca.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                if(editTextPlaca.getText().length() >= 1) {
                    recyclerSituados.removeAllViewsInLayout();
                    listSituado.clear();
                    recyclerSituados.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                    consulta2(editTextPlaca.getText().toString());
                    Situado sit = new Situado(listSituado, ClaUbicacionLogin,loginUserName,MAC,idUsuario);
                    recyclerSituados.setAdapter(sit);
                }else{
                    recyclerSituados.removeAllViewsInLayout();
                    listSituado.clear();
                    recyclerSituados.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                    consulta();
                    Situado sit = new Situado(listSituado, ClaUbicacionLogin,loginUserName,MAC,idUsuario);
                    recyclerSituados.setAdapter(sit);
                }
            }
        });
        imgBotonAdd = (ImageButton) findViewById(R.id.btnBuscarPlaca);
        imgBotonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(InspeccionMancomunadaActivity.this);
                builder.setIcon(R.drawable.notify_dialog);
                builder.setTitle(Html.fromHtml("<h1>!***** AVISO *****¡</h1>"));
                builder.setMessage(Html.fromHtml("<h2>¿Estas seguro de agregar la placa <font color='#FF0000'></b>"+
                        editTextPlaca.getText()+ "</b></font>?</h2> "));
                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String PlacaCarroNueva = editTextPlaca.getText().toString();
                        String IdConfigInspeccion,ClaTipoInspeccion="1",sRechaza="0",Reutiliza="0",AlturaInterna="null",AnchoInterno="null",LongitudInterna="null",PesoMaximo="null";
                        IdConfigInspeccion = objBD.getIdConfigInspeccion(ClaUbicacionLogin,"1");
                        boolean cancel = false;
                        View focusView = null;
                        // Check for a valid user.
                        if (TextUtils.isEmpty(PlacaCarroNueva)) {
                            editTextPlaca.setError(getString(R.string.error_field_required));
                            focusView = editTextPlaca;
                            cancel = true;
                        } else {
                            int total = objBD.validaPlacaBitSituadoTipoInspeccion(""+PlacaCarroNueva.replace(" ",""),"1", "1");
                            if(total == 0) {
                                respuesta = objBD.insertBitSituado("-1", "-1", "" + PlacaCarroNueva.replace(" ",""), "" + ClaUbicacionLogin, "" + IdConfigInspeccion, "1" , "" + sRechaza, "" + Reutiliza, "" + AlturaInterna, "" + AnchoInterno, "" + LongitudInterna, "" + PesoMaximo, MAC,"1");
                                int total2 = objBD.getFoundCarro(PlacaCarroNueva.replace(" ",""));
                                if(total2 > 0){
                                   /*if (toast!= null) { toast.cancel(); }
                                    toast = Toast.makeText(getApplicationContext(),"La placa "+ PlacaCarroNueva +" ya existe\n" +
                                            " "+objBD.getDataPlacaCarro(PlacaCarroNueva.replace(" ","")), Toast.LENGTH_LONG);
                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                    toast.show();*/
                                }else {
                                    //editTextPlaca.setText("");
                                    String Fecha = "";
                                    Date date = new Date();
                                    date.setDate(date.getDate()-1);
                                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                    Fecha= dateFormat.format(date);
                                    //Log.e("Fecha ",""+Fecha);
                                    objBD.InsertarFfccCatCarroVw("-1", PlacaCarroNueva.replace(" ",""), "NULL", "NULL"
                                            , "NULL", "NULL", "NULL", ""+Fecha, MAC, idUsuario, "-1", "0", "1", ""+Fecha, "NULL",""+ClaUbicacionLogin);
                                    // recyclerSituados.setLayoutManager(new GridLayoutManager(getApplicationContext(),2));
                                }
                                recyclerSituados.removeAllViewsInLayout();
                                listSituado.clear();
                                //listAddSituado.clear();
                                recyclerSituados.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                                // recyclerSituados.setLayoutManager(new GridLayoutManager(getApplicationContext(),2));
                                consulta2(editTextPlaca.getText().toString().replace(" ",""));
                                //AddSituado sit = new AddSituado(InspeccionMancomunadaActivity.this, listAddSituado,MAC ,idUsuario,loginUserName, ClaUbicacionLogin);
                                Situado sit = new Situado(listSituado, ClaUbicacionLogin,loginUserName,MAC,idUsuario);
                                recyclerSituados.setAdapter(sit);
                                if (toast!= null) { toast.cancel(); }
                                toast = Toast.makeText(getApplicationContext(),""+respuesta, Toast.LENGTH_LONG);
                                toast.setGravity(Gravity.CENTER, 0, 0);
                                toast.show();
                            }else{
                                if (toast!= null) { toast.cancel(); }
                                toast = Toast.makeText(getApplicationContext(),"La Placa "+ PlacaCarroNueva +"  aún esta disponible para inspeccionar.", Toast.LENGTH_LONG);
                                toast.setGravity(Gravity.CENTER, 0, 0);
                                toast.show();
                            }
                        }
                    }
                });
                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                builder.show();
            }
        });
        recyclerSituados.removeAllViewsInLayout();
        listSituado.clear();
        recyclerSituados.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        consulta();
        Situado sit = new Situado(listSituado,ClaUbicacionLogin,loginUserName,MAC,idUsuario);
        recyclerSituados.setAdapter(sit);


            c = objBD.getUserXLoginUser(loginUserName);
            if (c.getCount() > 0) {
                c.moveToFirst();
                Password = c.getString(4);
            }
            c.close();
            AuthenticationWS2 AuthWS = new AuthenticationWS2(InspeccionMancomunadaActivity.this, getString(R.string.ip_authentication), loginUserName, Password, MAC, "0");
            String respuesta = String.valueOf(AuthWS.execute(""));
            c2 = objBD.getUserXLoginUser(loginUserName);
            if (c2.getCount() > 0) {
                c2.moveToFirst();
                token = c2.getString(8);
            }
            c2.close();
            //objBD.close();
            GetCarrosWS WSCarros = new GetCarrosWS(InspeccionMancomunadaActivity.this,
                    token,
                    getString(R.string.IpGetCarros),
                    ClaUbicacionLogin,
                    MAC);
            WSCarros.execute("");

        try {
            c3 = objBD.getSituado("2","%","1");///a 2 porque son las placas que ya se han guardado
        } catch (Exception e) {
            e.printStackTrace();
        }
        c3.moveToFirst();            //va a act a 3 cuando se haya registrado con success
        if(c3.getCount()>0) {
            PostInspeccionWS WSSendInspeccion = new PostInspeccionWS(InspeccionMancomunadaActivity.this,
                    token, getString(R.string.IpPostInspeccionCarro),
                    ClaUbicacionLogin,
                    idUsuario,
                    MAC);
            WSSendInspeccion.execute("");
        }
        c3.close();
        objBD.close();
    }

    @Override
    public void onRestart() {
        super.onRestart(); //Toast.makeText(this,"restart ins",Toast.LENGTH_SHORT).show();
        recyclerSituados.removeAllViewsInLayout();
        listSituado.clear();
        recyclerSituados.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        consulta();
        Situado sit = new Situado(listSituado, ClaUbicacionLogin,loginUserName,MAC,idUsuario);
        recyclerSituados.setAdapter(sit);
    }

    private  void consulta() {
        try {
            c = objBD.getSituado("1","%","1");
            c.moveToFirst();
            if(c.getCount()>0) {
                for (int x = 0; x < c.getCount(); x++) {
                    String ID =  c.getString(0);
                    //Log.e("IDCONFIGINSPECCIONADOs","--"+ID);
                    String ClaCarro = c.getString(2);
                    String PlacaCarro = c.getString(3);
                    int Rechaza = Integer.parseInt(c.getString(6));
                    listSituado.add(new SituadoVO(ID,ClaCarro, PlacaCarro, Rechaza,R.drawable.next,InspeccionMancomunadaActivity.this));
                    c.moveToNext();
                }
            }else{
                if (toast!= null) { toast.cancel(); }
                toast = Toast.makeText(getApplicationContext(),"No Hay placas para inspeccionar.", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }
            c.close();
            objBD.CloseDB();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private  void consulta2(String Placa) {
        try {
            c = objBD.getSituado("1",Placa,"1");
            c.moveToFirst();
            if(c.getCount()>0) {
                for (int x = 0; x < c.getCount(); x++) {
                    String ID =  c.getString(0);
                    //Log.e("IDCONFIGINSPECCIONADOs","--"+ID);
                    String ClaCarro = c.getString(2);
                    String PlacaCarro = c.getString(3);
                    int Rechaza = Integer.parseInt(c.getString(6));
                    listSituado.add(new SituadoVO(ID,ClaCarro, PlacaCarro, Rechaza,R.drawable.next,InspeccionMancomunadaActivity.this));
                    c.moveToNext();
                }
            }
            else{
                Toast toast = Toast.makeText(getApplicationContext(),"No se encontraron registros.", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }
            c.close();
            objBD.CloseDB();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_insmancomunada, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.itmreturn:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
package com.deacero.www.ffcc_movil.ModuloInspeccionMancomunada;

import android.content.Context;

public class ConfigSituadoVO {
    private String IdInsCarro, IdConfig;
    private String IdConfigDet, NomConfig;
    private int Rechaza, Reutiliza;
    private int switchs;
    private Context context;

    public ConfigSituadoVO(String idInsCarro, String idConfig, String idConfigDet, String nomConfig, int rechaza, int reutiliza, int switchs, Context context) {
        IdInsCarro = idInsCarro;
        IdConfig = idConfig;
        IdConfigDet = idConfigDet;
        NomConfig = nomConfig;
        Rechaza = rechaza;
        Reutiliza = reutiliza;
        this.switchs = switchs;
        this.context = context;
    }

    public String getIdInsCarro() {
        return IdInsCarro;
    }

    public void setIdInsCarro(String idInsCarro) {
        IdInsCarro = idInsCarro;
    }

    public String getIdConfig() {
        return IdConfig;
    }

    public void setIdConfig(String idConfig) {
        IdConfig = idConfig;
    }

    public String getIdConfigDet() {
        return IdConfigDet;
    }

    public void setIdConfigDet(String idConfigDet) {
        IdConfigDet = idConfigDet;
    }

    public String getNomConfig() {
        return NomConfig;
    }

    public void setNomConfig(String nomConfig) {
        NomConfig = nomConfig;
    }

    public int getRechaza() {
        return Rechaza;
    }

    public void setRechaza(int rechaza) {
        Rechaza = rechaza;
    }

    public int getReutiliza() {
        return Reutiliza;
    }

    public void setReutiliza(int reutiliza) {
        Reutiliza = reutiliza;
    }

    public int getSwitchs() {
        return switchs;
    }

    public void setSwitchs(int switchs) {
        this.switchs = switchs;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }
}

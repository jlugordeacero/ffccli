package com.deacero.www.ffcc_movil.ModuloInspeccionMancomunada;

import android.content.Context;

public class AddSituadoVO {
    private String IdPlaca, Placa, IdInspeccionCarro;
    private int foto;
    private Context context;

    public AddSituadoVO(String idInspeccionCarro,String idPlaca, String placa, int foto,Context context) {
        IdPlaca = idPlaca;
        Placa = placa;
        this.foto = foto;
        this.context = context;
        this.IdInspeccionCarro = idInspeccionCarro;
    }

    public String getIdInspeccionCarro() {
        return IdInspeccionCarro;
    }

    public void setIdInspeccionCarro(String idInspeccionCarro) {
        IdInspeccionCarro = idInspeccionCarro;
    }

    public String getIdPlaca() {
        return IdPlaca;
    }

    public void setIdPlaca(String idPlaca) {
        IdPlaca = idPlaca;
    }

    public String getPlaca() {
        return Placa;
    }

    public void setPlaca(String placa) {
        Placa = placa;
    }

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }
}

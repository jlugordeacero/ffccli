package com.deacero.www.ffcc_movil.ModuloInspeccionMancomunada;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.InputFilter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.R;
import com.deacero.www.ffcc_movil.metodos.AuthenticationWS2;
import com.deacero.www.ffcc_movil.metodos.PostInspeccionWS;

import java.util.ArrayList;

public class Situado extends RecyclerView.Adapter<Situado.ViewHolderSituado> implements View.OnClickListener{
    BDFFCCMovil objBD;
    private ArrayList<SituadoVO> listaSituados;
    private View.OnClickListener listener;
    private AlertDialog dialog;
    private Context mContext;
    private String ClaUbicacionLogin, LoginUserName, MAC, idUsuario;
    public Situado(ArrayList<SituadoVO> listaSituados, String claUbicacionLogin, String loginUserName, String mAC, String idUsuario) {
        this.listaSituados = listaSituados;
        ClaUbicacionLogin = claUbicacionLogin;
        LoginUserName = loginUserName;
        MAC = mAC;
        this.idUsuario = idUsuario;
    }

    public String getClaUbicacionLogin() {
        return ClaUbicacionLogin;
    }

    public void setClaUbicacionLogin(String claUbicacionLogin) {
        ClaUbicacionLogin = claUbicacionLogin;
    }

    @NonNull
    @Override
    public ViewHolderSituado onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list_situados,null,false);
        view.setOnClickListener(this);
        return new ViewHolderSituado(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolderSituado viewHolderSituado, final int i) {
        viewHolderSituado.etiIdPlaca.setText(listaSituados.get(i).getIdPlaca());
        viewHolderSituado.EtiPlaca.setText(listaSituados.get(i).getPlaca());
        viewHolderSituado.ImgNext.setImageResource(listaSituados.get(i).getFoto());
       // Log.e("valorRechazadoBEFORE","--"+listaSituados.get(i).getRechaza());
        if(listaSituados.get(i).getRechaza()==1){
           // Log.e("valorRechazadoAFTER","--"+listaSituados.get(i).getRechaza());
            viewHolderSituado.checkBox.setTextColor(Color.parseColor("#FF0000"));
            viewHolderSituado.checkBox.setChecked(true);
            viewHolderSituado.checkBox.setText("Rechazado");
        }
    }

    @Override
    public int getItemCount() {
        return listaSituados.size();
    }

    public void setOnClickListener(View.OnClickListener listener){
        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        if(listener!=null){
            listener.onClick(v);
        }
    }

    public class ViewHolderSituado extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView etiIdPlaca, EtiPlaca, TextRechaza, edObservciones;
        ImageView ImgNext;
        CheckBox checkBox;
        ImageButton imgValidarReglasLlegada, DeleteInspeccion;

        public ViewHolderSituado(@NonNull View itemView) {
            super(itemView);
            etiIdPlaca=(TextView) itemView.findViewById(R.id.txtidplaca);
            EtiPlaca=(TextView) itemView.findViewById(R.id.txtplaca);
            ImgNext= (ImageView) itemView.findViewById(R.id.IdImagen);
            //TextRechaza= (TextView)itemView.findViewById(R.id.txtstatusRechazo);
            checkBox = (CheckBox) itemView.findViewById(R.id.txtstatusRechazo);
            imgValidarReglasLlegada = (ImageButton) itemView.findViewById(R.id.ValidaReglasLlegada);
            DeleteInspeccion = (ImageButton) itemView.findViewById(R.id.eliminarInspeccion);
            edObservciones = (TextView) itemView.findViewById(R.id.txtObservaciones);
            DeleteInspeccion.setOnClickListener(this);
            ImgNext.setOnClickListener(this);
            //imgValidarReglasLlegada.setOnClickListener(this);
            edObservciones.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            final int newPosition = getAdapterPosition();
            objBD = new BDFFCCMovil(listaSituados.get(newPosition).getContext());
            switch (v.getId()){
                case R.id.eliminarInspeccion:
                    final AlertDialog.Builder builder = new AlertDialog.Builder(listaSituados.get(newPosition).getContext());
                    builder.setIcon(R.drawable.notify_dialog);
                    builder.setTitle("¿Estas seguro de eliminar esta inspección?");
                    builder.setMessage("Placa: "+listaSituados.get(newPosition).getPlaca());
                    builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            objBD.DeleteSituadoDetyFoto(listaSituados.get(newPosition).getIdInspeccionCarro(),"0");
                            listaSituados.remove(newPosition);
                            notifyItemRemoved(newPosition);
                            notifyItemRangeChanged(newPosition, listaSituados.size());
                            notifyDataSetChanged();

                            }
                    });
                    builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    builder.show();
                    break;
                case R.id.IdImagen:
                    //add here code source for add detail of inspeccion

                    //System.out.println(""+listaAddSituados.get(pos).getIdInspeccionCarro()+" - "+listaAddSituados.get(pos).getIdPlaca()+" -  "+listaAddSituados.get(pos).getPlaca()+"  1");
                    objBD.updateEstatusSituado(listaSituados.get(newPosition).getIdInspeccionCarro(),listaSituados.get(newPosition).getPlaca(),"1","1");
                            try {

                                int total = objBD.existeDetalleInspeccion(listaSituados.get(newPosition).getIdInspeccionCarro());
                                Log.e("total: ", String.valueOf(total));
                                if(total == 0) {
                                    String IDCONFIGINSCARRO = objBD.getMaxTraInspecCarro(listaSituados.get(newPosition).getIdPlaca(), listaSituados.get(newPosition).getPlaca(), "1", "1");
                                    objBD.InsertarConfiguracionesPlacaDetalle("" + listaSituados.get(newPosition).getIdPlaca(), listaSituados.get(newPosition).getPlaca(),
                                            IDCONFIGINSCARRO, "0", "0", "1", "1");
                                }
                                objBD.CloseDB();


                                Intent intentDetalleInsManc = new Intent(listaSituados.get(newPosition).getContext(),DetalleInspeccionMancomunadaActivity.class);
                                intentDetalleInsManc.putExtra("IdPlaca", String.valueOf(listaSituados.get(newPosition).getIdPlaca()));
                                intentDetalleInsManc.putExtra("Placa", String.valueOf(listaSituados.get(newPosition).getPlaca()));
                                intentDetalleInsManc.putExtra("IdInspeccionCarro", String.valueOf(listaSituados.get(newPosition).getIdInspeccionCarro()));
                                intentDetalleInsManc.putExtra("ClaUbicacionLogin",  getClaUbicacionLogin());
                                intentDetalleInsManc.putExtra("loginUserName", LoginUserName);
                                intentDetalleInsManc.putExtra("idUsuario", idUsuario);
                                intentDetalleInsManc.putExtra("MAC",  MAC);
                                listaSituados.get(newPosition).getContext().startActivity(intentDetalleInsManc);

                            } catch (Exception e) {
                                e.printStackTrace();
                            }



                    break;
                case R.id.ValidaReglasLlegada:

                    String TipoUnidad = objBD.getTipoUnidadFn(""+listaSituados.get(newPosition).getPlaca().replace(" ", ""));
                    System.out.println("PLACA: "+listaSituados.get(newPosition).getPlaca()+" *************TIPO UNIDAD ************* "+TipoUnidad);
                    final CharSequence[] items = {" Capacidad minima "," Alto minimo "," Largo minimo "," Ancho minimo "};


                    //Fuente: https://www.iteramos.com/pregunta/33680/arrayliststring-a-charsequence
                    // arraylist to keep the selected items
                    final ArrayList seletedItems=new ArrayList();

                    final AlertDialog.Builder builder3 = new AlertDialog.Builder(listaSituados.get(newPosition).getContext());
                    builder3.setTitle("Validación de Reglas de Llegada, Placa:"+  String.valueOf(listaSituados.get(newPosition).getPlaca()));
                    builder3.setMultiChoiceItems(items, null,
                            new DialogInterface.OnMultiChoiceClickListener() {
                                // indexSelected contains the index of item (of which checkbox checked)
                                @Override
                                public void onClick(DialogInterface dialog, int indexSelected,
                                                    boolean isChecked) {
                                    if (isChecked) {
                                        seletedItems.add(indexSelected);
                                        System.out.println("ITEM SELECTED "+ items[indexSelected].toString() +" - " );
                                    } else if (seletedItems.contains(indexSelected)) {
                                        seletedItems.remove(Integer.valueOf(indexSelected));

                                    }
                                }
                            })
                            // Set the action buttons
                            .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int id) {
                                    System.out.println("****** TAMAÑO ELEMENTOS SELECCIONADOS    "+ seletedItems.size());
                                    if(seletedItems.size() == 4){
                                        objBD.UpdateEstatusCarro(""+listaSituados.get(newPosition).getIdInspeccionCarro(),"0");
                                        listaSituados.get(newPosition).setRechaza(0);

                                    }else{
                                        objBD.UpdateEstatusCarro(""+listaSituados.get(newPosition).getIdInspeccionCarro(),"1");
                                        listaSituados.get(newPosition).setRechaza(1);


                                    }

                                    notifyItemChanged(newPosition);
                                    notifyDataSetChanged();

                                }
                            })
                            .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int id) {
                                }
                            });
                    dialog = builder3.create();//AlertDialog dialog; create like this outside onClick
                    dialog.show();
                    break;

                case R.id.txtObservaciones:
                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(listaSituados.get(newPosition).getContext());
                    alertDialog.setTitle("Observaciones");
                    alertDialog.setMessage("Agrega Observaciones para la placa: "+listaSituados.get(newPosition).getPlaca());

                    final EditText input = new EditText(listaSituados.get(newPosition).getContext());
                    int maxLength = 300;
                    input.setFilters(new InputFilter[] {new InputFilter.LengthFilter(maxLength)});


                    input.setText(""+objBD.getObservaciones(""+listaSituados.get(newPosition).getIdInspeccionCarro()));

                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.MATCH_PARENT);
                    input.setLayoutParams(lp);
                    alertDialog.setView(input); // uncomment this line


                    alertDialog.setPositiveButton("Guardar",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    System.out.println("***************** OBS ******************** "+input.getText().toString());
                                    objBD.UpdateObservaciones(input.getText().toString(),listaSituados.get(newPosition).getIdInspeccionCarro());
                                    objBD.close();
                                }
                            });

                    alertDialog.setNegativeButton("Cancelar",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            });

                    alertDialog.show();

                    break;
            }
        }
    }
}

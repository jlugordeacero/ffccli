package com.deacero.www.ffcc_movil.ModuloServicioColocacion;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.ModuloDisenoServicio.TablaEquipoRequerido;
import com.deacero.www.ffcc_movil.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class EditarColocacionActivity2 extends AppCompatActivity implements View.OnClickListener{

    ///////BD
    BDFFCCMovil objBD= new BDFFCCMovil(this); //hace la conexión
    private Cursor c, c2;
    private RecyclerView recyclerTraControlUnidad,recyclerEditUniColoc;
    private TableLayout mytabla; // Layout donde se pintará la tabla
    private EditText EtxtSearchPlaca;
    private ArrayList<ColocacionCarrosVO> listaTraControlUnidad = new ArrayList<ColocacionCarrosVO>();
    //DATOS SESSION configuracion
    private String IdTraSolicitudServicio, ClaConfServiciosP,ClaConfVentanaP, ClaUbicacionP, IdColocacionSqlite, IdColocacionSQLServer, MAC, ClaCarroColocado, ClaUsuarioMod;

    private static final String CERO = "0";
    private static final String BARRA = "/";
    private Toast toast;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
    private Date date = new Date();
    private String fecha="";


    private ImageButton addPlacaNueva;

    private String ClienteInterno="";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editar_colocacion2);
        mytabla = (TableLayout) findViewById(R.id.TablaEquipoRequerido);
        IdTraSolicitudServicio = getIntent().getExtras().getString("ClaCfgSolicitudServicio");
        ClaConfServiciosP = getIntent().getExtras().getString("ClaConfServicios");
        ClaConfVentanaP = getIntent().getExtras().getString("ClaConfVentana");
        ClaUbicacionP = getIntent().getExtras().getString("ClaUbicacion");
        IdColocacionSqlite = getIntent().getExtras().getString("IdColocacion");
        IdColocacionSQLServer = getIntent().getExtras().getString("IdColocacionSqlServer");
        ClaCarroColocado = getIntent().getExtras().getString("ClaCarroColocado");
        MAC = getIntent().getExtras().getString("MAC");
        ClaUsuarioMod = getIntent().getExtras().getString("ClaUsuarioMod");

        recyclerTraControlUnidad = (RecyclerView) findViewById(R.id.recyclerBuscarPlaca);
        recyclerEditUniColoc = (RecyclerView) findViewById(R.id.recyclerEditarColocados);

        addPlacaNueva = (ImageButton) findViewById(R.id.addPlacaNueva);

        EtxtSearchPlaca = (EditText) findViewById(R.id.txtSearchPlaca);

        addPlacaNueva.setOnClickListener(this);

        //obtener el detalle
        if (!IdTraSolicitudServicio.isEmpty()) {
            c = objBD.getEquipoRequerido(IdTraSolicitudServicio);
            c.moveToFirst();
            mytabla.removeAllViews();
            TablaEquipoRequerido tabla = new TablaEquipoRequerido(this,mytabla);
            ArrayList<String> valorescabecera = new ArrayList<String>();
            valorescabecera.add("Tipo Unidad");
            valorescabecera.add("Material");
            valorescabecera.add("Cantidad");
            valorescabecera.add("Tapas");
            tabla.agregarCabecera(valorescabecera);
            ArrayList<String> elementos = new ArrayList<String>();
            for(int i = 0; i < c.getCount(); i++)
            {///se pintan los renglones
                elementos.add( c.getString(4).replace("null","").replace("",""));
                elementos.add( c.getString(5).replace("null","").replace("",""));
                elementos.add( c.getString(2).replace("null","").replace("",""));//cantidad
                elementos.add( c.getString(3).replace("null","").replace("",""));//tapas
                tabla.agregarFilaTabla(elementos);
                elementos.clear();
                c.moveToNext();
            }
            objBD.close();
            c.close();
        }

        EtxtSearchPlaca.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                if(EtxtSearchPlaca.getText().length() >= 2) {
                    LimpiarRecicleryListaBusqueda();
                    recyclerTraControlUnidad.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                    consultaBusqueda(EtxtSearchPlaca.getText().toString().replace(" ","").toUpperCase());
                    ColocacionCarrosAdapter adapterCarros = new ColocacionCarrosAdapter(EditarColocacionActivity2.this,listaTraControlUnidad, ClaUbicacionP,MAC,""+ClaUsuarioMod);
                    recyclerTraControlUnidad.setAdapter(adapterCarros);
                    recyclerTraControlUnidad.setNestedScrollingEnabled(false);
                }
            }
        });



        LimpiarRecicleryListaBusqueda();
        recyclerTraControlUnidad.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        consultaBusqueda("%");
        ColocacionCarrosAdapter adapterCarros = new ColocacionCarrosAdapter(EditarColocacionActivity2.this,listaTraControlUnidad, ClaUbicacionP,MAC,""+ClaUsuarioMod);
        recyclerTraControlUnidad.setAdapter(adapterCarros);
        recyclerTraControlUnidad.setNestedScrollingEnabled(false);
    }

    public void LimpiarRecicleryListaBusqueda(){
        recyclerTraControlUnidad.removeAllViewsInLayout();
        listaTraControlUnidad.clear();
    }

    private  void consultaBusqueda(String Placa) {
        BDFFCCMovil objBD= new BDFFCCMovil(this); //hace la conexión
        try {
            c = objBD.getFfccTraControlUnidad(Placa, "1");
            c.moveToFirst();
            if(c.getCount()>0) {
                for (int x = 0; x < c.getCount(); x++) {
                   // System.out.println("UBICACION--->"+c.getString(8));
                    ClienteInterno=c.getString(4);
                    listaTraControlUnidad.add(new ColocacionCarrosVO(""+c.getString(2), ""+c.getString(0), ""+c.getString(1), ""+c.getString(5),""+c.getString(8),IdTraSolicitudServicio, ClaConfServiciosP, ClaConfVentanaP,""+c.getString(3),""+c.getString(7),""+c.getString(9)));
                    c.moveToNext();
                }
                c.close();
                objBD.CloseDB();
            }
            else{
                if (toast!= null) { toast.cancel(); }
                toast = Toast.makeText(getApplicationContext(),"No se encontraron registros.", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add_insmancomunada, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.itmreturn:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.addPlacaNueva:
                AlertDialog.Builder builder = new AlertDialog.Builder(EditarColocacionActivity2.this);
                builder.setIcon(R.drawable.notify_dialog);
                builder.setTitle(Html.fromHtml("<h1>!***** AVISO *****¡</h1>"));
                builder.setMessage(Html.fromHtml("<h2>¿Estas seguro de agregar la placa <font color='#FF0000'></b>"+
                        EtxtSearchPlaca.getText().toString().replace(" ","").toUpperCase()+ "</b></font>?</h2> "));
                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //add para cambiar estatus en tracontrolunidad a 1 = Colocado

                        //;
                        //objBD.InsertarFfccCatCarroVw("-1",""+EtxtSearchPlaca.getText().toString(),""+objBD.getTipoUnidadFn(EtxtSearchPlaca.getText().toString()),"0","0","0","0","DateTime('now')",""+MAC,""+ClaUsuarioMod,"-1","0","1","DateTime('now')","");
                        int total = objBD.getFoundCarro(""+EtxtSearchPlaca.getText().toString().replace(" ","").toUpperCase());
                        if(total > 0){
                            if (toast!= null) { toast.cancel(); }
                            toast = Toast.makeText(getApplicationContext(),"La placa ya existe", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                        }else {
                            String Fecha = "";

                            Date date = new Date();
                            date.setDate(date.getDate()-1);
                            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                            Fecha= dateFormat.format(date);
                            Log.e("Fecha ",""+Fecha);
                            objBD.InsertCatCarro("-1", "" + EtxtSearchPlaca.getText().toString().replace(" ","").toUpperCase(), "null", "null", "null", "null", "-1", "0", "1", "null", "null", "null", ""+Fecha, "", "" + ClaUbicacionP,"","null","null");

                            LimpiarRecicleryListaBusqueda();
                            recyclerTraControlUnidad.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                            consultaBusqueda(EtxtSearchPlaca.getText().toString().replace(" ","").toUpperCase());
                            ColocacionCarrosAdapter adapterCarros = new ColocacionCarrosAdapter(EditarColocacionActivity2.this,listaTraControlUnidad, ClaUbicacionP,MAC,""+ClaUsuarioMod);
                            recyclerTraControlUnidad.setAdapter(adapterCarros);
                            recyclerTraControlUnidad.setNestedScrollingEnabled(false);
                        }

                    }
                });
                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();
                break;
        }
    }


}

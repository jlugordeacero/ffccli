package com.deacero.www.ffcc_movil.ModuloServicioColocacion;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.R;
import com.deacero.www.ffcc_movil.metodos.AuthenticationWS2;
import com.deacero.www.ffcc_movil.metodos.GetCarrosColocadosWS;
import com.deacero.www.ffcc_movil.metodos.Internet;
import com.deacero.www.ffcc_movil.metodos.PostColocacionWS;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class RegistroColocacionServicioActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener{
    ///////BD
    BDFFCCMovil objBD= new BDFFCCMovil(this); //hace la conexión
    private Cursor c;
    public static final String LLAVE_ENCRIPTAR = "deacero";
    //elementos interfaz gráfica
    private RecyclerView recyclerAdpColocUnidad;
    private Spinner spinnerViaOri, spinnerCliInt;
    private ImageButton imgBtnCalendario;
    private TextView EdTxtFecha;
    private ArrayList<ServicioColocacionVO> listColocacion = new ArrayList<ServicioColocacionVO>();
    private List<String> listId = new ArrayList<String>(),listNames = new ArrayList<String>();//para almacenar los NomVia
    private List<String> listCI = new ArrayList<String>();//para almacenar los NomVia
    //DATOS SESSION USUARIO y variables
    private String idUsuario,ClaEmpleado,NombreUsuario,loginUserName, ClaUbicacionLogin, MAC, token,Password, fecha, ClaVia, diaFormateado,mesFormateado, cliente, vias;
    private String[] Cliente, Vias;
    //Calendario para obtener fecha & hora
    private DatePickerDialog recogerFecha;
    public final Calendar ca = Calendar.getInstance();
    private static final String CERO = "0", BARRA = "/",GUION = "-";
    final int mes =  ca.get(Calendar.MONTH), dia = ca.get(Calendar.DAY_OF_MONTH), anio = ca.get(Calendar.YEAR);
    //
    private ArrayAdapter<String> AdpViaOri, AdpCI;
    private SimpleDateFormat dateFormat;
    private Date date;
    private Toast toast;
    private int posVia, posCI, mesActual;
    //servicios para comunicacion con api
    private Internet internet;
    private AuthenticationWS2 AuthWS;
    private PostColocacionWS WSSendColocacion;
    private GetCarrosColocadosWS WSCarrosColocadosSRV;
    private ServicioColocacionAdapter AdpColoc;
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registro_colocacion_servicio_activity);
        idUsuario = getIntent().getExtras().getString("idUsuario");
        ClaEmpleado = getIntent().getExtras().getString("ClaEmpleado");
        NombreUsuario = getIntent().getExtras().getString("NombreUsuario");
        loginUserName = getIntent().getExtras().getString("loginUserName");
        ClaUbicacionLogin  = getIntent().getExtras().getString("ClaUbicacion");
        MAC = getIntent().getExtras().getString("DireccionMAC");
        spinnerViaOri = (Spinner) findViewById(R.id.spinnerViaOrigen);
        spinnerCliInt= (Spinner) findViewById(R.id.spinnerClienteInterno);
        EdTxtFecha = (TextView) findViewById(R.id.edTxtFecha);
        imgBtnCalendario = (ImageButton)findViewById(R.id.imgBtnCalendar);
        recyclerAdpColocUnidad = (RecyclerView) findViewById(R.id.recyclercolocacion);
        spinnerViaOri.setOnItemSelectedListener(this);
        spinnerCliInt.setOnItemSelectedListener(this);
        imgBtnCalendario.setOnClickListener(this);
        c = objBD.getViaConCI(ClaUbicacionLogin);
        c.moveToFirst();
        if (c.moveToFirst()) {
            do {
                listId.add(c.getString(1));//adding ClaVia
                listNames.add(c.getString(2));//adding NomVia
            } while (c.moveToNext());
        }
        c.close();
        objBD.close();
        AdpViaOri = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listNames);
        AdpViaOri.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spinnerViaOri.setAdapter(AdpViaOri);
        spinnerViaOri.setSelected(true);
        dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        date = new Date();
        fecha = dateFormat.format(date);
        EdTxtFecha.setText(fecha);
        EdTxtFecha.setEnabled(false);
        recyclerAdpColocUnidad.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        c = objBD.getUserXLoginUser(loginUserName);
        if(c.getCount()>0){
            c.moveToFirst();
            Password = c.getString(4);
        }
        c.close();
        internet = new Internet(getApplicationContext());
        if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
            AuthWS = new AuthenticationWS2(RegistroColocacionServicioActivity.this, getString(R.string.ip_authentication), loginUserName, "" + Password, MAC, "0");
            AuthWS.execute("");
            c = objBD.getUserXLoginUser(loginUserName);
            if (c.getCount() > 0) {
                c.moveToFirst();
                token = c.getString(8);
            }
            c.close();
            c = objBD.getColocaciones("3");///a 3 porque se enviaran todas las que seas iguales a 3 colocacion terminada
            c.moveToFirst();
            if(c.getCount()>0) {
                WSSendColocacion = new PostColocacionWS(RegistroColocacionServicioActivity.this, token, getString(R.string.IpPostColocacion), ClaUbicacionLogin, idUsuario, MAC);
                WSSendColocacion.execute("");
            }
            c.close();                                                                                                                                                                                     //"yyyy-MM-dd"
            WSCarrosColocadosSRV = new GetCarrosColocadosWS(RegistroColocacionServicioActivity.this, token, getString(R.string.IpGetColocacionDiseno), ClaUbicacionLogin, EdTxtFecha.getText().toString());
            WSCarrosColocadosSRV.execute("");
            objBD.close();
        }
    }

    public void limpiaRecycleryLista(){
        recyclerAdpColocUnidad.removeAllViewsInLayout();
        listColocacion.clear();
    }

    @Override
    public void onRestart() {
        super.onRestart(); //Toast.makeText(this,"restart ins",Toast.LENGTH_SHORT).show();
        limpiaRecycleryLista();
        posVia = spinnerViaOri.getSelectedItemPosition();
        posCI = spinnerCliInt.getSelectedItemPosition();
        ClaVia = listId.get(posVia);//This will be the student id.
        cliente = listCI.get(posCI);
        Cliente =cliente.split(" -> ");
        // System.out.println("---------"+Cliente[0]);
        consulta(ClaVia,EdTxtFecha.getText().toString(), ""+Cliente[0]);
        AdpColoc = new ServicioColocacionAdapter(RegistroColocacionServicioActivity.this,listColocacion, MAC,loginUserName,ClaUbicacionLogin,idUsuario);
        recyclerAdpColocUnidad.setAdapter(AdpColoc);
    }

    private  void consulta(String Via, String FechaColocacion, String ClienteInterno) {
        limpiaRecycleryLista();
        try {
            c = objBD.getServicioColocacion("2",Via,FechaColocacion, ClienteInterno);
            c.moveToFirst();
            if(c.getCount()>0) {//string 16 nomclienteinterno
                for (int x = 0; x < c.getCount(); x++) {
                    listColocacion.add(new ServicioColocacionVO(""+c.getString(0),
                            ""+c.getString(1),
                            ""+c.getString(2),
                            ""+c.getString(3),
                            ""+c.getString(17),
                            ""+c.getString(5),
                            ""+ c.getString(6),
                            ""+c.getString(7),
                            ""+c.getString(8),
                            ""+c.getString(9),
                            ""+c.getString(10),
                            ""+c.getString(11),
                            ""+c.getString(12),
                            ""+ c.getString(13),
                            ""+ c.getString(14),
                            ""+c.getString(16),
                            ""+objBD.getCantidadColocadasDet(c.getString(1),
                            ""+c.getString(9))));
                    c.moveToNext();
                }
            }else{
                if (toast!= null) { toast.cancel(); }
                toast = Toast.makeText(this,"No hay servicios para colocar.", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }
            c.close();
            objBD.CloseDB();
        } catch (Exception e) {
            if (toast!= null) { toast.cancel(); }
            toast = Toast.makeText(this,"ERROR... " +e.toString(), Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
       switch (parent.getId()) {
            case R.id.spinnerViaOrigen:
                posVia = spinnerViaOri.getSelectedItemPosition();
                limpiaRecycleryLista();
                listCI.clear();
                vias= listId.get(posVia);
                Vias = vias.split(" -> ");
                c = objBD.getClienteInternoUbi(ClaUbicacionLogin,Vias[0]);
                if (c.moveToFirst()) {
                    do {
                        listCI.add(c.getString(1)+" -> "+c.getString(2));//
                    } while (c.moveToNext());
                }
                c.close();
                objBD.close();
                AdpCI = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, listCI);
                AdpCI.setDropDownViewResource(android.R.layout.simple_list_item_1);
                spinnerCliInt.setAdapter(AdpCI);
                spinnerCliInt.setSelected(true);

                break;
            case R.id.spinnerClienteInterno:
                posVia = spinnerViaOri.getSelectedItemPosition();
                posCI = spinnerCliInt.getSelectedItemPosition();
                ClaVia = listId.get(posVia);//This will be the student id.
                cliente = listCI.get(posCI);
                Cliente =cliente.split(" -> ");
                consulta(ClaVia,EdTxtFecha.getText().toString(), ""+Cliente[0]);
                AdpColoc = new ServicioColocacionAdapter(RegistroColocacionServicioActivity.this,listColocacion, MAC,loginUserName,ClaUbicacionLogin,idUsuario);
                recyclerAdpColocUnidad.setAdapter(AdpColoc);
                break;
        }
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }
    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add_insmancomunada, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.itmreturn:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.imgBtnCalendar:
                obtenerFecha();
                break;
        }
    }

    private void obtenerFecha(){
        recogerFecha = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                mesActual = month + 1;
                diaFormateado = (dayOfMonth < 10)? CERO + String.valueOf(dayOfMonth):String.valueOf(dayOfMonth);
                mesFormateado = (mesActual < 10)? CERO + String.valueOf(mesActual):String.valueOf(mesActual);
                EdTxtFecha.setText( year + GUION + mesFormateado + GUION + diaFormateado);
                ClaVia = listId.get(spinnerViaOri.getSelectedItemPosition());
                posVia = spinnerCliInt.getSelectedItemPosition();
                    cliente = listCI.get(posVia);
                    Cliente = cliente.split(" -> ");
                    consulta(ClaVia, EdTxtFecha.getText().toString(), Cliente[0]);
                    AdpColoc = new ServicioColocacionAdapter(RegistroColocacionServicioActivity.this, listColocacion, MAC,loginUserName,ClaUbicacionLogin,idUsuario);
                    recyclerAdpColocUnidad.setAdapter(AdpColoc);
            }
        },anio, mes, dia);
        recogerFecha.show();
    }
}
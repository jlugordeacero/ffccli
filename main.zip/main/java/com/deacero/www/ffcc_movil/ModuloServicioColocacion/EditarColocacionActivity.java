package com.deacero.www.ffcc_movil.ModuloServicioColocacion;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.ModuloDisenoServicio.TablaEquipoRequerido;
import com.deacero.www.ffcc_movil.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class EditarColocacionActivity extends AppCompatActivity {

    ///////BD
    BDFFCCMovil objBD= new BDFFCCMovil(this); //hace la conexión
    private Cursor c, c2;
    private RecyclerView recyclerTraControlUnidad,recyclerEditUniColoc;
    private ArrayList<ConfirmarColocacionCarrosVO> listaConfirmarCarrosColocados = new ArrayList<ConfirmarColocacionCarrosVO>();
    //DATOS SESSION configuracion
    private String IdTraSolicitudServicio, ClaConfServiciosP,ClaConfVentanaP, ClaUbicacionP, IdColocacionSqlite, IdColocacionSQLServer, MAC, ClaCarroColocado, ClaUsuarioMod;

    private static final String CERO = "0";
    private static final String BARRA = "/";
    private Toast toast;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
    private Date date = new Date();
    private String fecha="";

    private String ClienteInterno="";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editar_colocacion);
        IdTraSolicitudServicio = getIntent().getExtras().getString("ClaCfgSolicitudServicio");
        ClaConfServiciosP = getIntent().getExtras().getString("ClaConfServicios");
        ClaConfVentanaP = getIntent().getExtras().getString("ClaConfVentana");
        ClaUbicacionP = getIntent().getExtras().getString("ClaUbicacion");
        IdColocacionSqlite = getIntent().getExtras().getString("IdColocacion");
        IdColocacionSQLServer = getIntent().getExtras().getString("IdColocacionSqlServer");
        ClaCarroColocado = getIntent().getExtras().getString("ClaCarroColocado");
        MAC = getIntent().getExtras().getString("MAC");
        ClaUsuarioMod = getIntent().getExtras().getString("ClaUsuarioMod");

        recyclerTraControlUnidad = (RecyclerView) findViewById(R.id.recyclerBuscarPlaca);
        recyclerEditUniColoc = (RecyclerView) findViewById(R.id.recyclerEditarColocados);


        consulta();
        recyclerEditUniColoc.setLayoutManager(new LinearLayoutManager(EditarColocacionActivity.this));
        ConfirmarColocacionCarrosAdapter adapterCarros = new ConfirmarColocacionCarrosAdapter(EditarColocacionActivity.this,listaConfirmarCarrosColocados);
        recyclerEditUniColoc.setAdapter(adapterCarros);

    }


    private  void consulta() {
        BDFFCCMovil objBD= new BDFFCCMovil(EditarColocacionActivity.this); //hace la conexión
        try {
            String ClaCfgSolicitudServicio = IdTraSolicitudServicio;// listId.get(pos);
            String ClaUbicacion = ClaUbicacionP;// listUbicacion.get(pos);
            String ClaConfServicios = ClaConfServiciosP;// listClaConfServicios.get(pos);
            String ClaConfVentana = ClaConfVentanaP;//listClaConfVentana.get(pos);
           // Log.e("KEYS: ",ClaCfgSolicitudServicio+"-"+ClaUbicacion+"-"+ClaConfServicios+"-"+ClaConfVentana);
            c = objBD.getFfccCarrosColocados(ClaCfgSolicitudServicio, ClaUbicacion, ClaConfServicios, ClaConfVentana);
            c.moveToFirst();
            if(c.getCount()>0) {
                for (int x = 0; x < c.getCount(); x++) {
                    String IdControlUnidad = c.getString(0);
                    String ClaCarro = c.getString(1);
                    String PlacaCarro = c.getString(2);
                    String ClaCarroColocadoDet = c.getString(3);
                    String ClaCarroColocado = c.getString(4);
                    System.out.println("-----------------"+c.getString(5)+"---"+c.getString(6));

                    listaConfirmarCarrosColocados.add(new ConfirmarColocacionCarrosVO(ClaCfgSolicitudServicio, ClaUbicacion, ClaConfServicios, ClaConfVentana, ClaCarroColocado, ClaCarroColocadoDet, IdControlUnidad, ClaCarro, PlacaCarro,""+c.getString(5),""+c.getString(6) ));
                    c.moveToNext();
                }
                c.close();
                objBD.CloseDB();
            }
            else{
                if (toast!= null) { toast.cancel(); }
                toast = Toast.makeText(getApplicationContext(),"No hay placas asociadas.", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add_insmancomunada, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.itmreturn:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }





}

package com.deacero.www.ffcc_movil.ModuloServicioColocacion;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.R;

import java.util.ArrayList;

public class ConfirmarColocacionCarrosAdapter extends RecyclerView.Adapter<ConfirmarColocacionCarrosAdapter.ViewHolderConfirmarColocarCarros> implements View.OnClickListener{

    ArrayList<ConfirmarColocacionCarrosVO> listaTraControlUnidad;
    private View.OnClickListener listener;
    private Context mContext;
    private Cursor c;


    public class ViewHolderConfirmarColocarCarros extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView EtiPlaca;
        ImageView ImgDelete;
        CheckBox checkCargado, checkTapa;
        public ViewHolderConfirmarColocarCarros(@NonNull View itemView) {
            super(itemView);
            EtiPlaca=(TextView) itemView.findViewById(R.id.txtplaca);
            checkCargado = (CheckBox) itemView.findViewById(R.id.EsVacio);
            checkTapa = (CheckBox) itemView.findViewById(R.id.EsTapa);
            ImgDelete = (ImageView) itemView.findViewById(R.id.IdDelete);

            checkCargado.setOnClickListener(this);
            checkTapa.setOnClickListener(this);
        }


        @Override
        public void onClick(View v) {
            final BDFFCCMovil objBD = new BDFFCCMovil(mContext);
            switch (v.getId()) {
                case R.id.EsVacio:
                    Log.e("position placa ", "" + listaTraControlUnidad.get(getAdapterPosition()).getPlacaCarro());
                    System.out.println(""+listaTraControlUnidad.get(getAdapterPosition()).getClaCarroColocado()+" -- "+ listaTraControlUnidad.get(getAdapterPosition()).getClaCarroColocadoDet()+"  --  "+ listaTraControlUnidad.get(getAdapterPosition()).getClaUbicacion()+ " --1");
                    if (((CheckBox) v).isChecked()) {
                        //Case 1
                        System.out.println("c/v1 ");
                        listaTraControlUnidad.get(getAdapterPosition()).setEsVacio("1");
                        objBD.updateCargadoColocadoEsCarga(listaTraControlUnidad.get(getAdapterPosition()).getClaCarroColocado(), listaTraControlUnidad.get(getAdapterPosition()).getClaCarroColocadoDet(), listaTraControlUnidad.get(getAdapterPosition()).getClaUbicacion(), "1");
                    } else {
                        System.out.println("c/v2 ");
                        listaTraControlUnidad.get(getAdapterPosition()).setEsVacio("0");
                        objBD.updateCargadoColocadoEsCarga(listaTraControlUnidad.get(getAdapterPosition()).getClaCarroColocado(), listaTraControlUnidad.get(getAdapterPosition()).getClaCarroColocadoDet(), listaTraControlUnidad.get(getAdapterPosition()).getClaUbicacion(), "0");
                    }
                    notifyDataSetChanged();
                    break;
                case R.id.EsTapa:
                    Log.e("position placa ", "" + listaTraControlUnidad.get(getAdapterPosition()).getPlacaCarro());
                    if (((CheckBox) v).isChecked()) {
                        //Case 1
                        System.out.println("c/v1 ");
                        listaTraControlUnidad.get(getAdapterPosition()).setEsTapa("1");
                        objBD.updateCargadoColocadoEsTapa(listaTraControlUnidad.get(getAdapterPosition()).getClaCarroColocado(), listaTraControlUnidad.get(getAdapterPosition()).getClaCarroColocadoDet(), listaTraControlUnidad.get(getAdapterPosition()).getClaUbicacion(), "1");

                    } else {
                        System.out.println("c/v2 ");
                        listaTraControlUnidad.get(getAdapterPosition()).setEsTapa("0");
                        objBD.updateCargadoColocadoEsTapa(listaTraControlUnidad.get(getAdapterPosition()).getClaCarroColocado(), listaTraControlUnidad.get(getAdapterPosition()).getClaCarroColocadoDet(), listaTraControlUnidad.get(getAdapterPosition()).getClaUbicacion(), "0");

                    }
                    notifyDataSetChanged();
                    break;

            }
        }
    }

    public ConfirmarColocacionCarrosAdapter(Context context , ArrayList<ConfirmarColocacionCarrosVO> listaCarros) {
        this.listaTraControlUnidad = listaCarros;
        mContext = context;
    }

    @NonNull
    @Override
    public ViewHolderConfirmarColocarCarros onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list_confirmar_carros_colocacion,null,false);
        view.setOnClickListener(this);
        return new ViewHolderConfirmarColocarCarros(view);
    }


    @Override
    public void onBindViewHolder(@NonNull final ViewHolderConfirmarColocarCarros HolderColocar, final int position) {
        final BDFFCCMovil objBD = new BDFFCCMovil(mContext);
        HolderColocar.EtiPlaca.setText(listaTraControlUnidad.get(position).getPlacaCarro());

        HolderColocar.checkCargado.setChecked(true);
        if("0".equals(listaTraControlUnidad.get(position).getEsVacio()) || "null".equals(listaTraControlUnidad.get(position).getEsVacio()) || listaTraControlUnidad.get(position).getEsVacio().isEmpty()){
            HolderColocar.checkCargado.setChecked(false);
        }
        HolderColocar.checkTapa.setChecked(true);
        if("0".equals(listaTraControlUnidad.get(position).getEsTapa()) || "null".equals(listaTraControlUnidad.get(position).getEsTapa()) || listaTraControlUnidad.get(position).getEsTapa().isEmpty()){
            HolderColocar.checkTapa.setChecked(false);
        }


        HolderColocar.ImgDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                builder.setIcon(R.drawable.notify_dialog);
                builder.setTitle("¿Estas seguro de remover la placa para este servicio?");
                builder.setMessage("Placa: "+ listaTraControlUnidad.get(position).getPlacaCarro());
                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Remove the item on remove/button click
                        //add para cambiar estatus en tracontrolunidad de 1 a 0 = NO Colocado
                        objBD.ActualizaEstatusTraControlUnidad("0",listaTraControlUnidad.get(position).getIdControlUnidad(),listaTraControlUnidad.get(position).getClaUbicacion(),listaTraControlUnidad.get(position).getPlacaCarro());
                        //add para remover de FfccCarrosColocadosDet
                        objBD.deleteFfccCarrosColocadosDet(listaTraControlUnidad.get(position).getClaCarroColocadoDet(), listaTraControlUnidad.get(position).getPlacaCarro(), listaTraControlUnidad.get(position).getIdControlUnidad());

                        listaTraControlUnidad.remove(position);
                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position,getItemCount());
                    }
                });
                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                builder.show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaTraControlUnidad.size();
    }

    public void setOnClickListener(View.OnClickListener listener){
        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        if(listener!=null){
            listener.onClick(v);
        }
    }


}

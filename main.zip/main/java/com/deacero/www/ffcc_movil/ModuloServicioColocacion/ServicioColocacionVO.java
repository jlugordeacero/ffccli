package com.deacero.www.ffcc_movil.ModuloServicioColocacion;


public class ServicioColocacionVO {

    private String ClaCfgSolicitudServicio, ClaUbicacion, ClaConfServicios,ClaConfVentana,NomVia,Duracion,Unidad,Hora,HoraRegistro,ClaCarroColocado;
    private String FechaColocacion, FechaInicio, FechaFin;
    private String IdColocacion, IdColocacionSqlServer, ClienteInterno, CantidadColocados;

    public ServicioColocacionVO(String claCfgSolicitudServicio, String claUbicacion, String claConfServicios, String claConfVentana, String nomVia, String duracion, String unidad, String hora, String horaRegistro, String claCarroColocado, String fechaColocacion, String fechaInicio, String fechaFin, String idColocacion, String idColocacionSqlServer, String clienteInterno, String colocados) {
        ClaCfgSolicitudServicio = claCfgSolicitudServicio;
        ClaUbicacion = claUbicacion;
        ClaConfServicios = claConfServicios;
        ClaConfVentana = claConfVentana;
        NomVia = nomVia;
        Duracion = duracion;
        Unidad = unidad;
        Hora = hora;
        HoraRegistro = horaRegistro;
        ClaCarroColocado = claCarroColocado;
        FechaColocacion = fechaColocacion;
        FechaInicio = fechaInicio;
        FechaFin = fechaFin;
        IdColocacion = idColocacion;
        IdColocacionSqlServer = idColocacionSqlServer;
        ClienteInterno = clienteInterno;
        CantidadColocados = colocados;
    }
    public String getColocados() {
        return CantidadColocados;
    }

    public void setColocados(String colocados) {
        CantidadColocados = colocados;
    }
    public String getClienteInterno() {
        return ClienteInterno;
    }

    public void setClienteInterno(String clienteInterno) {
        ClienteInterno = clienteInterno;
    }

    public String getIdColocacionSqlServer() {
        return IdColocacionSqlServer;
    }

    public void setIdColocacionSqlServer(String idColocacionSqlServer) {
        IdColocacionSqlServer = idColocacionSqlServer;
    }

    public String getIdColocacion() {
        return IdColocacion;
    }

    public void setIdColocacion(String idColocacion) {
        IdColocacion = idColocacion;
    }

    public String getClaCfgSolicitudServicio() {
        return ClaCfgSolicitudServicio;
    }

    public void setClaCfgSolicitudServicio(String claCfgSolicitudServicio) {
        ClaCfgSolicitudServicio = claCfgSolicitudServicio;
    }

    public String getClaUbicacion() {
        return ClaUbicacion;
    }

    public void setClaUbicacion(String claUbicacion) {
        ClaUbicacion = claUbicacion;
    }

    public String getClaConfServicios() {
        return ClaConfServicios;
    }

    public void setClaConfServicios(String claConfServicios) {
        ClaConfServicios = claConfServicios;
    }

    public String getClaConfVentana() {
        return ClaConfVentana;
    }

    public void setClaConfVentana(String claConfVentana) {
        ClaConfVentana = claConfVentana;
    }

    public String getNomVia() {
        return NomVia;
    }

    public void setNomVia(String nomVia) {
        NomVia = nomVia;
    }

    public String getDuracion() {
        return Duracion;
    }

    public void setDuracion(String duracion) {
        Duracion = duracion;
    }

    public String getUnidad() {
        return Unidad;
    }

    public void setUnidad(String unidad) {
        Unidad = unidad;
    }

    public String getHora() {
        return Hora;
    }

    public void setHora(String hora) {
        Hora = hora;
    }

    public String getHoraRegistro() {
        return HoraRegistro;
    }

    public void setHoraRegistro(String horaRegistro) {
        HoraRegistro = horaRegistro;
    }

    public String getClaCarroColocado() {
        return ClaCarroColocado;
    }

    public void setClaCarroColocado(String claCarroColocado) {
        ClaCarroColocado = claCarroColocado;
    }

    public String getFechaColocacion() {
        return FechaColocacion;
    }

    public void setFechaColocacion(String fechaColocacion) {
        FechaColocacion = fechaColocacion;
    }

    public String getFechaInicio() {
        return FechaInicio;
    }

    public void setFechaInicio(String fechaInicio) {
        FechaInicio = fechaInicio;
    }

    public String getFechaFin() {
        return FechaFin;
    }

    public void setFechaFin(String fechaFin) {
        FechaFin = fechaFin;
    }
}

package com.deacero.www.ffcc_movil.ModuloServicioColocacion;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.media.Image;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.R;
import com.deacero.www.ffcc_movil.metodos.AuthenticationWS2;
import com.deacero.www.ffcc_movil.metodos.PostColocacionWS;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import static com.deacero.www.ffcc_movil.R.color.green;

public class ServicioColocacionAdapter extends RecyclerView.Adapter<ServicioColocacionAdapter.ViewHolderLoteoUnidad> {

    ArrayList<ServicioColocacionVO> listaColocacion;

    private Context mContext;
    private View.OnClickListener listener;
    private AlertDialog dialog;
    private String chooseItem, MAC,LoginUserName, ClaUbicacion,idUsuario;
    private Cursor c, c3, c2;
    private View view;

    public class ViewHolderLoteoUnidad extends ViewHolder implements View.OnClickListener {
        TextView NomVia,etFechaColocacion, etCantidad, etMinutos, etFechaInicio, etFechaFin, etClienteInterno, etCantidadColocadas, etHora;
        Button btnColocar;
        ImageView imgShowDetail,imgShowEdit;
        Toast toast;
        final BDFFCCMovil objBD = new BDFFCCMovil(mContext);
        String Password="", token="";

        public ViewHolderLoteoUnidad(@NonNull View itemView) {
            super(itemView);
            etFechaColocacion = (TextView) itemView.findViewById(R.id.txtFechaColocacion);
            etCantidad = (TextView) itemView.findViewById(R.id.txtCantidad);
            etMinutos=(TextView) itemView.findViewById(R.id.txtMinutos);
            etFechaInicio=(TextView) itemView.findViewById(R.id.txtFechaInicio);
            etFechaFin=(TextView) itemView.findViewById(R.id.txtFechaFin);
            btnColocar = (Button) itemView.findViewById(R.id.btnColocar);
            NomVia=(TextView) itemView.findViewById(R.id.txtNomVia);
            etClienteInterno = (TextView) itemView.findViewById(R.id.txtNomClienteInterno);
            etHora = (TextView) itemView.findViewById(R.id.txtVentana);
            imgShowDetail = (ImageView) itemView.findViewById(R.id.imgShowDetail);
            imgShowEdit = (ImageView) itemView.findViewById(R.id.imgShowEdit);
            etCantidadColocadas=(TextView) itemView.findViewById(R.id.txtCantidadColocadas);
            imgShowDetail.setOnClickListener(this);
            imgShowEdit.setOnClickListener(this);
            btnColocar.setOnClickListener(this);

        }

        @Override
        public void onClick(View v) {
            System.out.println("POSICION   "+getAdapterPosition());
            final int newPosition = getAdapterPosition();
            switch (v.getId()){
                case R.id.imgShowDetail:
                    if(listaColocacion.get(newPosition).getFechaFin()==null || ("null").equals(listaColocacion.get(newPosition).getFechaFin())){
                        Intent servicioColocacion = new Intent(mContext,EditarColocacionActivity.class);
                        servicioColocacion.putExtra("ClaCfgSolicitudServicio",listaColocacion.get(newPosition).getClaCfgSolicitudServicio());
                        servicioColocacion.putExtra("ClaConfServicios",listaColocacion.get(newPosition).getClaConfServicios());
                        servicioColocacion.putExtra("ClaConfVentana",listaColocacion.get(newPosition).getClaConfVentana());
                        servicioColocacion.putExtra("ClaUbicacion",listaColocacion.get(newPosition).getClaUbicacion());
                        servicioColocacion.putExtra("IdColocacion",listaColocacion.get(newPosition).getIdColocacion());
                        servicioColocacion.putExtra("IdColocacionSqlServer",listaColocacion.get(newPosition).getIdColocacionSqlServer());
                        servicioColocacion.putExtra("MAC",MAC);
                        servicioColocacion.putExtra("ClaCarroColocado",listaColocacion.get(newPosition).getClaCarroColocado());
                        mContext.startActivity(servicioColocacion);
                    }else{
                        if (toast!= null) { toast.cancel(); }
                        toast = Toast.makeText(mContext,"No se puede editar una colocación finalizada.", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                    }
                    break;
                case R.id.imgShowEdit:
                    if(listaColocacion.get(newPosition).getFechaFin()==null || ("null").equals(listaColocacion.get(newPosition).getFechaFin())){
                        Intent servicioColocacion = new Intent(mContext,EditarColocacionActivity2.class);
                        servicioColocacion.putExtra("ClaCfgSolicitudServicio",listaColocacion.get(newPosition).getClaCfgSolicitudServicio());
                        servicioColocacion.putExtra("ClaConfServicios",listaColocacion.get(newPosition).getClaConfServicios());
                        servicioColocacion.putExtra("ClaConfVentana",listaColocacion.get(newPosition).getClaConfVentana());
                        servicioColocacion.putExtra("ClaUbicacion",listaColocacion.get(newPosition).getClaUbicacion());
                        servicioColocacion.putExtra("IdColocacion",listaColocacion.get(newPosition).getIdColocacion());
                        servicioColocacion.putExtra("IdColocacionSqlServer",listaColocacion.get(newPosition).getIdColocacionSqlServer());
                        servicioColocacion.putExtra("MAC",MAC);
                        servicioColocacion.putExtra("ClaCarroColocado",listaColocacion.get(newPosition).getClaCarroColocado());
                        mContext.startActivity(servicioColocacion);
                    }else{
                        if (toast!= null) { toast.cancel(); }
                        toast = Toast.makeText(mContext,"No se puede editar una colocación finalizada.", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                    }
                    break;
                case R.id.btnColocar:
                    if(listaColocacion.get(newPosition).getFechaInicio()==null || ("null").equals(listaColocacion.get(newPosition).getFechaInicio())){
                        AlertDialog builder = new AlertDialog.Builder(mContext).create();
                        builder.setIcon(R.drawable.notify_dialog);
                        builder.setTitle("Confirma si deseas que inicie la colocación");
                        builder.setMessage("Cuando aceptes, comenzara a transcurrir el tiempo.");
                        builder.setButton(AlertDialog.BUTTON_POSITIVE, "Aceptar",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        SimpleDateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss", Locale.getDefault());
                                        Date date = new Date();
                                        String myfecha = dateFormat.format(date);
                                        objBD.SetDateIniFfccCarrosColocados(myfecha,listaColocacion.get(newPosition).getClaCarroColocado(), listaColocacion.get(newPosition).getClaCfgSolicitudServicio(),listaColocacion.get(newPosition).getClaUbicacion(), listaColocacion.get(newPosition).getClaConfServicios(), listaColocacion.get(newPosition).getClaConfVentana());
                                        objBD.CloseDB();
                                        listaColocacion.get(newPosition).setFechaInicio(myfecha);
                                        notifyItemChanged(newPosition); //actualiza los elementos no toma en cuenta el settext anterior necesito upd el dataset
                                        notifyDataSetChanged();
                                    }
                                });
                        builder.setButton(AlertDialog.BUTTON_NEGATIVE, "Cancelar",  new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });
                        builder.setCancelable(false);
                        builder.setCanceledOnTouchOutside(false);
                        builder.show();
                    }else{
                        AlertDialog builder = new AlertDialog.Builder(mContext).create();
                        builder.setIcon(R.drawable.notify_dialog);
                        builder.setTitle("Confirma si deseas que termine la colocación");
                        builder.setMessage("Cuando aceptes, se detendra el tiempo.");
                        builder.setButton(AlertDialog.BUTTON_POSITIVE, "Aceptar",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                            SimpleDateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss", Locale.getDefault());
                                            Date date = new Date();
                                            String myfecha = dateFormat.format(date);
                                            objBD.SetDateFinFfccCarrosColocados(myfecha,listaColocacion.get(newPosition).getClaCarroColocado(), listaColocacion.get(newPosition).getClaCfgSolicitudServicio(),listaColocacion.get(newPosition).getClaUbicacion(), listaColocacion.get(newPosition).getClaConfServicios(), listaColocacion.get(newPosition).getClaConfVentana());
                                            //actualizar el estatus de la colocacion a 3 porque ya termino
                                            objBD.ActualizaEstatusColocarCarro("3",""+listaColocacion.get(newPosition).getClaCfgSolicitudServicio(), ""+listaColocacion.get(newPosition).getClaUbicacion(), ""+listaColocacion.get(newPosition).getClaConfServicios(), ""+listaColocacion.get(newPosition).getClaConfVentana());
                                            //HACE FALTA UN OBJ para copiar la colocacion AL RETIRO......
                                            objBD.CopiarColocacionTOClienteInterno(listaColocacion.get(newPosition).getClaCarroColocado(),listaColocacion.get(newPosition).getClaUbicacion());
                                            objBD.CloseDB();
                                            listaColocacion.get(newPosition).setFechaFin(myfecha);
                                            notifyItemChanged(newPosition); //actualiza los elementos no toma en cuenta el settext anterior necesito upd el dataset
                                            notifyDataSetChanged();


                                        c3 = objBD.getUserXLoginUser(LoginUserName);
                                        if(c3.getCount()>0){
                                            c3.moveToFirst();
                                            Password = c3.getString(4);
                                        }
                                        c3.close();
                                        AuthenticationWS2 AuthWS = new AuthenticationWS2(mContext,itemView.getResources().getString(R.string.ip_authentication),LoginUserName,""+Password,MAC,"0");
                                        String respuesta = String.valueOf(AuthWS.execute(""));

                                        c2 = objBD.getUserXLoginUser(LoginUserName);
                                        if(c2.getCount()>0){
                                            c2.moveToFirst();
                                            token = c2.getString(8);
                                        }
                                        c2.close();
                                        objBD.close();

                                        PostColocacionWS WSSendColocacion = new PostColocacionWS(mContext,token,itemView.getResources().getString(R.string.IpPostColocacion),ClaUbicacion,idUsuario,MAC);
                                        WSSendColocacion.execute("");

                                    }
                                });
                        builder.setButton(AlertDialog.BUTTON_NEGATIVE, "Cancelar",  new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });
                        builder.setCancelable(false);
                        builder.setCanceledOnTouchOutside(false);
                        builder.show();
                    }
                    break;
            }
        }
    }

    public ServicioColocacionAdapter(Context context, ArrayList<ServicioColocacionVO> listLoteoUnidad, String MyMAC, String loginUserNmae, String claUbicacion, String idUsuario) {
        this.listaColocacion = listLoteoUnidad;
        this.mContext = context;
        this.MAC = MyMAC;
        this.LoginUserName = loginUserNmae;
        this.ClaUbicacion = claUbicacion;
        this.idUsuario = idUsuario;
    }

    @NonNull
    @Override
    public ViewHolderLoteoUnidad onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list_servicio_colocacion,null,false);
        return new ViewHolderLoteoUnidad(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolderLoteoUnidad viewHolderLoteoUnidad, final int position) {
        viewHolderLoteoUnidad.NomVia.setText(listaColocacion.get(position).getNomVia());

        viewHolderLoteoUnidad.etHora.setText("Ventana: "+listaColocacion.get(position).getHora());

        if(("null").equals(listaColocacion.get(position).getFechaColocacion()) || listaColocacion.get(position).getFechaColocacion() == null ){
            viewHolderLoteoUnidad.etFechaInicio.setText("Fecha: Indefinida");
        }else{
            viewHolderLoteoUnidad.etFechaColocacion.setText("Fecha Coloc.: "+listaColocacion.get(position).getFechaColocacion().replace("T"," "));
        }

        viewHolderLoteoUnidad.etCantidad.setText("Cantidad * Via: "+listaColocacion.get(position).getUnidad());
        viewHolderLoteoUnidad.etMinutos.setText("Duración: "+listaColocacion.get(position).getDuracion()+" Min.");
        //viewHolderLoteoUnidad.etMinutos.setTextColor(Color.RED);
        viewHolderLoteoUnidad.etCantidadColocadas.setText("Colocadas: "+listaColocacion.get(position).getColocados());
        viewHolderLoteoUnidad.etClienteInterno.setText(listaColocacion.get(position).getClienteInterno());
        if(("null").equals(listaColocacion.get(position).getFechaInicio()) || listaColocacion.get(position).getFechaInicio() == null ){
            viewHolderLoteoUnidad.etFechaInicio.setText("Inicio: Indefinida");
            viewHolderLoteoUnidad.btnColocar.setText("COLOCAR");
        }else{
            viewHolderLoteoUnidad.etFechaInicio.setText("Inicio: "+listaColocacion.get(position).getFechaInicio().replace("T"," "));
            viewHolderLoteoUnidad.btnColocar.setText("TERMINAR COLOCACIÓN");
        }
        if(("null").equals(listaColocacion.get(position).getFechaFin())  || listaColocacion.get(position).getFechaFin() == null ){
            viewHolderLoteoUnidad.etFechaFin.setText("Finalizo: Indefinida");
        }else{
            viewHolderLoteoUnidad.etFechaFin.setText("Finalizo: "+ listaColocacion.get(position).getFechaFin().replace("T", " "));
            viewHolderLoteoUnidad.btnColocar.setEnabled(false);
            viewHolderLoteoUnidad.btnColocar.setText("¡COLOCACIÓN FINALIZADA!");
        }
    }

    @Override
    public int getItemCount() {
        return listaColocacion.size();
    }

}
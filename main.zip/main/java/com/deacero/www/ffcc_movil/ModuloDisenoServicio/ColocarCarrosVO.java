package com.deacero.www.ffcc_movil.ModuloDisenoServicio;

import android.content.Context;

import java.util.List;

public class ColocarCarrosVO {
    private String IdControlUnidad,ClaCarro, PlacaCarro,DiasPlanta, ClaUbicacion;
    private  String ClaCfgSolicitudServicio, ClaConfServicios, ClaConfVentana, EsVacio, ClienteInterno, NomTipoUnidad;


    public ColocarCarrosVO(String idControlUnidad, String claCarro, String placaCarro, String diasPlanta, String claUbicacion, String claCfgSolicitudServicio, String claConfServicios, String claConfVentana, String esVacio, String clienteInterno, String nomTipoUnidad) {
        IdControlUnidad = idControlUnidad;
        ClaCarro = claCarro;
        PlacaCarro = placaCarro;
        DiasPlanta = diasPlanta;
        ClaUbicacion = claUbicacion;
        ClaCfgSolicitudServicio = claCfgSolicitudServicio;
        ClaConfServicios = claConfServicios;
        ClaConfVentana = claConfVentana;
        EsVacio = esVacio;
        ClienteInterno = clienteInterno;
        NomTipoUnidad = nomTipoUnidad;
    }

    public String getNomTipoUnidad() {
        return NomTipoUnidad;
    }

    public void setNomTipoUnidad(String nomTipoUnidad) {
        NomTipoUnidad = nomTipoUnidad;
    }

    public String getEsVacio() {
        return EsVacio;
    }

    public void setEsVacio(String esVacio) {
        EsVacio = esVacio;
    }

    public String getClienteInterno() {
        return ClienteInterno;
    }

    public void setClienteInterno(String clienteInterno) {
        ClienteInterno = clienteInterno;
    }

    public String getIdControlUnidad() {
        return IdControlUnidad;
    }

    public void setIdControlUnidad(String idControlUnidad) {
        IdControlUnidad = idControlUnidad;
    }

    public String getClaCarro() {
        return ClaCarro;
    }

    public void setClaCarro(String claCarro) {
        ClaCarro = claCarro;
    }

    public String getPlacaCarro() {
        return PlacaCarro;
    }

    public void setPlacaCarro(String placaCarro) {
        PlacaCarro = placaCarro;
    }

    public String getDiasPlanta() {
        return DiasPlanta;
    }

    public void setDiasPlanta(String diasPlanta) {
        DiasPlanta = diasPlanta;
    }

    public String getClaUbicacion() {
        return ClaUbicacion;
    }

    public void setClaUbicacion(String claUbicacion) {
        DiasPlanta = claUbicacion;
    }

    public String getClaCfgSolicitudServicio() {
        return ClaCfgSolicitudServicio;
    }

    public void setClaCfgSolicitudServicio(String claCfgSolicitudServicio) {
        ClaCfgSolicitudServicio = claCfgSolicitudServicio;
    }

    public String getClaConfServicios() {
        return ClaConfServicios;
    }

    public void setClaConfServicios(String claConfServicios) {
        ClaConfServicios = claConfServicios;
    }

    public String getClaConfVentana() {
        return ClaConfVentana;
    }

    public void setClaConfVentana(String claConfVentana) {
        ClaConfVentana = claConfVentana;
    }
}

package com.deacero.www.ffcc_movil.ModuloDisenoServicio;

public class ConfirmarColocarCarrosVO {
    private String ClaCfgSolicitudServicio, ClaUbicacion, ClaConfServicios, ClaConfVentana;
    private String ClaCarroColocado, ClaCarroColocadoDet;
    private String IdControlUnidad,ClaCarro, PlacaCarro;


    public ConfirmarColocarCarrosVO(String claCfgSolicitudServicio, String claUbicacion, String claConfServicios, String claConfVentana, String claCarroColocado, String claCarroColocadoDet, String idControlUnidad, String claCarro, String placaCarro) {
        ClaCfgSolicitudServicio = claCfgSolicitudServicio;
        ClaUbicacion = claUbicacion;
        ClaConfServicios = claConfServicios;
        ClaConfVentana = claConfVentana;
        ClaCarroColocado = claCarroColocado;
        ClaCarroColocadoDet = claCarroColocadoDet;
        IdControlUnidad = idControlUnidad;
        ClaCarro = claCarro;
        PlacaCarro = placaCarro;
    }

    public String getClaCfgSolicitudServicio() {
        return ClaCfgSolicitudServicio;
    }

    public void setClaCfgSolicitudServicio(String claCfgSolicitudServicio) {
        ClaCfgSolicitudServicio = claCfgSolicitudServicio;
    }

    public String getClaUbicacion() {
        return ClaUbicacion;
    }

    public void setClaUbicacion(String claUbicacion) {
        ClaUbicacion = claUbicacion;
    }

    public String getClaConfServicios() {
        return ClaConfServicios;
    }

    public void setClaConfServicios(String claConfServicios) {
        ClaConfServicios = claConfServicios;
    }

    public String getClaConfVentana() {
        return ClaConfVentana;
    }

    public void setClaConfVentana(String claConfVentana) {
        ClaConfVentana = claConfVentana;
    }

    public String getClaCarroColocado() {
        return ClaCarroColocado;
    }

    public void setClaCarroColocado(String claCarroColocado) {
        ClaCarroColocado = claCarroColocado;
    }

    public String getClaCarroColocadoDet() {
        return ClaCarroColocadoDet;
    }

    public void setClaCarroColocadoDet(String claCarroColocadoDet) {
        ClaCarroColocadoDet = claCarroColocadoDet;
    }

    public String getIdControlUnidad() {
        return IdControlUnidad;
    }

    public void setIdControlUnidad(String idControlUnidad) {
        IdControlUnidad = idControlUnidad;
    }

    public String getClaCarro() {
        return ClaCarro;
    }

    public void setClaCarro(String claCarro) {
        ClaCarro = claCarro;
    }

    public String getPlacaCarro() {
        return PlacaCarro;
    }

    public void setPlacaCarro(String placaCarro) {
        PlacaCarro = placaCarro;
    }
}

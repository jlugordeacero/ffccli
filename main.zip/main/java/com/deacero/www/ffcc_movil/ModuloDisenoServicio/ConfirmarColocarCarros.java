package com.deacero.www.ffcc_movil.ModuloDisenoServicio;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.ModuloServicioColocacion.ConfirmarColocacionCarrosAdapter;
import com.deacero.www.ffcc_movil.ModuloServicioColocacion.RegistroColocacionServicioActivity;
import com.deacero.www.ffcc_movil.R;
import com.deacero.www.ffcc_movil.metodos.AuthenticationWS2;
import com.deacero.www.ffcc_movil.metodos.Internet;
import com.deacero.www.ffcc_movil.metodos.PostColocacionWS;
import com.deacero.www.ffcc_movil.metodos.PostDisenoWS;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ConfirmarColocarCarros extends Fragment implements AdapterView.OnItemSelectedListener, View.OnClickListener {

    private Cursor c, c2;

    private RecyclerView recyclerConfirmColocarCarros;

    private ArrayList<ConfirmarColocarCarrosVO> listaConfirmarCarrosColocados = new ArrayList<ConfirmarColocarCarrosVO>();

    private Spinner SpinnerVias,spinnerClienteInterno,spinConfServices;
    private TextView txtInfoHora, txtInfoMin, txtInfoCantidad,txtInfoClienteInterno, txtInfoEsCarga;
    private FloatingActionButton btnConfirmarCarros;

    private List<String> listId = new ArrayList<String>();//almaceno los IdTraSolicitudServicio
    private List<String> listNames = new ArrayList<String>();//para almacenar los NomVia
    private List<String> listVias = new ArrayList<String>();//para VIAS
    private List<String> listCI = new ArrayList<String>();//para VIAS

    private String IdTraSolicitudServicio, ClaUbicacion, ClaConfServicios, ClaConfVentana;
    private String idUsuario,ClaEmpleado,loginUserName,token,DireccionMAC,ClaUbicacionLogin;

    private TextView EdTxtFecha;
    private ImageButton imgBtnCalendario;
    private static final String CERO = "0";
    private static final String BARRA = "/";
    private Toast toast;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
    private Date date = new Date();
    private String fecha="", Password="", MAC="";


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        BDFFCCMovil objBD= new BDFFCCMovil(getContext()); //hace la conexión
        View view = inflater.inflate(R.layout.item_list_confirm_colocar_carros, container, false);

        SpinnerVias = (Spinner) view.findViewById(R.id.viasSpinner);
        spinnerClienteInterno = (Spinner) view.findViewById(R.id.spinnerClienteInterno);
        EdTxtFecha = (TextView) view.findViewById(R.id.edTxtFecha);
        imgBtnCalendario = (ImageButton) view.findViewById(R.id.imgBtnCalendar);
        spinConfServices = (Spinner) view.findViewById(R.id.SpinConfServ);
        txtInfoHora = (TextView) view.findViewById(R.id.infoHora);
        txtInfoMin = (TextView) view.findViewById(R.id.infoMinutos) ;
        txtInfoCantidad  = (TextView) view.findViewById(R.id.infoCantidad);
        txtInfoClienteInterno  = (TextView) view.findViewById(R.id.infoClienteInterno);
        txtInfoEsCarga  = (TextView) view.findViewById(R.id.infoEsCarga);
        recyclerConfirmColocarCarros = (RecyclerView) view.findViewById(R.id.recyclerConfirmarColocarCarros);
        btnConfirmarCarros = (FloatingActionButton) view.findViewById(R.id.btnFlotanteConfirmarCarros);

        imgBtnCalendario.setOnClickListener(this);

        fecha = dateFormat.format(date);
        EdTxtFecha.setText(fecha);
        EdTxtFecha.setEnabled(false);

        DisenoServicioActivity activity = (DisenoServicioActivity) getActivity();
        String recibeDato = activity.getDataFragment();

        ClaUbicacionLogin = recibeDato;
        MAC = activity.getDataMAC();
        loginUserName = activity.getDataLoginUserName();

        SpinnerVias.setOnItemSelectedListener(this);
        c2 = objBD.getViaConCI(ClaUbicacionLogin);
        if (c2.moveToFirst()) {
            do {
                listVias.add(c2.getString(1)+" -> "+c2.getString(2));//adding IdTraSolicitudServicio
            } while (c2.moveToNext());
        }
        c2.close();
        objBD.close();
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1, listVias);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        SpinnerVias.setAdapter(dataAdapter);
        SpinnerVias.setSelected(true);
        SpinnerVias.setOnItemSelectedListener(this);
        spinnerClienteInterno.setOnItemSelectedListener(this);
        spinConfServices.setOnItemSelectedListener(this);

        c = objBD.getViaColocarServicio(ClaUbicacionLogin,"","","");
        if (c.moveToFirst()) {
            do {
                String[] HoraConfig = c.getString(7).split("T");
                String[] HoraConfig2 = HoraConfig[1].split(":");
                listNames.add(c.getString(0)+" -> Duracion:"+ c.getString(5)+" - Cantidad:"+c.getString(6)+" - Hora: "+HoraConfig2[0]+":"+HoraConfig2[1]);
                // IdTraSolicitudServicio  0// ClaConfServicios 2 // ClaConfVentana 3 // Hora 7 // minutos  5 // cantidad 6// cliente interno 12// EsCarga//nomviaclienteinetno //ubicacion
                listId.add(c.getString(0)+" -> "
                        +c.getString(2)+" -> "
                        +c.getString(3)+" -> "
                        +c.getString(7)+" -> "
                        +c.getString(5)+" -> "
                        +c.getString(6)+" -> "
                        +c.getString(12)+" -> "
                        +c.getString(10)+" -> "
                        +c.getString(11)+" -> "
                        +c.getString(1)+"");//adding todos los ids
            } while (c.moveToNext());
        }

        consulta();

        recyclerConfirmColocarCarros.setLayoutManager(new LinearLayoutManager(getActivity()));
        ConfirmarColocarCarrosAdapter adapterCarros = new ConfirmarColocarCarrosAdapter(getContext(),listaConfirmarCarrosColocados);
        recyclerConfirmColocarCarros.setAdapter(adapterCarros);

        btnConfirmarCarros.setOnClickListener(this);
        return view;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            // Refresh your fragment here
            Log.e("is visible 2 ", 1+ "");

            listaConfirmarCarrosColocados.clear();
            recyclerConfirmColocarCarros.removeAllViews();
            consulta();
            recyclerConfirmColocarCarros.setLayoutManager(new LinearLayoutManager(getActivity()));
            ConfirmarColocarCarrosAdapter adapterCarros = new ConfirmarColocarCarrosAdapter(getContext(),listaConfirmarCarrosColocados);
            recyclerConfirmColocarCarros.setAdapter(adapterCarros);
            if(SpinnerVias!=null){

                SpinnerVias.setSelected(true);
            }
          //  getFragmentManager().beginTransaction().detach(this).attach(this).commit();
        }
    }

    private  void consulta() {
        BDFFCCMovil objBD= new BDFFCCMovil(getActivity()); //hace la conexión
        int pos = spinConfServices.getSelectedItemPosition();
        try {
            if(listId.size() >0){
                IdTraSolicitudServicio = listId.get(pos);
                String configuracion = listId.get(pos);// este es el id de IdTraSolicitudServicio
                String[] posConfiguracion = configuracion.split(" -> ");
                Log.e("KEYS: ",posConfiguracion[0]+"-"+ClaUbicacionLogin+"-"+posConfiguracion[1]+"-"+posConfiguracion[2]);
                c = objBD.getFfccCarrosColocados(posConfiguracion[0], ClaUbicacionLogin, posConfiguracion[1], posConfiguracion[2]);
                c.moveToFirst();
                if(c.getCount()>0) {
                    for (int x = 0; x < c.getCount(); x++) {
                        String IdControlUnidad = c.getString(0);
                        String ClaCarro = c.getString(1);
                        String PlacaCarro = c.getString(2);
                        String ClaCarroColocadoDet = c.getString(3);
                        String ClaCarroColocado = c.getString(4);

                        listaConfirmarCarrosColocados.add(new ConfirmarColocarCarrosVO(IdTraSolicitudServicio, ClaUbicacionLogin, ClaConfServicios, ClaConfVentana, ClaCarroColocado, ClaCarroColocadoDet, IdControlUnidad, ClaCarro, PlacaCarro ));
                        c.moveToNext();
                    }
                    c.close();
                    objBD.CloseDB();
                }
                else{
                    if (toast!= null) { toast.cancel(); }
                    toast = Toast.makeText(getActivity(),"Aún no hay placas asociadas para este servicio.", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
            }else{
                if (toast!= null) { toast.cancel(); }
                toast = Toast.makeText(getActivity(),"No hay datos disponibles.", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void limpiarRecyclerYLista(){
        recyclerConfirmColocarCarros.removeAllViewsInLayout();
        listaConfirmarCarrosColocados.clear();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        BDFFCCMovil objBD= new BDFFCCMovil(getActivity()); //hace la conexión
        String vias="",FechaCaptura="",cliInt="";
        String[] Vias,ClienteInt,FechaFormat;
        switch (parent.getId()) {
            case R.id.viasSpinner:
                limpiarRecyclerYLista();
                vias = listVias.get(parent.getSelectedItemPosition());
                listNames.clear();
                listId.clear();
                listCI.clear();

                Vias = vias.split(" -> ");
                c2 = objBD.getClienteInternoUbi(ClaUbicacionLogin,Vias[0]);
                if (c2.moveToFirst()) {
                    do {
                        listCI.add(c2.getString(1)+" -> "+c2.getString(2));//
                    } while (c2.moveToNext());
                }
                c2.close();
                objBD.close();
                ArrayAdapter<String> dataAdapterCI = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1, listCI);
                dataAdapterCI.setDropDownViewResource(android.R.layout.simple_list_item_1);
                spinnerClienteInterno.setAdapter(dataAdapterCI);
                spinnerClienteInterno.setSelected(true);

                break;
            case R.id.spinnerClienteInterno:
                limpiarRecyclerYLista();
                cliInt = listCI.get(parent.getSelectedItemPosition());
                ClienteInt = cliInt.split(" -> ");
                listNames.clear();
                listId.clear();

                final int posVias = SpinnerVias.getSelectedItemPosition();

                vias = listVias.get(posVias);
                Vias = vias.split(" -> ");
                FechaCaptura = EdTxtFecha.getText().toString();
                FechaFormat = FechaCaptura.split("/");

                c = objBD.getViaColocarServicio(ClaUbicacionLogin, Vias[0], FechaFormat[2]+"-"+FechaFormat[1]+"-"+FechaFormat[0]+"T00:00:00",ClienteInt[0]);
                if(c.getCount()>0) {
                    if (c.moveToFirst()) {
                        do {
                            String[] HoraConfig = c.getString(7).split("T");
                            String[] HoraConfig2 = HoraConfig[1].split(":");
                            listNames.add(c.getString(0) + " -> Duracion:" + c.getString(5) + " - Cantidad:" + c.getString(6)+ " - Hora: "+HoraConfig2[0]+":"+HoraConfig2[1]);
                            // IdTraSolicitudServicio 0 // ClaConfServicios 2 // ClaConfVentana 3 // Hora 7 // minutos 5  // cantidad 6// cliente interno 12// EsCarga//nomviaclienteinetno //ubicacion
                            listId.add(c.getString(0) + " -> "
                                    + c.getString(2) + " -> "
                                    + c.getString(3) + " -> "
                                    + c.getString(7) + " -> "
                                    + c.getString(5) + " -> "
                                    + c.getString(6) + " -> "
                                    + c.getString(12) + " -> "
                                    + c.getString(10) + " -> "
                                    + c.getString(11) + " -> "
                                    + c.getString(1) + "");//adding todos los ids
                        } while (c.moveToNext());
                    }
                    c.close();
                    objBD.close();
                    // Creating adapter for spinner
                    ArrayAdapter<String> AdapterServ = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, listNames);
                    AdapterServ.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinConfServices.setAdapter(AdapterServ);
                    spinConfServices.setSelected(true);
                    spinConfServices.setOnItemSelectedListener(this);

                    String configuracion = listId.get(0);// este es el id de IdTraSolicitudServicio
                    String[] posConfiguracion = configuracion.split(" -> ");
                    //Log.e("config ",""+posConfiguracion[0]+" - "+posConfiguracion[1]+" - "+posConfiguracion[2]+" - "+posConfiguracion[3]+" - "+posConfiguracion[4]+" - "+posConfiguracion[5]+" - "+posConfiguracion[6]+" - "+posConfiguracion[7]+" - "+posConfiguracion[8]);
                    String[] HoraConfig = posConfiguracion[3].split("T");
                    String[] HoraConfig2 = HoraConfig[1].split(":");
                    txtInfoHora.setText(HoraConfig2[0] + ":" + HoraConfig2[1] + " Horas.");
                    txtInfoMin.setText(posConfiguracion[4] + " Minutos.");
                    txtInfoCantidad.setText(posConfiguracion[5] + "");
                    txtInfoClienteInterno.setText("" + posConfiguracion[6]);
                    if ("null".equals(posConfiguracion[6]) || posConfiguracion[6].isEmpty()) {
                        txtInfoClienteInterno.setText("Indefinido");
                    }
                    txtInfoEsCarga.setText("NO");
                    if ("1".equals(posConfiguracion[7])) {
                        txtInfoEsCarga.setText("SI");
                    }
                }else{
                    if (toast!= null) { toast.cancel(); }
                    toast = Toast.makeText(getActivity(),"No hay servicios.", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    listNames.clear();
                    ArrayAdapter<String> AdapterServ = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1, listNames);
                    AdapterServ.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinConfServices.setAdapter(AdapterServ);

                    txtInfoHora.setText( "HH");
                    txtInfoMin.setText("MM");
                    txtInfoCantidad.setText("##");
                    txtInfoClienteInterno.setText("N/A");
                    txtInfoEsCarga.setText("N/A");
                }
                break;
             case R.id.SpinConfServ:
                 limpiarRecyclerYLista();

                 //Log.e("selected ", " --");
                 String configuracion = listId.get(spinConfServices.getSelectedItemPosition());// este es el id de IdTraSolicitudServicio
                 String[] posConfiguracion = configuracion.split(" -> ");
                 //Log.e("config ",""+posConfiguracion[0]+" - "+posConfiguracion[1]+" - "+posConfiguracion[2]+" - "+posConfiguracion[3]+" - "+posConfiguracion[4]+" - "+posConfiguracion[5]+" - "+posConfiguracion[6]+" - "+posConfiguracion[7]+" - "+posConfiguracion[8]);
                 String[] HoraConfig = posConfiguracion[3].split("T");
                 String[] HoraConfig2 = HoraConfig[1].split(":");
                 txtInfoHora.setText( HoraConfig2[0]+":"+HoraConfig2[1]+ " Horas.");
                 txtInfoMin.setText( posConfiguracion[4]+" Minutos.");
                 txtInfoCantidad.setText(posConfiguracion[5]+"");
                 txtInfoClienteInterno.setText(""+posConfiguracion[6]);
                 if("null".equals(posConfiguracion[6]) || posConfiguracion[6].isEmpty()){
                     txtInfoClienteInterno.setText("Indefinido");
                 }
                 txtInfoEsCarga.setText("NO");
                 if("1".equals(posConfiguracion[7])){
                     txtInfoEsCarga.setText("SI");
                 }
                        consulta();
                        ConfirmarColocarCarrosAdapter adapterCarros = new ConfirmarColocarCarrosAdapter(getContext(),listaConfirmarCarrosColocados);
                        recyclerConfirmColocarCarros.setAdapter(adapterCarros);
              break;
        }
    }


    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.btnFlotanteConfirmarCarros:///boton flotante

                final BDFFCCMovil objBD= new BDFFCCMovil(getActivity()); //hace la conexión

                fecha = dateFormat.format(date);
                Log.e("fecha ",""+fecha);
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setIcon(R.drawable.notify_dialog);
                builder.setTitle("Alerta");
                builder.setMessage("¿Estas seguro de confirmar el diseño del servicio con estos carros?");
                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Remove the item on remove/button click
                        //add para cambiar estatus en tracontrolunidad a 1 = Colocado
                        int pos = spinConfServices.getSelectedItemPosition();
                        try {
                            if(listId.size() >0){
                                IdTraSolicitudServicio = listId.get(pos);
                                String configuracion = listId.get(pos);// este es el id de IdTraSolicitudServicio
                                String[] posConfiguracion = configuracion.split(" -> ");
                              //  Log.e("KEYS: ",posConfiguracion[0]+"-"+ClaUbicacionLogin+"-"+posConfiguracion[1]+"-"+posConfiguracion[2]);
                                c = objBD.getFfccCarrosColocados(posConfiguracion[0], ClaUbicacionLogin, posConfiguracion[1], posConfiguracion[2]);
                                c.moveToFirst();
                                if(c.getCount()>0) {
                                    String configuracion2 = listId.get(spinConfServices.getSelectedItemPosition());// este es el id de IdTraSolicitudServicio
                                    String[] posConfiguracion2 = configuracion2.split(" -> ");
                                   // System.out.println("sol "+posConfiguracion2[0]+" --- serv "+posConfiguracion2[1]+" ven "+posConfiguracion2[2]+"");
                                    //objBD.ActualizaEstatusTraControlUnidad("1",listaTraControlUnidad.get(position).getIdControlUnidad(),listaTraControlUnidad.get(position).getClaUbicacion(),listaTraControlUnidad.get(position).getClaCarro());
                                    objBD.ActualizaEstatusColocarCarro("1",posConfiguracion2[0], ClaUbicacionLogin, posConfiguracion2[1], posConfiguracion2[2]);
                                    objBD.ActualizaEstatusDisenoServicio("1",posConfiguracion2[0], ClaUbicacionLogin, posConfiguracion2[1], posConfiguracion2[2]);
                                    Toast.makeText(getActivity(),"Se ha confirmado correctamente.",Toast.LENGTH_SHORT);
                                    limpiarRecyclerYLista();

                                    //sincronizacion
                                    System.out.println();
                                    c = objBD.getUserXLoginUser(loginUserName);
                                    if(c.getCount()>0){
                                        c.moveToFirst();
                                        Password = c.getString(4);
                                    }
                                    c.close();
                                    Internet internet = new Internet(getContext());

                                    // Log.e("CONEXION:",""+ConexionInternet.toString());
                                    if(internet.compruebaConexion(getContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
                                        AuthenticationWS2 AuthWS = new AuthenticationWS2(getContext(), getString(R.string.ip_authentication), loginUserName, "" + Password, MAC, "0");
                                        String respuesta = String.valueOf(AuthWS.execute(""));

                                        c2 = objBD.getUserXLoginUser(loginUserName);
                                        if (c2.getCount() > 0) {
                                            c2.moveToFirst();
                                            token = c2.getString(8);
                                            idUsuario = c2.getString(1);
                                        }
                                        c2.close();
                                        objBD.close();
                                        PostDisenoWS WSSendDiseno = new PostDisenoWS(getContext(), token, getString(R.string.IpPostColocacion), ClaUbicacionLogin, idUsuario, MAC);
                                        WSSendDiseno.execute("");
                                    }
                                }
                                else{
                                    if (toast!= null) { toast.cancel(); }
                                    toast = Toast.makeText(getActivity(),"No puedes confirmar  un servicio sin placas.", Toast.LENGTH_LONG);
                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                    toast.show();
                                }
                                c.close();
                            }else{
                                if (toast!= null) { toast.cancel(); }
                                toast = Toast.makeText(getActivity(),"No hay datos disponibles.", Toast.LENGTH_LONG);
                                toast.setGravity(Gravity.CENTER, 0, 0);
                                toast.show();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                });
                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                builder.show();

                break;

            case R.id.imgBtnCalendar://boton fecha

                final Calendar calendario = Calendar.getInstance();
                int yy = calendario.get(Calendar.YEAR);
                int mm = calendario.get(Calendar.MONTH);
                int dd = calendario.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePicker = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
                    String diaFormateado,mesFormateado;
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        final int mesActual = monthOfYear + 1;
                        diaFormateado = (dayOfMonth < 10)? CERO + String.valueOf(dayOfMonth):String.valueOf(dayOfMonth);
                        mesFormateado = (mesActual < 10)? CERO + String.valueOf(mesActual):String.valueOf(mesActual);
                        EdTxtFecha.setText(diaFormateado + BARRA + mesFormateado + BARRA + year);
                        final BDFFCCMovil objBD= new BDFFCCMovil(getActivity()); //hace la conexión

                        limpiarRecyclerYLista();
                        listVias.clear();
                        c2 = objBD.getViaConCI(ClaUbicacionLogin);
                        if (c2.moveToFirst()) {
                            do {
                                listVias.add(c2.getString(1)+" -> "+c2.getString(2));//adding IdTraSolicitudServicio
                            } while (c2.moveToNext());
                        }
                        c2.close();
                        objBD.close();
                        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1, listVias);
                        dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
                        SpinnerVias.setAdapter(dataAdapter);
                        SpinnerVias.setSelected(true);


                    }
                }, yy, mm, dd);
                datePicker.show();

                break;


            default:
                break;
        }


    }
}
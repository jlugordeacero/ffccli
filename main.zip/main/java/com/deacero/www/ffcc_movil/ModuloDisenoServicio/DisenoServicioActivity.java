package com.deacero.www.ffcc_movil.ModuloDisenoServicio;

import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.MenuActivity;
import com.deacero.www.ffcc_movil.ModuloServicioRetiro.ServicioRetiroActivity;
import com.deacero.www.ffcc_movil.R;
import com.deacero.www.ffcc_movil.metodos.AuthenticationWS2;
import com.deacero.www.ffcc_movil.metodos.GetCfgSolicitudServicioWS;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DisenoServicioActivity extends AppCompatActivity {
    public String idUsuario,ClaEmpleado,loginUserName,token,DireccionMAC,ClaUbicacionLogin, Password;
    private Cursor c, c2;
    BDFFCCMovil objBD= new BDFFCCMovil(this); //hace la conexión
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diseno_servicio_activity);
        idUsuario = getIntent().getExtras().getString("idUsuario");//ClaUsuarioMod
        ClaEmpleado = getIntent().getExtras().getString("ClaEmpleado");//Clave del empleado, la misma que el login
        loginUserName = getIntent().getExtras().getString("loginUserName");//Usuario
        token = getIntent().getExtras().getString("token");
        DireccionMAC = getIntent().getExtras().getString("DireccionMAC");
        ClaUbicacionLogin = getIntent().getExtras().getString("ClaUbicacion");


        c = objBD.getUserXLoginUser(loginUserName);
        if(c.getCount()>0){
            c.moveToFirst();
            Password = c.getString(4);
        }
        c.close();
        AuthenticationWS2 AuthWS = new AuthenticationWS2(DisenoServicioActivity.this,getString(R.string.ip_authentication),loginUserName,Password,DireccionMAC,"0");
        String respuesta = String.valueOf(AuthWS.execute(""));

        c2 = objBD.getUserXLoginUser(loginUserName);
        if(c2.getCount()>0){
            c2.moveToFirst();
            token = c2.getString(8);
        }
        c2.close();
        objBD.close();

        String Fecha = "";

        Date date = new Date();
        date.setDate(date.getDate()-1);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Fecha= dateFormat.format(date);
        Log.e("Fecha ",""+Fecha);

        GetCfgSolicitudServicioWS WSCfgSolServ = new GetCfgSolicitudServicioWS(DisenoServicioActivity.this,token,getString(R.string.IpGetCfgSolicitudServicio),ClaUbicacionLogin, Fecha,null, "NO",""+DireccionMAC,""+idUsuario);
        WSCfgSolServ.execute("");

        // Setting ViewPager for each Tabs
        ViewPager viewPager = (ViewPager) findViewById(R.id.viewpager);
        setupViewPager(viewPager);
        // Set Tabs inside Toolbar
        TabLayout tabs = (TabLayout) findViewById(R.id.tabs);
        tabs.setupWithViewPager(viewPager);



    }
    public String getDataMAC(){
        return DireccionMAC;
    }

    public String getDataLoginUserName(){
        return loginUserName;
    }

    public String recibeClaUsuarioMod(){
        return idUsuario;
    }

    public String getDataFragment(){
        return ClaUbicacionLogin;
    }



    // Add Fragments to Tabs
    private void setupViewPager(final ViewPager viewPager) {
        Adapter adapter = new Adapter(getSupportFragmentManager());
        adapter.addFragment(new ColocarCarros(), "Colocar Carros");
        adapter.addFragment(new ConfirmarColocarCarros(), "Confirmar Carros a Colocar");
        viewPager.setAdapter(adapter);
        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {
              //  Log.e("page scroll ", ""+0);
            }
            @Override
            public void onPageSelected(int i) {
                Log.e("page sel ", ""+0);
            }
            @Override
            public void onPageScrollStateChanged(int i) {
               // Log.e("page chang ", ""+0);
            }

        });
    }

    static class Adapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();
        public Adapter(FragmentManager manager) {
            super(manager);
        }
        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }
        @Override
        public int getCount() {
            return mFragmentList.size();
        }
        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }
        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_add_insmancomunada, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.itmreturn:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
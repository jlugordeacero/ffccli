package com.deacero.www.ffcc_movil.ModuloDisenoServicio;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.R;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class ColocarCarrosAdapter extends RecyclerView.Adapter<ColocarCarrosAdapter.ViewHolderColocarCarros> implements View.OnClickListener{

    ArrayList<ColocarCarrosVO> listaTraControlUnidad;
    private View.OnClickListener listener;
    private Context mContext;
    private Cursor c,c2;
    private String ClaUbicacion, MAC,ClaUsuarioMod;

    public class ViewHolderColocarCarros extends RecyclerView.ViewHolder {
        TextView EtiPlaca, EtiDiasPlanta, txtEsVacio, txtVia, txtTipoUnidad;
        ImageView ImgAdd;
        public ViewHolderColocarCarros(@NonNull View itemView) {
            super(itemView);
            EtiPlaca=(TextView) itemView.findViewById(R.id.txtplaca);
            EtiDiasPlanta=(TextView) itemView.findViewById(R.id.txtDiasPlanta);
            txtEsVacio = (TextView) itemView.findViewById(R.id.txtEsVacio);
            txtVia = (TextView) itemView.findViewById(R.id.txtVia);
            txtTipoUnidad = (TextView) itemView.findViewById(R.id.txtTipoUnidad);
            ImgAdd= (ImageView) itemView.findViewById(R.id.IdImagen);
        }
    }

    public ColocarCarrosAdapter(Context context , ArrayList<ColocarCarrosVO> listaCarros, String claUbicacion, String myMAC, String MyClaUsuarioMod) {
        this.listaTraControlUnidad = listaCarros;
        mContext = context;
        ClaUbicacion = claUbicacion;
        MAC = myMAC;
        ClaUsuarioMod = MyClaUsuarioMod;
    }

    @NonNull
    @Override
    public ViewHolderColocarCarros onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list_tra_control_unidad,null,false);
        view.setOnClickListener(this);
        return new ViewHolderColocarCarros(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolderColocarCarros viewHolderColocar, final int position) {
        final BDFFCCMovil objBD = new BDFFCCMovil(mContext);
        viewHolderColocar.EtiPlaca.setText(listaTraControlUnidad.get(position).getPlacaCarro());
        viewHolderColocar.EtiDiasPlanta.setText(listaTraControlUnidad.get(position).getDiasPlanta());
        viewHolderColocar.txtEsVacio.setText("SI");
        if("0".equals(listaTraControlUnidad.get(position).getEsVacio()) || "null".equals(listaTraControlUnidad.get(position).getEsVacio()) || listaTraControlUnidad.get(position).getEsVacio().isEmpty()){
            viewHolderColocar.txtEsVacio.setText("NO");
        }
        viewHolderColocar.txtVia.setText(listaTraControlUnidad.get(position).getClienteInterno());
        if("0".equals(listaTraControlUnidad.get(position).getClienteInterno()) || "null".equals(listaTraControlUnidad.get(position).getClienteInterno()) || listaTraControlUnidad.get(position).getClienteInterno().isEmpty()){
            viewHolderColocar.txtVia.setText("Indefinida");
        }

        //System.out.println("NomTipoUnidad: ++++++++  "+listaTraControlUnidad.get(position).getNomTipoUnidad());
        if("null".equals(listaTraControlUnidad.get(position).getNomTipoUnidad())){
            viewHolderColocar.txtTipoUnidad.setText(""+objBD.getNameTipoUnidad(ClaUbicacion,objBD.getTipoUnidadFn(listaTraControlUnidad.get(position).getPlacaCarro())));
        }else{
            viewHolderColocar.txtTipoUnidad.setText(""+listaTraControlUnidad.get(position).getNomTipoUnidad());
        }

        viewHolderColocar.ImgAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                builder.setIcon(R.drawable.notify_dialog);
                builder.setTitle("¿Estas seguro de agregar esta placa?");
                builder.setMessage("Placa: "+ listaTraControlUnidad.get(position).getPlacaCarro());
                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //add para cambiar estatus en tracontrolunidad a 1 = Colocado
                          objBD.ActualizaEstatusTraControlUnidad("1",listaTraControlUnidad.get(position).getIdControlUnidad(),listaTraControlUnidad.get(position).getClaUbicacion(),listaTraControlUnidad.get(position).getPlacaCarro());
                        try {
                            c=objBD.getId_FfccCarrosColocados(listaTraControlUnidad.get(position).getClaCfgSolicitudServicio(), listaTraControlUnidad.get(position).getClaUbicacion(), listaTraControlUnidad.get(position).getClaConfServicios(), listaTraControlUnidad.get(position).getClaConfVentana());
                            c.moveToFirst();
                            if(c.getCount()>0){//si ya hay  registros y debo insertar el IdColocacion
                                c2=objBD.ExistePlacaEnColocacion(listaTraControlUnidad.get(position).getPlacaCarro(),c.getString(0));
                                c2.moveToFirst();
                                if(c2.getCount()==0) {
                                    objBD.ADD_FfccCarrosColocadosDet(objBD.getMax_FfccCarrosColocadosDet(), c.getString(0), listaTraControlUnidad.get(position).getIdControlUnidad(), listaTraControlUnidad.get(position).getClaCarro(), listaTraControlUnidad.get(position).getPlacaCarro(), listaTraControlUnidad.get(position).getClaUbicacion());
                                }
                                c2.close();
                                c.close();
                                objBD.close();
                            }else{//se genera un nuevo IdColocacion
                                objBD.ADD_FfccCarrosColocados(objBD.getMax_FfccCarrosColocados(),listaTraControlUnidad.get(position).getClaCfgSolicitudServicio(), listaTraControlUnidad.get(position).getClaUbicacion(),listaTraControlUnidad.get(position).getClaConfServicios(),listaTraControlUnidad.get(position).getClaConfVentana(),""+MAC,"0",ClaUsuarioMod);
                                objBD.ADD_FfccCarrosColocadosDet(objBD.getMax_FfccCarrosColocadosDet(),objBD.getMax_FfccCarrosColocadosFOrdet(), listaTraControlUnidad.get(position).getIdControlUnidad(),listaTraControlUnidad.get(position).getClaCarro(),listaTraControlUnidad.get(position).getPlacaCarro(),listaTraControlUnidad.get(position).getClaUbicacion());
                            }
                            c.close();
                            objBD.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        listaTraControlUnidad.remove(position);
                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position,getItemCount());
                    }
                });
                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaTraControlUnidad.size();
    }

    public void setOnClickListener(View.OnClickListener listener){
        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        if(listener!=null){
            listener.onClick(v);
        }
    }


}

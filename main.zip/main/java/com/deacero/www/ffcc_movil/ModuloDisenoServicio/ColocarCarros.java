package com.deacero.www.ffcc_movil.ModuloDisenoServicio;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.Html;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.ModuloLoteoUnidades.AddLoteoUnidadActivity;
import com.deacero.www.ffcc_movil.ModuloLoteoUnidades.AddLoteoUnidadAdapter;
import com.deacero.www.ffcc_movil.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ColocarCarros extends Fragment implements AdapterView.OnItemSelectedListener, AdapterView.OnClickListener{

    BDFFCCMovil objBD;
    private Cursor c, c2;
    private Spinner SpinnerVias,SpinnerCI, SpinnerServicios;
    private TextView txtHora, txtMinutos, txtCantidad, txtClienteInterno, txtEsCarga;
    private RecyclerView recyclerTraControlUnidad;
    private EditText EtxtSearchPlaca;
    private List<String> listId = new ArrayList<String>();//almaceno la configuracion de todo el serv
    private List<String> listNames = new ArrayList<String>();//para almacenar los NomVia

    private List<String> listVias = new ArrayList<String>();//para VIAS
    private List<String> listCI = new ArrayList<String>();//para VIAS
    //estructura tabla
    private int FILAS, COLUMNAS = 0; // Filas y columnas de nuestra tabla
    private TableLayout mytabla; // Layout donde se pintará la tabla
    private ArrayList<TableRow> filas; // Array de las filas de la tabla
    private String idUsuario,ClaEmpleado,loginUserName,token,DireccionMAC,ClaUbicacionLogin,ClaUsuarioMod;

    private ArrayList<ColocarCarrosVO> listaTraControlUnidad = new ArrayList<ColocarCarrosVO>();

    private TextView EdTxtFecha;
    private ImageButton imgBtnCalendario, AddPlaca;
    private static final String CERO = "0";
    private static final String BARRA = "/";
    private Toast toast;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
    private Date date = new Date();
    private String fecha="", MAC;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,   Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.colocar_carros_list, container, false);
        objBD= new BDFFCCMovil(getContext()); //hace la conexión

        SpinnerVias = (Spinner) view.findViewById(R.id.viasSpinner);
        SpinnerCI = (Spinner) view.findViewById(R.id.spinnerClienteInterno);
        EdTxtFecha = (TextView) view.findViewById(R.id.edTxtFecha);
        imgBtnCalendario = (ImageButton) view.findViewById(R.id.imgBtnCalendar);
        SpinnerServicios = (Spinner) view.findViewById(R.id.ComboServicios);
        txtHora = (TextView)view.findViewById(R.id.textViewHora);
        txtMinutos = (TextView)view.findViewById(R.id.textViewDuracion);
        txtCantidad = (TextView)view.findViewById(R.id.textViewUnidad);
        txtClienteInterno = (TextView)view.findViewById(R.id.textViewClienteInterno);
        txtEsCarga = (TextView)view.findViewById(R.id.textViewEsCarga);
        EtxtSearchPlaca = (EditText) view.findViewById(R.id.txtSearchPlaca);
        mytabla = (TableLayout)view.findViewById(R.id.TablaEquipoRequerido);
        AddPlaca = (ImageButton) view.findViewById(R.id.addPlaca);
        recyclerTraControlUnidad = (RecyclerView) view.findViewById(R.id.recyclerTrainspeccionCarro);

        fecha = dateFormat.format(date);
        EdTxtFecha.setText(fecha);
        EdTxtFecha.setEnabled(false);

        imgBtnCalendario.setOnClickListener(this);
        AddPlaca.setOnClickListener(this);

        DisenoServicioActivity activity = (DisenoServicioActivity) getActivity();
        String recibeDato = activity.getDataFragment();
        MAC = activity.getDataMAC();
        ClaUbicacionLogin = recibeDato;
        ClaUsuarioMod = activity.recibeClaUsuarioMod();
        SpinnerVias.setOnItemSelectedListener(this);
        c2 = objBD.getViaConCI(ClaUbicacionLogin);
        if (c2.moveToFirst()) {
            do {
                listVias.add(c2.getString(1)+" -> "+c2.getString(2));//
            } while (c2.moveToNext());
        }
        c2.close();
        objBD.close();
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1, listVias);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        SpinnerVias.setAdapter(dataAdapter);
        SpinnerVias.setSelected(true);

        SpinnerCI.setOnItemSelectedListener(this);
        SpinnerServicios.setOnItemSelectedListener(this);

        ArrayList<String> valorescabecera = new ArrayList<String>();
        valorescabecera.add(" Tipo Unidad ");
        valorescabecera.add(" Material ");
        valorescabecera.add(" Cantidad ");
        valorescabecera.add(" Tapas ");
        TablaEquipoRequerido tabla = new TablaEquipoRequerido(getActivity(), mytabla);
        tabla.agregarCabecera(valorescabecera);

        return view;
    }

    private  void consulta(String Placa) {
        BDFFCCMovil objBD= new BDFFCCMovil(getActivity()); //hace la conexión
        try {
            c = objBD.getFfccTraControlUnidad(Placa, "1");
            c.moveToFirst();
            if(c.getCount()>0) {
                for (int x = 0; x < c.getCount(); x++) {
                    int PosSelecSpinner = SpinnerServicios.getSelectedItemPosition();/////////////////////////////
                    //Log.e("pos serv ",""+SpinnerServicios.getSelectedItemPosition());
                    String configuracion = listId.get(PosSelecSpinner); //Obtengo el id ClaCfgSolicitudServicio seleccionado actualmente
                    Log.e("*c.7 ",""+c.getString(7));
                    String[] posConfiguracion = configuracion.split(" -> ");
                    listaTraControlUnidad.add(new ColocarCarrosVO(""+c.getString(2), ""+c.getString(0), ""+c.getString(1), ""+c.getString(5),""+posConfiguracion[9],""+posConfiguracion[0], ""+posConfiguracion[1], ""+posConfiguracion[2],""+c.getString(3),""+c.getString(7),""+c.getString(9)));
                    c.moveToNext();
                }
                c.close();
                objBD.CloseDB();
            }
            else{
                Toast toast = Toast.makeText(getActivity(),"No se encontraron registros.", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void LimpiarRecicleryLista(){
        recyclerTraControlUnidad.removeAllViewsInLayout();
        listaTraControlUnidad.clear();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        BDFFCCMovil objBD= new BDFFCCMovil(getActivity()); //hace la conexión
        String vias="",FechaCaptura="",cliInt="";
        String[] Vias,ClienteInt,FechaFormat;
        switch (parent.getId()) {
            case R.id.viasSpinner:
                vias = listVias.get(parent.getSelectedItemPosition());
                listNames.clear();
                listId.clear();

                listCI.clear();

                Vias = vias.split(" -> ");
                c2 = objBD.getClienteInternoUbi(ClaUbicacionLogin,Vias[0]);
                if (c2.moveToFirst()) {
                    do {
                        listCI.add(c2.getString(1)+" -> "+c2.getString(2));//
                    } while (c2.moveToNext());
                }
                c2.close();
                objBD.close();
                ArrayAdapter<String> dataAdapterCI = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1, listCI);
                dataAdapterCI.setDropDownViewResource(android.R.layout.simple_list_item_1);
                SpinnerCI.setAdapter(dataAdapterCI);
                SpinnerCI.setSelected(true);

                break;
            case R.id.spinnerClienteInterno:
                cliInt = listCI.get(parent.getSelectedItemPosition());
                ClienteInt = cliInt.split(" -> ");
                listNames.clear();
                listId.clear();

                final int posVias = SpinnerVias.getSelectedItemPosition();

                vias = listVias.get(posVias);
                Vias = vias.split(" -> ");
                FechaCaptura = EdTxtFecha.getText().toString();
                FechaFormat = FechaCaptura.split("/");

                c = objBD.getViaColocarServicio(ClaUbicacionLogin, Vias[0], FechaFormat[2]+"-"+FechaFormat[1]+"-"+FechaFormat[0]+"T00:00:00",ClienteInt[0]);

                if(c.getCount()>0){
                    if (c.moveToFirst()) {
                        do {
                            String[] HoraConfig = c.getString(7).split("T");
                            String[] HoraConfig2 = HoraConfig[1].split(":");
                           // c.getString(7);
                            //System.out.println("----------->"+c.getString(7));
                            listNames.add(c.getString(0)+" -> Duracion:"+ c.getString(5)+" - Cantidad:"+c.getString(6)+" - Hora: "+HoraConfig2[0]+":"+HoraConfig2[1]);
                            // IdTraSolicitudServicio  // ClaConfServicios  // ClaConfVentana  // Hora  // minutos   // cantidad // cliente interno 12 // EsCarga//nomviaclienteinetno //ubicacion
                            listId.add(c.getString(0)+" -> "
                                    +c.getString(2)+" -> "
                                    +c.getString(3)+" -> "
                                    +c.getString(7)+" -> "
                                    +c.getString(5)+" -> "
                                    +c.getString(6)+" -> "
                                    +c.getString(12)+" -> "
                                    +c.getString(10)+" -> "
                                    +c.getString(11)+" -> "
                                    +c.getString(1)+"");//adding todos los ids
                        } while (c.moveToNext());
                    }
                    c.close();
                    objBD.close();
                    // Creating adapter for spinner
                    ArrayAdapter<String> AdapterServ = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1, listNames);
                    AdapterServ.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    SpinnerServicios.setAdapter(AdapterServ);
                    SpinnerServicios.setSelected(true);

                    String configuracion = listId.get(0);// este es el id de IdTraSolicitudServicio
                    String[] posConfiguracion = configuracion.split(" -> ");
                    String[] HoraConfig = posConfiguracion[3].split("T");
                    String[] HoraConfig2 = HoraConfig[1].split(":");
                    txtHora.setText( HoraConfig2[0]+":"+HoraConfig2[1]+ " Horas.");
                    txtMinutos.setText( posConfiguracion[4]+" Minutos.");
                    txtCantidad.setText(posConfiguracion[5]+"");
                    txtClienteInterno.setText(""+posConfiguracion[6]);
                    if("null".equals(posConfiguracion[6]) || posConfiguracion[6].isEmpty()){
                        txtClienteInterno.setText("Indefinido");
                    }
                    txtEsCarga.setText("NO");
                    if("1".equals(posConfiguracion[7])){
                        txtEsCarga.setText("SI");
                    }
                    /*if (!posConfiguracion[0].isEmpty()) {
                        c = objBD.getEquipoRequerido(posConfiguracion[0]);
                        c.moveToFirst();
                        mytabla.removeAllViews();
                        TablaEquipoRequerido tabla = new TablaEquipoRequerido(getActivity(),mytabla);
                        ArrayList<String> valorescabecera = new ArrayList<String>();
                        valorescabecera.add("Tipo Unidad");
                        valorescabecera.add("Cantidad");
                        valorescabecera.add("Tapas");
                        tabla.agregarCabecera(valorescabecera);
                        int TotalColumnas = valorescabecera.size();
                        ArrayList<String> elementos = new ArrayList<String>();
                        for(int i = 0; i < c.getCount(); i++){///se pintan los renglones
                            elementos.add( c.getString(4).replace("null","").replace("",""));
                            elementos.add( c.getString(2).replace("null","").replace("",""));//cantidad
                            elementos.add( c.getString(3).replace("null","").replace("",""));//tapas
                            tabla.agregarFilaTabla(elementos);
                            elementos.clear();
                            c.moveToNext();
                        }
                        objBD.close();
                        c.close();
                    }*/
                    LimpiarRecicleryLista();
                    EtxtSearchPlaca.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void onTextChanged(CharSequence s, int start, int before, int count) {
                        }
                        @Override
                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        }
                        @Override
                        public void afterTextChanged(Editable s) {
                            if(EtxtSearchPlaca.getText().length() >= 3) {
                                LimpiarRecicleryLista();
                                recyclerTraControlUnidad.setLayoutManager(new LinearLayoutManager(getActivity()));
                                consulta(EtxtSearchPlaca.getText().toString().replace(" ", "") );
                                ColocarCarrosAdapter adapterCarros = new ColocarCarrosAdapter(getContext(),listaTraControlUnidad, ClaUbicacionLogin,MAC, ClaUsuarioMod);
                                recyclerTraControlUnidad.setAdapter(adapterCarros);
                            }
                        }
                    });
                }else{
                    if (toast!= null) { toast.cancel(); }
                    toast = Toast.makeText(getActivity(),"No hay servicios.", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    listNames.clear();
                    ArrayAdapter<String> AdapterServ = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1, listNames);
                    AdapterServ.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    SpinnerServicios.setAdapter(AdapterServ);

                    txtHora.setText( "hh");
                    txtMinutos.setText("mm");
                    txtCantidad.setText("#");
                    txtClienteInterno.setText("N/A");
                    txtEsCarga.setText("N/A");

                    mytabla.removeAllViews();
                }
                // LimpiarRecicleryLista();
                break;
            case R.id.ComboServicios:

                LimpiarRecicleryLista();

                //Log.e("selected ", " --");
                String configuracion = listId.get(SpinnerServicios.getSelectedItemPosition());// este es el id de IdTraSolicitudServicio
                String[] posConfiguracion = configuracion.split(" -> ");
                //Log.e("config ",""+posConfiguracion[0]+" - "+posConfiguracion[1]+" - "+posConfiguracion[2]+" - "+posConfiguracion[3]+" - "+posConfiguracion[4]+" - "+posConfiguracion[5]+" - "+posConfiguracion[6]+" - "+posConfiguracion[7]+" - "+posConfiguracion[8]);
                String[] HoraConfig = posConfiguracion[3].split("T");
                String[] HoraConfig2 = HoraConfig[1].split(":");
                txtHora.setText( HoraConfig2[0]+":"+HoraConfig2[1]+ " Horas.");
                txtMinutos.setText( posConfiguracion[4]+" Minutos.");
                txtCantidad.setText(posConfiguracion[5]+"");
                txtClienteInterno.setText(""+posConfiguracion[6]);
                if("null".equals(posConfiguracion[6]) || posConfiguracion[6].isEmpty()){
                    txtClienteInterno.setText("Indefinido");
                }
                txtEsCarga.setText("NO");
                if("1".equals(posConfiguracion[7])){
                    txtEsCarga.setText("SI");
                }

                if (!posConfiguracion[0].isEmpty()) {
                    Log.e("equipo: ",posConfiguracion[0]);
                    c = objBD.getEquipoRequerido(posConfiguracion[0]);
                    c.moveToFirst();
                    mytabla.removeAllViews();
                    TablaEquipoRequerido tabla = new TablaEquipoRequerido(getActivity(),mytabla);
                    ArrayList<String> valorescabecera = new ArrayList<String>();
                    valorescabecera.add(" Tipo Unidad ");
                    valorescabecera.add(" Material ");
                    valorescabecera.add(" Cantidad ");
                    valorescabecera.add(" Tapas ");
                    tabla.agregarCabecera(valorescabecera);
                    int TotalColumnas = valorescabecera.size();
                    ArrayList<String> elementos = new ArrayList<String>();
                    for(int i = 0; i < c.getCount(); i++){///se pintan los renglones
                        elementos.add( c.getString(4).replace("null","").replace("",""));
                        elementos.add( c.getString(5).replace("null","").replace("",""));
                        elementos.add( c.getString(2).replace("null","").replace("",""));//cantidad
                        elementos.add( c.getString(3).replace("null","").replace("",""));//tapas
                        tabla.agregarFilaTabla(elementos);
                        elementos.clear();
                        c.moveToNext();
                    }
                    objBD.close();
                    c.close();
                }

                break;
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            // Refresh your fragment here
            Log.e("is visible ",  " --");

            if(SpinnerVias!=null){
                SpinnerVias.setSelected(true);
            }
            //getFragmentManager().beginTransaction().detach(this).attach(this).commit();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.imgBtnCalendar:
                final Calendar calendario = Calendar.getInstance();
                int yy = calendario.get(Calendar.YEAR);
                int mm = calendario.get(Calendar.MONTH);
                int dd = calendario.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePicker = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
                    String diaFormateado,mesFormateado;
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        final int mesActual = monthOfYear + 1;
                        diaFormateado = (dayOfMonth < 10)? CERO + String.valueOf(dayOfMonth):String.valueOf(dayOfMonth);
                        mesFormateado = (mesActual < 10)? CERO + String.valueOf(mesActual):String.valueOf(mesActual);
                        EdTxtFecha.setText(diaFormateado + BARRA + mesFormateado + BARRA + year);


                        LimpiarRecicleryLista();
                        listVias.clear();
                        c2 = objBD.getViaConCI(ClaUbicacionLogin);
                        if (c2.moveToFirst()) {
                            do {
                                listVias.add(c2.getString(1)+" -> "+c2.getString(2));//adding IdTraSolicitudServicio
                            } while (c2.moveToNext());
                        }
                        c2.close();
                        objBD.close();
                        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1, listVias);
                        dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
                        SpinnerVias.setAdapter(dataAdapter);
                        SpinnerVias.setSelected(true);


                    }
                }, yy, mm, dd);
                datePicker.show();
                break;
            case R.id.addPlaca:
                AlertDialog.Builder builder2 = new AlertDialog.Builder(getContext());
                builder2.setIcon(R.drawable.notify_dialog);
                builder2.setTitle(Html.fromHtml("<h1>!***** AVISO *****¡</h1>"));
                builder2.setMessage(Html.fromHtml("<h2>¿Estas seguro de agregar la placa <font color='#FF0000'></b>"+
                        EtxtSearchPlaca.getText()+ "</b></font>?</h2> "));
                builder2.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String PlacaCarroNueva = EtxtSearchPlaca.getText().toString();
                        int total = objBD.getFoundCarro(PlacaCarroNueva.replace(" ",""));
                        if(total > 0){
                            if (toast!= null) { toast.cancel(); }
                            toast = Toast.makeText(getContext(),"La placa ya existe", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                        }else {
                            // Check for a valid user.
                            if (TextUtils.isEmpty(PlacaCarroNueva)) {
                                EtxtSearchPlaca.setError(getString(R.string.error_field_required));
                            } else {
                               String vias = listVias.get(SpinnerVias.getSelectedItemPosition());
                               String[] Vias = vias.split(" -> ");

                                String Fecha = "";

                                Date date = new Date();
                                date.setDate(date.getDate()-1);
                                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                Fecha= dateFormat.format(date);
                                Log.e("Fecha ",""+Fecha);

                                objBD.InsertarFfccCatCarroVw("-1", PlacaCarroNueva.replace(" ",""), "NULL", "NULL"
                                        , "NULL", "NULL", "NULL", ""+Fecha, MAC, ClaUsuarioMod, "-1", "0", Vias[0], ""+Fecha, "NULL",""+ClaUbicacionLogin);
                                LimpiarRecicleryLista();
                                recyclerTraControlUnidad.setLayoutManager(new LinearLayoutManager(getActivity()));
                                consulta(EtxtSearchPlaca.getText().toString().replace(" ","") );
                                ColocarCarrosAdapter adapterCarros = new ColocarCarrosAdapter(getContext(),listaTraControlUnidad, ClaUbicacionLogin,MAC, ClaUsuarioMod);
                                recyclerTraControlUnidad.setAdapter(adapterCarros);
                            }
                        }
                        c.close();
                        objBD.close();

                    }
                });
                builder2.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                builder2.show();
                break;
        }

    }
    
}
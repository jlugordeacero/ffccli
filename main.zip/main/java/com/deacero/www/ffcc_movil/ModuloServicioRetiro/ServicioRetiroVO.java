package com.deacero.www.ffcc_movil.ModuloServicioRetiro;

public class ServicioRetiroVO {

    private String IdRetiro, Via, ClaUbicacion, FechaRetiro, FechaColocacion, Unidad;
    private String ClaCfgSolicitudServicio, ClaConfServicios,ClaConfVentana,NomVia,ClienteInterno,ClaCarroColocado, Retiradas, ClaUsuarioMod, EstatusRetiro;

    public ServicioRetiroVO(String idRetiro, String via, String claUbicacion, String fechaRetiro, String fechaColocacion, String unidad, String claCfgSolicitudServicio, String claConfServicios, String claConfVentana, String nomVia, String clienteInterno, String claCarroColocado, String retiradas, String claUsuarioMod, String estatusRetiro) {
        IdRetiro = idRetiro;
        Via = via;
        ClaUbicacion = claUbicacion;
        FechaRetiro = fechaRetiro;
        FechaColocacion = fechaColocacion;
        Unidad = unidad;
        ClaCfgSolicitudServicio = claCfgSolicitudServicio;
        ClaConfServicios = claConfServicios;
        ClaConfVentana = claConfVentana;
        NomVia = nomVia;
        ClienteInterno = clienteInterno;
        ClaCarroColocado = claCarroColocado;
        Retiradas = retiradas;
        ClaUsuarioMod = claUsuarioMod;
        EstatusRetiro = estatusRetiro;
    }

    public String getEstatusRetiro() {
        return EstatusRetiro;
    }

    public void setEstatusRetiro(String estatusRetiro) {
        EstatusRetiro = estatusRetiro;
    }

    public String getClaUsuarioMod() {
        return ClaUsuarioMod;
    }

    public void setClaUsuarioMod(String claUsuarioMod) {
        ClaUsuarioMod = claUsuarioMod;
    }

    public String getRetiradas() {
        return Retiradas;
    }

    public void setRetiradas(String retiradas) {
        Retiradas = retiradas;
    }

    public String getIdRetiro() {
        return IdRetiro;
    }

    public void setIdRetiro(String idRetiro) {
        IdRetiro = idRetiro;
    }

    public String getVia() {
        return Via;
    }

    public void setVia(String via) {
        Via = via;
    }

    public String getClaUbicacion() {
        return ClaUbicacion;
    }

    public void setClaUbicacion(String claUbicacion) {
        ClaUbicacion = claUbicacion;
    }

    public String getFechaRetiro() {
        return FechaRetiro;
    }

    public void setFechaRetiro(String fechaRetiro) {
        FechaRetiro = fechaRetiro;
    }

    public String getFechaColocacion() {
        return FechaColocacion;
    }

    public void setFechaColocacion(String fechaColocacion) {
        FechaColocacion = fechaColocacion;
    }

    public String getUnidad() {
        return Unidad;
    }

    public void setUnidad(String unidad) {
        Unidad = unidad;
    }

    public String getClaCfgSolicitudServicio() {
        return ClaCfgSolicitudServicio;
    }

    public void setClaCfgSolicitudServicio(String claCfgSolicitudServicio) {
        ClaCfgSolicitudServicio = claCfgSolicitudServicio;
    }

    public String getClaConfServicios() {
        return ClaConfServicios;
    }

    public void setClaConfServicios(String claConfServicios) {
        ClaConfServicios = claConfServicios;
    }

    public String getClaConfVentana() {
        return ClaConfVentana;
    }

    public void setClaConfVentana(String claConfVentana) {
        ClaConfVentana = claConfVentana;
    }

    public String getNomVia() {
        return NomVia;
    }

    public void setNomVia(String nomVia) {
        NomVia = nomVia;
    }

    public String getClienteInterno() {
        return ClienteInterno;
    }

    public void setClienteInterno(String clienteInterno) {
        ClienteInterno = clienteInterno;
    }

    public String getClaCarroColocado() {
        return ClaCarroColocado;
    }

    public void setClaCarroColocado(String claCarroColocado) {
        ClaCarroColocado = claCarroColocado;
    }
}

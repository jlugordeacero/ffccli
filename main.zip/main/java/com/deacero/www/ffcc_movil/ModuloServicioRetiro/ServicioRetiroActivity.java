package com.deacero.www.ffcc_movil.ModuloServicioRetiro;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.ModuloServicioColocacion.RegistroColocacionServicioActivity;
import com.deacero.www.ffcc_movil.R;
import com.deacero.www.ffcc_movil.metodos.AuthenticationWS;
import com.deacero.www.ffcc_movil.metodos.AuthenticationWS2;
import com.deacero.www.ffcc_movil.metodos.GetCarrosColocadosWS;
import com.deacero.www.ffcc_movil.metodos.Internet;
import com.deacero.www.ffcc_movil.metodos.PostColocacionWS;
import com.deacero.www.ffcc_movil.metodos.PostEvalaucionRetiroWS;
import com.deacero.www.ffcc_movil.metodos.PostRetiroWS;

import java.net.NetworkInterface;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class ServicioRetiroActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener{
    ///////BD
    BDFFCCMovil objBD= new BDFFCCMovil(this); //hace la conexión
    public static final String LLAVE_ENCRIPTAR = "deacero";
    private Cursor c, c2,c3,c4,c5;
    private RecyclerView recyclerServicioRetiro;
    private Spinner spinnerViaOri, spinnerViaClienteInterno;
    private ImageButton imgBtnCalendario;
    private TextView txtFecha;
    private ArrayList<ServicioRetiroVO> listRetiro = new ArrayList<ServicioRetiroVO>();
    private List<String> listId = new ArrayList<String>();//almaceno los claVias
    private List<String> listNames = new ArrayList<String>();//para almacenar los NomVia
    private List<String> listCI = new ArrayList<String>();//para almacenar los NomVia
    //DATOS SESSION USUARIO
    private String idUsuario,ClaEmpleado,NombreUsuario,loginUserName, ClaUbicacionLogin, MAC, token, Password;
    private static final String CERO = "0";
    private static final String BARRA = "/";
    //Calendario para obtener fecha & hora
    public final Calendar ca = Calendar.getInstance();
    //Variables para obtener la fecha
    final int mes =  ca.get(Calendar.MONTH);
    final int dia = ca.get(Calendar.DAY_OF_MONTH);
    final int anio = ca.get(Calendar.YEAR);
    private Toast toast;
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.servicio_retiro_activity);
        //vars
        //vars
        idUsuario = getIntent().getExtras().getString("idUsuario");
        ClaEmpleado = getIntent().getExtras().getString("ClaEmpleado");
        NombreUsuario = getIntent().getExtras().getString("NombreUsuario");
        loginUserName = getIntent().getExtras().getString("loginUserName");
        ClaUbicacionLogin  = getIntent().getExtras().getString("ClaUbicacion");
        MAC = getIntent().getExtras().getString("DireccionMAC");

        spinnerViaOri = (Spinner) findViewById(R.id.spinnerViaOrigen);
        spinnerViaClienteInterno = (Spinner) findViewById(R.id.spinnerViaClienteInterno);
        txtFecha = (TextView) findViewById(R.id.txtFecha);
        imgBtnCalendario = (ImageButton)findViewById(R.id.imgBtnCalendar);
        recyclerServicioRetiro = (RecyclerView) findViewById(R.id.recyclerServRetiro);


        c = objBD.getUserXLoginUser(loginUserName);
        if(c.getCount()>0){
            c.moveToFirst();
            Password = c.getString(4);
        }
        c.close();

        Internet internet = new Internet(getApplicationContext());

        // Log.e("CONEXION:",""+ConexionInternet.toString());
        if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
            AuthenticationWS2 AuthWS = new AuthenticationWS2(ServicioRetiroActivity.this, getString(R.string.ip_authentication), loginUserName, Password, MAC, "0");
            String respuesta = String.valueOf(AuthWS.execute(""));

            c2 = objBD.getUserXLoginUser(loginUserName);
            if (c2.getCount() > 0) {
                c2.moveToFirst();
                token = c2.getString(8);
            }
            c2.close();
            objBD.close();

            c3 = objBD.getColocaciones("3");///a 3 porque se enviaran todas las que seas iguales a 3 colocacion terminada
            c3.moveToFirst();
            if(c3.getCount()>0) {
                PostColocacionWS WSSendColocacion = new PostColocacionWS(ServicioRetiroActivity.this, token, getString(R.string.IpPostColocacion), ClaUbicacionLogin, idUsuario, MAC);
                WSSendColocacion.execute("");
            }
            c3.close();
            c4 = objBD.getRetirosAPI("1");///a 1 porque se enviaran todos los retiros que hayan terminado
            c4.moveToFirst();
            if(c4.getCount()>0) {
                PostRetiroWS WSSendRetiro = new PostRetiroWS(ServicioRetiroActivity.this, token, getString(R.string.IpPostRetiro), ClaUbicacionLogin, idUsuario, MAC);
                WSSendRetiro.execute("");
            }
            c4.close();
            c5 = objBD.getEvaluacionRetirosAPI("1");///a 1 porque se enviaran todos los retiros que hayan terminado
            c5.moveToFirst();
            if(c5.getCount()>0) {
                PostEvalaucionRetiroWS WSSendEvalRetiro = new PostEvalaucionRetiroWS(ServicioRetiroActivity.this, token, getString(R.string.IpPostEvaluacionRetiro), ClaUbicacionLogin, idUsuario, MAC);
                WSSendEvalRetiro.execute("");
            }
            c5.close();
            String Fecha = "";

            Date date = new Date();
            date.setDate(date.getDate() - 1);
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Fecha = dateFormat.format(date);
            Log.e("Fecha ", "" + Fecha);

            // GetCarrosColocadosWS WSCarrosColocadosSRV = new GetCarrosColocadosWS(ServicioRetiroActivity.this,token,getString(R.string.IpGetColocacionDiseno),ClaUbicacionLogin, Fecha);
            // WSCarrosColocadosSRV.execute("");


        }



        spinnerViaOri.setOnItemSelectedListener(this);
        spinnerViaClienteInterno.setOnItemSelectedListener(this);

        c = objBD.getViaConCI(ClaUbicacionLogin);
        c.moveToFirst();
        if (c.moveToFirst()) {
            do {
                listId.add(c.getString(1));//adding ClaVia
                listNames.add(c.getString(2));//adding NomVia
            } while (c.moveToNext());
        }
        c.close();
        objBD.close();
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listNames);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerViaOri.setAdapter(dataAdapter);

        imgBtnCalendario.setOnClickListener(this);

        SimpleDateFormat dateFormat2 = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        Date date2 = new Date();
        String fecha = dateFormat2.format(date2);
        txtFecha.setText(fecha);
        txtFecha.setEnabled(false);

        recyclerServicioRetiro.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
      /*  String Via = listId.get(spinnerViaOri.getSelectedItemPosition());
        String[] FechaAcomodada = fecha.split("/");
        String FECHAA = FechaAcomodada[2]+FechaAcomodada[1]+FechaAcomodada[0];
        consulta(Via,FECHAA,);
        ServicioRetiroAdapter colocados = new ServicioRetiroAdapter(ServicioRetiroActivity.this,listRetiro,MAC);
        recyclerServicioRetiro.setAdapter(colocados);*/




    }

    @Override
    public void onRestart() {
        super.onRestart(); //Toast.makeText(this,"restart ins",Toast.LENGTH_SHORT).show();
        String ClaVia1 = listId.get(spinnerViaOri.getSelectedItemPosition());//This will be the student id.
        String NomVia1 = listNames.get(spinnerViaOri.getSelectedItemPosition());//This will be the student id.
        String fecha1 = String.valueOf(txtFecha.getText());
        //Log.e("fecha:",ClaVia+"--"+"fecha:"+fecha);
       String[] FechaAcomodada1 = fecha1.split("/");
       String FECHAA1 = FechaAcomodada1[2]+"-"+FechaAcomodada1[1]+"-"+FechaAcomodada1[0];

       String CI= listCI.get(spinnerViaClienteInterno.getSelectedItemPosition());
       String[] CliInt = CI.split(" -> ");
        // System.out.println("-------------datos:"+ClaVia1+"--"+"fecha:"+FECHAA1+"  -----------"+CliInt[0]);

        consulta(ClaVia1,FECHAA1,""+CliInt[0]);
        ServicioRetiroAdapter loteo = new ServicioRetiroAdapter(ServicioRetiroActivity.this,listRetiro,MAC,loginUserName,idUsuario,ClaUbicacionLogin);
        recyclerServicioRetiro.setAdapter(loteo);
        System.out.println("ON RESTART");
    }

    public String desencriptar(String textoEncriptado) {
        String secretKey = LLAVE_ENCRIPTAR; //llave para desenciptar datos
        String base64EncryptedString = "";

        try {
            byte[] message = Base64.decode(textoEncriptado.getBytes("utf-8"), Base64.DEFAULT);
            MessageDigest md = MessageDigest.getInstance("SHA256");
            byte[] digestOfPassword = md.digest(secretKey.getBytes("utf-8"));
            byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);
            SecretKey key = new SecretKeySpec(keyBytes, "DESede");

            Cipher decipher = Cipher.getInstance("DESede");
            decipher.init(Cipher.DECRYPT_MODE, key);

            byte[] plainText = decipher.doFinal(message);

            base64EncryptedString = new String(plainText, "UTF-8");

        } catch (Exception ex) {
        }
        return base64EncryptedString;
    }


    public void limpiaRecycleryLista(){
        recyclerServicioRetiro.removeAllViewsInLayout();
        listRetiro.clear();
    }

    private  void consulta(String Via, String FechaColocacion, String ClaClienteInterno) {
        limpiaRecycleryLista();
        try {
            System.out.println("FECHACOOLOC******************** "+FechaColocacion);
            //el valor es 3
            c = objBD.getServicioRetiroClienteInterno("3",Via,FechaColocacion, ClaClienteInterno);//14 estatus retiro
            if(c.getCount()>0) {
                c.moveToFirst();
                for (int x = 0; x < c.getCount(); x++) {
                    listRetiro.add(new ServicioRetiroVO(""+c.getString(0),""+c.getString(7), ""+c.getString(1),""+c.getString(6),""+c.getString(4), ""+objBD.getCantidadColocadasDet(c.getString(1),c.getString(2)),""+c.getString(9),""+c.getString(10),""+c.getString(11),""+c.getString(7),""+c.getString(12),""+c.getString(2),""+objBD.getCantidadRetiradasDet(c.getString(1),c.getString(0)),c.getString(13), ""+c.getString(14)));
                    c.moveToNext();
                }
            }else{
                if (toast!= null) { toast.cancel(); }
                toast = Toast.makeText(getApplicationContext(),"No hay servicios para retirar.", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }
            c.close();
            objBD.CloseDB();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String vias="",FECHAA1="",CI="";
        String[] Vias,FechaAcomodada1,CliInt;
        switch (parent.getId()) {
            case R.id.spinnerViaOrigen:
                limpiaRecycleryLista();
                listCI.clear();

                vias= listId.get(position);
                Vias = vias.split(" -> ");
                c2 = objBD.getClienteInternoUbi(ClaUbicacionLogin,Vias[0]);
                if (c2.moveToFirst()) {
                    do {
                        listCI.add(c2.getString(1)+" -> "+c2.getString(2));//
                    } while (c2.moveToNext());
                }
                c2.close();
                objBD.close();
                ArrayAdapter<String> dataAdapterCI = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, listCI);
                dataAdapterCI.setDropDownViewResource(android.R.layout.simple_list_item_1);
                spinnerViaClienteInterno.setAdapter(dataAdapterCI);
                spinnerViaClienteInterno.setSelected(true);

                break;
            case R.id.spinnerViaClienteInterno:
                String ClaVia1 = listId.get(spinnerViaOri.getSelectedItemPosition());//This will be the student id.
                String NomVia1 = listNames.get(spinnerViaOri.getSelectedItemPosition());//This will be the student id.
                String fecha1 = String.valueOf(txtFecha.getText());
                //Log.e("fecha:",ClaVia+"--"+"fecha:"+fecha);
                FechaAcomodada1 = fecha1.split("/");
                FECHAA1 = FechaAcomodada1[2]+"-"+FechaAcomodada1[1]+"-"+FechaAcomodada1[0];

                CI= listCI.get(spinnerViaClienteInterno.getSelectedItemPosition());
                CliInt = CI.split(" -> ");
               // System.out.println("-------------datos:"+ClaVia1+"--"+"fecha:"+FECHAA1+"  -----------"+CliInt[0]);

                consulta(ClaVia1,FECHAA1,""+CliInt[0]);
                ServicioRetiroAdapter loteo = new ServicioRetiroAdapter(ServicioRetiroActivity.this,listRetiro,MAC,loginUserName,idUsuario,ClaUbicacionLogin);
                recyclerServicioRetiro.setAdapter(loteo);
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add_insmancomunada, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.itmreturn:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.imgBtnCalendar:
                System.out.println("CALENDAR ******** ");
                obtenerFecha();
                break;
        }
    }

    private void obtenerFecha(){
        DatePickerDialog recogerFecha = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                final int mesActual = month + 1;
                String diaFormateado = (dayOfMonth < 10)? CERO + String.valueOf(dayOfMonth):String.valueOf(dayOfMonth);
                String mesFormateado = (mesActual < 10)? CERO + String.valueOf(mesActual):String.valueOf(mesActual);
                txtFecha.setText(diaFormateado + BARRA + mesFormateado + BARRA + year);

                String ClaVia = listId.get(spinnerViaOri.getSelectedItemPosition());
                final int pos = spinnerViaClienteInterno.getSelectedItemPosition();
                System.out.println("pos   *** "+ pos );
               // if(pos>0) {
                    String ClienteInterno = listCI.get(pos);
                    String[] MyCliInt = ClienteInterno.split(" -> ");

                    String fecha1 = String.valueOf(txtFecha.getText().toString());
                    String[] FechaAcomodada1 = fecha1.split("/");
                    System.out.println("FECHAACOMODADA-------------------- "+FechaAcomodada1[2] + "-" + FechaAcomodada1[1] + "-" + FechaAcomodada1[0]);
                    //System.out.println("-------------datos:"+ClaVia+"--"+"fecha:"+FechaAcomodada1[2]+"-"+FechaAcomodada1[1]+"-"+FechaAcomodada1[0]+"  -----------"+MyCliInt[0]);
                    consulta(ClaVia, FechaAcomodada1[2] + "-" + FechaAcomodada1[1] + "-" + FechaAcomodada1[0], "" + MyCliInt[0]);
                    ServicioRetiroAdapter loteo = new ServicioRetiroAdapter(ServicioRetiroActivity.this, listRetiro, MAC,loginUserName,idUsuario,ClaUbicacionLogin);
                    recyclerServicioRetiro.setAdapter(loteo);
               // }
            }
        },anio, mes, dia);
        recogerFecha.show();


    }

}

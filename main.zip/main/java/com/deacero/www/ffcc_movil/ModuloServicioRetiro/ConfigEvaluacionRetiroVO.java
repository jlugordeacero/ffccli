package com.deacero.www.ffcc_movil.ModuloServicioRetiro;


public class ConfigEvaluacionRetiroVO {
    private String ClaUbicacion, IdTraEvaluacionRetiroCIDet, IdTraEvaluacionRetiroCI, IdCfgEvaluacionRetiroDet,
            NomCfgElavuacionRetiroDet, Valor, ClaUsuarioMod, NombrePcMod, IdRetiro;


    public ConfigEvaluacionRetiroVO(String claUbicacion, String idTraEvaluacionRetiroCIDet, String idTraEvaluacionRetiroCI, String idCfgEvaluacionRetiroDet, String nomCfgElavuacionRetiroDet, String valor, String claUsuarioMod, String nombrePcMod, String idRetiro) {
        ClaUbicacion = claUbicacion;
        IdTraEvaluacionRetiroCIDet = idTraEvaluacionRetiroCIDet;
        IdTraEvaluacionRetiroCI = idTraEvaluacionRetiroCI;
        IdCfgEvaluacionRetiroDet = idCfgEvaluacionRetiroDet;
        NomCfgElavuacionRetiroDet = nomCfgElavuacionRetiroDet;
        Valor = valor;
        ClaUsuarioMod = claUsuarioMod;
        NombrePcMod = nombrePcMod;
        IdRetiro = idRetiro;
    }
    public String getIdRetiro() {
        return IdRetiro;
    }

    public void setIdRetiro(String idRetiro) {
        IdRetiro = idRetiro;
    }

    public String getClaUbicacion() {
        return ClaUbicacion;
    }

    public void setClaUbicacion(String claUbicacion) {
        ClaUbicacion = claUbicacion;
    }

    public String getIdTraEvaluacionRetiroCIDet() {
        return IdTraEvaluacionRetiroCIDet;
    }

    public void setIdTraEvaluacionRetiroCIDet(String idTraEvaluacionRetiroCIDet) {
        IdTraEvaluacionRetiroCIDet = idTraEvaluacionRetiroCIDet;
    }

    public String getIdTraEvaluacionRetiroCI() {
        return IdTraEvaluacionRetiroCI;
    }

    public void setIdTraEvaluacionRetiroCI(String idTraEvaluacionRetiroCI) {
        IdTraEvaluacionRetiroCI = idTraEvaluacionRetiroCI;
    }

    public String getIdCfgEvaluacionRetiroDet() {
        return IdCfgEvaluacionRetiroDet;
    }

    public void setIdCfgEvaluacionRetiroDet(String idCfgEvaluacionRetiroDet) {
        IdCfgEvaluacionRetiroDet = idCfgEvaluacionRetiroDet;
    }

    public String getNomCfgElavuacionRetiroDet() {
        return NomCfgElavuacionRetiroDet;
    }

    public void setNomCfgElavuacionRetiroDet(String nomCfgElavuacionRetiroDet) {
        NomCfgElavuacionRetiroDet = nomCfgElavuacionRetiroDet;
    }

    public String getValor() {
        return Valor;
    }

    public void setValor(String valor) {
        Valor = valor;
    }

    public String getClaUsuarioMod() {
        return ClaUsuarioMod;
    }

    public void setClaUsuarioMod(String claUsuarioMod) {
        ClaUsuarioMod = claUsuarioMod;
    }

    public String getNombrePcMod() {
        return NombrePcMod;
    }

    public void setNombrePcMod(String nombrePcMod) {
        NombrePcMod = nombrePcMod;
    }
}

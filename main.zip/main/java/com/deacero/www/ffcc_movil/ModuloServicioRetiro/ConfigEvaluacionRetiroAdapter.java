package com.deacero.www.ffcc_movil.ModuloServicioRetiro;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.R;

import java.util.ArrayList;

public class ConfigEvaluacionRetiroAdapter extends RecyclerView.Adapter<ConfigEvaluacionRetiroAdapter.ViewHolderConfigSituadoAdapter>  {
    private ArrayList<ConfigEvaluacionRetiroVO> listaConfiguraciones;
    private Context mContext;

    public class ViewHolderConfigSituadoAdapter extends RecyclerView.ViewHolder implements CompoundButton.OnCheckedChangeListener {
        final BDFFCCMovil objBD = new BDFFCCMovil(mContext);
        TextView EtiNomConf;
        Switch switchtoogle;
        public ViewHolderConfigSituadoAdapter(@NonNull View itemView) {
            super(itemView);
            EtiNomConf=(TextView) itemView.findViewById(R.id.txtNomConf);
            switchtoogle= (Switch) itemView.findViewById(R.id.IdSwitch);

            switchtoogle.setOnCheckedChangeListener(this);
        }

        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            final int pos = getAdapterPosition();
            if(isChecked){
                System.out.println("valor "+isChecked);
                switchtoogle.setChecked(true);
                switchtoogle.setText("SI");

                listaConfiguraciones.get(pos).setValor("1");

                objBD.UpdateEvaluacionCI(""+listaConfiguraciones.get(pos).getClaUbicacion(),"1",""+listaConfiguraciones.get(pos).getIdTraEvaluacionRetiroCI(),""+listaConfiguraciones.get(pos).getIdCfgEvaluacionRetiroDet());
              //  notifyItemChanged(pos);
                //notifyDataSetChanged();
            }else{
                System.out.println("valor2 "+isChecked);
                switchtoogle.setChecked(false);
                switchtoogle.setText("NO");

                listaConfiguraciones.get(pos).setValor("0");

                objBD.UpdateEvaluacionCI(""+listaConfiguraciones.get(pos).getClaUbicacion(),"0",""+listaConfiguraciones.get(pos).getIdTraEvaluacionRetiroCI(),""+listaConfiguraciones.get(pos).getIdCfgEvaluacionRetiroDet());
             //   notifyItemChanged(pos);
               // notifyDataSetChanged();
            }
        }
    }

    public ConfigEvaluacionRetiroAdapter(Context context, ArrayList<ConfigEvaluacionRetiroVO> listaConfiguraciones) {
        this.listaConfiguraciones = listaConfiguraciones;
        this.mContext = context;
    }

    @NonNull
    @Override
    public ViewHolderConfigSituadoAdapter onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_cfg_eval_retiro,viewGroup,false);
        return new ViewHolderConfigSituadoAdapter(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolderConfigSituadoAdapter viewHolderConfigSituadoAdapter, final int position) {
             viewHolderConfigSituadoAdapter.EtiNomConf.setText(listaConfiguraciones.get(position).getNomCfgElavuacionRetiroDet());
        System.out.println("---"+listaConfiguraciones.get(position).getValor());


        System.out.println("CERO");
        viewHolderConfigSituadoAdapter.switchtoogle.setText("NO");
        viewHolderConfigSituadoAdapter.switchtoogle.setChecked(false);

             if("1".equals(listaConfiguraciones.get(position).getValor())){

                 System.out.println("UNO");
                 viewHolderConfigSituadoAdapter.switchtoogle.setText("SI");
                 viewHolderConfigSituadoAdapter.switchtoogle.setChecked(true);
             }

    }

    @Override
    public int getItemCount() {
        return listaConfiguraciones.size();
    }

}

package com.deacero.www.ffcc_movil.ModuloServicioRetiro;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.BuildConfig;
import com.deacero.www.ffcc_movil.ModuloInspeccionMancomunada.ConfigSituadoAdapter;
import com.deacero.www.ffcc_movil.ModuloInspeccionMancomunada.ConfigSituadoVO;
import com.deacero.www.ffcc_movil.R;
import com.deacero.www.ffcc_movil.cn.EnumExt;
import com.deacero.www.ffcc_movil.metodos.AuthenticationWS2;
import com.deacero.www.ffcc_movil.metodos.Internet;
import com.deacero.www.ffcc_movil.metodos.PostEvalaucionRetiroWS;
import com.deacero.www.ffcc_movil.metodos.PostRetiroWS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class EvalucionRetiroActivity extends AppCompatActivity implements View.OnClickListener {
    /////////BD
    BDFFCCMovil objBD = new BDFFCCMovil(this);//hace la conexión
    private Cursor c, c2, c3;
    ////////
    private ArrayList<ConfigEvaluacionRetiroVO> listCfgEvaluacion = new ArrayList<ConfigEvaluacionRetiroVO>();
    private RecyclerView recyclerConfigSituados;
    private TextView textViewPlaca;
    private ImageView ImgVSave,ImageViewRegresar;
    ///variables globales
    private String Placa,ClaCarro,IdRetiro, ClaUbicacionLogin, FechaRetiro,loginUserName="",Password="",token="",idUsuario,MAC;
    private Toast toast;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.evaluacion_retiro_cliente_interno_activity);
        //ClaCarro = getIntent().getExtras().getString("IdPlaca");
       // Placa = getIntent().getExtras().getString("Placa");
        IdRetiro = getIntent().getExtras().getString("IdRetiro");
        ClaUbicacionLogin = getIntent().getExtras().getString("ClaUbicacionLogin");
        loginUserName = getIntent().getExtras().getString("loginUserName");
        idUsuario = getIntent().getExtras().getString("ClaUsuarioMod");
        MAC = getIntent().getExtras().getString("MAC");
        System.out.println("IdRetiro: "+IdRetiro+" ClaUbicacionLogin: "+ClaUbicacionLogin);
        //FechaRetiro = getIntent().getExtras().getString("fechaRetiro");

        ImgVSave = (ImageView)findViewById(R.id.ImgSaveEvaluacionRetiro);
        ImageViewRegresar = (ImageView)findViewById(R.id.IdImagenRegresar);
        recyclerConfigSituados =(RecyclerView)findViewById(R.id.reciclerevaluacionretiro);

        ImageViewRegresar.setOnClickListener(this);

        ImgVSave.setOnClickListener(this);

        recyclerConfigSituados.setLayoutManager(new LinearLayoutManager(this));
        consulta();
        ConfigEvaluacionRetiroAdapter sit = new ConfigEvaluacionRetiroAdapter(EvalucionRetiroActivity.this,listCfgEvaluacion);
        recyclerConfigSituados.setAdapter(sit);
    }

    private  void consulta() {
        System.out.println("DATOS******************** "+ClaUbicacionLogin+" - "+IdRetiro);
        c = objBD.getDataTraEvaluacionRetiro(ClaUbicacionLogin,IdRetiro);
        c.moveToFirst();
        if (c.getCount()>0) {
            for (int x = 0; x < c.getCount(); x++) {
                //System.out.println("---"+c.getString(3));
                    listCfgEvaluacion.add(new ConfigEvaluacionRetiroVO(""+c.getString(0),""+c.getString(1),""+c.getString(2),""+c.getString(3),""+c.getString(4),""+c.getString(5),""+c.getString(6),""+c.getString(7),""+c.getString(8)));
                c.moveToNext();
            }
        }else{
            Log.e("No hay registros.",String.valueOf(c.getCount()));
            if (toast!= null) { toast.cancel(); }
            toast = Toast.makeText(getApplicationContext(),"No se encontraron registros.", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();

        }
        c.close();
        objBD.close();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.IdImagenRegresar:
                        finish();
                break;
            case R.id.ImgSaveEvaluacionRetiro:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setIcon(R.drawable.notify_dialog);
                builder.setTitle("¡Si guardas los cambios, no podrás editar la evaluación al salir de esta pantalla!");
                builder.setMessage("Da click en aceptar para continuar ");
                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                            for (int x = 0; x < listCfgEvaluacion.size(); x++){
                                //System.out.println(x+" -- "+listCfgEvaluacion.get(x).getIdRetiro() + " ------- " + listCfgEvaluacion.get(x).getValor());
                                objBD.updateTraEvaluacionRetiro(listCfgEvaluacion.get(x).getValor(),listCfgEvaluacion.get(x).getClaUsuarioMod(),listCfgEvaluacion.get(x).getNombrePcMod(),listCfgEvaluacion.get(x).getClaUbicacion(),listCfgEvaluacion.get(x).getIdTraEvaluacionRetiroCI(),listCfgEvaluacion.get(x).getIdTraEvaluacionRetiroCIDet(),listCfgEvaluacion.get(x).getIdCfgEvaluacionRetiroDet());
                                objBD.updateEstatusTraEvaluacionRetiro("1",listCfgEvaluacion.get(x).getClaUbicacion(),listCfgEvaluacion.get(x).getIdTraEvaluacionRetiroCI());


                                c = objBD.getUserXLoginUser(loginUserName);
                                if(c.getCount()>0){
                                    c.moveToFirst();
                                    Password = c.getString(4);
                                }
                                c.close();

                                Internet internet = new Internet(getApplicationContext());

                                // Log.e("CONEXION:",""+ConexionInternet.toString());
                                if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
                                    AuthenticationWS2 AuthWS = new AuthenticationWS2(EvalucionRetiroActivity.this, getString(R.string.ip_authentication), loginUserName, Password, MAC, "0");
                                    String respuesta = String.valueOf(AuthWS.execute(""));

                                    c2 = objBD.getUserXLoginUser(loginUserName);
                                    if (c2.getCount() > 0) {
                                        c2.moveToFirst();
                                        token = c2.getString(8);
                                    }
                                    c2.close();
                                    objBD.close();


                                    PostEvalaucionRetiroWS WSSendEvalRetiro = new PostEvalaucionRetiroWS(EvalucionRetiroActivity.this, token, getString(R.string.IpPostEvaluacionRetiro), ClaUbicacionLogin, idUsuario, MAC);
                                    WSSendEvalRetiro.execute("");
                                }
                            }

                        objBD.CloseDB();
                            finish();

                    }
                });
                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                builder.show();
                objBD.CloseDB();
                break;
        }
    }
}

package com.deacero.www.ffcc_movil.ModuloServicioRetiro;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.Image;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.ModuloServicioColocacion.EditarColocacionActivity;
import com.deacero.www.ffcc_movil.ModuloServicioColocacion.ServicioColocacionVO;
import com.deacero.www.ffcc_movil.R;
import com.deacero.www.ffcc_movil.metodos.AuthenticationWS2;
import com.deacero.www.ffcc_movil.metodos.PostEdicionRetiroWS;
import com.deacero.www.ffcc_movil.metodos.PostEvalaucionRetiroWS;
import com.deacero.www.ffcc_movil.metodos.PostRetiroWS;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class ServicioRetiroAdapter extends RecyclerView.Adapter<ServicioRetiroAdapter.ViewHolderLoteoUnidad> {

    private ArrayList<ServicioRetiroVO> listaRetiro;

    private Context mContext;
    private View.OnClickListener listener;
    private AlertDialog dialog;
    private String chooseItem;
    private Cursor c,c2,c3;
    private View view;
    private String MAC ,loginUserName ="",Password="",token="",idUsuario="",ClaUbicacionLogin="";

    public class ViewHolderLoteoUnidad extends ViewHolder implements View.OnClickListener {
        private TextView NomVia,etFechaColocacion, etCantidad, etFechaRetiro, etFechaInicio, etFechaFin, etRetiradas, etCantRet;
        private Button btnRetirar,btnEditarRetiro;
        private ImageView MyDetail, MyEdit;
        private Toast toast;

        final BDFFCCMovil objBD = new BDFFCCMovil(mContext);

        public ViewHolderLoteoUnidad(@NonNull View itemView) {
            super(itemView);
            etFechaColocacion = (TextView) itemView.findViewById(R.id.txtFechaColocacion);
            etFechaRetiro = (TextView) itemView.findViewById(R.id.txtFechaRetiro);
            etCantidad = (TextView) itemView.findViewById(R.id.txtCantidad);
            btnRetirar = (Button) itemView.findViewById(R.id.btnRetirar);
            btnEditarRetiro = (Button) itemView.findViewById(R.id.btnEditarRetiro);
            NomVia = (TextView) itemView.findViewById(R.id.txtNomVia);
            MyDetail = (ImageView) itemView.findViewById(R.id.imgShowDetalle);
            MyEdit = (ImageView) itemView.findViewById(R.id.imgShowEdit);
            etRetiradas = (TextView) itemView.findViewById(R.id.txtCantidadRetiradas);
            btnRetirar.setOnClickListener(this);
            btnEditarRetiro.setOnClickListener(this);
            MyDetail.setOnClickListener(this);
            MyEdit.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            System.out.println("POSICION   "+getAdapterPosition());
            final int newPosition = getAdapterPosition();
            switch (v.getId()){
                case R.id.imgShowDetalle:
                    if("1".equals(listaRetiro.get(newPosition).getEstatusRetiro()) || listaRetiro.get(newPosition).getFechaRetiro() == null || ("null").equals(listaRetiro.get(newPosition).getFechaRetiro()) || "3".equals(listaRetiro.get(newPosition).getEstatusRetiro()) || "2".equals(listaRetiro.get(newPosition).getEstatusRetiro()) ) {
                        Intent servicioRet = new Intent(mContext, EditarRetiroActivity.class);
                        servicioRet.putExtra("ClaCfgSolicitudServicio", listaRetiro.get(newPosition).getClaCfgSolicitudServicio());
                        servicioRet.putExtra("IdRetiro", listaRetiro.get(newPosition).getIdRetiro());
                        servicioRet.putExtra("ClaConfServicios", listaRetiro.get(newPosition).getClaConfServicios());
                        servicioRet.putExtra("ClaConfVentana", listaRetiro.get(newPosition).getClaConfVentana());
                        servicioRet.putExtra("ClaUbicacion", listaRetiro.get(newPosition).getClaUbicacion());
                        servicioRet.putExtra("IdColocacion", listaRetiro.get(newPosition).getClaCarroColocado());
                        // servicioRet.putExtra("IdColocacionSqlServer",listaRetiro.get(newPosition).getIdColocacionSqlServer());
                        servicioRet.putExtra("MAC", MAC);
                        servicioRet.putExtra("ClaCarroColocado", listaRetiro.get(newPosition).getClaCarroColocado());
                        mContext.startActivity(servicioRet);
                    }else{
                        if (toast!= null) { toast.cancel(); }
                        toast = Toast.makeText(mContext,"No puedes editar un retiro terminado.", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();

                    }
                    break;

                case R.id.imgShowEdit:
                    if("1".equals(listaRetiro.get(newPosition).getEstatusRetiro()) || listaRetiro.get(newPosition).getFechaRetiro() == null || ("null").equals(listaRetiro.get(newPosition).getFechaRetiro()) || "3".equals(listaRetiro.get(newPosition).getEstatusRetiro()) || "2".equals(listaRetiro.get(newPosition).getEstatusRetiro()) ) {
                        Intent servicioRet = new Intent(mContext, EditarRetiroActivity2.class);
                        servicioRet.putExtra("ClaCfgSolicitudServicio", listaRetiro.get(newPosition).getClaCfgSolicitudServicio());
                        servicioRet.putExtra("IdRetiro", listaRetiro.get(newPosition).getIdRetiro());
                        servicioRet.putExtra("ClaConfServicios", listaRetiro.get(newPosition).getClaConfServicios());
                        servicioRet.putExtra("ClaConfVentana", listaRetiro.get(newPosition).getClaConfVentana());
                        servicioRet.putExtra("ClaUbicacion", listaRetiro.get(newPosition).getClaUbicacion());
                        servicioRet.putExtra("IdColocacion", listaRetiro.get(newPosition).getClaCarroColocado());
                        // servicioRet.putExtra("IdColocacionSqlServer",listaRetiro.get(newPosition).getIdColocacionSqlServer());
                        servicioRet.putExtra("MAC", MAC);
                        servicioRet.putExtra("ClaCarroColocado", listaRetiro.get(newPosition).getClaCarroColocado());
                        mContext.startActivity(servicioRet);
                    }else{
                        if (toast!= null) { toast.cancel(); }
                        toast = Toast.makeText(mContext,"No puedes editar un retiro mas de una vez.", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();

                    }
                    break;
                case R.id.btnRetirar:
                    if(listaRetiro.get(newPosition).getFechaRetiro() == null || ("null").equals(listaRetiro.get(newPosition).getFechaRetiro())) {
                        AlertDialog builder;
                        builder = new AlertDialog.Builder(mContext).create();
                        // AlertDialog.Builder builder = new AlertDialog.Builder(listaRetiro.get(position).getContext());
                        builder.setIcon(R.drawable.notify_dialog);
                        builder.setTitle("Confirma si deseas retirar");
                        builder.setMessage("Cuando aceptes, se marcara como retirada.");
                        builder.setButton(AlertDialog.BUTTON_POSITIVE, "Aceptar",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        SimpleDateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss", Locale.getDefault());
                                        Date date = new Date();
                                        String myfecha = dateFormat.format(date);
                                        objBD.SetDateFechaRetiro(myfecha, listaRetiro.get(newPosition).getIdRetiro(), listaRetiro.get(newPosition).getClaUbicacion());
                                        objBD.updateEstatusRetiro2("" + listaRetiro.get(newPosition).getIdRetiro(), "" + listaRetiro.get(newPosition).getClaUbicacion(), "1");
                                        objBD.CloseDB();
                                        listaRetiro.get(newPosition).setFechaRetiro(myfecha);
                                        listaRetiro.get(newPosition).setEstatusRetiro("2");

                                        notifyItemChanged(newPosition); //actualiza los elementos no toma en cuenta el settext anterior necesito upd el dataset
                                        notifyDataSetChanged();

                                        c3 = objBD.getUserXLoginUser(loginUserName);
                                        if(c3.getCount()>0){
                                            c3.moveToFirst();
                                            Password = c3.getString(4);
                                        }
                                        c3.close();
                                        AuthenticationWS2 AuthWS = new AuthenticationWS2(mContext,itemView.getResources().getString(R.string.ip_authentication),loginUserName,Password,MAC,"0");
                                        String respuesta = String.valueOf(AuthWS.execute(""));

                                        c2 = objBD.getUserXLoginUser(loginUserName);
                                        if(c2.getCount()>0){
                                            c2.moveToFirst();
                                            token = c2.getString(8);
                                        }
                                        c2.close();
                                        objBD.close();

                                        PostRetiroWS WSSendRetiro = new PostRetiroWS(mContext,token,itemView.getResources().getString(R.string.IpPostRetiro),ClaUbicacionLogin,idUsuario,MAC);
                                        WSSendRetiro.execute("");


                                    }
                                });
                        builder.setButton(AlertDialog.BUTTON_NEGATIVE, "Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });
                        builder.setCancelable(false);
                        builder.setCanceledOnTouchOutside(false);
                        builder.show();
                    }else{
                            if("0".equals(objBD.getEstatusEvaluacion(listaRetiro.get(newPosition).getClaUbicacion(),listaRetiro.get(newPosition).getIdRetiro()))){
                                Intent EvalRet = new Intent(mContext,EvalucionRetiroActivity.class);
                                EvalRet.putExtra("IdRetiro",listaRetiro.get(newPosition).getIdRetiro());
                                EvalRet.putExtra("MAC",MAC);
                                EvalRet.putExtra("loginUserName",loginUserName);
                                EvalRet.putExtra("ClaUsuarioMod",idUsuario);
                                EvalRet.putExtra("ClaUbicacionLogin",ClaUbicacionLogin);
                                objBD.generarTraEvaluacionRetiro(listaRetiro.get(newPosition).getIdRetiro(),listaRetiro.get(newPosition).getClaUbicacion(),MAC,listaRetiro.get(newPosition).getClaUsuarioMod());
                                mContext.startActivity(EvalRet);
                            }else{
                                if (toast!= null) { toast.cancel(); }
                                toast = Toast.makeText(mContext,"Ya has evaluado este retiro.", Toast.LENGTH_LONG);
                                toast.setGravity(Gravity.CENTER, 0, 0);
                                toast.show();
                            }
                    }
                    break;
                case R.id.btnEditarRetiro:
                       AlertDialog builder;
                        builder = new AlertDialog.Builder(mContext).create();
                        // AlertDialog.Builder builder = new AlertDialog.Builder(listaRetiro.get(position).getContext());
                        builder.setIcon(R.drawable.notify_dialog);
                        builder.setTitle("Confirma si deseas editar este retiro");
                        builder.setMessage("Solo puedes editar una vez el retiro.");
                        builder.setButton(AlertDialog.BUTTON_POSITIVE, "Aceptar",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        SimpleDateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd HH:mm:ss", Locale.getDefault());
                                        Date date = new Date();
                                        String myfecha = dateFormat.format(date);
                                        objBD.SetDateFechaRetiro(myfecha, listaRetiro.get(newPosition).getIdRetiro(), listaRetiro.get(newPosition).getClaUbicacion());
                                        objBD.updateEstatusRetiro2("" + listaRetiro.get(newPosition).getIdRetiro(), "" + listaRetiro.get(newPosition).getClaUbicacion(), "3");
                                        objBD.CloseDB();
                                        listaRetiro.get(newPosition).setFechaRetiro(myfecha);

                                        notifyItemChanged(newPosition); //actualiza los elementos no toma en cuenta el settext anterior necesito upd el dataset
                                        notifyDataSetChanged();

                                         c3 = objBD.getUserXLoginUser(loginUserName);
                                        if(c3.getCount()>0){
                                            c3.moveToFirst();
                                            Password = c3.getString(4);
                                        }
                                        c3.close();
                                        AuthenticationWS2 AuthWS = new AuthenticationWS2(mContext,itemView.getResources().getString(R.string.ip_authentication),loginUserName,Password,MAC,"0");
                                        String respuesta = String.valueOf(AuthWS.execute(""));

                                        c2 = objBD.getUserXLoginUser(loginUserName);
                                        if(c2.getCount()>0){
                                            c2.moveToFirst();
                                            token = c2.getString(8);
                                        }
                                        c2.close();
                                        objBD.close();


                                        PostRetiroWS WSSendRetiro = new PostRetiroWS(mContext,token,itemView.getResources().getString(R.string.IpPostRetiro),ClaUbicacionLogin,idUsuario,MAC);
                                        WSSendRetiro.execute("");

                                        PostEdicionRetiroWS WSSendEditRetiro = new PostEdicionRetiroWS(mContext,token,itemView.getResources().getString(R.string.IpPostRetiro),ClaUbicacionLogin,idUsuario,MAC);
                                        WSSendEditRetiro.execute("");

                                    }
                                });
                        builder.setButton(AlertDialog.BUTTON_NEGATIVE, "Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });
                        builder.setCancelable(false);
                        builder.setCanceledOnTouchOutside(false);
                        builder.show();

                    break;
            }
        }
    }

    public ServicioRetiroAdapter(Context context, ArrayList<ServicioRetiroVO> listLoteoUnidad, String MyMAC,String loginUserName,String idUsuario,String ClaUbicacionLogin) {
        this.listaRetiro = listLoteoUnidad;
        this.mContext = context;
        this.MAC = MyMAC;
        this.loginUserName = loginUserName;
        this.idUsuario = idUsuario;
        this.ClaUbicacionLogin = ClaUbicacionLogin;
    }

    @NonNull
    @Override
    public ViewHolderLoteoUnidad onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list_servicio_retiro,null,false);
        return new ViewHolderLoteoUnidad(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolderLoteoUnidad viewHolderLoteoUnidad, final int position) {
        viewHolderLoteoUnidad.NomVia.setText(listaRetiro.get(position).getVia());
        viewHolderLoteoUnidad.etFechaColocacion.setText("Fecha Colocación: "+listaRetiro.get(position).getFechaColocacion().replace("T"," "));
        viewHolderLoteoUnidad.etCantidad.setText("Colocadas: "+listaRetiro.get(position).getUnidad());
        viewHolderLoteoUnidad.etRetiradas.setText("Retiradas. "+ listaRetiro.get(position).getRetiradas());

        if(("null").equals(listaRetiro.get(position).getFechaRetiro()) || listaRetiro.get(position).getFechaRetiro() == null ){
            viewHolderLoteoUnidad.etFechaRetiro.setText("Fecha Retiro: Indefinida");
            viewHolderLoteoUnidad.btnRetirar.setText("RETIRAR");
        }else{
            viewHolderLoteoUnidad.etFechaRetiro.setText("Fecha Retiro: "+listaRetiro.get(position).getFechaRetiro());
            viewHolderLoteoUnidad.btnRetirar.setText("EVALUAR");
        }

        if("1".equals(listaRetiro.get(position).getEstatusRetiro()) || "2".equals(listaRetiro.get(position).getEstatusRetiro()) || "3".equals(listaRetiro.get(position).getEstatusRetiro())  || "4".equals(listaRetiro.get(position).getEstatusRetiro())  ) {
            viewHolderLoteoUnidad.btnEditarRetiro.setVisibility(View.VISIBLE);
        }

        if("3".equals(listaRetiro.get(position).getEstatusRetiro()) || "2".equals(listaRetiro.get(position).getEstatusRetiro()) || "1".equals(listaRetiro.get(position).getEstatusRetiro()) ) {
            viewHolderLoteoUnidad.btnRetirar.setVisibility(View.GONE);
        }

    }

    @Override
    public int getItemCount() {
        return listaRetiro.size();
    }

}
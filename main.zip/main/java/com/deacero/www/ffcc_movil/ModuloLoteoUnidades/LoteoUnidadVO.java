package com.deacero.www.ffcc_movil.ModuloLoteoUnidades;

import android.content.Context;

public class LoteoUnidadVO {

    private String IdLoteoUnidadEnc;
    private String IdLoteoUnidadDet;
    private String ClaCarro;
    private String Placa;
    private String EsCarcado;
    private String ClaMaterial;
    private String ClaViaDestino, NombreMaterial;


    private String NomViaDestino;
    private int imgelimina, imgcambiovia;
    private Context context;

    public LoteoUnidadVO(String idLoteoUnidadEnc, String idLoteoUnidadDet, String claCarro, String placa, String esCarcado, String claMaterial, String claViaDestino, String nomViaDestino, int imgelimina, int imgcambiovia, Context context, String nombreMaterial) {
        IdLoteoUnidadEnc = idLoteoUnidadEnc;
        IdLoteoUnidadDet = idLoteoUnidadDet;
        ClaCarro = claCarro;
        Placa = placa;
        EsCarcado = esCarcado;
        ClaMaterial = claMaterial;
        ClaViaDestino = claViaDestino;
        NomViaDestino = nomViaDestino;
        this.imgelimina = imgelimina;
        this.imgcambiovia = imgcambiovia;
        this.context = context;
        this.NombreMaterial = nombreMaterial;
    }

    public String getNombreMaterial() {
        return NombreMaterial;
    }

    public void setNombreMaterial(String nombreMaterial) {
        NombreMaterial = nombreMaterial;
    }

    public String getNomViaDestino() {
        return NomViaDestino;
    }

    public void setNomViaDestino(String nomViaDestino) {
        NomViaDestino = nomViaDestino;
    }

    public String getIdLoteoUnidadEnc() {
        return IdLoteoUnidadEnc;
    }

    public void setIdLoteoUnidadEnc(String idLoteoUnidadEnc) {
        IdLoteoUnidadEnc = idLoteoUnidadEnc;
    }

    public String getIdLoteoUnidadDet() {
        return IdLoteoUnidadDet;
    }

    public void setIdLoteoUnidadDet(String idLoteoUnidadDet) {
        IdLoteoUnidadDet = idLoteoUnidadDet;
    }

    public String getClaCarro() {
        return ClaCarro;
    }

    public void setClaCarro(String claCarro) {
        ClaCarro = claCarro;
    }

    public String getPlaca() {
        return Placa;
    }

    public void setPlaca(String placa) {
        Placa = placa;
    }

    public String getEsCarcado() {
        return EsCarcado;
    }

    public void setEsCarcado(String esCarcado) {
        EsCarcado = esCarcado;
    }

    public String getClaMaterial() {
        return ClaMaterial;
    }




    public void setClaMaterial(String claMaterial) {
        ClaMaterial = claMaterial;
    }

    public String getClaViaDestino() {
        return ClaViaDestino;
    }

    public void setClaViaDestino(String claViaDestino) {
        ClaViaDestino = claViaDestino;
    }

    public int getImgelimina() {
        return imgelimina;
    }

    public void setImgelimina(int imgelimina) {
        this.imgelimina = imgelimina;
    }

    public int getImgcambiovia() {
        return imgcambiovia;
    }

    public void setImgcambiovia(int imgcambiovia) {
        this.imgcambiovia = imgcambiovia;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }
}

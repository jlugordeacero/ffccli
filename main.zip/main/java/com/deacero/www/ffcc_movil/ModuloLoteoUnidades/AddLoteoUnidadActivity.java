package com.deacero.www.ffcc_movil.ModuloLoteoUnidades;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.Html;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.R;
import com.deacero.www.ffcc_movil.metodos.AuthenticationWS2;
import com.deacero.www.ffcc_movil.metodos.GetCarrosWS;
import com.deacero.www.ffcc_movil.metodos.Internet;
import com.deacero.www.ffcc_movil.metodos.PostLoteoWS;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AddLoteoUnidadActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    ///////BD
    private BDFFCCMovil objBD= new BDFFCCMovil(this); //hace la conexión
    private Cursor c,c2;
    private ArrayList<AddLoteoUnidadVO> listAddLoteoUnidad = new ArrayList<AddLoteoUnidadVO>();
    public static final String LLAVE_ENCRIPTAR = "deacero";
    private RecyclerView recyclerAddLoteoUnidad;
    private String idUsuario, ClaEmpleado,loginUserName,token,DireccionMAC,ClaUbicacionLogin;
    private String Password;
    private Toast toast;
    private EditText editTextPlaca;
    private ImageButton imgBotonAdd;
    private CheckBox MyCheckMasivo;
    private ImageView MyImageSendAll;
    private Spinner spinnerViaDes, spinnerViaOri;
    private List<String> listId = new ArrayList<String>();//almaceno los claVias
    private List<String> listNames = new ArrayList<String>();//para almacenar los NomVia
    private List<String> listNamesDes = new ArrayList<String>();//para almaceno NomTipoMaterial
    private String chequearTodos="0";
    private ArrayAdapter<String> AdpViaOri, AdpViaDes;
    private AddLoteoUnidadAdapter sit;
    private AuthenticationWS2 AuthWS;
    private GetCarrosWS WSCarros;
    private AlertDialog.Builder builder;
    private FloatingActionButton btnTerminarLoteo;
    private Internet internet;
    private PostLoteoWS WSSendLoteo;
    private Button btnConsulta;
    private TextView TextInfo;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_loteo_unidad_activity);

        idUsuario = getIntent().getExtras().getString("idUsuario");//NombrePcMod
        ClaEmpleado = getIntent().getExtras().getString("ClaEmpleado");//Clave del empleado, la misma que el login
        loginUserName = getIntent().getExtras().getString("loginUserName");
        token = getIntent().getExtras().getString("token");
        DireccionMAC = getIntent().getExtras().getString("DireccionMAC");
        ClaUbicacionLogin = getIntent().getExtras().getString("ClaUbicacion");
        //Asignacion Objetos
        spinnerViaOri = (Spinner) findViewById(R.id.spinnerViaOrigen);
        spinnerViaDes = (Spinner) findViewById(R.id.spinnerViaDestinoMasivo);
        MyCheckMasivo = (CheckBox) findViewById(R.id.checkMasivo);
        MyImageSendAll = (ImageView) findViewById(R.id.imgSendAll);
        recyclerAddLoteoUnidad =(RecyclerView)findViewById(R.id.recycleraddsituados);
        editTextPlaca = (EditText) findViewById(R.id.txtSearchPlaca);
        imgBotonAdd = (ImageButton) findViewById(R.id.btnBuscarPlaca);
        btnTerminarLoteo = (FloatingActionButton) findViewById(R.id.btnTerminarLoteo);
        btnConsulta = (Button) findViewById(R.id.btnConsulta);
        TextInfo = (TextView) findViewById(R.id.TextInfo);

        //Asignacion escuchadores
        spinnerViaOri.setOnItemSelectedListener(this);
        MyImageSendAll.setOnClickListener(this);
        imgBotonAdd.setOnClickListener(this);
        btnTerminarLoteo.setOnClickListener(this);
        btnConsulta.setOnClickListener(this);

        c = objBD.getVia(ClaUbicacionLogin);
        c.moveToFirst();
        if (c.moveToFirst()) {
            do {
                listId.add(c.getString(1));//adding ClaVia
                listNames.add(c.getString(2));//adding NomVia
            } while (c.moveToNext());
        }
        c.close();
        objBD.close();
        AdpViaOri = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_activated_1 , listNames);
        AdpViaOri.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        spinnerViaOri.setAdapter(AdpViaOri);
        spinnerViaOri.setSelected(true);

        c = objBD.getViaExcluye(ClaUbicacionLogin,listId.get(spinnerViaOri.getSelectedItemPosition()));
        c.moveToFirst();
        listNamesDes.add("* -> Elige Via Destino");//adding NomVia
        if (c.moveToFirst()) {
            do {
                listNamesDes.add(c.getString(1)+" -> "+c.getString(2));//adding NomVia
            } while (c.moveToNext());
        }
        c.close();
        objBD.close();
        // Creating adapter for spinner
        AdpViaDes = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_activated_1, listNamesDes);
        AdpViaDes.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
        spinnerViaDes.setAdapter(AdpViaDes);

        MyCheckMasivo.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if ( isChecked ){
                    chequearTodos="1";
                }else{
                    chequearTodos="0";
                }
                recyclerAddLoteoUnidad.removeAllViewsInLayout();
                listAddLoteoUnidad.clear();
                recyclerAddLoteoUnidad.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                String Valor = editTextPlaca.getText().toString().replace(" ","").toUpperCase();
                if(editTextPlaca.getText().toString().replace(" ","").toUpperCase() == ""){
                     Valor = "%";
                }
                consulta(Valor,"2", chequearTodos);
                sit = new AddLoteoUnidadAdapter(AddLoteoUnidadActivity.this,listAddLoteoUnidad,ClaUbicacionLogin,listId.get(spinnerViaOri.getSelectedItemPosition()), DireccionMAC,idUsuario);
                recyclerAddLoteoUnidad.setAdapter(sit);
            }
        });

        editTextPlaca.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                if(editTextPlaca.getText().length() >= 3) {
                    recyclerAddLoteoUnidad.removeAllViewsInLayout();
                    listAddLoteoUnidad.clear();
                    recyclerAddLoteoUnidad.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                    consulta(editTextPlaca.getText().toString().replace(" ","").toUpperCase(),"1",chequearTodos);
                    sit = new AddLoteoUnidadAdapter(AddLoteoUnidadActivity.this,listAddLoteoUnidad,ClaUbicacionLogin,listId.get(spinnerViaOri.getSelectedItemPosition()), DireccionMAC,idUsuario);
                    recyclerAddLoteoUnidad.setAdapter(sit);
                }
            }
        });

        c = objBD.getUserXLoginUser(loginUserName);
        if(c.getCount()>0){
            c.moveToFirst();
            Password = c.getString(4);
        }
        c.close();
        AuthWS = new AuthenticationWS2(AddLoteoUnidadActivity.this,getString(R.string.ip_authentication),loginUserName,Password,DireccionMAC,"0");
        String respuesta = String.valueOf(AuthWS.execute(""));

        c2 = objBD.getUserXLoginUser(loginUserName);
        if(c2.getCount()>0){
            c2.moveToFirst();
            token = c2.getString(8);
            System.out.println("TOKEN ............... "+token);
        }
        c2.close();
        objBD.close();

        WSCarros = new GetCarrosWS(AddLoteoUnidadActivity.this,token,getString(R.string.IpGetCarros),ClaUbicacionLogin,DireccionMAC);
        WSCarros.execute("");

        recyclerAddLoteoUnidad.removeAllViewsInLayout();
        listAddLoteoUnidad.clear();
        recyclerAddLoteoUnidad.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        consulta(editTextPlaca.getText().toString().replace(" ","").toUpperCase(), "2",chequearTodos);
        sit = new AddLoteoUnidadAdapter(AddLoteoUnidadActivity.this,listAddLoteoUnidad,ClaUbicacionLogin,listId.get(spinnerViaOri.getSelectedItemPosition()),DireccionMAC,idUsuario);
        recyclerAddLoteoUnidad.setAdapter(sit);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add_insmancomunada, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.itmreturn:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private  void consulta(String Placa, String FormaBusqueda, String chequearTodos) {
        try {                        //FormaBusqueda 1->EditText  2->Via
            c = objBD.getCatCarroVw(Placa, listId.get(spinnerViaOri.getSelectedItemPosition()), FormaBusqueda);///getcarro es una mezcla con tracontrolunidad
            c.moveToFirst();
            TextInfo.setText("Hay " + c.getCount() + " gondolas en la via seleccionada.");
            TextInfo.setTextColor(Color.BLUE);

            if(c.getCount()>0) {
                for (int x = 0; x < c.getCount(); x++) {
                    if("0".equals(c.getString(20))){
                        chequearTodos= "1" ;
                    }else if("1".equals(c.getString(20))){
                        chequearTodos = "0";
                    }
                    listAddLoteoUnidad.add(new AddLoteoUnidadVO(chequearTodos,
                            ""+c.getString(0),
                            ""+c.getString(1),
                            ""+c.getString(10),
                            ""+c.getString(11),
                            ""+c.getString(12),
                            this,
                            ""+c.getString(17),
                            ""+c.getString(20)));
                    c.moveToNext();
                }
                c.close();
                objBD.CloseDB();
            }
            else{
               //eliminar toat actual cuando no se aya cerrado cuando se ejecuto otro
                if (toast!= null) { toast.cancel(); }
                toast = Toast.makeText(getApplicationContext(),"No se encontraron registros.", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.imgSendAll:
                builder = new AlertDialog.Builder(AddLoteoUnidadActivity.this);
                builder.setIcon(R.drawable.notify_dialog);
                builder.setTitle("!*****AVISO*****¡");
                builder.setMessage("¿Estas seguro de lotear todas las placas elegidas?");
                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String Valor = listNamesDes.get(spinnerViaDes.getSelectedItemPosition());
                        String[] NewValor =  Valor.split(" -> ");
                        if("*".equals(NewValor[0])) {
                            if (toast!= null) { toast.cancel(); }
                            toast = Toast.makeText(getApplicationContext(),"Elige la via de destino.", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                        }else {
                            if (listAddLoteoUnidad.size() > 0) {
                                final int posViaMasivo =  spinnerViaDes.getSelectedItemPosition();
                                for (int x = 0; x < listAddLoteoUnidad.size(); x++) {
                                    String ViasMASIVO = listNamesDes.get(posViaMasivo);
                                    String[] MASIVOVias = ViasMASIVO.split(" -> ");
                                    if("1".equals(listAddLoteoUnidad.get(x).getMasivo())){
                                        objBD.AddLoteo(ClaUbicacionLogin,""+listId.get(spinnerViaOri.getSelectedItemPosition()) , "", DireccionMAC, ""+idUsuario, ""+idUsuario, ""+MASIVOVias[0], "null", listAddLoteoUnidad.get(x).getIdPlaca(), listAddLoteoUnidad.get(x).getPlaca(), listAddLoteoUnidad.get(x).getEsVacio(), listAddLoteoUnidad.get(x).getNombreMaterial());
                                        objBD.ActualizaEstatusLoteoFFCCCarro(listAddLoteoUnidad.get(x).getIdControlUnidad(),listAddLoteoUnidad.get(x).getPlaca(),"1");
                                    }
                                }
                                recyclerAddLoteoUnidad.removeAllViewsInLayout();
                                listAddLoteoUnidad.clear();
                                recyclerAddLoteoUnidad.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                                consulta(editTextPlaca.getText().toString().replace(" ","").toUpperCase(), "2",chequearTodos);
                                sit = new AddLoteoUnidadAdapter(AddLoteoUnidadActivity.this,listAddLoteoUnidad,ClaUbicacionLogin,listId.get(spinnerViaOri.getSelectedItemPosition()),DireccionMAC,idUsuario);
                                recyclerAddLoteoUnidad.setAdapter(sit);

                                btnTerminarLoteo.callOnClick();///lllama el webservice

                            }else{
                                if (toast!= null) { toast.cancel(); }
                                toast = Toast.makeText(getApplicationContext(),"No hay nada para lotear", Toast.LENGTH_LONG);
                                toast.setGravity(Gravity.CENTER, 0, 0);
                                toast.show();
                            }
                        }
                    }
                });
                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                builder.show();
                break;
            case R.id.btnBuscarPlaca:
                builder = new AlertDialog.Builder(AddLoteoUnidadActivity.this);
                builder.setIcon(R.drawable.notify_dialog);
                builder.setTitle(Html.fromHtml("<h1>!***** AVISO *****¡</h1>"));
                builder.setMessage(Html.fromHtml("<h2>¿Estas seguro de agregar la placa <font color='#FF0000'></b>"+
                        editTextPlaca.getText().toString().replace(" ","").toUpperCase()+ "</b></font>?</h2> "));
                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //String PlacaCarroNueva = editTextPlaca.getText().toString();
                        int total = objBD.getFoundCarro(editTextPlaca.getText().toString().replace(" ","").toUpperCase());
                        if(total > 0){
                            if (toast!= null) { toast.cancel(); }
                            toast = Toast.makeText(getApplicationContext(),"La placa "+ editTextPlaca.getText().toString().replace(" ","").toUpperCase() +" ya existe\n" +
                                    " "+objBD.getDataPlacaCarro(editTextPlaca.getText().toString().replace(" ","").toUpperCase()), Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                        }else {
                            // Check for a valid user.
                            if (TextUtils.isEmpty(editTextPlaca.getText().toString().replace(" ","").toUpperCase())) {
                                editTextPlaca.setError(getString(R.string.error_field_required));
                            } else {
                                String Fecha = "";

                                Date date = new Date();
                                date.setDate(date.getDate()-1);
                                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                Fecha= dateFormat.format(date);

                                objBD.InsertarFfccCatCarroVw("-1",
                                        editTextPlaca.getText().toString().replace(" ","").toUpperCase(),
                                        "NULL",
                                        "NULL",
                                        "NULL",
                                        "NULL",
                                        "NULL",
                                        ""+Fecha,
                                        ""+DireccionMAC,
                                        ""+idUsuario,
                                        "-1",
                                        "0",
                                        ""+listId.get(spinnerViaOri.getSelectedItemPosition()),
                                        ""+Fecha,
                                        "NULL",
                                        ""+ClaUbicacionLogin);
                                recyclerAddLoteoUnidad.removeAllViewsInLayout();
                                listAddLoteoUnidad.clear();
                                recyclerAddLoteoUnidad.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                                consulta(editTextPlaca.getText().toString().replace(" ","").toUpperCase(), "2", chequearTodos);
                                sit = new AddLoteoUnidadAdapter(AddLoteoUnidadActivity.this, listAddLoteoUnidad, ClaUbicacionLogin, listId.get(spinnerViaOri.getSelectedItemPosition()), DireccionMAC, idUsuario);
                                recyclerAddLoteoUnidad.setAdapter(sit);
                            }
                        }
                        c.close();
                        objBD.close();

                    }
                });
                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                builder.show();
                break;
            case R.id.btnTerminarLoteo:
                try {
                            try {
                                c = objBD.getLoteoUnidadEncDet(ClaUbicacionLogin,"0");
                                if(c.getCount()>0) {
                                    c.moveToFirst();
                                    objBD.updateEstatusLoteo(ClaUbicacionLogin,
                                            ""+c.getString(2),
                                            "1",
                                            c.getString(0));
                                    for (int x = 0; x < c.getCount(); x++) {
                                        objBD.UpdCatCarroLoteo(""+c.getString(8),
                                                ""+c.getString(6),
                                                ""+c.getString(5),
                                                "0");
                                        c.moveToNext();
                                    }
                                }
                                c.close();
                                objBD.close();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            objBD.close();
                            c = objBD.getUserXLoginUser(loginUserName);
                            if (c.getCount() > 0) {
                                c.moveToFirst();
                                Password = c.getString(4);
                            }
                            c.close();
                            internet = new Internet(getApplicationContext());
                            if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
                                AuthWS = new AuthenticationWS2(AddLoteoUnidadActivity.this, getString(R.string.ip_authentication), loginUserName, Password, DireccionMAC, "0");
                                String respuesta = String.valueOf(AuthWS.execute(""));
                                c2 = objBD.getUserXLoginUser(loginUserName);
                                if (c2.getCount() > 0) {
                                    c2.moveToFirst();
                                    token = c2.getString(8);
                                }
                                c2.close();
                                WSSendLoteo = new PostLoteoWS(AddLoteoUnidadActivity.this, token, getString(R.string.IpPostLoteo), ClaUbicacionLogin, idUsuario, DireccionMAC, btnConsulta, "SI");
                                WSSendLoteo.execute("");
                            }
                    objBD.CloseDB();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            case R.id.btnConsulta:
                recyclerAddLoteoUnidad.removeAllViewsInLayout();
                listAddLoteoUnidad.clear();
                consulta("%","2",""+chequearTodos);
                sit = new AddLoteoUnidadAdapter(AddLoteoUnidadActivity.this,listAddLoteoUnidad,ClaUbicacionLogin,listId.get(spinnerViaOri.getSelectedItemPosition()), DireccionMAC,idUsuario);
                recyclerAddLoteoUnidad.setAdapter(sit);
                break;
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()) {
            case R.id.spinnerViaOrigen:
                listNamesDes.clear();
                c = objBD.getViaExcluye(ClaUbicacionLogin,listId.get(spinnerViaOri.getSelectedItemPosition()));
                c.moveToFirst();
                listNamesDes.add("* -> Elige Via Destino");//adding NomVia
                if (c.moveToFirst()) {
                    do {
                        listNamesDes.add(c.getString(1)+" -> "+c.getString(2));//adding NomVia
                    } while (c.moveToNext());
                }
                c.close();
                objBD.close();
                // Creating adapter for spinner
                AdpViaDes = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_activated_1, listNamesDes);
                AdpViaDes.setDropDownViewResource(android.R.layout.simple_list_item_single_choice);
                spinnerViaDes.setAdapter(AdpViaDes);

                recyclerAddLoteoUnidad.removeAllViewsInLayout();
                listAddLoteoUnidad.clear();
                recyclerAddLoteoUnidad.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                consulta(editTextPlaca.getText().toString().replace(" ","").toUpperCase(),"1",chequearTodos);
                sit = new AddLoteoUnidadAdapter(AddLoteoUnidadActivity.this,listAddLoteoUnidad,ClaUbicacionLogin,listId.get(position), DireccionMAC,idUsuario);
                recyclerAddLoteoUnidad.setAdapter(sit);
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
package com.deacero.www.ffcc_movil.ModuloLoteoUnidades;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;
import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.LoginActivity;
import com.deacero.www.ffcc_movil.MenuActivity;
import com.deacero.www.ffcc_movil.R;
import com.deacero.www.ffcc_movil.metodos.AuthenticationWS;
import com.deacero.www.ffcc_movil.metodos.AuthenticationWS2;
import com.deacero.www.ffcc_movil.metodos.GetCarrosWS;
import com.deacero.www.ffcc_movil.metodos.Internet;
import com.deacero.www.ffcc_movil.metodos.PostLoteoWS;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class LoteoUnidadesActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {
    private BDFFCCMovil objBD= new BDFFCCMovil(this); //hace la conexión

    public static final String LLAVE_ENCRIPTAR = "deacero";
    private Cursor c, c2;
    private RecyclerView recyclerLoteoUnidad;
    private Spinner spinnerViaOri;
    private ArrayList<LoteoUnidadVO> listLoteoUnidad = new ArrayList<LoteoUnidadVO>();
    private List<String> listId = new ArrayList<String>();//almaceno los claVias
    private List<String> listNames = new ArrayList<String>();//para almacenar los NomVia
    private String idUsuario,ClaEmpleado,loginUserName,token,DireccionMAC,ClaUbicacionLogin, Password;
    private FloatingActionButton btnTerminarLoteo;
    private Toast toast;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loteo_unidades_activity);
        idUsuario = getIntent().getExtras().getString("idUsuario");//ClaUsuarioMod
        ClaEmpleado = getIntent().getExtras().getString("ClaEmpleado");//Clave del empleado, la misma que el login
        loginUserName = getIntent().getExtras().getString("loginUserName");//Usuario
        token = getIntent().getExtras().getString("token");
        DireccionMAC = getIntent().getExtras().getString("DireccionMAC");
        ClaUbicacionLogin = getIntent().getExtras().getString("ClaUbicacion");
        btnTerminarLoteo = (FloatingActionButton) findViewById(R.id.btnTerminarLoteo);

        btnTerminarLoteo.setOnClickListener(this);


        spinnerViaOri = (Spinner) findViewById(R.id.spinnerViaOrigen);
        spinnerViaOri.setOnItemSelectedListener(this);
        c = objBD.getVia(ClaUbicacionLogin);
        c.moveToFirst();
        if (c.moveToFirst()) {
            do {
                listId.add(c.getString(1));//adding ClaVia
                listNames.add(c.getString(2));//adding NomVia
            } while (c.moveToNext());
        }
        c.close();
        objBD.close();
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, listNames);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spinnerViaOri.setAdapter(dataAdapter);
        spinnerViaOri.setSelected(true);
       // consulta(listId.get(spinnerViaOri.getSelectedItemPosition()),ClaUbicacionLogin);
        recyclerLoteoUnidad = (RecyclerView) findViewById(R.id.recyclerloteounidades);
        recyclerLoteoUnidad.setLayoutManager(new LinearLayoutManager(getApplicationContext()));


        c = objBD.getUserXLoginUser(loginUserName);
        if(c.getCount()>0){
            c.moveToFirst();
            Password = c.getString(4);
        }
        c.close();
        AuthenticationWS2 AuthWS = new AuthenticationWS2(LoteoUnidadesActivity.this,getString(R.string.ip_authentication),loginUserName,Password,DireccionMAC,"0");
        String respuesta = String.valueOf(AuthWS.execute(""));

        c2 = objBD.getUserXLoginUser(loginUserName);
        if(c2.getCount()>0){
            c2.moveToFirst();
            token = c2.getString(8);
            System.out.println("TOKEN ............... "+token);
        }
        c2.close();
        objBD.close();

        GetCarrosWS WSCarros = new GetCarrosWS(LoteoUnidadesActivity.this,token,getString(R.string.IpGetCarros),ClaUbicacionLogin,DireccionMAC);
        WSCarros.execute("");

    }

    @Override
    public void onRestart() {
        super.onRestart(); //Toast.makeText(this,"restart ins",Toast.LENGTH_SHORT).show();
        recyclerLoteoUnidad.removeAllViewsInLayout();
        listLoteoUnidad.clear();
        recyclerLoteoUnidad.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        final int position = spinnerViaOri.getSelectedItemPosition();
        String ClaVia = listId.get(position);
        consulta(""+ClaVia,""+ClaUbicacionLogin);
        LoteoUnidadAdapter sit = new LoteoUnidadAdapter(LoteoUnidadesActivity.this,listLoteoUnidad,ClaUbicacionLogin);
        recyclerLoteoUnidad.setAdapter(sit);
    }

    private  void consulta(String ClaViaOrigen, String ClaUbicacion) {
        recyclerLoteoUnidad.removeAllViewsInLayout();
        listLoteoUnidad.clear();
        //Log.e("VIALOTEO: ",""+ClaViaOrigen);//debe ser la 2 test
        try {
            c = objBD.getLoteoUnidadEnc(ClaViaOrigen,ClaUbicacion,"0");
            c.moveToFirst();
            if(c.getCount()>0) {
                for (int x = 0; x < c.getCount(); x++) {
                    String IdLoteoUnidadEnc =  c.getString(0);
                    //Log.e("count enc ",""+c.getCount());
                    c2 = objBD.getLoteoUnidadDet(IdLoteoUnidadEnc);
                    c2.moveToFirst();
                    //Log.e("count  detalle",""+c2.getCount());
                    if(c2.getCount()>0) {
                        for (int y = 0; y < c2.getCount(); y++) {
                            String IdLoteoUnidadDet = c2.getString(1);
                            //Log.e("det ", "" + IdLoteoUnidadDet);
                            String ClaCarro = c2.getString(2);
                            String Placa = c2.getString(3);
                            String esCargado = c2.getString(4);
                            String ClaMaterial = c2.getString(5);
                            String ClaViaDestino = c2.getString(6);//7 nomvia,  6 clavia
                            String NomViaDestino = c2.getString(7);//7 nomvia,  6 clavia
                            listLoteoUnidad.add(new LoteoUnidadVO(IdLoteoUnidadEnc, IdLoteoUnidadDet, ClaCarro, Placa, esCargado, ClaMaterial, ClaViaDestino, NomViaDestino, R.drawable.trash, R.drawable.cambiovia, LoteoUnidadesActivity.this, ""+c2.getString(8)));
                            c2.moveToNext();
                        }
                        c2.close();
                    }else{
                        if (toast!= null) { toast.cancel(); }
                        toast = Toast.makeText(getApplicationContext(),"Para:  "+spinnerViaOri.getSelectedItem()+", aún no hay placas para lotear.", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                    }
                    c2.close();
                        c.moveToNext();
                }
            }else{
                if (toast!= null) { toast.cancel(); }
                toast = Toast.makeText(getApplicationContext(),"Para la via "+spinnerViaOri.getSelectedItem()+", no hay placas para lotear.", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }
            c.close();
            objBD.CloseDB();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()) {
            case R.id.spinnerViaOrigen:
                String ClaVia = listId.get(position);//This will be the student id.
                String NomVia = listNames.get(position);//This will be the student id.
                consulta(ClaVia,ClaUbicacionLogin);
                LoteoUnidadAdapter loteo = new LoteoUnidadAdapter(LoteoUnidadesActivity.this,listLoteoUnidad,ClaUbicacionLogin);
                recyclerLoteoUnidad.setAdapter(loteo);
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }
    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_loteounidades, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.itmeditplaca:
                int posicion = spinnerViaOri.getSelectedItemPosition();//obtengo posicion del item seleccionado
                if(listId.size()<=0 && listNames.size()<=0){
                    if (toast!= null) { toast.cancel(); }
                    toast = Toast.makeText(getApplicationContext(),"No hay vias cargadas para hacer loteos.", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }else{
                    String ClaVia = listId.get(posicion);//This will be the student id.
                    String NomVia = listNames.get(posicion);//This will be the student id.
                    Intent intlistasql = new Intent(getApplicationContext(),AddLoteoUnidadActivity.class);
                    intlistasql.putExtra("idUsuario",idUsuario);//ClaUsuarioMod
                    intlistasql.putExtra("ClaEmpleado",ClaEmpleado);//Clave del empleado, la misma que el login
                    intlistasql.putExtra("loginUserName",loginUserName);//Usuario
                    intlistasql.putExtra("token",token);
                    intlistasql.putExtra("DireccionMAC",DireccionMAC);
                    intlistasql.putExtra("ClaUbicacion",ClaUbicacionLogin);
                    intlistasql.putExtra("ClaViaSelected",ClaVia);
                    intlistasql.putExtra("NomViaSelected",NomVia);
                    startActivity(intlistasql);
                }
                return true;
            case R.id.itmreturn:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnTerminarLoteo:
                if(listId.size() <= 0){
                    if (toast != null) {
                        toast.cancel();
                    }
                    toast = Toast.makeText(getApplicationContext(), "No hay vias para hacer loteos.", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }else {

                    try {
                        AlertDialog.Builder builder = new AlertDialog.Builder(LoteoUnidadesActivity.this);
                        builder.setIcon(R.drawable.notify_dialog);
                        builder.setTitle("¿Estas seguro de terminar el Loteo?");
                        builder.setMessage("Via Elegida: " + listNames.get(spinnerViaOri.getSelectedItemPosition()));
                        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                            @RequiresApi(api = Build.VERSION_CODES.O)
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                // Remove the item on remove/button click
                                String ClaViaOri = listId.get(spinnerViaOri.getSelectedItemPosition());
                                //Log.e("ESTATUS UPD: ",ClaViaOri+"-"+""+ClaUbicacionLogin);
                                if (listLoteoUnidad.size() > 0) {
                                    objBD.updateEstatusLoteo(ClaUbicacionLogin, ClaViaOri, "1", listLoteoUnidad.get(0).getIdLoteoUnidadEnc());
                                    for (int x = 0; x < listLoteoUnidad.size(); x++) {
                                        System.out.println("libera loteo carro:" + listLoteoUnidad.get(x).getClaViaDestino() + "--" + listLoteoUnidad.get(x).getEsCarcado() + "--" + listLoteoUnidad.get(x).getPlaca());
                                        objBD.UpdateCatCarrosLoteo(listLoteoUnidad.get(x).getClaViaDestino(), listLoteoUnidad.get(x).getEsCarcado(), "" + listLoteoUnidad.get(x).getPlaca());
                                        objBD.ActualizaEstatusLoteoFFCCCarro2(listLoteoUnidad.get(x).getPlaca(), "0");
                                    }

                                    recyclerLoteoUnidad.removeAllViewsInLayout();
                                    listLoteoUnidad.clear();
                                    objBD.close();
                                    System.out.println(loginUserName + " -- " + ClaEmpleado);

                                    c = objBD.getUserXLoginUser(loginUserName);
                                    if (c.getCount() > 0) {
                                        c.moveToFirst();
                                        // System.out.println("PASS!1------- "+c.getString(4));
                                        Password = c.getString(4);
                                    }
                                    c.close();
                                    Internet internet = new Internet(getApplicationContext());
                                    // Log.e("CONEXION:",""+ConexionInternet.toString());
                                    if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
                                        AuthenticationWS2 AuthWS = new AuthenticationWS2(LoteoUnidadesActivity.this, getString(R.string.ip_authentication), loginUserName, Password, DireccionMAC, "0");
                                        String respuesta = String.valueOf(AuthWS.execute(""));
                                        c2 = objBD.getUserXLoginUser(loginUserName);
                                        if (c2.getCount() > 0) {
                                            c2.moveToFirst();
                                            token = c2.getString(8);
                                        }
                                        c2.close();
                                        //objBD.close();
                                        PostLoteoWS WSSendLoteo = new PostLoteoWS(LoteoUnidadesActivity.this, token, getString(R.string.IpPostLoteo), ClaUbicacionLogin, idUsuario, DireccionMAC,null,"NO");
                                        WSSendLoteo.execute("");
                                    }
                                } else {
                                    if (toast != null) {
                                        toast.cancel();
                                    }
                                    toast = Toast.makeText(getApplicationContext(), "No hay loteos pendientes.", Toast.LENGTH_LONG);
                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                    toast.show();
                                }
                            }
                        });
                        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });
                        builder.show();
                        objBD.CloseDB();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                break;
        }
    }
}
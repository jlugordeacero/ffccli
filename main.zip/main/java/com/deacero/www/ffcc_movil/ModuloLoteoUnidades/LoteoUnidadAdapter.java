package com.deacero.www.ffcc_movil.ModuloLoteoUnidades;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.R;

import java.util.ArrayList;
import java.util.List;

public class LoteoUnidadAdapter extends RecyclerView.Adapter<LoteoUnidadAdapter.ViewHolderLoteoUnidad> {
    ArrayList<LoteoUnidadVO> listaLoteo;
    List<String> listId = new ArrayList<String>();//almaceno los claVias
    List<String> listNames = new ArrayList<String>();//para almacenar los NomVia
    private Context mContext;
    private View.OnClickListener listener;
    private AlertDialog dialog;
    private String ClaUbicacionLogin;
    private Cursor c;
    private View view;
    public LoteoUnidadAdapter(Context context,ArrayList<LoteoUnidadVO> listLoteoUnidad, String claUbicacionLogin) {
        this.listaLoteo = listLoteoUnidad;
        this.mContext = context;
        ClaUbicacionLogin = claUbicacionLogin;
    }

    @NonNull
    @Override
    public ViewHolderLoteoUnidad onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list_loteounidades,null,false);
        return new ViewHolderLoteoUnidad(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final LoteoUnidadAdapter.ViewHolderLoteoUnidad viewHolderLoteoUnidad,final int position) {
        final BDFFCCMovil objBD = new BDFFCCMovil(listaLoteo.get(position).getContext());
        viewHolderLoteoUnidad.etiIdPlaca.setText(listaLoteo.get(position).getIdLoteoUnidadEnc());
        viewHolderLoteoUnidad.EtiPlaca.setText(listaLoteo.get(position).getPlaca());
        viewHolderLoteoUnidad.NomVia.setText(listaLoteo.get(position).getNomViaDestino());
        viewHolderLoteoUnidad.Material.setText(listaLoteo.get(position).getNombreMaterial());
        if(("0").equals(listaLoteo.get(position).getNombreMaterial()) || ("null").equals(listaLoteo.get(position).getNombreMaterial()) || listaLoteo.get(position).getNombreMaterial() == null){
            viewHolderLoteoUnidad.Material.setText("Indefinido");
        }
        String EsCargado = listaLoteo.get(position).getEsCarcado();
       // System.out.println(" ******* VALUE ES CARGADO: *******----> "+EsCargado);
        if("1".equals(EsCargado)) {
            viewHolderLoteoUnidad.CargadoVacio.setText("Cargado");
        }else{
            viewHolderLoteoUnidad.CargadoVacio.setText("Vacío");
        }
        viewHolderLoteoUnidad.ImgElimina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                builder.setIcon(R.drawable.notify_dialog);
                builder.setTitle("¿Estas seguro de eliminar este elemento?");
                builder.setMessage("Placa: "+ listaLoteo.get(position).getPlaca());
                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Boolean result = objBD.DeleteLoteoDet(listaLoteo.get(position).getIdLoteoUnidadEnc(), listaLoteo.get(position).getIdLoteoUnidadDet());
                        Log.e("boolean "," "+result);
                        objBD.ActualizaEstatusLoteoFFCCCarro2(listaLoteo.get(position).getPlaca(),"0");
                        listaLoteo.remove(position);
                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position,getItemCount());
                    }
                });
                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                builder.show();
            }
        });
        viewHolderLoteoUnidad.imgCambiaVia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog builder;
                builder = new AlertDialog.Builder(mContext).create();
                        builder.setIcon(R.drawable.notify_dialog);
                        builder.setTitle("Cambia la Vía Destino");
                        c = objBD.getVia(ClaUbicacionLogin);
                        c.moveToFirst();
                        if (c.moveToFirst()) {
                            do {
                                listId.add(c.getString(1));//adding ClaVia
                                listNames.add(c.getString(2));//adding NomVia
                            } while (c.moveToNext());
                        }
                        c.close();
                        objBD.close();
                        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(listaLoteo.get(position).getContext(),android.R.layout.simple_list_item_single_choice, listNames);
                        final Spinner sp = new Spinner(listaLoteo.get(position).getContext());
                        sp.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT));
                        sp.setAdapter(dataAdapter);
                        builder.setView(sp);
                    builder.setButton(AlertDialog.BUTTON_POSITIVE, "Aceptar",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                int posSpinner = sp.getSelectedItemPosition();
                                String IdViaDestino = listId.get(posSpinner);
                                String LoteoEnc =listaLoteo.get(position).getIdLoteoUnidadEnc();
                                String LoteoDet = listaLoteo.get(position).getIdLoteoUnidadDet();
                                objBD.UpdateViaDestino(LoteoEnc,LoteoDet,IdViaDestino);
                                objBD.CloseDB();
                                viewHolderLoteoUnidad.NomVia.setText(listNames.get(posSpinner));
                                //notifyItemChanged(position);
                                ///////////////////////----------------------------------
                                ///---DE ESTA MANERA SE ACTUALIZAN LOS DATOS DE LA LISTA :3
                                /////////////////--------------------
                                listaLoteo.get(position).setNomViaDestino(listNames.get(posSpinner));
                                //notifyDataSetChanged();
                                //notifyItemChanged(position); //actualiza los elementos no toma en cuenta el settext anterior necesito upd el dataset
                                listId.clear();
                                listNames.clear();
                            }
                        });
                    builder.setButton(AlertDialog.BUTTON_NEGATIVE, "Cancelar",  new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            listId.clear();
                            listNames.clear();
                        }
                    });
                        builder.setCancelable(false);
                        builder.setCanceledOnTouchOutside(false);
                        builder.show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaLoteo.size();
    }

    public class ViewHolderLoteoUnidad extends RecyclerView.ViewHolder {
        TextView etiIdPlaca, EtiPlaca,NomVia,Material,CargadoVacio;
        ImageView ImgElimina;
        ImageButton imgCambiaVia;
        public ViewHolderLoteoUnidad(@NonNull View itemView) {
            super(itemView);
            etiIdPlaca=(TextView) itemView.findViewById(R.id.txtidplaca);
            EtiPlaca=(TextView) itemView.findViewById(R.id.txtplaca);
            ImgElimina= (ImageView) itemView.findViewById(R.id.imgEliminaLoteo);
            imgCambiaVia = (ImageButton) itemView.findViewById(R.id.IdCambiaVia);
            NomVia=(TextView) itemView.findViewById(R.id.txtNomVia);
            Material=(TextView) itemView.findViewById(R.id.txtMaterial);
            CargadoVacio=(TextView) itemView.findViewById(R.id.txtCargadoVacio);
        }
    }
}
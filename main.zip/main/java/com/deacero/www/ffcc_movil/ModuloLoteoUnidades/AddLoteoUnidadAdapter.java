package com.deacero.www.ffcc_movil.ModuloLoteoUnidades;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.R;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class AddLoteoUnidadAdapter extends RecyclerView.Adapter<AddLoteoUnidadAdapter.ViewHolderAddSituado> {
    ArrayList<AddLoteoUnidadVO> listaAddLoteoUni;
    private View.OnClickListener listener;
    private Context mContext;
    private Cursor c, c2;
    private String ClaUbicacionLogin, ViaOrigen, DirMAC, ClaUsuario;
    private Toast toast;

    public String getClaUbicacionLogin() {
        return ClaUbicacionLogin;
    }
    public void setClaUbicacionLogin(String claUbicacionLogin) { ClaUbicacionLogin = claUbicacionLogin;   }
    public String getViaOrigen() {
        return ViaOrigen;
    }
    public void setViaOrigen(String viaOrigen) {
        ViaOrigen = viaOrigen;
    }
    public String getDirMAC() {
        return DirMAC;
    }
    public void setDirMAC(String dirMAC) {
        DirMAC = dirMAC;
    }
    public String getClaUsuario() {
        return ClaUsuario;
    }
    public void setClaUsuario(String claUsuario) {
        ClaUsuario = claUsuario;
    }

    public class ViewHolderAddSituado extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView etiIdPlaca, EtiPlaca, NomMaterial,NomViaDiseno, EtiEstatus;
        ImageView ImgNext;
        Spinner  spinnerViaDestino;
        CheckBox CheckCargado, CheckMasivo;
        List<String> listNames = new ArrayList<String>();//para almacenar los NomVia
        ArrayAdapter<String> AdpViaDest;
        public ViewHolderAddSituado(@NonNull View itemView) {
            super(itemView);
            final BDFFCCMovil objBD = new BDFFCCMovil(mContext);
            //etiIdPlaca=(TextView) itemView.findViewById(R.id.txtidplaca);
            EtiPlaca=(TextView) itemView.findViewById(R.id.txtplaca);
            ImgNext= (ImageView) itemView.findViewById(R.id.IdImagen);
            NomMaterial = (TextView) itemView.findViewById(R.id.NomMaterial);
            CheckMasivo = (CheckBox) itemView.findViewById(R.id.checkMasivoInterno);
            CheckCargado = (CheckBox) itemView.findViewById(R.id.CheckCargado);
            NomViaDiseno = (TextView) itemView.findViewById(R.id.NomViaDiseno);
            spinnerViaDestino = (Spinner) itemView.findViewById(R.id.spinnerViaDestino);
            EtiEstatus = (TextView) itemView.findViewById(R.id.TxtEstatus);
            ImgNext.setOnClickListener(this);
            CheckMasivo.setOnClickListener(this);
            CheckCargado.setOnClickListener(this);

            c = objBD.getViaExcluye(getClaUbicacionLogin(),ViaOrigen);
            c.moveToFirst();
            listNames.add("*-Elige la Via");//adding NomVia
            if (c.moveToFirst()) {
                do {
                    listNames.add(c.getString(1)+"-"+c.getString(2));//adding NomVia
                } while (c.moveToNext());
            }
            c.close();
            objBD.close();
            AdpViaDest = new ArrayAdapter<String>(mContext,android.R.layout.simple_list_item_1, listNames);
            AdpViaDest.setDropDownViewResource(android.R.layout.simple_list_item_1);
            spinnerViaDestino.setAdapter(AdpViaDest);
        }

        @Override
        public void onClick(View v) {
            final BDFFCCMovil objBD = new BDFFCCMovil(mContext);
            switch(v.getId()) {
                case R.id.checkMasivoInterno:///boton masivo
                    Log.e("position placa ",""+listaAddLoteoUni.get(getAdapterPosition()).getPlaca());
                    if (((CheckBox) v).isChecked()) {
                        listaAddLoteoUni.get(getAdapterPosition()).setMasivo("1");
                    }
                    else{
                        listaAddLoteoUni.get(getAdapterPosition()).setMasivo("0");
                    }
                    notifyDataSetChanged();
                    break;
                case R.id.CheckCargado:///check cargado o vacio
                    if (((CheckBox) v).isChecked()) {
                        listaAddLoteoUni.get(getAdapterPosition()).setEsVacio("1");
                    }
                    else{
                        listaAddLoteoUni.get(getAdapterPosition()).setEsVacio("0");
                    }
                    notifyDataSetChanged();
                    break;
                case R.id.IdImagen:///imagen confirmar
                    try {
                        final int newPosition = getAdapterPosition();
                        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                        builder.setIcon(R.drawable.notify_dialog);
                        builder.setTitle("¿Estas seguro de lotear esta placa?");
                        builder.setMessage("Placa: "+ listaAddLoteoUni.get(newPosition).getPlaca());
                        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                String[] ClaViaDestino = String.valueOf(spinnerViaDestino.getSelectedItem()).split("-");
                                final boolean isChecked = CheckCargado.isChecked();
                                String EsCargado = "0";
                                if(isChecked == true){
                                    EsCargado = "1";
                                }
                                if(ClaViaDestino[0].equals("*") ){
                                    if (toast!= null) { toast.cancel(); }
                                    toast = Toast.makeText(mContext,"Debes elegir una via de destino", Toast.LENGTH_LONG);
                                    toast.setGravity(Gravity.CENTER, 0, 0);
                                    toast.show();

                                }else {
                                    objBD.AddLoteo(getClaUbicacionLogin(), getViaOrigen(), "", getDirMAC(), getClaUsuario(), getClaUsuario(), ClaViaDestino[0], "null", listaAddLoteoUni.get(newPosition).getIdPlaca(), listaAddLoteoUni.get(newPosition).getPlaca(), EsCargado, listaAddLoteoUni.get(newPosition).getNombreMaterial());
                                    objBD.ActualizaEstatusLoteoFFCCCarro(listaAddLoteoUni.get(newPosition).getIdControlUnidad(),listaAddLoteoUni.get(newPosition).getPlaca(),"1");
                                    //listaAddLoteoUni.remove(newPosition);
                                    //notifyItemRemoved(newPosition);
                                    listaAddLoteoUni.get(newPosition).setEstatus("1");
                                    listaAddLoteoUni.get(newPosition).setClaVia(ClaViaDestino[0]);
                                    notifyItemChanged(newPosition);
                                    notifyItemRangeChanged(newPosition, listaAddLoteoUni.size());
                                    notifyDataSetChanged();
                                }
                            }
                        });
                        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });
                        builder.show();
                        objBD.CloseDB();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
            }
        }
    }

    public AddLoteoUnidadAdapter(Context context , ArrayList<AddLoteoUnidadVO> listaAddLoteoUnidad,String claUbicacionLogin,String viaOrigen, String dirMAC, String claUsuario) {
        this.listaAddLoteoUni = listaAddLoteoUnidad;
        mContext = context;
        ClaUbicacionLogin = claUbicacionLogin;
        ViaOrigen = viaOrigen;
        DirMAC = dirMAC;
        ClaUsuario = claUsuario;
    }

    @NonNull
    @Override
    public ViewHolderAddSituado onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list_add_loteo_unidad,null,false);
        return new ViewHolderAddSituado(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolderAddSituado viewHolderAddSituado, final int i) {
        final BDFFCCMovil objBD = new BDFFCCMovil(mContext);
        viewHolderAddSituado.EtiPlaca.setText(listaAddLoteoUni.get(i).getPlaca());
        if ("1".equals(listaAddLoteoUni.get(i).getMasivo())){
            viewHolderAddSituado.CheckMasivo.setChecked(true);
        }else{
            viewHolderAddSituado.CheckMasivo.setChecked(false);
        }
        if ("1".equals(listaAddLoteoUni.get(i).getEsVacio())){
            viewHolderAddSituado.CheckCargado.setChecked(true);
        }else{
            viewHolderAddSituado.CheckCargado.setChecked(false);
        }
        viewHolderAddSituado.NomMaterial.setText(listaAddLoteoUni.get(i).getNombreMaterial());
        if( listaAddLoteoUni.get(i).getNombreMaterial() == null || ("null").equals(listaAddLoteoUni.get(i).getNombreMaterial())){
            viewHolderAddSituado.NomMaterial.setText("Indefinido");
        }
        //falta add codigo para diseño de servicio
        // buscar por clacarro y idcontrolunidad si existe una diseño de servicio y devolver la via.
        //los diseños se guardan en colocaciones entonces se buscara en la colocacion
        viewHolderAddSituado.NomViaDiseno.setText(objBD.getViaDisenoServ(listaAddLoteoUni.get(i).getIdPlaca(), listaAddLoteoUni.get(i).getIdControlUnidad()));
        if ("null".equals( objBD.getViaDisenoServ(listaAddLoteoUni.get(i).getIdPlaca(), listaAddLoteoUni.get(i).getIdControlUnidad()))){
            viewHolderAddSituado.NomViaDiseno.setText("Indefinido");
        }

        if("0".equals(listaAddLoteoUni.get(i).getEstatus())){
            viewHolderAddSituado.EtiEstatus.setText("No Loteado");
            viewHolderAddSituado.EtiEstatus.setTextColor(Color.BLUE);
            viewHolderAddSituado.CheckMasivo.setEnabled(true);
            viewHolderAddSituado.CheckCargado.setEnabled(true);
            viewHolderAddSituado.spinnerViaDestino.setEnabled(true);
            viewHolderAddSituado.ImgNext.setEnabled(true);
        }else if ("1".equals(listaAddLoteoUni.get(i).getEstatus())){
            viewHolderAddSituado.EtiEstatus.setText("Loteado y Pendiente de Envio");
            viewHolderAddSituado.EtiEstatus.setTextColor(Color.RED);
            viewHolderAddSituado.CheckMasivo.setEnabled(false);
            viewHolderAddSituado.CheckCargado.setEnabled(false);
            viewHolderAddSituado.spinnerViaDestino.setEnabled(false);
            viewHolderAddSituado.ImgNext.setEnabled(false);
        }

    }

    @Override
    public int getItemCount() {
        return listaAddLoteoUni.size();
    }
}
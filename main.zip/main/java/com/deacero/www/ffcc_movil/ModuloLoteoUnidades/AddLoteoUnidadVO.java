package com.deacero.www.ffcc_movil.ModuloLoteoUnidades;

import android.content.Context;

import java.util.List;

public class AddLoteoUnidadVO {
    private String Masivo, IdPlaca, Placa, IdControlUnidad, EsVacio, ClaVia, NombreMaterial, Estatus;
    private Context context;

    public AddLoteoUnidadVO(String masivo,String idPlaca, String placa, String idControlUnidad, String esVacio, String claVia, Context context, String nombreMaterial, String estatus) {
        Masivo = masivo;
        IdPlaca = idPlaca;
        Placa = placa;
        IdControlUnidad = idControlUnidad;
        EsVacio = esVacio;
        ClaVia = claVia;
        this.context = context;
        this.NombreMaterial = nombreMaterial;
        Estatus = estatus;
    }

    public String getEstatus() {
        return Estatus;
    }

    public void setEstatus(String estatus) {
        Estatus = estatus;
    }

    public String getNombreMaterial() {
        return NombreMaterial;
    }

    public void setNombreMaterial(String nombreMaterial) {
        NombreMaterial = nombreMaterial;
    }

    public String getMasivo() {
        return Masivo;
    }

    public void setMasivo(String masivo) {
        Masivo = masivo;
    }

    public String getIdPlaca() {
        return IdPlaca;
    }

    public void setIdPlaca(String idPlaca) {
        IdPlaca = idPlaca;
    }

    public String getPlaca() {
        return Placa;
    }

    public void setPlaca(String placa) {
        Placa = placa;
    }

    public String getIdControlUnidad() {
        return IdControlUnidad;
    }

    public void setIdControlUnidad(String idControlUnidad) {
        IdControlUnidad = idControlUnidad;
    }


    public String getEsVacio() {
        return EsVacio;
    }

    public void setEsVacio(String esVacio) {
        EsVacio = esVacio;
    }

    public String getClaVia() {
        return ClaVia;
    }

    public void setClaVia(String claVia) {
        ClaVia = claVia;
    }


    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }
}

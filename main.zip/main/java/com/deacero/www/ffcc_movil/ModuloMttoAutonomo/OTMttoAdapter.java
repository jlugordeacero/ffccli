package com.deacero.www.ffcc_movil.ModuloMttoAutonomo;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.R;

import java.util.ArrayList;
import java.util.List;

public class OTMttoAdapter extends RecyclerView.Adapter<OTMttoAdapter.ViewHoldeOTMtto> {
    private ArrayList<OTMtto> listaOTMttodos;
    Context mContext;
    String[] ActSplit;
    public OTMttoAdapter(ArrayList<OTMtto> listaOTMttodos, Context mContext) {
        this.listaOTMttodos = listaOTMttodos;
        this.mContext = mContext;
    }

    @Override
    public ViewHoldeOTMtto onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list_otmtto,null,false);
        return new ViewHoldeOTMtto(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHoldeOTMtto ViewHoldeOTMtto, final int i) {
        ViewHoldeOTMtto.IdOT.setText(listaOTMttodos.get(i).getIdOt());
        ViewHoldeOTMtto.ClaActividad.setText(listaOTMttodos.get(i).getClaActividad());
        /*ActSplit= listaOTMttodos.get(i).getNomActividad().split(":");
        ViewHoldeOTMtto.NomActividad.setText(ActSplit[0].trim()+": "+ActSplit[1].trim());*/
        ViewHoldeOTMtto.NomActividad.setText(listaOTMttodos.get(i).getNomActividad().trim());
        ViewHoldeOTMtto.Variable.setText(listaOTMttodos.get(i).getNomVariable().trim());
        ViewHoldeOTMtto.Unidad.setText(listaOTMttodos.get(i).getNomUnidadMedidaVariable().trim());
        ViewHoldeOTMtto.TiempoEstimado.setText(listaOTMttodos.get(i).getTiempoEstimado());
        ViewHoldeOTMtto.TiempoReal.setText(listaOTMttodos.get(i).getTiempoRealHrs());
        ViewHoldeOTMtto.ValorEstandar.setText(listaOTMttodos.get(i).getValorEstandar());
        ViewHoldeOTMtto.ValorMinimo.setText(listaOTMttodos.get(i).getValorMinimo());
        ViewHoldeOTMtto.ValorMaximo.setText(listaOTMttodos.get(i).getValorMaximo());
        ViewHoldeOTMtto.ValorReal.setText(listaOTMttodos.get(i).getValorReal());
        ViewHoldeOTMtto.etReferencia.setText(listaOTMttodos.get(i).getNomReferenciaCumple());

        System.out.println("bindholder ");
        System.out.println("clatipovariable "+listaOTMttodos.get(i).getClaTipoVariable() +" Referencia "+listaOTMttodos.get(i).getReferencia()+ " valorreal "+listaOTMttodos.get(i).getValorReal());

        if( "2".equals(listaOTMttodos.get(i).getClaTipoVariable()) &&
            "2".equals(listaOTMttodos.get(i).getValorReal()) ) {//Evalua variable cualitativa
            ViewHoldeOTMtto.spinnerEsRealizada.setSelection(1);
        }else if( "2".equals(listaOTMttodos.get(i).getClaTipoVariable()) &&
                "1".equals(listaOTMttodos.get(i).getValorReal()) ) {//Evalua variable cuantitativa (numerica)
            ViewHoldeOTMtto.spinnerEsRealizada.setSelection(0);
        }else if("2".equals(listaOTMttodos.get(i).getClaTipoVariable()) &&
                "2".equals(listaOTMttodos.get(i).getReferencia())){
            ViewHoldeOTMtto.spinnerEsRealizada.setSelection(1);
        }else if("2".equals(listaOTMttodos.get(i).getClaTipoVariable()) &&
                "1".equals(listaOTMttodos.get(i).getReferencia())){
            ViewHoldeOTMtto.spinnerEsRealizada.setSelection(0);
        }

        /*if("1".equals(listaOTMttodos.get(i).getEsRealizada())
                && Integer.parseInt(listaOTMttodos.get(i).getClaEstatus()) >= 2) {///bloquea realizado spinner edittext cuando esta en proceso
            ViewHoldeOTMtto.switchRealizada.setEnabled(false);
            ViewHoldeOTMtto.spinnerEsRealizada.setEnabled(false);
            ViewHoldeOTMtto.ValorReal.setEnabled(false);
        }*/

        if("2".equals(listaOTMttodos.get(i).getClaTipoVariable())) {
            ViewHoldeOTMtto.ValorEstandar.setVisibility(View.GONE);
            ViewHoldeOTMtto.ValorMinimo.setVisibility(View.GONE);
            ViewHoldeOTMtto.ValorMaximo.setVisibility(View.GONE);
            ViewHoldeOTMtto.ValorReal.setVisibility(View.GONE);
            ViewHoldeOTMtto.etMinimo.setVisibility(View.GONE);
            ViewHoldeOTMtto.etMaximo.setVisibility(View.GONE);
            ViewHoldeOTMtto.etEstandar.setVisibility(View.GONE);
            ViewHoldeOTMtto.spinnerEsRealizada.setVisibility(View.VISIBLE);
        }else{
            ViewHoldeOTMtto.ValorEstandar.setVisibility(View.VISIBLE);
            ViewHoldeOTMtto.ValorMinimo.setVisibility(View.VISIBLE);
            ViewHoldeOTMtto.ValorMaximo.setVisibility(View.VISIBLE);
            ViewHoldeOTMtto.ValorReal.setVisibility(View.VISIBLE);
            ViewHoldeOTMtto.etMinimo.setVisibility(View.VISIBLE);
            ViewHoldeOTMtto.etMaximo.setVisibility(View.VISIBLE);
            ViewHoldeOTMtto.etEstandar.setVisibility(View.VISIBLE);
            ViewHoldeOTMtto.spinnerEsRealizada.setVisibility(View.GONE);
        }

        if("0".equals(listaOTMttodos.get(i).getEsRealizada())){///
            ViewHoldeOTMtto.switchRealizada.setText("NO");
            ViewHoldeOTMtto.switchRealizada.setTextColor(Color.parseColor("#ff0000"));
            ViewHoldeOTMtto.switchRealizada.setChecked(false);
        }else if("1".equals(listaOTMttodos.get(i).getEsRealizada())){
            ViewHoldeOTMtto.switchRealizada.setText("SI");
            ViewHoldeOTMtto.switchRealizada.setChecked(true);
            ViewHoldeOTMtto.switchRealizada.setTextColor(Color.parseColor("#0000ff"));
        }

        System.out.println("\n queeeee traeee "+listaOTMttodos.get(i).getGeneraDerivada());
        if("0".equals(listaOTMttodos.get(i).getGeneraDerivada())){///
            ViewHoldeOTMtto.ValGeneraDerivada.setText("");
        }else  if("1".equals(listaOTMttodos.get(i).getGeneraDerivada())){
            ViewHoldeOTMtto.ValGeneraDerivada.setText("SI Genera Derivada   ");
        }



    }

    @Override
    public int getItemCount() {
        return listaOTMttodos.size();
    }


    public class ViewHoldeOTMtto extends RecyclerView.ViewHolder implements CompoundButton.OnCheckedChangeListener, AdapterView.OnItemSelectedListener {
        TextView IdOT, ClaActividad, NomActividad, TiempoEstimado,ValorEstandar, ValorMinimo, ValorMaximo,Variable,Unidad, etMinimo, etEstandar, etMaximo, etReferencia, ValGeneraDerivada;
        Switch switchRealizada;
        EditText TiempoReal, ValorReal;
        Spinner spinnerEsRealizada;
        final BDFFCCMovil objBD = new BDFFCCMovil(mContext);
        ArrayAdapter<String> dataAdapter;
        List<String> listNames = new ArrayList<String>();
        AlertDialog.Builder builder;
        AlertDialog alert;
        Toast toast;

        public ViewHoldeOTMtto(@NonNull View itemView) {
            super(itemView);
            IdOT=(TextView) itemView.findViewById(R.id.txtIdOT);
            ClaActividad=(TextView) itemView.findViewById(R.id.txtClaAct);
            NomActividad=(TextView) itemView.findViewById(R.id.txtNomAct);
            Variable=(TextView) itemView.findViewById(R.id.txtNomVar);
            Unidad=(TextView) itemView.findViewById(R.id.txtNomVarUnidad);
            ValorEstandar=(TextView) itemView.findViewById(R.id.txtValorEstandar);
            ValorMinimo=(TextView) itemView.findViewById(R.id.txtValorMinimo);
            ValorMaximo=(TextView) itemView.findViewById(R.id.txtValorMaximo);
            TiempoEstimado=(TextView) itemView.findViewById(R.id.txtTiempoEstimado);
            etMinimo=(TextView) itemView.findViewById(R.id.EtMinimo);
            etEstandar=(TextView) itemView.findViewById(R.id.EtEstandar);
            etMaximo=(TextView) itemView.findViewById(R.id.EtMaximo);
            etReferencia=(TextView) itemView.findViewById(R.id.txtValReferencia);
            TiempoReal=(EditText) itemView.findViewById(R.id.EtxtTimeReal);
            ValGeneraDerivada = (TextView) itemView.findViewById(R.id.ValGeneraDerivada);

            ValorReal=(EditText) itemView.findViewById(R.id.EtxtValReal);
            ValorReal.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                }
                @Override
                public void afterTextChanged(Editable s) {
                    if(s.length()<=0 && "1".equals(listaOTMttodos.get(getAdapterPosition()).getClaTipoVariable())){
                        if (toast!= null) { toast.cancel(); }
                        toast = Toast.makeText(mContext,"Agrega el valor Real.", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();



                    }else if("1".equals(listaOTMttodos.get(getAdapterPosition()).getClaTipoVariable())) {
                        objBD.updateOTActItemValor("" + listaOTMttodos.get(getAdapterPosition()).getIdOt(),
                                "" + listaOTMttodos.get(getAdapterPosition()).getClaActividad(),
                                "" + listaOTMttodos.get(getAdapterPosition()).getClaActividadPaso(),
                                "" + ValorReal.getText());

                        if("0".equals(listaOTMttodos.get(getAdapterPosition()).getGeneraDerivada())){
                            objBD.updateOTActItemDerivada("" + listaOTMttodos.get(getAdapterPosition()).getIdOt(),
                                    "" + listaOTMttodos.get(getAdapterPosition()).getClaActividad(),
                                    "" + listaOTMttodos.get(getAdapterPosition()).getClaActividadPaso(),
                                    "0");
                        }
                        objBD.close();
                        System.out.println("SE EJECUTO EN LA CONSULTA POR ESO LO REGRESA A CERO");

                        listaOTMttodos.get(getAdapterPosition()).setValorReal("" + ValorReal.getText());
                        switchRealizada.setText("NO");
                        switchRealizada.setTextColor(Color.parseColor("#ff0000"));
                        switchRealizada.setChecked(false);
                        ValGeneraDerivada.setText("");
                    }
                }
            });
            spinnerEsRealizada=(Spinner) itemView.findViewById(R.id.spinnerEsRealizada);
            switchRealizada=(Switch) itemView.findViewById(R.id.IdSwitchRealizado);
            switchRealizada.setOnCheckedChangeListener(this);
            switchRealizada.setChecked(false);
            listNames.add("SI");
            listNames.add("NO");
            dataAdapter = new ArrayAdapter<String>(mContext,android.R.layout.simple_list_item_1, listNames);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
            spinnerEsRealizada.setAdapter(dataAdapter);
            spinnerEsRealizada.setOnItemSelectedListener(this);
            spinnerEsRealizada.setSelected(true);
        }


        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            System.out.println("CONFIGURACIONES: -- "+ listaOTMttodos.get(getAdapterPosition()).getClaActividad());

            if(switchRealizada.isChecked()){

                    listaOTMttodos.get(getAdapterPosition()).setEsRealizada("1");
                    switchRealizada.setText("SI");
                switchRealizada.setChecked(true);
                    switchRealizada.setTextColor(Color.parseColor("#0000ff"));
                    objBD.updateOTActItem("" + listaOTMttodos.get(getAdapterPosition()).getIdOt(),
                            "" + listaOTMttodos.get(getAdapterPosition()).getClaActividad(),
                            "" + listaOTMttodos.get(getAdapterPosition()).getClaActividadPaso(),
                            "1");

                /*setea el valor real variable cualitativa*/
                /*if(listNames.size()>0 && "2".equals(listaOTMttodos.get(getAdapterPosition()).getClaTipoVariable())) {//solo para cualitativas
                    if ("SI".equals(listNames.get(spinnerEsRealizada.getSelectedItemPosition()))) {
                        objBD.updateOTActItemValor("" + listaOTMttodos.get(getAdapterPosition()).getIdOt(),
                                "" + listaOTMttodos.get(getAdapterPosition()).getClaActividad(),
                                "" + listaOTMttodos.get(getAdapterPosition()).getClaActividadPaso(),
                                "1");
                        listaOTMttodos.get(getAdapterPosition()).setValorReal("1");
                        objBD.close();

                    } else {
                        objBD.updateOTActItemValor("" + listaOTMttodos.get(getAdapterPosition()).getIdOt(),
                                "" + listaOTMttodos.get(getAdapterPosition()).getClaActividad(),
                                "" + listaOTMttodos.get(getAdapterPosition()).getClaActividadPaso(),
                                "2");
                        listaOTMttodos.get(getAdapterPosition()).setValorReal("2");
                        objBD.close();

                    }
                }*/
               /* * */

                System.out.println("\nClaRef "+listaOTMttodos.get(getAdapterPosition()).getClaReferenciaCumple()
                +" \nValReal "+listaOTMttodos.get(getAdapterPosition()).getValorReal()
                +" \nDerivada "+listaOTMttodos.get(getAdapterPosition()).getGeneraDerivada());

                    if ("2".equals(listaOTMttodos.get(getAdapterPosition()).getClaTipoVariable())) {//cualitativa
                        if ("SI".equals(spinnerEsRealizada.getSelectedItem().toString())){
                            listaOTMttodos.get(getAdapterPosition()).setValorReal("1");
                        }else if ("NO".equals(spinnerEsRealizada.getSelectedItem().toString())){
                            listaOTMttodos.get(getAdapterPosition()).setValorReal("2");
                        }
                        /*TEST*/
                        if("0".equals(listaOTMttodos.get(getAdapterPosition()).getGeneraDerivada())){///
                            ValGeneraDerivada.setText("");
                        }else  if("1".equals(listaOTMttodos.get(getAdapterPosition()).getGeneraDerivada())){
                            ValGeneraDerivada.setText("SI Genera Derivada   ");
                        }
                        /*FINTEST*/

                        if (Integer.parseInt(listaOTMttodos.get(getAdapterPosition()).getClaReferenciaCumple())
                                != Integer.parseInt(listaOTMttodos.get(getAdapterPosition()).getValorReal())
                                && "0".equals(listaOTMttodos.get(getAdapterPosition()).getGeneraDerivada())) {//preg si genera derivada
                            builder = new AlertDialog.Builder(mContext);
                            builder.setTitle(R.string.app_name);
                            builder.setMessage("¿Deseas generar una OT Derivada?");
                            builder.setIcon(R.drawable.notify_dialog);
                            builder.setPositiveButton("SI", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.dismiss();
                                    objBD.updateOTActItemDerivada("" + listaOTMttodos.get(getAdapterPosition()).getIdOt(),
                                            "" + listaOTMttodos.get(getAdapterPosition()).getClaActividad(),
                                            "" + listaOTMttodos.get(getAdapterPosition()).getClaActividadPaso(),
                                            "1");
                                    objBD.close();
                                    listaOTMttodos.get(getAdapterPosition()).setGeneraDerivada("1");
                                    ValGeneraDerivada.setText("SI Genera derivada   ");
                                }
                            });
                            builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.dismiss();
                                    objBD.updateOTActItemDerivada("" + listaOTMttodos.get(getAdapterPosition()).getIdOt(),
                                            "" + listaOTMttodos.get(getAdapterPosition()).getClaActividad(),
                                            "" + listaOTMttodos.get(getAdapterPosition()).getClaActividadPaso(),
                                            "0");
                                    objBD.close();
                                    listaOTMttodos.get(getAdapterPosition()).setGeneraDerivada("0");
                                    ValGeneraDerivada.setText("");
                                }
                            });
                            builder.setCancelable(false);
                            alert = builder.create();
                            alert.show();
                        }else if (Integer.parseInt(listaOTMttodos.get(getAdapterPosition()).getClaReferenciaCumple())
                                != Integer.parseInt(listaOTMttodos.get(getAdapterPosition()).getValorReal())
                                && "1".equals(listaOTMttodos.get(getAdapterPosition()).getGeneraDerivada())) {

                            listaOTMttodos.get(getAdapterPosition()).setGeneraDerivada("1");
                            ValGeneraDerivada.setText("Si Genera derivada   ");
                        }else{
                            objBD.updateOTActItemDerivada("" + listaOTMttodos.get(getAdapterPosition()).getIdOt(),
                                    "" + listaOTMttodos.get(getAdapterPosition()).getClaActividad(),
                                    "" + listaOTMttodos.get(getAdapterPosition()).getClaActividadPaso(),
                                    "0");
                            objBD.close();
                            listaOTMttodos.get(getAdapterPosition()).setGeneraDerivada("0");
                            ValGeneraDerivada.setText("");
                        }

                    } else if ("1".equals(listaOTMttodos.get(getAdapterPosition()).getClaTipoVariable())) {//cuantitativa (numerica)
                        System.out.println("\nValorReal "+listaOTMttodos.get(getAdapterPosition()).getValorReal()
                                +"\n GEnera D "+listaOTMttodos.get(getAdapterPosition()).getGeneraDerivada()
                        );
                        if(listaOTMttodos.get(getAdapterPosition()).getValorReal() != "") {
                            if (listaOTMttodos.get(getAdapterPosition()).getValorReal() != ""
                                    && "0".equals(listaOTMttodos.get(getAdapterPosition()).getGeneraDerivada())
                                    && Integer.parseInt(listaOTMttodos.get(getAdapterPosition()).getValorReal())
                                    < Integer.parseInt(listaOTMttodos.get(getAdapterPosition()).getValorMinimo())
                                    || Integer.parseInt(listaOTMttodos.get(getAdapterPosition()).getValorReal())
                                    > Integer.parseInt(listaOTMttodos.get(getAdapterPosition()).getValorMaximo())
                                    ) {//preg si genera derivada
                                builder = new AlertDialog.Builder(mContext);
                                builder.setTitle(R.string.app_name);
                                builder.setMessage("¿Deseas generar una OT Derivada?");
                                builder.setIcon(R.drawable.notify_dialog);
                                builder.setPositiveButton("SI", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.dismiss();
                                        objBD.updateOTActItemDerivada("" + listaOTMttodos.get(getAdapterPosition()).getIdOt(),
                                                "" + listaOTMttodos.get(getAdapterPosition()).getClaActividad(),
                                                "" + listaOTMttodos.get(getAdapterPosition()).getClaActividadPaso(),
                                                "1");
                                        objBD.close();
                                        listaOTMttodos.get(getAdapterPosition()).setGeneraDerivada("1");
                                        ValGeneraDerivada.setText("SI Genera derivada   ");
                                    }
                                });
                                builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.dismiss();
                                        objBD.updateOTActItemDerivada("" + listaOTMttodos.get(getAdapterPosition()).getIdOt(),
                                                "" + listaOTMttodos.get(getAdapterPosition()).getClaActividad(),
                                                "" + listaOTMttodos.get(getAdapterPosition()).getClaActividadPaso(),
                                                "0");
                                        objBD.close();
                                        listaOTMttodos.get(getAdapterPosition()).setGeneraDerivada("0");
                                        ValGeneraDerivada.setText("");
                                    }
                                });
                                builder.setCancelable(false);
                                alert = builder.create();
                                alert.show();
                            }

                        }else{
                            if (toast!= null) { toast.cancel(); }
                            toast = Toast.makeText(mContext,"Agrega el valor Real.", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                        }
                    }
                    objBD.close();

                ValorReal.setEnabled(false);
                spinnerEsRealizada.setEnabled(false);
            }else{
                listaOTMttodos.get(getAdapterPosition()).setEsRealizada("0");
                switchRealizada.setText("NO");
                switchRealizada.setTextColor(Color.parseColor("#ff0000"));
                switchRealizada.setChecked(false);
                objBD.updateOTActItem(""+listaOTMttodos.get(getAdapterPosition()).getIdOt(),
                        ""+listaOTMttodos.get(getAdapterPosition()).getClaActividad(),
                        ""+listaOTMttodos.get(getAdapterPosition()).getClaActividadPaso(),
                        "0");
                listaOTMttodos.get(getAdapterPosition()).setValorReal("");
                objBD.close();
                listaOTMttodos.get(getAdapterPosition()).setGeneraDerivada("0");
                ValorReal.setText("");
                ValGeneraDerivada.setText("");

                ValorReal.setEnabled(true);
                spinnerEsRealizada.setEnabled(true);
            }
        }

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            switch (parent.getId()) {
                case R.id.spinnerEsRealizada:
                    //listNames.get(parent.getSelectedItemPosition());
                    System.out.println("SE EJECUTA SPINEERRR: "+listNames.get(parent.getSelectedItemPosition()));
                    if(listNames.size()>0 && "2".equals(listaOTMttodos.get(getAdapterPosition()).getClaTipoVariable())) {//solo para cualitativas
                        if ("SI".equals(listNames.get(parent.getSelectedItemPosition()))) {
                            objBD.updateOTActItemValor("" + listaOTMttodos.get(getAdapterPosition()).getIdOt(),
                                                "" + listaOTMttodos.get(getAdapterPosition()).getClaActividad(),
                                                "" + listaOTMttodos.get(getAdapterPosition()).getClaActividadPaso(),
                                                "1");
                            listaOTMttodos.get(getAdapterPosition()).setValorReal("1");
                            objBD.close();

                        } else {
                            objBD.updateOTActItemValor("" + listaOTMttodos.get(getAdapterPosition()).getIdOt(),
                                                "" + listaOTMttodos.get(getAdapterPosition()).getClaActividad(),
                                                "" + listaOTMttodos.get(getAdapterPosition()).getClaActividadPaso(),
                                                "2");
                            listaOTMttodos.get(getAdapterPosition()).setValorReal("2");
                            objBD.close();

                        }
                    }
                    if("0".equals(listaOTMttodos.get(getAdapterPosition()).getGeneraDerivada())
                            && "2".equals(listaOTMttodos.get(getAdapterPosition()).getClaTipoVariable())){
                        ValGeneraDerivada.setText("");
                    }else if("1".equals(listaOTMttodos.get(getAdapterPosition()).getGeneraDerivada())
                            && "2".equals(listaOTMttodos.get(getAdapterPosition()).getClaTipoVariable())){
                        ValGeneraDerivada.setText("SI Genera Derivada   ");
                    }
                    if(Integer.parseInt(listaOTMttodos.get(getAdapterPosition()).getClaEstatus() ) == 1
                            && "2".equals(listaOTMttodos.get(getAdapterPosition()).getClaTipoVariable())
                           && "0".equals(listaOTMttodos.get(getAdapterPosition()).getEsRealizada())) {
                        switchRealizada.setText("NO");
                        switchRealizada.setTextColor(Color.parseColor("#ff0000"));
                        switchRealizada.setChecked(false);
                    }
                    break;
            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    }
}

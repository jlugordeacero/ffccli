package com.deacero.www.ffcc_movil.ModuloMttoAutonomo;

import android.content.Context;

public class OTMtto {

    private String IdOt,
            Fecha,
            ClaEquipo,
            ClaveEquipo,
            ClaSistema,
            NomSistema,
            ClaSubsistema,
            NomSubsistema,
            ClaActividad,
            ClaActividadPaso,
            NomActividad,
            EsRealizada,
            TiempoEstimado,
            TiempoRealHrs,
            RecursoAsignado,
            ClaVariable,
            NomVariable,
            NomUnidadMedidaVariable,
            ValorEstandar,
            ValorMinimo,
            ValorMaximo,
            ValorReal,
            ClaReferenciaCumple,
            NomReferenciaCumple,
            ClaOpcionFija,
            NomOpcionFija,
            Referencia,
            ClaTipoVariable,
            ValorEstandar1,
            ClaTurno,
            ClaEstatus,
            GeneraDerivada;

    public OTMtto(String idOt, String fecha, String claEquipo, String claveEquipo, String claSistema, String nomSistema, String claSubsistema, String nomSubsistema, String claActividad, String claActividadPaso, String nomActividad, String esRealizada, String tiempoEstimado, String tiempoRealHrs, String recursoAsignado, String claVariable, String nomVariable, String nomUnidadMedidaVariable, String valorEstandar, String valorMinimo, String valorMaximo, String valorReal, String claReferenciaCumple, String nomReferenciaCumple, String claOpcionFija, String nomOpcionFija, String referencia, String claTipoVariable, String valorEstandar1, String claTurno,String claEstatus, String generaDerivada) {
        IdOt = idOt;
        Fecha = fecha;
        ClaEquipo = claEquipo;
        ClaveEquipo = claveEquipo;
        ClaSistema = claSistema;
        NomSistema = nomSistema;
        ClaSubsistema = claSubsistema;
        NomSubsistema = nomSubsistema;
        ClaActividad = claActividad;
        ClaActividadPaso = claActividadPaso;
        NomActividad = nomActividad;
        EsRealizada = esRealizada;
        TiempoEstimado = tiempoEstimado;
        TiempoRealHrs = tiempoRealHrs;
        RecursoAsignado = recursoAsignado;
        ClaVariable = claVariable;
        NomVariable = nomVariable;
        NomUnidadMedidaVariable = nomUnidadMedidaVariable;
        ValorEstandar = valorEstandar;
        ValorMinimo = valorMinimo;
        ValorMaximo = valorMaximo;
        ValorReal = valorReal;
        ClaReferenciaCumple = claReferenciaCumple;
        NomReferenciaCumple = nomReferenciaCumple;
        ClaOpcionFija = claOpcionFija;
        NomOpcionFija = nomOpcionFija;
        Referencia = referencia;
        ClaTipoVariable = claTipoVariable;
        ValorEstandar1 = valorEstandar1;
        ClaTurno = claTurno;
        ClaEstatus = claEstatus;
        GeneraDerivada = generaDerivada;
    }

    public String getClaEstatus() {
        return ClaEstatus;
    }

    public void setClaEstatus(String claEstatus) {
        ClaEstatus = claEstatus;
    }
    public String getGeneraDerivada() {
        return GeneraDerivada;
    }

    public void setGeneraDerivada(String generaDerivada) {
        GeneraDerivada = generaDerivada;
    }

    public String getIdOt() {
        return IdOt;
    }

    public void setIdOt(String idOt) {
        IdOt = idOt;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String fecha) {
        Fecha = fecha;
    }

    public String getClaEquipo() {
        return ClaEquipo;
    }

    public void setClaEquipo(String claEquipo) {
        ClaEquipo = claEquipo;
    }

    public String getClaveEquipo() {
        return ClaveEquipo;
    }

    public void setClaveEquipo(String claveEquipo) {
        ClaveEquipo = claveEquipo;
    }

    public String getClaSistema() {
        return ClaSistema;
    }

    public void setClaSistema(String claSistema) {
        ClaSistema = claSistema;
    }

    public String getNomSistema() {
        return NomSistema;
    }

    public void setNomSistema(String nomSistema) {
        NomSistema = nomSistema;
    }

    public String getClaSubsistema() {
        return ClaSubsistema;
    }

    public void setClaSubsistema(String claSubsistema) {
        ClaSubsistema = claSubsistema;
    }

    public String getNomSubsistema() {
        return NomSubsistema;
    }

    public void setNomSubsistema(String nomSubsistema) {
        NomSubsistema = nomSubsistema;
    }

    public String getClaActividad() {
        return ClaActividad;
    }

    public void setClaActividad(String claActividad) {
        ClaActividad = claActividad;
    }

    public String getClaActividadPaso() {
        return ClaActividadPaso;
    }

    public void setClaActividadPaso(String claActividadPaso) {
        ClaActividadPaso = claActividadPaso;
    }

    public String getNomActividad() {
        return NomActividad;
    }

    public void setNomActividad(String nomActividad) {
        NomActividad = nomActividad;
    }

    public String getEsRealizada() {
        return EsRealizada;
    }

    public void setEsRealizada(String esRealizada) {
        EsRealizada = esRealizada;
    }

    public String getTiempoEstimado() {
        return TiempoEstimado;
    }

    public void setTiempoEstimado(String tiempoEstimado) {
        TiempoEstimado = tiempoEstimado;
    }

    public String getTiempoRealHrs() {
        return TiempoRealHrs;
    }

    public void setTiempoRealHrs(String tiempoRealHrs) {
        TiempoRealHrs = tiempoRealHrs;
    }

    public String getRecursoAsignado() {
        return RecursoAsignado;
    }

    public void setRecursoAsignado(String recursoAsignado) {
        RecursoAsignado = recursoAsignado;
    }

    public String getClaVariable() {
        return ClaVariable;
    }

    public void setClaVariable(String claVariable) {
        ClaVariable = claVariable;
    }

    public String getNomVariable() {
        return NomVariable;
    }

    public void setNomVariable(String nomVariable) {
        NomVariable = nomVariable;
    }

    public String getNomUnidadMedidaVariable() {
        return NomUnidadMedidaVariable;
    }

    public void setNomUnidadMedidaVariable(String nomUnidadMedidaVariable) {
        NomUnidadMedidaVariable = nomUnidadMedidaVariable;
    }

    public String getValorEstandar() {
        return ValorEstandar;
    }

    public void setValorEstandar(String valorEstandar) {
        ValorEstandar = valorEstandar;
    }

    public String getValorMinimo() {
        return ValorMinimo;
    }

    public void setValorMinimo(String valorMinimo) {
        ValorMinimo = valorMinimo;
    }

    public String getValorMaximo() {
        return ValorMaximo;
    }

    public void setValorMaximo(String valorMaximo) {
        ValorMaximo = valorMaximo;
    }

    public String getValorReal() {
        return ValorReal;
    }

    public void setValorReal(String valorReal) {
        ValorReal = valorReal;
    }

    public String getClaReferenciaCumple() {
        return ClaReferenciaCumple;
    }

    public void setClaReferenciaCumple(String claReferenciaCumple) {
        ClaReferenciaCumple = claReferenciaCumple;
    }

    public String getNomReferenciaCumple() {
        return NomReferenciaCumple;
    }

    public void setNomReferenciaCumple(String nomReferenciaCumple) {
        NomReferenciaCumple = nomReferenciaCumple;
    }

    public String getClaOpcionFija() {
        return ClaOpcionFija;
    }

    public void setClaOpcionFija(String claOpcionFija) {
        ClaOpcionFija = claOpcionFija;
    }

    public String getNomOpcionFija() {
        return NomOpcionFija;
    }

    public void setNomOpcionFija(String nomOpcionFija) {
        NomOpcionFija = nomOpcionFija;
    }

    public String getReferencia() {
        return Referencia;
    }

    public void setReferencia(String referencia) {
        Referencia = referencia;
    }

    public String getClaTipoVariable() {
        return ClaTipoVariable;
    }

    public void setClaTipoVariable(String claTipoVariable) {
        ClaTipoVariable = claTipoVariable;
    }

    public String getValorEstandar1() {
        return ValorEstandar1;
    }

    public void setValorEstandar1(String valorEstandar1) {
        ValorEstandar1 = valorEstandar1;
    }

    public String getClaTurno() {
        return ClaTurno;
    }

    public void setClaTurno(String claTurno) {
        ClaTurno = claTurno;
    }


}

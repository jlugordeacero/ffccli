package com.deacero.www.ffcc_movil.ModuloMttoAutonomo;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.ModuloServicioColocacion.RegistroColocacionServicioActivity;
import com.deacero.www.ffcc_movil.ModuloServicioColocacion.ServicioColocacionAdapter;
import com.deacero.www.ffcc_movil.R;
import com.deacero.www.ffcc_movil.metodos.AuthenticationWS2;
import com.deacero.www.ffcc_movil.metodos.GetAutonomoWS;
import com.deacero.www.ffcc_movil.metodos.GetFacturacionWS;
import com.deacero.www.ffcc_movil.metodos.PostOtAutonomaWS;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class OTMttoActivity extends AppCompatActivity implements View.OnClickListener ,  AdapterView.OnItemSelectedListener{
    ///////BD
    BDFFCCMovil objBD= new BDFFCCMovil(this); //hace la conexión
    private Cursor c, c2;
    public ArrayList<OTMtto> listFactOtMtto = new ArrayList<OTMtto>();
    public RecyclerView recyclerOtMtto;
    private OTMttoAdapter adp = new OTMttoAdapter(listFactOtMtto,this);

    //DATOS SESSION USUARIO
    private String idUsuario,ClaEmpleado,NombreUsuario,loginUserName, ClaUbicacionLogin, MAC, token, Password;
    private Toast toast;
    private TextView txtFechaOT;
    public ImageButton imgBotonConsultaOt, imgBtnCalendario;
    private Spinner spinnerTurno, spinnerEquipo;
    private List<String> listIdTurno = new ArrayList<String>();//almaceno los ClaTurno
    private List<String> listNamesTurno = new ArrayList<String>();//para almacenar los NomTurno
    private List<String> listIdEquipo = new ArrayList<String>();//almaceno los ClaEquipo
    private List<String> listNamesEquipo = new ArrayList<String>();//para almacenar los NomEquipo
    private static final String CERO = "0";
    private static final String BARRA = "/";
    private static final String GUION = "-";
    //Calendario para obtener fecha & hora
    public final Calendar ca = Calendar.getInstance();
    //Variables para obtener la fecha
    final int mes =  ca.get(Calendar.MONTH);
    final int dia = ca.get(Calendar.DAY_OF_MONTH);
    final int anio = ca.get(Calendar.YEAR);
    private String Mensaje, fecha, diaFormateado,mesFormateado;
    private ArrayAdapter<String> AdpTurno, AdpEquipo;
    private SimpleDateFormat dateFormat;
    private Date date;
    private FloatingActionButton btnTerminarOt;
    PostOtAutonomaWS PostOt;
    GetAutonomoWS Autonomo;
    AuthenticationWS2 AuthWS;
    AlertDialog.Builder builder = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.otmtto_activity);
        //vars
        idUsuario = getIntent().getExtras().getString("idUsuario");
        ClaEmpleado = getIntent().getExtras().getString("ClaEmpleado");
        NombreUsuario = getIntent().getExtras().getString("NombreUsuario");
        loginUserName = getIntent().getExtras().getString("loginUserName");
        ClaUbicacionLogin = getIntent().getExtras().getString("ClaUbicacion");
        token = getIntent().getExtras().getString("token");
        MAC = getIntent().getExtras().getString("DireccionMAC");

        recyclerOtMtto =(RecyclerView)findViewById(R.id.recyclerOtMtto);
        recyclerOtMtto.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        txtFechaOT = (TextView) findViewById(R.id.txtFechaOt);
        imgBotonConsultaOt = (ImageButton) findViewById(R.id.imgBtnBuscarOt);
        imgBtnCalendario = (ImageButton)findViewById(R.id.imgBtnCalendar);
        imgBotonConsultaOt.setOnClickListener(this);
        imgBtnCalendario.setOnClickListener(this);
        spinnerTurno = (Spinner) findViewById(R.id.spinnerTurno);
        spinnerEquipo = (Spinner) findViewById(R.id.spinnerEquipo);

        spinnerTurno.setOnItemSelectedListener(this);
        spinnerEquipo.setOnItemSelectedListener(this);
        btnTerminarOt = (FloatingActionButton) findViewById(R.id.btnTerminarOT);
        btnTerminarOt.setOnClickListener(this);

        c = objBD.getTurnoxClaUbicacionAll(ClaUbicacionLogin);
        c.moveToFirst();
        if (c.moveToFirst()) {
            do {
                listIdTurno.add(c.getString(1));//adding ClaVia
                listNamesTurno.add(c.getString(2));//adding NomVia
            } while (c.moveToNext());
        }
        c.close();
        objBD.close();
        AdpTurno = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, listNamesTurno);
        AdpTurno.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spinnerTurno.setAdapter(AdpTurno);
        spinnerTurno.setSelected(true);

        c = objBD.getEquipoxClaUbicacionAll(ClaUbicacionLogin);
        c.moveToFirst();
        if (c.moveToFirst()) {
            do {
                listIdEquipo.add(c.getString(1));//adding ClaVia
                listNamesEquipo.add(c.getString(2));//adding NomVia
            } while (c.moveToNext());
        }
        c.close();
        objBD.close();
        AdpEquipo = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, listNamesEquipo);
        AdpEquipo.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spinnerEquipo.setAdapter(AdpEquipo);
        spinnerEquipo.setSelected(true);


        dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        date = new Date();
        fecha = dateFormat.format(date);
        txtFechaOT.setText(fecha);
        txtFechaOT.setEnabled(false);
        recyclerOtMtto.setAdapter(adp);

        imgBotonConsultaOt.callOnClick();//se llama el onclick hasta el ultimo para que no lanze el mensaje de validacion
    }

    @Override
    public void onRestart() {
        super.onRestart(); //Toast.makeText(this,"restart ins",Toast.LENGTH_SHORT).show();
       // recyclerOtMtto.removeAllViewsInLayout();
        //listFactOtMtto.clear();
        //recyclerOtMtto.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        //consulta();
        //FacturacionAdapter sit = new FacturacionAdapter(listFactOtMtto);
        //recyclerOtMtto.setAdapter(sit);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.imgBtnBuscarOt:
                if(ValidaMensaje().length()<=0) {
                            recyclerOtMtto.removeAllViewsInLayout();
                            listFactOtMtto.clear();//claturno 3  claequipo 305
                            System.out.println("CONSULTA "+txtFechaOT.getText().toString()+  " - "+listIdTurno.get(spinnerTurno.getSelectedItemPosition())+" - " +listIdEquipo.get(spinnerEquipo.getSelectedItemPosition()));
                            System.out.println("CONSULTA2 "+listIdTurno.get(spinnerTurno.getSelectedItemPosition())+"-"+listIdEquipo.get(spinnerEquipo.getSelectedItemPosition())+"-"+txtFechaOT.getText().toString()+"T00:00:00");
                            c = objBD.getOTIndividual(listIdTurno.get(spinnerTurno.getSelectedItemPosition()),listIdEquipo.get(spinnerEquipo.getSelectedItemPosition()),txtFechaOT.getText().toString()+"T00:00:00");//2019-04-25T00:00:00
                            if (c.getCount()>0){
                                c.moveToFirst();
                                for (int i = 0; i < c.getCount(); i++) {
                                    listFactOtMtto.add(new OTMtto(
                                            ""+c.getString(0),
                                            ""+c.getString(1),
                                            ""+c.getString(2),
                                            ""+c.getString(3),
                                            ""+c.getString(4),
                                            ""+c.getString(5),
                                            ""+c.getString(6),
                                            ""+c.getString(7),
                                            ""+c.getString(8),
                                            ""+c.getString(9),
                                            ""+c.getString(10),
                                            ""+c.getString(11),
                                            ""+c.getString(12),
                                            ""+c.getString(13),
                                            ""+c.getString(14),
                                            ""+c.getString(15),
                                            ""+c.getString(16),
                                            ""+c.getString(17),
                                            ""+c.getString(18).replace("null",""),
                                            ""+c.getString(19).replace("null",""),
                                            ""+c.getString(20).replace("null",""),
                                            ""+c.getString(21).replace("null",""),
                                            ""+c.getString(22),
                                            ""+c.getString(23),
                                            ""+c.getString(24).replace("null",""),
                                            ""+c.getString(25).replace("null",""),
                                            ""+c.getString(26),
                                            ""+c.getString(27),
                                            ""+c.getString(28),
                                            ""+c.getString(29),
                                            ""+c.getString(30),
                                            ""+c.getString(31))
                                    ); //System.out.println("FECHAAAAAAAAA "+ c.getString(1));
                                    //System.out.println("valor real "+c.getString(21).replace("null",""));
                                    //System.out.println("clatipovariable "+c.getString(27).replace("null",""));
                                    c.moveToNext();
                                }
                            }else{
                            if (toast!= null) { toast.cancel(); }
                            toast = Toast.makeText(getApplicationContext(),"No hay OT para los parámetros elegidos.", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                            }
                            c.close();
                            objBD.close();
                            recyclerOtMtto.setAdapter(adp);
                } else{
                    if (toast!= null) { toast.cancel(); }
                    toast = Toast.makeText(getApplicationContext(),"Mensaje: "+Mensaje, Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
                break;
            case R.id.imgBtnCalendar:
                obtenerFecha();
                break;
            case R.id.btnTerminarOT:
                builder = new AlertDialog.Builder(this);
                builder.setIcon(R.drawable.notify_dialog);
                builder.setTitle("¿Estas seguro de guardar la OT?");
                builder.setMessage("*******");
                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        c = objBD.getUserXLoginUser(loginUserName);
                        if (c.getCount() > 0) {
                            c.moveToFirst();
                            Password = c.getString(4);
                        }
                        c.close();
                        AuthWS = new AuthenticationWS2(OTMttoActivity.this,
                                getString(R.string.ip_authentication),
                                "" + loginUserName,
                                Password,
                                MAC,
                                "0");
                        AuthWS.execute("");
                        c2 = objBD.getUserXLoginUser(loginUserName);
                        if (c2.getCount() > 0) {
                            c2.moveToFirst();
                            token = c2.getString(8);
                        }
                        c2.close();
                        objBD.close();

                        PostOt = new PostOtAutonomaWS(OTMttoActivity.this,
                                "" + token,
                                "" + getString(R.string.IpPostUpdAutonomo),
                                "" + ClaUbicacionLogin,
                                "" + idUsuario,
                                "" + MAC,
                                imgBotonConsultaOt,
                                ""+txtFechaOT.getText().toString(),
                                ""+listIdEquipo.get(spinnerEquipo.getSelectedItemPosition()),
                                ""+listIdTurno.get(spinnerTurno.getSelectedItemPosition()));
                        PostOt.execute();
                    }
                    });
                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                builder.show();
                break;
        }
    }

    private String ValidaMensaje(){
        Mensaje="";
        if(txtFechaOT.getText().length()<=0){
            Mensaje += "Debe elegir una fecha.\n";
        }
        if(listIdEquipo.size()<=0){
            Mensaje += "Debe elegir un equipo, recargue la información.\n";
        }
        if(listIdTurno.size()<=0){
            Mensaje += "Debe elegir un turno, recargue la información.\n";
        }
        return  Mensaje;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_ot, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.itmDown:
                if(ValidaMensaje().length()<=0) {
                c = objBD.getUserXLoginUser(loginUserName);
                if (c.getCount() > 0) {
                    c.moveToFirst();
                    Password = c.getString(4);
                }
                c.close();
                AuthWS = new AuthenticationWS2(OTMttoActivity.this,
                                                                            getString(R.string.ip_authentication),
                                                                            ""+loginUserName,
                                                                            Password,
                                                                            MAC, 
                                                                            "0");
                AuthWS.execute("");
                c2 = objBD.getUserXLoginUser(loginUserName);
                if (c2.getCount() > 0) {
                    c2.moveToFirst();
                    token = c2.getString(8);
                }
                c2.close();
                objBD.close();

                System.out.println("CHECHA "+  listIdTurno.get(spinnerTurno.getSelectedItemPosition())+" - "+listIdEquipo.get(spinnerEquipo.getSelectedItemPosition()));
                Autonomo = new GetAutonomoWS(OTMttoActivity.this,
                        token,
                        getString(R.string.IpGetAutonomo),
                        ClaUbicacionLogin,
                        txtFechaOT.getText().toString(),
                        listIdTurno.get(spinnerTurno.getSelectedItemPosition()),
                        listIdEquipo.get(spinnerEquipo.getSelectedItemPosition()),
                        getString(R.string.IpPostUpdOtTablet),
                        imgBotonConsultaOt);
                Autonomo.execute();
                } else{
                    if (toast!= null) { toast.cancel(); }
                    toast = Toast.makeText(getApplicationContext(),"Mensaje: "+Mensaje, Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void obtenerFecha(){
        final DatePickerDialog recogerFecha = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                final int mesActual = month + 1;
                diaFormateado = (dayOfMonth < 10)? CERO + String.valueOf(dayOfMonth):String.valueOf(dayOfMonth);
                mesFormateado = (mesActual < 10)? CERO + String.valueOf(mesActual):String.valueOf(mesActual);
                txtFechaOT.setText(year + GUION + mesFormateado + GUION +diaFormateado );
                recyclerOtMtto.removeAllViewsInLayout();
                listFactOtMtto.clear();
            }
        },anio, mes, dia);
        recogerFecha.show();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()) {
            case R.id.spinnerTurno:
                String ClaTur = listIdTurno.get(position);//This will be the student id.
                String NomTur = listNamesTurno.get(position);//This will be the student id.
                recyclerOtMtto.removeAllViewsInLayout();
                listFactOtMtto.clear();
                break;
            case R.id.spinnerEquipo:
                String ClaEq = listIdEquipo.get(position);//This will be the student id.
                String NomEq = listNamesEquipo.get(position);//This will be the student id.
                recyclerOtMtto.removeAllViewsInLayout();
                listFactOtMtto.clear();
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
package com.deacero.www.ffcc_movil;

import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.annotation.StringRes;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.metodos.AuthenticationWS;
import com.deacero.www.ffcc_movil.metodos.Internet;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.channels.FileChannel;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

/**
 * A login screen that offers login via nomina/password.
 */
public class LoginActivity extends AppCompatActivity  {
    private static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 1;
    BDFFCCMovil objBD; //hace la conexión
    private Cursor c;
    // UI references.
    private TextView mTextView, mTextView2,customView;
    private EditText mUserView;
    private TextInputLayout mTextLayot, mTextLayot2;
    private TextInputEditText mPasswordView;
    private View mProgressView;
    private View mLoginFormView;
    public Button mUserSignInButton, mUserOutInButton;
    public static final String LLAVE_ENCRIPTAR = "deacero";
    private String  MAC;
    private Boolean ConexionInternet;

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.mipmap.deacero);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        //base datos
        objBD = new BDFFCCMovil(this);
        // Set up the login form.
        mUserView = (TextInputEditText) findViewById(R.id.usuario);
        mTextView = (TextView) findViewById(R.id.textView1);
        mTextView2 = (TextView) findViewById(R.id.textView2);
        mTextLayot = (TextInputLayout) findViewById(R.id.etpassword);
        mTextLayot2 = (TextInputLayout) findViewById(R.id.etusuario);
        mPasswordView = (TextInputEditText) findViewById(R.id.password);
        mPasswordView.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public boolean onEditorAction(TextView textView, int id, KeyEvent keyEvent) {
                if (id == EditorInfo.IME_ACTION_DONE || id == EditorInfo.IME_NULL) {
                    attemptLogin();
                    return true;
                }
                return false;
            }
        });
         mUserSignInButton = (Button) findViewById(R.id.user_sign_in_button);
         mUserOutInButton = (Button) findViewById(R.id.user_action_out);
        mUserSignInButton.setOnClickListener(new OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                //Inicio valida permisos
                if(validaPermisos()){
                    attemptLogin();
                }else{
                    Toast.makeText(getApplicationContext(),"Debes conceder los permisos",Toast.LENGTH_SHORT).show();
                }
            }
        });
        validaPermisos();
        mUserOutInButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(LoginActivity.this, R.style.CustomDialogTheme)
                        .setTitle("Confirmar Salida")
                        .setMessage("¿Estas seguro de cerrar la aplicación?")
                        .setPositiveButton("SI", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent salida=new Intent(Intent.ACTION_MAIN); //Llamando a la activity principal
                                finish();
                            }
                        })
                        .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        })
                        .show();
            }
        });
        mLoginFormView = findViewById(R.id.login_form);
        mProgressView = findViewById(R.id.login_progress);
        objBD.CloseDB();
        exportDatabse("FFCCMovil");
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void exportDatabse(String databaseName) {
        try {
            //File sd = Environment.getExternalStorageDirectory();
            File sd = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).getAbsolutePath());//write on DCIM FOLDER
            File data = Environment.getDataDirectory();
            if (sd.canWrite()) {
                String currentDBPath = "//data//"+getPackageName()+"//databases//"+databaseName+"";
                String backupDBPath = "BackUPFFCCLI.db";
                File currentDB = new File(data, currentDBPath);
                File backupDB = new File(sd, backupDBPath);
                if (currentDB.exists()) {
                    FileChannel src = new FileInputStream(currentDB).getChannel();
                    FileChannel dst = new FileOutputStream(backupDB).getChannel();
                    dst.transferFrom(src, 0, src.size());
                    src.close();
                    dst.close();
                }
            }
        } catch (Exception e) {
            Log.e("BACK ------ ",""+e.toString());
        }
    }

    //Inicio solicito permisos
    private boolean validaPermisos() {
        if(Build.VERSION.SDK_INT<Build.VERSION_CODES.M){
            return true;
        }
        if(    (checkSelfPermission(CAMERA)==PackageManager.PERMISSION_GRANTED)&&
               (checkSelfPermission(WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED)){
            return true;
        }
        if(     (shouldShowRequestPermissionRationale(CAMERA)) ||
                (shouldShowRequestPermissionRationale(WRITE_EXTERNAL_STORAGE))){
            cargarDialogoRecomendacion();
        }else{
            requestPermissions(new String[]{WRITE_EXTERNAL_STORAGE,CAMERA},100);
        }
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==100){
            if(grantResults.length==2 && grantResults[0]==PackageManager.PERMISSION_GRANTED
                    && grantResults[1]==PackageManager.PERMISSION_GRANTED){
                mUserSignInButton.setEnabled(true);
            }else{
                solicitarPermisosManual();
            }
        }
    }

    private void solicitarPermisosManual() {
        final CharSequence[] opciones={"Si","No"};
        final AlertDialog.Builder alertOpciones=new AlertDialog.Builder(LoginActivity.this);
        alertOpciones.setTitle("¿Desea configurar los permisos de forma manual?");
        alertOpciones.setIcon(R.drawable.notify_dialog);
        alertOpciones.setItems(opciones, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (opciones[i].equals("si")){
                    Intent intent=new Intent();
                    intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    Uri uri=Uri.fromParts("package",getPackageName(),null);
                    intent.setData(uri);
                    startActivity(intent);
                }else{
                    Toast.makeText(getApplicationContext(),"Los permisos no fueron aceptados",Toast.LENGTH_SHORT).show();
                    dialogInterface.dismiss();
                }
            }
        });
        alertOpciones.show();
    }

    private void cargarDialogoRecomendacion() {
        AlertDialog.Builder dialogo=new AlertDialog.Builder(LoginActivity.this);
        dialogo.setTitle("Notificación.");
        dialogo.setIcon(R.drawable.notify_dialog);
        dialogo.setMessage("Debe conceder permisos a la aplicación, para poder Iniciar Sesión y pueda operar correctamente.");

        dialogo.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                requestPermissions(new String[]{WRITE_EXTERNAL_STORAGE,CAMERA},100);
            }
        });
        dialogo.show();
    }
    //Finalizo pido permisos

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void attemptLogin() {
        String usuario = mUserView.getText().toString();
        String password = mPasswordView.getText().toString();
        mUserView.setError(null);
        mPasswordView.setError(null);
        boolean cancel = false;
        View focusView = null;
        if (!TextUtils.isEmpty(password) && !isPasswordValid(password)) {
            mPasswordView.setError(getString(R.string.error_invalid_password));
            focusView = mPasswordView;
            cancel = true;
        }
        if (TextUtils.isEmpty(usuario)) {
            mUserView.setError(getString(R.string.error_field_required));
            focusView = mUserView;
            cancel = true;
        } else if (TextUtils.isEmpty(password)) {
            mPasswordView.setError(getString(R.string.error_field_required));
            focusView = mPasswordView;
            cancel = true;
        }
        if (cancel) {
            focusView.requestFocus();
        } else {
            showProgress(true);
            Internet internet = new Internet(getApplicationContext());
            MAC = internet.getMacAddress();
            ConexionInternet = internet.compruebaConexion(getApplicationContext());
            Log.e("CONEXION:",""+ConexionInternet.toString());
            if(ConexionInternet == true){///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"

                AuthenticationWS AuthWS = new AuthenticationWS(LoginActivity.this,getString(R.string.ip_authentication),usuario,password,MAC,"0",getString(R.string.ip_getUsuarios),mUserSignInButton);
                AuthWS.execute("");
                showProgress(false);
            }else{///HACE LA CONEXION DE MANERA LOCAL
                UserLoginTask runner = new UserLoginTask(mUserView.getText().toString(),mPasswordView.getText().toString());
                runner.execute("");
            }
        }
    }

    private boolean isPasswordValid(String password) {
        //TODO: Replace this with your own logic
        return password.length() > 2;
    }

    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);
            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
            mLoginFormView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    /**
     * Represents an asynchronous login/registration task used to authenticate
     * the user.
     */
    public String encriptar(String texto) {
        String secretKey = LLAVE_ENCRIPTAR; //llave para encriptar datos
        String base64EncryptedString = "";
        try {
            MessageDigest md = MessageDigest.getInstance("SHA256");
            byte[] digestOfPassword = md.digest(secretKey.getBytes("utf-8"));
            byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);
            SecretKey key = new SecretKeySpec(keyBytes, "DESede");
            Cipher cipher = Cipher.getInstance("DESede");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] plainTextBytes = texto.getBytes("utf-8");
            byte[] buf = cipher.doFinal(plainTextBytes);
            byte[] base64Bytes = Base64.encode(buf, Base64.DEFAULT);
            base64EncryptedString = new String(base64Bytes);
        } catch (Exception ex) {
        }
        return base64EncryptedString;
    }
    public String desencriptar(String textoEncriptado) {
        String secretKey = LLAVE_ENCRIPTAR; //llave para desenciptar datos
        String base64EncryptedString = "";
        try {
            byte[] message = Base64.decode(textoEncriptado.getBytes("utf-8"), Base64.DEFAULT);
            MessageDigest md = MessageDigest.getInstance("SHA256");
            byte[] digestOfPassword = md.digest(secretKey.getBytes("utf-8"));
            byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);
            SecretKey key = new SecretKeySpec(keyBytes, "DESede");
            Cipher decipher = Cipher.getInstance("DESede");
            decipher.init(Cipher.DECRYPT_MODE, key);
            System.out.println("----"+message);
            byte[] plainText = decipher.doFinal(message);
            System.out.println("----"+plainText);
            base64EncryptedString = new String(plainText, "UTF-8");
            System.out.println("----"+base64EncryptedString);
        } catch (Exception ex) {
        }
        return base64EncryptedString;
    }

    class UserLoginTask extends AsyncTask<String, String, String> {
        private String ClaUsuarioMod, NombrePcMod, ClaUbicacion, resp;
        AlertDialog.Builder dialogg = new AlertDialog.Builder(LoginActivity.this);
        String nomina,contra,loginUserName = null,passUserName = null,BajaLogicaData;
        String mUserVieww,mPasswordVieww;
        public UserLoginTask(String myUserView,String myPasswordView){
            mUserVieww= myUserView;
            mPasswordVieww = myPasswordView;
        }
        @Override
        protected String doInBackground(String... params) {
            // TODO: attempt authentication against a network service.
            try {
                // Simulate network access.
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                return "";
            }
            nomina = mUserVieww;
            contra = mPasswordVieww;
            Integer totalrows;
            c = objBD.getUserXLoginUser(nomina);
            totalrows = c.getCount();
            if(totalrows>0){
                c.moveToFirst();
                ClaUbicacion = c.getString(0);
                ClaUsuarioMod = c.getString(1);
                NombrePcMod = c.getString(3);
                loginUserName = c.getString(6);
                passUserName = desencriptar(c.getString(4));
                //Log.e("usr: ",nomina+" - "+loginUserName);
               // Log.e("contra: ",contra+" - "+passUserName+"-"+desencriptar(c.getString(4)));
                BajaLogicaData = c.getString(7);
                if (!(nomina.equals(loginUserName))) {
                    c.close();
                    objBD.CloseDB();
                    return resp = "noexistuser" ;
                }else if(passUserName.equals(contra) && BajaLogicaData.equals("0")){
                    c.close();
                    objBD.CloseDB();
                    return resp = "succcess";
                }else if(!(BajaLogicaData.equals("0"))){
                    c.close();
                    objBD.CloseDB();
                    return resp = "usuariobaja";
                }else{
                    c.close();
                    objBD.CloseDB();
                    return resp = "smspasswrong";
                }
            }else{
                c.close();
                objBD.CloseDB();
                return resp = "El usuario no existe, actualizando datos...";
            }
        }

        @Override
        protected void onPostExecute(String result) {
            showProgress(false);
            if(result.equals("succcess")){
                Toast.makeText(getApplicationContext(),"Bienvenido ", Toast.LENGTH_LONG).show();
                Intent intmenu = new Intent(getApplicationContext(),MenuActivity.class);
                String usuario = mUserView.getText().toString();
                intmenu.putExtra("loginUserName", usuario);//num nomina
                intmenu.putExtra("NombreUsuario", NombrePcMod);///nombre completo user
                intmenu.putExtra("idUsuario", ClaUsuarioMod);//id del usuario
                intmenu.putExtra("ClaUbicacion", ClaUbicacion);//id del usuario
                intmenu.putExtra("DireccionMAC", MAC);//id del usuario
                startActivity(intmenu);
                //DatosUsuario datausu = new DatosUsuario(NombrePcMod,ClaUsuarioMod);
            }else if(result.equals("smspasswrong")){
                mPasswordView.setError(getString(R.string.error_incorrect_password));
                mPasswordView.requestFocus();
            }else if(result.equals("usuariobaja")){
                mUserView.setError(getString(R.string.error_invalid_disable));
                mUserView.requestFocus();
            }else{   //no hay registros encontrados con el loginusername proporcionado
                mUserView.setError(getString(R.string.prompt_email_notfound));
                mUserView.requestFocus();
            }
        }

        @Override
        protected void onCancelled() {
            showProgress(false);
        }
    }


}
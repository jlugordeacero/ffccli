package com.deacero.www.ffcc_movil.ModuloInspeccionSalida;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.content.FileProvider;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.BuildConfig;
import com.deacero.www.ffcc_movil.R;
import com.deacero.www.ffcc_movil.cn.EnumExt;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class ConfigSituadoAdapter extends RecyclerView.Adapter<ConfigSituadoAdapter.ViewHolderConfigSituadoAdapter>  {
    private ArrayList<ConfigSituadoVO> listaConfiguraciones;
    private View.OnClickListener listener;
    private Context mContext;
    ///////BD
    //private BDFFCCMovil objBD; //hace la conexión
    ////CAMARA
    private int CAPTURE_PHOTO2 = 2;
    private int SELECT_PHOTO = 100;
    public Uri mCapturedImageURI;
    private String mCurrentPhotoPath2, ClaUbicacionLogin, fileName, placa;
    private Cursor c, c2;
    private Toast toast;
    private  ProgressDialog dialogo;

    public class ViewHolderConfigSituadoAdapter extends RecyclerView.ViewHolder implements CompoundButton.OnCheckedChangeListener, View.OnClickListener {
        //TextView etiIdConf;
        TextView EtiNomConf;
        // ToggleButton switchtoogle;
        Switch switchtoogle;
        ImageView imgRechaza, imgTakePhoto, imgSeePhoto;

        public ViewHolderConfigSituadoAdapter(@NonNull View itemView) {
            super(itemView);
            //etiIdConf=(TextView) itemView.findViewById(R.id.txtidConf);
            EtiNomConf=(TextView) itemView.findViewById(R.id.txtNomConf);
            imgRechaza = (ImageView)itemView.findViewById(R.id.ImgRechazaCarro);
            imgTakePhoto = (ImageView)itemView.findViewById(R.id.ImgPickPhoto);
            imgSeePhoto = (ImageView)itemView.findViewById(R.id.ImgSeePhoto);
            switchtoogle= (Switch) itemView.findViewById(R.id.IdSwitch);
            switchtoogle.setOnCheckedChangeListener(this);
            imgTakePhoto.setOnClickListener(this);
            imgSeePhoto.setOnClickListener(this);
        }

        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            final BDFFCCMovil objBD = new BDFFCCMovil(listaConfiguraciones.get(getAdapterPosition()).getContext());
            switchtoogle.getText();
            System.out.println("CONFIGURACIONES: -- "+ listaConfiguraciones.get(getAdapterPosition()).getNomConfig());
            if(switchtoogle.isChecked()){
                listaConfiguraciones.get(getAdapterPosition()).setSwitchs(1);
                switchtoogle.setText("SI");
                switchtoogle.setChecked(true);
                switchtoogle.setTextColor(Color.parseColor("#0000ff"));
                objBD.updateTraInsCarroDet(listaConfiguraciones.get(getAdapterPosition()).getIdInsCarro(),listaConfiguraciones.get(getAdapterPosition()).getIdConfig(),listaConfiguraciones.get(getAdapterPosition()).getIdConfigDet(),"1", listaConfiguraciones.get(getAdapterPosition()).getRechaza(),1);
                Log.e("true1---", String.valueOf(listaConfiguraciones.get(getAdapterPosition()).getSwitchs()));
                objBD.close();
//                notifyDataSetChanged();
            }else{
                listaConfiguraciones.get(getAdapterPosition()).setSwitchs(0);
                switchtoogle.setText("NO");
                switchtoogle.setTextColor(Color.parseColor("#ff0000"));
                switchtoogle.setChecked(false);
                objBD.updateTraInsCarroDet(listaConfiguraciones.get(getAdapterPosition()).getIdInsCarro(),listaConfiguraciones.get(getAdapterPosition()).getIdConfig(),listaConfiguraciones.get(getAdapterPosition()).getIdConfigDet(),"0",listaConfiguraciones.get(getAdapterPosition()).getRechaza(),0);
                Log.e("false1---", String.valueOf(listaConfiguraciones.get(getAdapterPosition()).getSwitchs()));
                objBD.close();
            //    notifyDataSetChanged();
            }
        }

        @Override
        public void onClick(View v) {
            final BDFFCCMovil objBD = new BDFFCCMovil(listaConfiguraciones.get(getAdapterPosition()).getContext());
            switch (v.getId()){
                case R.id.ImgPickPhoto:
                    //String IdConfigInspeccion;
                   // IdConfigInspeccion = objBD.getIdConfigInspeccion(""+);
                   // c = objBD.getDataConfigInspeccionCARRO(ClaUbicacionLogin,ClaCarro,listaConfiguraciones.get(getAdapterPosition()).get,IdConfigInspeccion,listaConfiguraciones.get(getAdapterPosition()).getIdInsCarro());
                    c2 = objBD.getImagenesInspeccion(""+listaConfiguraciones.get(getAdapterPosition()).getIdInsCarro(),""+listaConfiguraciones.get(getAdapterPosition()).getIdConfigDet());
                    if(c2.getCount() >= 1){
                        if (toast!= null) { toast.cancel(); }
                        toast = Toast.makeText(listaConfiguraciones.get(getAdapterPosition()).getContext(),"No puedes tomar mas fotos para "+listaConfiguraciones.get(getAdapterPosition()).getNomConfig()+" \nSolo Puedes tomar una foto por por cada elemento a evaluar.", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                    }else{
                        try {
                            dispatchTakePictureIntent();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                   /* c.close();*/
                    c2.close();
                    objBD.close();
                    break;
                case R.id.ImgSeePhoto:
                    Intent gallery = new Intent(mContext, DetalleFotosActivity.class);
                    gallery.putExtra("idInspeccion",listaConfiguraciones.get(getAdapterPosition()).getIdInsCarro());//ClaUsuarioMod
                    gallery.putExtra("ClaUbicacion",ClaUbicacionLogin);//ClaUsuarioMod
                    gallery.putExtra("idInspeccionCfgDet",listaConfiguraciones.get(getAdapterPosition()).getIdConfigDet());//ClaUsuarioMod
                    System.out.println("FOTOOOOOOOOO ID "+listaConfiguraciones.get(getAdapterPosition()).getIdConfigDet());
                    mContext.startActivity(gallery);
                    break;
            }
        }

        private void dispatchTakePictureIntent() throws IOException {
            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            // Ensure that there's a camera activity to handle the intent
            if (takePictureIntent.resolveActivity(mContext.getPackageManager()) != null) {
                // Create the File where the photo should go
                File photoFile = null;
                try {
                    photoFile = createImageFile();
                } catch (IOException ex) {
                    ex.toString();
                    return;
                }
                // Continue only if the File was successfully created
                if (photoFile != null) {
                    //Uri photoURI = Uri.fromFile(createImageFile());
                    Uri photoURI = FileProvider.getUriForFile(mContext,
                            BuildConfig.APPLICATION_ID + ".provider",
                            createImageFile());
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                    //this.mContext.startActivityForResult(takePictureIntent, CAPTURE_PHOTO2);
                    ((Activity) mContext).startActivityForResult(takePictureIntent,CAPTURE_PHOTO2);

                }
            }
        }

        private File createImageFile() throws IOException {
            int rand = (int)Math.floor(Math.random()*(999999));
            fileName = String.valueOf(listaConfiguraciones.get(getAdapterPosition()).getIdConfigDet()+"_"+placa+"_"+listaConfiguraciones.get(getAdapterPosition()).getNomConfig()+"_"+listaConfiguraciones.get(0).getIdInsCarro())+"_"+ String.valueOf(rand)+ "." + EnumExt.JPG.getValor();
            File storageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).getAbsolutePath());//write on DCIM FOLDER
            File image = new File(storageDir, fileName);
            mCurrentPhotoPath2 = "file:"+image.getAbsolutePath();//ruta del archivo de donde debo obtener el registro
            return image;
        }
    }

    public ConfigSituadoAdapter(Context context, ArrayList<ConfigSituadoVO> listaConfiguraciones, String claUbicacionLogin, String Placa) {
        this.listaConfiguraciones = listaConfiguraciones;
        this.mContext = context;
        this.ClaUbicacionLogin = claUbicacionLogin;
        this.placa = Placa;
    }

    @NonNull
    @Override
    public ConfigSituadoAdapter.ViewHolderConfigSituadoAdapter onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_config_situados,viewGroup,false);
        return new ConfigSituadoAdapter.ViewHolderConfigSituadoAdapter(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ConfigSituadoAdapter.ViewHolderConfigSituadoAdapter viewHolderConfigSituadoAdapter, final int position) {
        //final BDFFCCMovil objBD = new BDFFCCMovil(listaConfiguraciones.get(position).getContext());
        //viewHolderConfigSituadoAdapter.etiIdConf.setText(listaConfiguraciones.get(position).getIdConfig());
        viewHolderConfigSituadoAdapter.EtiNomConf.setText(listaConfiguraciones.get(position).getNomConfig());
        //int valor = objBD.checkValueTraInsCarroDet(listaConfiguraciones.get(position).getIdInsCarro(),listaConfiguraciones.get(position).getIdConfigDet());
       // Log.e("BINDHOLDER","IDINSCARRO--->"+listaConfiguraciones.get(position).getIdInsCarro()+" IDCONFIDET--->"+listaConfiguraciones.get(position).getIdConfig()+"  --VALOR-->"+valor);
        final int valor = listaConfiguraciones.get(position).getSwitchs();
        if(listaConfiguraciones.get(position).getRechaza()!=1) {
            viewHolderConfigSituadoAdapter.imgRechaza.setVisibility(View.GONE);
            //Log.e("carro img-",".."+listaConfiguraciones.get(position).getRechaza());
        }
      //  Log.e("DETALLE-VAL-",".."+valor);
      if(valor==0){///desde aqui consultar a la BD el valor contra el que se va a comparar == 0
            viewHolderConfigSituadoAdapter.switchtoogle.setText("NO");
           viewHolderConfigSituadoAdapter.switchtoogle.setTextColor(Color.parseColor("#ff0000"));
            viewHolderConfigSituadoAdapter.switchtoogle.setChecked(false);
          //listaConfiguraciones.get(position).setSwitchs(0);
           /* viewHolderConfigSituadoAdapter.switchtoogle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked== true) { //isChecked
                        Log.e("true1-",".."+isChecked);
                        viewHolderConfigSituadoAdapter.switchtoogle.setText("SI");
                        viewHolderConfigSituadoAdapter.switchtoogle.setTextColor(Color.parseColor("#0000ff"));
                        objBD.updateTraInsCarroDet(listaConfiguraciones.get(position).getIdInsCarro(),listaConfiguraciones.get(position).getIdConfig(),listaConfiguraciones.get(position).getIdConfigDet(),"1", listaConfiguraciones.get(position).getRechaza(),1);
//                        notifyItemChanged(position);
                        viewHolderConfigSituadoAdapter.switchtoogle.setChecked(true);
                        listaConfiguraciones.get(position).setSwitchs(1);
                        //notifyDataSetChanged();
                        Log.e("true1---", String.valueOf(listaConfiguraciones.get(position).getSwitchs()));
                        objBD.close();

                    } else {
                        Log.e("false1-",".."+isChecked);
                        viewHolderConfigSituadoAdapter.switchtoogle.setText("NO");
                        viewHolderConfigSituadoAdapter.switchtoogle.setTextColor(Color.parseColor("#ff0000"));
                        objBD.updateTraInsCarroDet(listaConfiguraciones.get(position).getIdInsCarro(),listaConfiguraciones.get(position).getIdConfig(),listaConfiguraciones.get(position).getIdConfigDet(),"0",listaConfiguraciones.get(position).getRechaza(),0);
               //         notifyItemChanged(position);
                        viewHolderConfigSituadoAdapter.switchtoogle.setChecked(false);
                        listaConfiguraciones.get(position).setSwitchs(0);
                        Log.e("false1---", String.valueOf(listaConfiguraciones.get(position).getSwitchs()));
                        objBD.close();
                    }
                }
            });*/
        }else{
            viewHolderConfigSituadoAdapter.switchtoogle.setText("SI");
            viewHolderConfigSituadoAdapter.switchtoogle.setChecked(true);
           viewHolderConfigSituadoAdapter.switchtoogle.setTextColor(Color.parseColor("#0000ff"));
          //listaConfiguraciones.get(position).setSwitchs(1);
         /*  viewHolderConfigSituadoAdapter.switchtoogle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
               @Override
               public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                   if (isChecked == true) { //isChecked
                       Log.e("true2-",".."+isChecked);
                       viewHolderConfigSituadoAdapter.switchtoogle.setText("SI");
                       viewHolderConfigSituadoAdapter.switchtoogle.setTextColor(Color.parseColor("#0000ff"));
                       objBD.updateTraInsCarroDet(listaConfiguraciones.get(position).getIdInsCarro(),listaConfiguraciones.get(position).getIdConfig(),listaConfiguraciones.get(position).getIdConfigDet(),"1",listaConfiguraciones.get(position).getRechaza(),1);
                    //   notifyItemChanged(position);
                       viewHolderConfigSituadoAdapter.switchtoogle.setChecked(true);
                       listaConfiguraciones.get(position).setSwitchs(1);
                       Log.e("true2---", String.valueOf(listaConfiguraciones.get(position).getSwitchs()));
                       objBD.close();
                   } else {
                       Log.e("false2-",".."+isChecked);
                       viewHolderConfigSituadoAdapter.switchtoogle.setText("NO");
                       viewHolderConfigSituadoAdapter.switchtoogle.setTextColor(Color.parseColor("#ff0000"));
                       objBD.updateTraInsCarroDet(listaConfiguraciones.get(position).getIdInsCarro(),listaConfiguraciones.get(position).getIdConfig(),listaConfiguraciones.get(position).getIdConfigDet(),"0",listaConfiguraciones.get(position).getRechaza(),0);
                  //     notifyItemChanged(position);
                       viewHolderConfigSituadoAdapter.switchtoogle.setChecked(false);
                       listaConfiguraciones.get(position).setSwitchs(0);
                       Log.e("false2---", String.valueOf(listaConfiguraciones.get(position).getSwitchs()));
                       objBD.close();
                   }
                   //notifyDataSetChanged();
                   //notifyItemChanged(i);

               }
           });*/
        }
    }
    public String getFile(){
        return fileName;
    }

    public String getFileRuta(){
        return mCurrentPhotoPath2;
    }

    @Override
    public int getItemCount() {
        return listaConfiguraciones.size();
    }


}

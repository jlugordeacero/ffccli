package com.deacero.www.ffcc_movil.ModuloInspeccionSalida;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.Html;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.R;

import java.util.ArrayList;


public class AddInspeccionMancomunadaActivity extends AppCompatActivity {
    ///////BD
    private BDFFCCMovil objBD= new BDFFCCMovil(this); //hace la conexión
    private Cursor c;
    private ArrayList<AddSituadoVO> listAddSituado = new ArrayList<AddSituadoVO>();
    private RecyclerView recyclerSituados;
    //DATOS SESSION USUARIO
    private String ClaUbicacionLogin,MAC;
    //
    private EditText editTextPlaca;
    private Button btnFoundPlaca;
    private ImageButton imgBotonAdd;
    private Toast toast;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_inspeccion_mancomunada_activity);
        //vars
        ClaUbicacionLogin = getIntent().getExtras().getString("ClaUbicacion");
        MAC = getIntent().getExtras().getString("DireccionMAC");

        recyclerSituados =(RecyclerView)findViewById(R.id.recycleraddsituados);
        editTextPlaca = (EditText) findViewById(R.id.txtSearchPlaca);
        editTextPlaca.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void afterTextChanged(Editable s) {
                if(editTextPlaca.getText().length() >= 0) {
                    recyclerSituados.removeAllViewsInLayout();
                    listAddSituado.clear();
                    recyclerSituados.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                    // recyclerSituados.setLayoutManager(new GridLayoutManager(getApplicationContext(),2));
                    consulta(editTextPlaca.getText().toString().replace(" ","").toUpperCase());
                    //AddSituado sit = new AddSituado(AddInspeccionMancomunadaActivity.this,listAddSituado);
                    //recyclerSituados.setAdapter(sit);
                }
            }
        });
        imgBotonAdd = (ImageButton) findViewById(R.id.btnBuscarPlaca);
        imgBotonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(AddInspeccionMancomunadaActivity.this);
                builder.setIcon(R.drawable.notify_dialog);
                builder.setTitle(Html.fromHtml("<h1>!***** AVISO *****¡</h1>"));
                builder.setMessage(Html.fromHtml("<h2>¿Estas seguro de agregar la placa <font color='#FF0000'></b>"+
                        editTextPlaca.getText().toString().replace(" ","").toUpperCase()+ "</b></font>?</h2> "));
                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String PlacaCarroNueva = editTextPlaca.getText().toString().replace(" ","").toUpperCase();
                        String IdConfigInspeccion,ClaTipoInspeccion="1",sRechaza="0",Reutiliza="0",AlturaInterna="null",AnchoInterno="null",LongitudInterna="null",PesoMaximo="null";
                        IdConfigInspeccion = objBD.getIdConfigInspeccion(ClaUbicacionLogin,"2");
                        boolean cancel = false;
                        View focusView = null;
                        // Check for a valid user.
                        if (TextUtils.isEmpty(PlacaCarroNueva)) {
                            editTextPlaca.setError(getString(R.string.error_field_required));
                            focusView = editTextPlaca;
                            cancel = true;
                        } else {
                            int total = objBD.validaPlacaBitSituadoTipoInspeccion(""+PlacaCarroNueva,"2","1");
                            if(total == 0) {
                                objBD.insertBitSituado("-1", "-1", "" + PlacaCarroNueva, "" + ClaUbicacionLogin, "" + IdConfigInspeccion, "2" , "" + sRechaza, "" + Reutiliza, "" + AlturaInterna, "" + AnchoInterno, "" + LongitudInterna, "" + PesoMaximo, MAC,"1");
                                recyclerSituados.removeAllViewsInLayout();
                                listAddSituado.clear();
                                recyclerSituados.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                                // recyclerSituados.setLayoutManager(new GridLayoutManager(getApplicationContext(),2));
                                consulta(editTextPlaca.getText().toString().replace(" ","").toUpperCase());
                               // AddSituado sit = new AddSituado(AddInspeccionMancomunadaActivity.this, listAddSituado);
                              // recyclerSituados.setAdapter(sit);
                            }else{
                                if (toast!= null) { toast.cancel(); }
                                toast = Toast.makeText(getApplicationContext(),"La Placa "+ PlacaCarroNueva +"  ya existe.", Toast.LENGTH_LONG);
                                toast.setGravity(Gravity.CENTER, 0, 0);
                                toast.show();
                            }
                        }
                    }
                });
                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                builder.show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add_insmancomunada, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.itmreturn:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private  void consulta(String Placa) {
        try {
            c = objBD.getSituado("0",Placa,"2");
            c.moveToFirst();
            if(c.getCount()>0) {
                for (int x = 0; x < c.getCount(); x++) {
                    String IdInspeccionCarro = c.getString(0);
                    String ClaCarro = c.getString(2);
                    String PlacaCarro = c.getString(3);
                    listAddSituado.add(new AddSituadoVO(IdInspeccionCarro,ClaCarro, PlacaCarro, R.drawable.addlist, this));
                    c.moveToNext();
                }
            }
            else{
                Toast toast = Toast.makeText(getApplicationContext(),"No se encontraron registros.", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }
            c.close();
            objBD.CloseDB();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
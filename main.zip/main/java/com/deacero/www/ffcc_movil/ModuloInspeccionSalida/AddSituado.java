package com.deacero.www.ffcc_movil.ModuloInspeccionSalida;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.R;

import java.util.ArrayList;

public class AddSituado extends RecyclerView.Adapter<AddSituado.ViewHolderAddSituado> implements View.OnClickListener{

    ArrayList<AddSituadoVO> listaAddSituados;
    private View.OnClickListener listener;
    private Context mContext;
    private String MAC,idUsuario, LoginUserName, getClaUbicacionLogin;

    public AddSituado(Context context ,ArrayList<AddSituadoVO> listaSituados, String mMAC, String midUsuario, String mLoginUserName, String mgetClaUbicacionLogin) {
        this.listaAddSituados = listaSituados;
        mContext = context;
        MAC = mMAC;
        idUsuario = midUsuario;
        LoginUserName = mLoginUserName;
        getClaUbicacionLogin = mgetClaUbicacionLogin;
    }

    @NonNull
    @Override
    public ViewHolderAddSituado onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list_add_situados,null,false);
        view.setOnClickListener(this);
        return new ViewHolderAddSituado(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderAddSituado viewHolderAddSituado,final int pos) {
        final BDFFCCMovil objBD = new BDFFCCMovil(listaAddSituados.get(pos).getContext());
       // viewHolderAddSituado.etiIdPlaca.setText(listaAddSituados.get(i).getIdPlaca());
        viewHolderAddSituado.EtiPlaca.setText(listaAddSituados.get(pos).getPlaca());
        viewHolderAddSituado.ImgNext.setImageResource(listaAddSituados.get(pos).getFoto());
        // Set a click listener for item remove button
        viewHolderAddSituado.ImgNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                builder.setIcon(R.drawable.notify_dialog);
                builder.setTitle("¿Acepta si deseas inspeccionar esta placa?");
                builder.setMessage("Placa: "+listaAddSituados.get(pos).getPlaca());
                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //System.out.println(""+listaAddSituados.get(pos).getIdInspeccionCarro()+" - "+listaAddSituados.get(pos).getIdPlaca()+" -  "+listaAddSituados.get(pos).getPlaca()+"  1");
                        objBD.updateEstatusSituado(listaAddSituados.get(pos).getIdInspeccionCarro(),listaAddSituados.get(pos).getPlaca(),"1","2");
                        try {
                            String IDCONFIGINSCARRO = objBD.getMaxTraInspecCarro(listaAddSituados.get(pos).getIdPlaca(),listaAddSituados.get(pos).getPlaca(),"2","1");
                            System.out.println("******** IDCONFIGINSCARRO "+ IDCONFIGINSCARRO);
                            objBD.InsertarConfiguracionesPlacaDetalle(""+listaAddSituados.get(pos).getIdPlaca(),listaAddSituados.get(pos).getPlaca(),
                                    IDCONFIGINSCARRO, "0",  "0", "1", "2");
                            objBD.CloseDB();


                            Intent intentDetalleInsManc = new Intent(listaAddSituados.get(pos).getContext(), DetalleInspeccionMancomunadaActivity.class);
                            intentDetalleInsManc.putExtra("IdPlaca", String.valueOf(listaAddSituados.get(pos).getIdPlaca()));
                            intentDetalleInsManc.putExtra("Placa", String.valueOf(listaAddSituados.get(pos).getPlaca()));
                            intentDetalleInsManc.putExtra("IdInspeccionCarro", String.valueOf(listaAddSituados.get(pos).getIdInspeccionCarro()));
                            intentDetalleInsManc.putExtra("ClaUbicacionLogin", getClaUbicacionLogin);
                            intentDetalleInsManc.putExtra("loginUserName", LoginUserName);
                            intentDetalleInsManc.putExtra("idUsuario", idUsuario);
                            intentDetalleInsManc.putExtra("MAC", MAC);
                            listaAddSituados.get(pos).getContext().startActivity(intentDetalleInsManc);

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        listaAddSituados.remove(pos);
                        notifyItemRemoved(pos);
                        notifyItemRangeChanged(pos  ,listaAddSituados.size());
                    }
                });
                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                builder.show();




            }
        });
    }

    @Override
    public int getItemCount() {
        return listaAddSituados.size();
    }

    public void setOnClickListener(View.OnClickListener listener){
        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        if(listener!=null){
            listener.onClick(v);
        }
    }

    public class ViewHolderAddSituado extends RecyclerView.ViewHolder {
        TextView etiIdPlaca, EtiPlaca;
        ImageView ImgNext;
        public ViewHolderAddSituado(@NonNull View itemView) {
            super(itemView);
            //etiIdPlaca=(TextView) itemView.findViewById(R.id.txtidplaca);
            EtiPlaca=(TextView) itemView.findViewById(R.id.txtplaca);
            ImgNext= (ImageView) itemView.findViewById(R.id.IdImagen);

        }
    }
}

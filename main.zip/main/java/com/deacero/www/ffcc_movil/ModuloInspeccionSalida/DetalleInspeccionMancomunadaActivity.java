package com.deacero.www.ffcc_movil.ModuloInspeccionSalida;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.BuildConfig;
import com.deacero.www.ffcc_movil.R;
import com.deacero.www.ffcc_movil.cn.EnumExt;
import com.deacero.www.ffcc_movil.metodos.AuthenticationWS2;
import com.deacero.www.ffcc_movil.metodos.Internet;
import com.deacero.www.ffcc_movil.metodos.PostInspeccionSalidaWS;
import com.deacero.www.ffcc_movil.metodos.PostInspeccionWS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DetalleInspeccionMancomunadaActivity extends AppCompatActivity  {
    /////////BD
    BDFFCCMovil objBD = new BDFFCCMovil(this);//hace la conexión
    private Cursor c, c2;
    ////////
    private ArrayList<ConfigSituadoVO> listConfSituado = new ArrayList<ConfigSituadoVO>();
    private RecyclerView recyclerConfigSituados;
    private TextView textViewPlaca, textViewIdPlaca;
    private ImageView ImageViewPhoto, ImageViewRegresar,ImageViewGallery;
    ////CAMARA
    private int CAPTURE_PHOTO = 2;
    private int SELECT_PHOTO = 100;
    public Uri mCapturedImageURI;
    ///variables globales
    private String Placa,ClaCarro,IdInspeccionCarro, ClaUbicacionLogin, loginUserName, Password, token, MAC, idUsuario;
    private String mCurrentPhotoPath;
    private List<String> listId = new ArrayList<String>();//almaceno los id img
    private List<String> listNames = new ArrayList<String>();//para almacenar rutas names
    private Toast toast;

    private ConfigSituadoAdapter sit;
    //@RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detalle_inspeccion_mancomunada_activity);
        ClaCarro = getIntent().getExtras().getString("IdPlaca");
        Placa = getIntent().getExtras().getString("Placa");
        IdInspeccionCarro = getIntent().getExtras().getString("IdInspeccionCarro");
        ClaUbicacionLogin = getIntent().getExtras().getString("ClaUbicacionLogin");
        idUsuario = getIntent().getExtras().getString("idUsuario");
        loginUserName = getIntent().getExtras().getString("loginUserName");
        MAC = getIntent().getExtras().getString("MAC");
        textViewIdPlaca = (TextView)findViewById(R.id.txtPlacaConf);
        ImageViewPhoto = (ImageView)findViewById(R.id.ImgTakePhoto);
        ImageViewRegresar = (ImageView)findViewById(R.id.IdImagenRegresar);
        ImageViewGallery = (ImageView)findViewById(R.id.ImgShowPhoto);


        ImageViewGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //test another activity
                Intent gallery = new Intent(getApplicationContext(), DetalleFotosActivity.class);
                gallery.putExtra("idInspeccion",IdInspeccionCarro);//ClaUsuarioMod
                gallery.putExtra("ClaUbicacion",ClaUbicacionLogin);//ClaUsuarioMod
                startActivity(gallery);
            }
        });

        textViewIdPlaca.setText(Placa);
        ImageViewRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        ImageViewPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //////Intent para la camara FUNCIONA :D   hay que revisar los permisos de escritura activos si funciona
               /* Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (cameraIntent.resolveActivity((getApplicationContext()).getPackageManager()) != null) {
                    String fileName = String.valueOf(IdPlaca) + "_" + String.valueOf(Placa) +  "." + EnumExt.JPG.getValor();
                    File out = Environment.getExternalStorageDirectory();//escirbe en raiz y se tiene que configurar el provider xml
                    //File out = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).getAbsolutePath());//write on DCIM FOLDER
                    out = new File(out, fileName);
                    //mCapturedImageURI = Uri.fromFile(out);//change this line for the next because don´t work in enviroment sdk <23
                    mCapturedImageURI = FileProvider.getUriForFile(DetalleInspeccionMancomunadaActivity.this,
                            BuildConfig.APPLICATION_ID + ".provider",
                            out);
                    cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, mCapturedImageURI);
                    startActivityForResult(cameraIntent, CAPTURE_PHOTO);
                }else{
                    Toast.makeText(getApplicationContext(),"No se pudo tomar la foto.",Toast.LENGTH_SHORT).show();
                }*/
                String IdConfigInspeccion;
                IdConfigInspeccion = objBD.getIdConfigInspeccion(ClaUbicacionLogin,"2");
                c = objBD.getDataConfigInspeccionCARRO(ClaUbicacionLogin,ClaCarro,Placa,IdConfigInspeccion,IdInspeccionCarro,"2");
                c2 = objBD.getImagenesInspeccion2(""+IdInspeccionCarro);
               if(c2.getCount() >= c.getCount()){
                   if (toast!= null) { toast.cancel(); }
                   toast = Toast.makeText(getApplicationContext(),"No puedes tomar mas fotos. No puede ser mayor a: "+ c.getCount(), Toast.LENGTH_LONG);
                   toast.setGravity(Gravity.CENTER, 0, 0);
                   toast.show();
               }else{
                   try {
                       dispatchTakePictureIntent();
                   } catch (IOException e) {
                       e.printStackTrace();
                   }
               }
               c.close();
               c2.close();
               objBD.close();

                ////////Intent save file on sqlite since Gallery  FUNCIONA :D a///////
                /*Intent intent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, SELECT_PHOTO);*/
            }
        });

        recyclerConfigSituados =(RecyclerView)findViewById(R.id.reciclerdetalleinsman);
        recyclerConfigSituados.setLayoutManager(new LinearLayoutManager(this));//de esta manera pongo la lista vertical
        //recyclerConfigSituados.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));//de esta manera pongo la lista vertical
        //recyclerConfigSituados.setLayoutManager(new GridLayoutManager(this,2));
        consulta();
        sit = new ConfigSituadoAdapter(DetalleInspeccionMancomunadaActivity.this,listConfSituado, ClaUbicacionLogin,Placa);
        recyclerConfigSituados.setAdapter(sit);
    //Log.e("CREATE","...");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_detalle_insmancomunada, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.itmasaveplaca:
                final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setIcon(R.drawable.notify_dialog);
                builder.setTitle("¿Estas seguro de guardar esta inspección?");
                builder.setMessage("Placa: "+ Placa);
                builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        try {
                            objBD.updateEstatusSituado(IdInspeccionCarro,Placa,"2","2");
                            String Fecha = "";

                            Date date = new Date();
                            date.setDate(date.getDate());
                            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                            Fecha= dateFormat.format(date);
                            Log.e("Fecha ",""+Fecha);
                            objBD.updateFechaInspeccion(IdInspeccionCarro,ClaCarro,Placa,idUsuario,Fecha);
                            objBD.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        c = objBD.getUserXLoginUser(loginUserName);
                        if(c.getCount()>0){
                            c.moveToFirst();
                            Password = c.getString(4);
                        }
                        c.close();
                        Internet internet = new Internet(getApplicationContext());
                        // Log.e("CONEXION:",""+ConexionInternet.toString());
                        if(internet.compruebaConexion(getApplicationContext())) {///CONSUME WEBSERVICE PARA TRAER TOKEN Y USUARIOS  "http://172.29.84.97:5555/api/login/autenticacion"  "https://ffccli.deacero.com/api/login/autenticacion"
                            AuthenticationWS2 AuthWS = new AuthenticationWS2(DetalleInspeccionMancomunadaActivity.this, getString(R.string.ip_authentication), loginUserName, Password, MAC, "0");
                            String respuesta = String.valueOf(AuthWS.execute(""));

                            c2 = objBD.getUserXLoginUser(loginUserName);
                            if (c2.getCount() > 0) {
                                c2.moveToFirst();
                                token = c2.getString(8);
                                idUsuario = c2.getString(1);
                            }
                            c2.close();
                            objBD.close();
                            PostInspeccionSalidaWS WSSendInspeccion = new PostInspeccionSalidaWS(DetalleInspeccionMancomunadaActivity.this, token, getString(R.string.IpPostInspeccionCarro), ClaUbicacionLogin, idUsuario, MAC);
                            WSSendInspeccion.execute("");
                        }
                        finish();
                    }
                });
                builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();
                return true;

        }
        return super.onOptionsItemSelected(item);
    }

    private  void consulta() {
        //Log.e("DETALLE","...."+ClaCarro+"...."+Placa+"--"+IdInspeccionCarro);
        String IdConfigInspeccion;
        IdConfigInspeccion = objBD.getIdConfigInspeccion(ClaUbicacionLogin,"2");
        if( IdConfigInspeccion  == null){
            if (toast!= null) { toast.cancel(); }
            toast = Toast.makeText(getApplicationContext(),"No se encontro una configuración disponible para esta tableta.", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }else {
            c = objBD.getDataConfigInspeccionCARRO(ClaUbicacionLogin, ClaCarro, Placa, IdConfigInspeccion, IdInspeccionCarro, "2");
            c.moveToFirst();
            if (c.getCount() > 0) {
                for (int x = 0; x < c.getCount(); x++) {
                    String idinscarro = c.getString(1);
                    String idconfig = c.getString(1);
                    String idconfigDet = c.getString(2);
                    String nomconfig = c.getString(3);
                    int switchs = Integer.parseInt(c.getString(4));
                    int rechazaVacio = Integer.parseInt(c.getString(5));
                    int puedeReutilizar = Integer.parseInt(c.getString(6));
                    /// Log.e("CONSUTLA-->",""+idinscarro +"--IDCONFIGDET"+idconfigDet + "----"+c.getString(5));
                    listConfSituado.add(new ConfigSituadoVO(idinscarro, IdConfigInspeccion, idconfigDet, nomconfig, 0, 0, switchs, this));
                    c.moveToNext();
                }
            } else {
                if (toast != null) {
                    toast.cancel();
                }
                toast = Toast.makeText(getApplicationContext(), "No se encontraron configuraciones. Elimina la placa y vuelve a agregarla, para que cargue la conf. si existe.", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }
            c.close();
        }
        objBD.close();
    }

    public String getPath(Uri uri){
        if(uri==null){
            String[] projection = {MediaStore.Images.Media.DATA};
            Cursor cursor = managedQuery(uri,projection,null,null,null);
            if(cursor!=null){
                int colum_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                cursor.moveToFirst();
                return cursor.getString(colum_index);
            }
        }
        return uri.getPath();
    }

    private File createImageFile() throws IOException {
        // Create an image file name
        //String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new java.util.Date());
       /* String imageFileName = IdPlaca+"_"+Placa+"_";
        File storageDir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DCIM), "Camera");
        File image = File.createTempFile(
                imageFileName,  /* prefix */
             /*   ".jpg",         /* suffix */
            /*    storageDir      /* directory */
       /// );*/
        int rand = (int)Math.floor(Math.random()*(999999));
        String fileName = String.valueOf(IdInspeccionCarro)+"_"+String.valueOf(ClaCarro) + "_" + String.valueOf(Placa) + String.valueOf(rand)+ "." + EnumExt.JPG.getValor();
        File storageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).getAbsolutePath());//write on DCIM FOLDER
        File image = new File(storageDir, fileName);
        mCurrentPhotoPath = "file:"+image.getAbsolutePath();//ruta del archivo de donde debo obtener el registro
        return image;
    }

    private void dispatchTakePictureIntent() throws IOException {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                ex.toString();
                return;
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                //Uri photoURI = Uri.fromFile(createImageFile());
                Uri photoURI = FileProvider.getUriForFile(DetalleInspeccionMancomunadaActivity.this,
                        BuildConfig.APPLICATION_ID + ".provider",
                        createImageFile());
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, CAPTURE_PHOTO);
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
       // super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 100://SELECT_PHOTO
                //Log.e("SELEC","100");
                if (resultCode == RESULT_OK) {//falataria checar esto para saber si almacena la ruta correcta
                    Uri uri = data.getData();
                    String x = getPath(uri);
                    Integer num = Integer.parseInt(ClaCarro);
                    String placa = Placa;
                    Bitmap b ;
                    //if ( objBD.insertImg(num,x)){
                    if ( objBD.insertImg("",x,"")){
                        //Toast.makeText(getApplicationContext(),"EXITO-->"+num ,Toast.LENGTH_SHORT).show();
                            if (toast!= null) { toast.cancel(); }
                            toast = Toast.makeText(getApplicationContext(),"Almacenamiento exitoso.", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                    }else{
                        //Toast.makeText(getApplicationContext(),"ERROR" ,Toast.LENGTH_SHORT).show();
                            if (toast!= null) { toast.cancel(); }
                            toast = Toast.makeText(getApplicationContext(),"Error al agregar imagen.", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                    }
                    c = objBD.getImagenes();
                    c.moveToFirst();
                    for (int i=0;i<c.getCount();i++){
                       // Log.e("consulta-->", "ID-->"+c.getString(0)+"-->RUTA-->"+c.getString(1));
                        c.moveToNext();
                    }
                }
                break;
            case 2://CAPTURE_PHOTO= 2
                //Log.e("TAKE","2");
                if (resultCode == RESULT_OK) {
//                    String x = mCapturedImageURI.getPath();

                    mCurrentPhotoPath= sit.getFileRuta();

                    String x = mCurrentPhotoPath.toString();
                    String x2 = sit.getFile();
                    //generar id para idImg  asociarlo ha la inspeccion
                  //  if (objBD.addImgPlaca(ClaCarro, Placa, x)) {
                  //      Toast.makeText(getApplicationContext(), "Se gurado la imagen." + ClaCarro, Toast.LENGTH_SHORT).show();
                  //  }
                    String[] NombreFoto = x2.split("_");//NombreFoto[0]->IdCfgInspeccion
                    System.out.println("FOTOOOOOOOOOOOOOOOO "+NombreFoto[0]);
                    if(objBD.insertImg(IdInspeccionCarro,x,NombreFoto[0])){
                        if (toast!= null) { toast.cancel(); }
                        toast = Toast.makeText(getApplicationContext(),"La foto se tomo correctamente.", Toast.LENGTH_LONG);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                    }

                    c = objBD.getImagenesSituado(ClaCarro, Placa, IdInspeccionCarro);
                    c.moveToFirst();
                    for (int i = 0; i < c.getCount(); i++) {
                        Uri imageUri2 = Uri.parse(mCurrentPhotoPath);
                        File file2 = new File(imageUri2.getPath());
                        try {
                            InputStream ims = new FileInputStream(file2);
                            //ImageViewPhoto.setImageURI(imageUri2);
                            //ImageViewPhoto.setImageBitmap(BitmapFactory.decodeStream(ims));
                            //ImageViewPhoto.layout(10,10,10,10);
                        } catch (FileNotFoundException e) {
                            return;
                        }
                        c.moveToNext();
                    }
                }
                break;
            default:
                Log.e("DEFAULT","..");
                break;
        }

    }









}

package com.deacero.www.ffcc_movil.ModuloInspeccionSalida;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.InputFilter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.R;

import java.util.ArrayList;

public class Situado extends RecyclerView.Adapter<Situado.ViewHolderSituado> implements View.OnClickListener{
    BDFFCCMovil objBD;
    private ArrayList<SituadoVO> listaSituados;
    private View.OnClickListener listener;
    private AlertDialog dialog;
    private Context mContext;
    private String ClaUbicacionLogin, LoginUserName, MAC, idUsuario;
    public Situado(ArrayList<SituadoVO> listaSituados, String claUbicacionLogin, String loginUserName, String mAC, String idUsuario) {
        this.listaSituados = listaSituados;
        ClaUbicacionLogin = claUbicacionLogin;
        LoginUserName = loginUserName;
        MAC = mAC;
        this.idUsuario = idUsuario;
    }

    public String getClaUbicacionLogin() {
        return ClaUbicacionLogin;
    }

    public void setClaUbicacionLogin(String claUbicacionLogin) {
        ClaUbicacionLogin = claUbicacionLogin;
    }

    @NonNull
    @Override
    public ViewHolderSituado onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list_situados_salida,null,false);
        view.setOnClickListener(this);
        return new ViewHolderSituado(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolderSituado viewHolderSituado, final int i) {
        viewHolderSituado.etiIdPlaca.setText(listaSituados.get(i).getIdPlaca());
        viewHolderSituado.EtiPlaca.setText(listaSituados.get(i).getPlaca());
        viewHolderSituado.ImgNext.setImageResource(listaSituados.get(i).getFoto());
       // Log.e("valorRechazadoBEFORE","--"+listaSituados.get(i).getRechaza());
    }

    @Override
    public int getItemCount() {
        return listaSituados.size();
    }

    public void setOnClickListener(View.OnClickListener listener){
        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        if(listener!=null){
            listener.onClick(v);
        }
    }

    public class ViewHolderSituado extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView etiIdPlaca, EtiPlaca, TextRechaza, edObservciones;
        ImageView ImgNext;
        ImageButton  DeleteInspeccion;

        public ViewHolderSituado(@NonNull View itemView) {
            super(itemView);
            etiIdPlaca=(TextView) itemView.findViewById(R.id.txtidplaca);
            EtiPlaca=(TextView) itemView.findViewById(R.id.txtplaca);
            ImgNext= (ImageView) itemView.findViewById(R.id.IdImagen);
            DeleteInspeccion = (ImageButton) itemView.findViewById(R.id.eliminarInspeccion);
            edObservciones = (TextView) itemView.findViewById(R.id.txtObservaciones);
            DeleteInspeccion.setOnClickListener(this);
            ImgNext.setOnClickListener(this);
            edObservciones.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            final int newPosition = getAdapterPosition();
            objBD = new BDFFCCMovil(listaSituados.get(newPosition).getContext());
            switch (v.getId()){
                case R.id.eliminarInspeccion:
                    final AlertDialog.Builder builder = new AlertDialog.Builder(listaSituados.get(newPosition).getContext());
                    builder.setIcon(R.drawable.notify_dialog);
                    builder.setTitle("¿Estas seguro de eliminar esta inspección?");
                    builder.setMessage("Placa: "+listaSituados.get(newPosition).getPlaca());
                    builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            objBD.DeleteSituadoDetyFoto(listaSituados.get(newPosition).getIdInspeccionCarro(),"0");
                            listaSituados.remove(newPosition);
                            notifyItemRemoved(newPosition);
                            notifyItemRangeChanged(newPosition, listaSituados.size());
                            notifyDataSetChanged();

                            }
                    });
                    builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    builder.show();
                    break;
                case R.id.IdImagen:
                    //add code  here

                            //System.out.println(""+listaAddSituados.get(pos).getIdInspeccionCarro()+" - "+listaAddSituados.get(pos).getIdPlaca()+" -  "+listaAddSituados.get(pos).getPlaca()+"  1");
                            objBD.updateEstatusSituado(listaSituados.get(newPosition).getIdInspeccionCarro(),listaSituados.get(newPosition).getPlaca(),"1","2");
                            try {
                                int total = objBD.existeDetalleInspeccion(listaSituados.get(newPosition).getIdInspeccionCarro());
                                Log.e("total: ", String.valueOf(total));
                                if(total == 0) {
                                String IDCONFIGINSCARRO = objBD.getMaxTraInspecCarro(listaSituados.get(newPosition).getIdPlaca(),listaSituados.get(newPosition).getPlaca(),"2","1");
                                System.out.println("******** IDCONFIGINSCARRO "+ IDCONFIGINSCARRO);
                                objBD.InsertarConfiguracionesPlacaDetalle(""+listaSituados.get(newPosition).getIdPlaca(),listaSituados.get(newPosition).getPlaca(),
                                        IDCONFIGINSCARRO, "0",  "0", "1", "2");
                                }
                                objBD.CloseDB();
                                Intent intentDetalleInsManc = new Intent(listaSituados.get(newPosition).getContext(), DetalleInspeccionMancomunadaActivity.class);
                                intentDetalleInsManc.putExtra("IdPlaca", String.valueOf(listaSituados.get(newPosition).getIdPlaca()));
                                intentDetalleInsManc.putExtra("Placa", String.valueOf(listaSituados.get(newPosition).getPlaca()));
                                intentDetalleInsManc.putExtra("IdInspeccionCarro", String.valueOf(listaSituados.get(newPosition).getIdInspeccionCarro()));
                                intentDetalleInsManc.putExtra("ClaUbicacionLogin", getClaUbicacionLogin());
                                intentDetalleInsManc.putExtra("loginUserName", LoginUserName);
                                intentDetalleInsManc.putExtra("idUsuario", idUsuario);
                                intentDetalleInsManc.putExtra("MAC", MAC);
                                listaSituados.get(newPosition).getContext().startActivity(intentDetalleInsManc);

                            } catch (Exception e) {
                                e.printStackTrace();
                            }



                    break;
                case R.id.txtObservaciones:
                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(listaSituados.get(newPosition).getContext());
                    alertDialog.setTitle("Observaciones");
                    alertDialog.setMessage("Agrega Observaciones para la placa: "+listaSituados.get(newPosition).getPlaca());

                    final EditText input = new EditText(listaSituados.get(newPosition).getContext());
                    int maxLength = 300;
                    input.setFilters(new InputFilter[] {new InputFilter.LengthFilter(maxLength)});


                    input.setText(""+objBD.getObservaciones(""+listaSituados.get(newPosition).getIdInspeccionCarro()));

                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.MATCH_PARENT);
                    input.setLayoutParams(lp);
                    alertDialog.setView(input); // uncomment this line


                    alertDialog.setPositiveButton("Guardar",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    System.out.println("***************** OBS ******************** "+input.getText().toString());
                                    objBD.UpdateObservaciones(input.getText().toString(),listaSituados.get(newPosition).getIdInspeccionCarro());
                                    objBD.close();
                                }
                            });

                    alertDialog.setNegativeButton("Cancelar",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            });

                    alertDialog.show();

                    break;

            }
        }
    }
}

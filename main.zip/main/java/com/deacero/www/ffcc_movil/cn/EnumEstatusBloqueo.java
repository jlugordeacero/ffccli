package com.deacero.www.ffcc_movil.cn;

/**
 * Created by AROUCHETT on 11/02/2016.
 */
public enum EnumEstatusBloqueo {
    BLOQUEAR(1), DESBLOQUEAR(0);

    private int status;

    private EnumEstatusBloqueo(int s) {
        status = s;
    }

    public int getStatus() {
        return status;
    }
}

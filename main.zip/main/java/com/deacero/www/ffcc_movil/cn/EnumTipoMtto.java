package com.deacero.www.ffcc_movil.cn;

/**
 * Created by AROUCHETT on 13/04/2016.
 */
public enum EnumTipoMtto {
    DERIVADA(5), CORRECTIVO(2);

    private int status;

    private EnumTipoMtto(int s) {
        status = s;
    }

    public int getStatus() {
        return status;
    }
}


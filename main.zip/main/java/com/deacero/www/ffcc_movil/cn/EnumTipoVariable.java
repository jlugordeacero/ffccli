package com.deacero.www.ffcc_movil.cn;

/**
 * Created by AROUCHETT on 23/03/2016.
 */
public enum EnumTipoVariable {
    NUMERICO(1), CUALITATIVO(2);

    private int status;

    private EnumTipoVariable(int s) {
        status = s;
    }

    public int getStatus() {
        return status;
    }
}

package com.deacero.www.ffcc_movil.cn;

/**
 * Created by AROUCHETT on 06/11/2015.
 */
public enum EnumPermisos {
    //ENTRAR,
    //GUARDAR,
    //BAJARINFO
    //SUBIRINFO
    //CARGARINFO
    //SOLOCONSULTA

    ENTRAR(1), GUARDAR(2), BAJARINFO(3), SUBIRINFO(4), CARGARINFO(5), SOLOCONSULTA(6), ACTUALIZARINFOSERVER(7), ACTUALIZARINFOMOVIL(8);

    private int status;

    private EnumPermisos(int s) {
        status = s;
    }

    public int getStatus() {
        return status;
    }
}

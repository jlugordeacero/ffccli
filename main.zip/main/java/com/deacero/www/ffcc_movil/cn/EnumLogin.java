package com.deacero.www.ffcc_movil.cn;

/**
 * Created by AROUCHETT on 03/11/2015.
 */
public enum EnumLogin {
    //EXITOSO,
    //ERRORIDUSUARIO,
    //ERRORPASS
    //SINPERMISO

    EXITOSO(1), ERRORIDUSUARIO(2), ERRORPASS(3), SINPERMISO(4);

    private int statusCode;

    private EnumLogin(int s) {
        statusCode = s;
    }

    public int getStatusCode() {
        return statusCode;
    }
}

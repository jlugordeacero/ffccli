package com.deacero.www.ffcc_movil.cn;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by AROUCHETT on 11/08/2016.
 */
public enum EnumExt {
    PNG(0, "PNG"), JPG(1,"JPG"), GIF(2, "GIF");

    private int status;
    private String valor;

    private static Map<Integer, EnumExt> codeToStatusMapping;

    private EnumExt(int s, String v) {
        status = s;
        valor = v;
    }

    public static EnumExt getStatus(int i) {
        if (codeToStatusMapping == null) {
            initMapping();
        }
        return codeToStatusMapping.get(i);
    }

    private static void initMapping() {
        codeToStatusMapping = new HashMap<Integer, EnumExt>();
        for (EnumExt s : values()) {
            codeToStatusMapping.put(s.status, s);
        }
    }

    public int getStatus() {
        return status;
    }

    public String getValor() {
        return valor;
    }
}

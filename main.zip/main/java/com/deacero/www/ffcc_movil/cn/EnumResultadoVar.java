package com.deacero.www.ffcc_movil.cn;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by AROUCHETT on 23/03/2016.
 */
public enum EnumResultadoVar {
    NA(0, ""), SI(1,"SI"), NO(2, "NO");

    private int status;
    private String valor;

    private static Map<Integer, EnumResultadoVar> codeToStatusMapping;

    private EnumResultadoVar(int s, String v) {
        status = s;
        valor = v;
    }

    public static EnumResultadoVar getStatus(int i) {
        if (codeToStatusMapping == null) {
            initMapping();
        }
        return codeToStatusMapping.get(i);
    }

    private static void initMapping() {
        codeToStatusMapping = new HashMap<Integer, EnumResultadoVar>();
        for (EnumResultadoVar s : values()) {
            codeToStatusMapping.put(s.status, s);
        }
    }

    public int getStatus() {
        return status;
    }

    public String getValor() {
        return valor;
    }
}

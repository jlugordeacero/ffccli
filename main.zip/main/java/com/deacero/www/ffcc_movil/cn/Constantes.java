package com.deacero.www.ffcc_movil.cn;

/**
 * Created by AROUCHETT on 26/10/2015.
 */
public class Constantes {
    public static final int COUNT_RECORD = 0;
    public static final int DATABASE_VERSION = 1;
    public static final int DIAS_ACTUALIZAR_DB = 7;
    public static final String LLAVE_ENCRIPTAR = "deacero";

    /**Seccion para las constantes de la base de datos y tablas*/
    public static final String DATABASE_NAME = "operacionMovilDb.db";
    public static final String DATABASE_NAME_CFGSERVER = "configServerTablet.db";
    public static final String DATABASE_NAME_CONFIG = "configMovilDb.db";
    //public static final String DATABASE_NAME = "databases/operacionMovilDb.db";
    public static final String TABLA_USUARIOS = "catUsuarios";
    public static final String TABLA_OBJETOS = "catObjetos";
    public static final String TABLA_OT = "traOt";
    public static final String TABLA_RELOTTRABAJADOR = "relOtTrabajador";
    public static final String TABLA_OTARCHIVOSADJUNTOS = "otArchivosAdjuntos";
    public static final String TABLA_OTRELACTIVIDADES = "relOtActividades";
    public static final String TABLA_OTPASOS = "traOtPasos";
    public static final String TABLA_OTMATERIALES = "traOtMateriales";
    public static final String TABLA_OTHMTAPERSONAL = "traOtHmtaPersonal";
    public static final String TABLA_OTEQUIPOESPE = "traOtEquipoEspe";
    public static final String TABLA_OTEQUIPOSEGURIDAD = "traOtEquipoSeguridad";
    public static final String TABLA_OTCONDICIONSEGURIDAD = "traOtCondicionSeguridad";
    public static final String TABLA_OTVARIABLES = "traOtVariables";
    public static final String TABLA_CONFIG = "traConfig";
    public static final String TABLA_CONFIGTABLET = "traConfigTablet";
    public static final String TABLA_AREA = "catArea";
    public static final String TABLA_SUBAREA = "catSubArea";
    public static final String TABLA_EQUIPO = "catEquipo";
    public static final String TABLA_DEPTO = "catDepto";
    public static final String TABLA_RESPONSABLE = "catResponsable";
    public static final String TABLA_USUARIOSLOGEADOS = "catUsuariosLogeados";
    public static final String TABLA_USUARIOSGRAL = "catUsuariosGral";

    public static final String TABLA_SISTEMA = "catSistema";
    public static final String TABLA_SUBSISTEMA = "catSubSistema";
    public static final String TABLA_RCMFUNCION = "catRcmFuncion";
    public static final String TABLA_RCMFUNCIONFALLA = "catRcmFuncionFalla";
    public static final String TABLA_RCMMODOFALLA = "catRcmModoFalla";
    public static final String TABLA_ACTIVIDAD_CORR_DERI = "catActividadCorrDeri";
    public static final String TABLA_PASOS_CORR_DERI = "catPasosCorrDeri";
    public static final String TABLA_LOG = "catLog";
    public static final String TABLA_REL_OTNUEVA_TRABAJADOR = "relOtNuevaTrabajador";
    public static final String TABLA_ARTICULO = "catArticulos";
    public static final String TABLA_RELOTNUEVA_ARTICULO = "relOtNuevaArticulo";
    public static final String TABLA_RELOTPASOS_TRABAJADOR = "relOtPasosTrabajador";
    public static final String TABLA_RELOTPAROS = "traOtRelParo";
    public static final String TABLA_ESTHISTORICOCORR = "estHistoricoCorrectivo";
    public static final String TABLA_ESTHISTORICOMATECORR = "estHistoricoMaterialCorr";
    //public static final String TABLA_REL_OTNUEVA_TRABAJADOR_TEMP = "relOtNuevaTrabajadorTemp";
    public static final String TABLA_CONTROLSYNC = "traControlSync";

    public static final String TABLA_FUNCIONPUESTO = "catFuncionPuesto";
    public static final String TABLA_CATEGORIA = "catCategoria";
    public static final String TABLA_DISCIPLINA = "catDisciplina";
    public static final String TABLA_OTNUEVA = "traOtNueva";
    public static final String TABLA_VARIABLES = "catVariables";
    public static final String TABLA_RELCONTRESP = "relContratistaResponsable";

    public static final String TABLE_CFG_SERVERTABLET = "catCfgServidoresTablet";
    public static final String TABLE_RELCFG_MAC = "relConfiguracionMac";

    public static final String SCHEMA_MTO = "MtoSch";

    /**Seccion para las constantes de las columnas general*/
    public static final String CLA_UBICACION = "claUbicacion";
    public static final String ID_USUARIO = "idUsuario";
    public static final String ID_USUARIO_SOLICITA = "idUsuarioSolicita";

    /**Seccion para las constantes de las columnas para los articulos*/
    public static final String CANTIDAD_ARTI = "cantidadArti";
    public static final String ID_VALE = "idVale";
    public static final String ESTATUS_VALE ="estatusVale";
    public static final String REQUIERE_VALE_SN = "requiereValeSN";
    public static final String ID_ARTICULO_NUEVO = "idArticuloNuevo";
    public static final String SE_CANCELA_SN = "seCancelaSN";
    public static final String SE_CANCELO_SN = "seCanceloSN";
    public static final String CLA_ESTATUS_VALE = "claEstatusVale";
    public static final String CANTIDAD_ARTI_CORR = "cantidad";

    /**Seccion para las constantes de las columnas para los usuarios*/
    public static final String CLA_NOMINA = "claNomina";
    public static final String CLA_TRABAJADOR = "claTrabajador";
    public static final String ESRESPONSABLE = "esResponsable";
    public static final String USER = "user";
    public static final String NOMBRE_TRABAJADOR = "nombreTrabajador";
    public static final String PASS_TRABAJADOR  = "passwordTrabajador";
    public static final String CLA_NOMINADEPENDE = "claNominaDepende";
    public static final String CLA_RESPONSABLEDEPENDE = "claResponsableDepende";
    public static final String CLA_FUNCIONPUESTO = "claFuncionPuesto";
    public static final String CLA_CATEGORIA = "claCategoria";
    public static final String ID_PERFIL = "idPerfil";

    public static final String NOM_USER_LOGEADO = "nomUserLogeado";

    /**Seccion para las constantes de las columnas para los objetos*/
    public static final String ID_OBJETO = "IdObjeto";
    public static final String PER1  = "permiso1";
    public static final String PER2 = "permiso2";
    public static final String PER3  = "permiso3";
    public static final String PER4  = "permiso4";
    public static final String PER5= "permiso5";
    public static final String PER6  = "permiso6";
    public static final String PER7 = "permiso7";
    public static final String PER8 = "permiso8";

    public static final String EXISTEOT = "ExisteOt";
    public static final String ESTATUSERRONEOSN = "EstatusErroneoSN";

    /**Seccion para las constantes de las columnas para las OT*/
    public static final String ID_OT = "idOt";
    public static final String FECHA_PROG_OT = "fechaProgramacion";
    public static final String FECHA_INICIO_OT = "fechaInicio";
    public static final String FECHA_FIN_OT = "fechaFinal";
    public static final String DURACION_OT = "duracionOt";
    public static final String NOM_GUIA_OT = "nomGuia";
    public static final String NOM_EQUIPO_OT = "nomEquipo";
    public static final String REQUIERE_PARO_OT = "requiereParoSN";
    public static final String CLA_NOMINA_RESP_OT = "claNominaResponsable";
    public static final String CLA_TRABAJADOR_RESP_OT = "claTrabajadorResponsable";
    public static final String CLA_ESTATUS_OT = "claEstatusOt";
    public static final String NOM_ESTATUS_OT = "nomEstatusOt";
    public static final String CLA_EQUIPO_OT = "claEquipo";
    public static final String CLA_GRUPO_EQUIPO_OT = "claGrupoEquipo";
    public static final String NOM_TIPOMANTENIMIENTO_OT = "nomTipoMantenimiento";
    public static final String NOM_SIGLASTM_OT = "nomSiglasTM";
    public static final String CLA_NOMINA_VAL_OT = "claNominaVal";
    public static final String CLA_TRABAJADOR_VAL_OT = "claTrabajadorVal";

    public static final String CLA_AREA_OT = "claArea";
    public static final String CLA_SUBAREA_OT = "claSubArea";
    public static final String NOM_AREA_OT = "nomArea";
    public static final String NOM_SUBAREA_OT = "nomSubArea";

    public static final String FECHA_SALE_OPERACION = "fechaSaleOperacion";
    public static final String FECHA_ENTREGA_OPERACION = "fechaEntregaOperacion";
    public static final String CLA_NOMINA_OPERACION = "claNominaOperacion";
    public static final String CLA_TRABAJADOR_OPERACION = "claTrabajadorOperacion";
    public static final String ES_REAliZADA_OT_NUEVA = "seRealizo";

    /**Seccion para el manejo de las columnas para las imagenes y audio*/
    public static final String OT_IMAGEN = "otImagne";
    public static final String EXT_IMAGEN = "extImagen";
    public static final String OT_AUDIO = "otAudio";
    public static final String EXT_AUDIO = "extAudio";
    public static final String OT_OTROS = "otOtros";
    public static final String EXT_OTROS = "extOtros";

    /**Seccion para el manejo de las columnas para las actividades*/
    public static final String ORDEN_ACT_OT = "orden";
    public static final String CLA_ACTIVIDAD_OT = "claActividad";
    public static final String NOM_ACTIVIDAD_OT = "nomOtActividad";
    public static final String TIEMPO_ESTIMADO_ACTI_OT = "tiempoEstimado";
    public static final String PROCEDIMIENTO_BASE_OT = "procedimientoBase";

    /**Seccion para el manejo de las columnas para los Pasos*/
    public static final String CLA_ACTIVIDAD_PASO_OT = "claActividadPaso";
    public static final String DESCRIPCION_PASO_OT = "descripcion";
    public static final String TIEMPOESTIMADO_PASO_OT = "tiempoEstimado";
    public static final String TIEMPOREAL_PASO_OT = "tiempoRealHrs";
    public static final String ESREALIZADA_PASO_OT = "esRealizada";
    public static final String ESPERSONALEXTERNO_PASO_OT = "esPersonalExterno";
    public static final String CLABENEFICIARIO_PASO_OT = "claBeneficiario";
    public static final String RECURSO_PASO_OT = "recurso";
    public static final String PREDECESOR_PASO_OT = "predecesor";
    public static final String TIEMPOREALIZADO_PASO_OT = "tiempoRealizado";
    public static final String TIEMPOPORREALIZAR_PASO_OT = "tiempoPorRealizar";

    /**Seccion para el manejo de las columnas para las refacciones **/
    public static final String CLAVE_ARTICULO = "claveArticulo";
    public static final String CODIGO_MATE_OT = "codigo";
    public static final String CLA_ARTICULO_MATE_OT = "claArticulo";
    public static final String NOMARTICULO_MATE_OT = "nomArticulo";
    public static final String ESSTOCK_MATE_OT = "esStock";
    public static final String NOMUNIDAD_MATE_OT = "nomUnidad";
    public static final String CANTIDAD_MATE_OT = "cantidad";
    public static final String CANTIDADREAL_MATE_OT = "cantidadReal";
    public static final String REQUIERETALLER_MATE_OT = "esRequiereServicioTaller";
    public static final String TIEMPOTALLER_MATE_OT = "tiempoEstimadoServicioTaller";

    /**Seccion para el manejo de las columnas para las refacciones **/
    public static final String APLICADO_MATE_OT = "aplicado";

    /**Seccion para el manejo de las columnas para las condiciones de seguridad**/
    public static final String CLA_CONDI_SEGURIDAD_OT = "claCondicionesSeguridad";
    public static final String NOM_CONDI_SEGURIDAD_OT = "nomCondicionesSeguridad";

    /**Seccion para el manejo de las columnas para las variables**/
    public static final String CLA_VARIABLE_OT = "claVariable";
    public static final String NOM_VARIABLE_OT = "nomVariable";
    public static final String NOM_UNIDADMEDIDAVARIABLE_OT = "nomUnidadMedidaVariable";
    public static final String VALOR_ESTANDAR_OT = "valorEstandar";
    public static final String VALOR_MINIMO_OT = "valorMinimo";
    public static final String VALOR_MAXIMO_OT = "valorMaximo";
    public static final String VALOR_REAL_OT = "valorReal";
    public static final String CLA_TIPO_VARIABLE_OT = "claTipoVariable";
    public static final String SEL_NUEVA = "selNueva";

    public static final String CLA_DEPTO_OT = "claDepto";
    public static final String NOM_DEPTO_OT = "nomDepto";
    public static final String FECHA_ULT_MOD = "fechaUltimaMod";

    public static final String CLA_VARIABLE = "claVariable";
    public static final String NOM_VARIABLE = "nomVariable";
    public static final String CLA_TIPO_VARIABLE = "claTipoVariable";
    public static final String NOM_UNIDAD_VARIABLE = "nomUnidadMedidaVariable";

    public static final String FECHA_ULT_MOD_SQL = "FechaUltimaMod";

    /**Seccion para el manejo de las columnas para las las configuraciones de conexion de la tableta**/
    public static final String CLA_CONFIG = "claConfig";
    public static final String INSTANCIA = "instancia";
    public static final String SERVER_CON = "server";
    public static final String PORT_CON = "port";
    public static final String USER_CON = "user";
    public static final String PASS_CON = "pass";
    public static final String DATABASE_CON = "database";
    public static final String OBJETO_CON = "Objeto";
    public static final String FECHA_ACT = "fechaAct";
    public static final String CON_VALIDACION_SN = "conValidacionSN";

    public static final String DOMINIOFOLDER_CON = "dominioFolder";
    public static final String USURIOFOLDER_CON = "usuarioFolder";
    public static final String PASSFOLDER_CON = "passFolder";
    public static final String SERVERFOLDER_CON = "serverFolder";
    public static final String SHAREFOLDER_CON = "shareFolder";

    public static final String SESINCRONIZAOT_SN = "seSincronizaOt";
    public static final String SECARGADATABASE_SN = "seCargaDataBase";
    public static final String CLA_CONTROLSYNC = "claControlSync";

    /**CAT SISTEMAS**/
    public static final String CLA_SISTEMA = "claSistema";
    public static final String CLA_GRUPO_EQUIPO = "claGrupoEquipo";
    public static final String NOM_SISTEMA = "nomSistema";
    /**CAT SUBSISTEMAS**/
    public static final String CLA_SUBSISTEMA = "claSubSistema";
    public static final String NOM_SUBSISTEMA = "nomSubSistema";
    /**CAT RCMFUNCION**/
    public static final String CLA_RCMFUNCION = "claRcmFuncion";
    public static final String NOM_RCMFUNCION = "nomRcmFuncion";
    /**CAT FUNCION FALLA**/
    public static final String CLA_RCMFUNCIONFALLA = "claRcmFuncionFalla";
    public static final String NOM_RCMFUNCIONFALLA = "nomRcmFuncionFalla";
    /**CAT MODO FALLA**/
    public static final String CLA_RCMMODOFALLA = "claRcmModoFalla";
    public static final String NOM_RCMMODOFALLA = "descRcmModoFalla";
    public static final String ES_MIGRACION = "esMigracion";
    /**CAT ACTIVIDAD**/
    public static final String CLA_TIPOMANTENIMIENTO = "claTipoMantenimiento";
    public static final String CLA_DISCIPLINA = "claDisciplina";
    public static final String NOM_DISCIPLINA = "nomDisciplina";
    public static final String TIEMPO_ESTIMADO = "tiempoEstimado";

    /**REL PARO OT**/
    public static final String ID_PARO = "idParo";
    public static final String NOM_PARO = "nombreParo";
    public static final String FECHAHORAINICIO_PARO = "fechaHoraInicioParo";
    public static final String FECHAHORAFIN_PARO = "fechaHoraFinParo";

    public static final String TOTALVECES = "totalVeces";
    public static final String ANIO = "anio";
    public static final String MES = "mes";
    public static final String CADENA_SQL = "Cadena";

    public static final String ESNUEVA_SN = "esNuevaSN";
    public static final String ESNUEVA_SN_SQL = "EsNuevaSN";

    public static final String ES_TEMPORAL_SN = "esTemporalSN";
    public static final String ES_SELECCIONADA_SN = "esSeleccionadaSN";

    public static final String ID_NUEVA = "idNueva";
    public static final String ID_OT_PADRE = "idOtPadre";
    public static final String CLA_ACTIVIDAD_PADRE = "claActividadPadre";

    public static final String FECHA_LOG = "fechaLog";
    public static final String CADENA_LOG = "cadenaLog";
    public static final String RUTA_LOG = "rutaLog";

    public static final String NOM_FUNCIONPUESTO = "nomFuncionPuesto";
    public static final String NOM_CATEGORIA = "nomCategoria";
    public static final String DIAS_GRACIA_OT = "diasGracia";
    public static final String ESTATUS_OT = "estatus";

    public static final String FECHA_DESCARGA = "fechaDesCarga";
    public static final String SE_DESCARGA = "seDescargaSN";
    public static final String CLA_NOMINA_CARGA = "claNominaCarga";
    public static final String CLA_TRABAJADOR_CARGA = "claTrabajadorCarga";
    public static final String ES_RESPONABLE_CARGA = "esResponableCarga";

    /**Seccion para las constantes de los nombres de los SPs y sus resultados*/

    /**SECCION SP*/
    public static final String SP_CU450_TRAEROT_MOVIL_SEL  = "{call MtoSch.MTO_CU450_TraerOt_Movil_Sel(?,?,?,?,?,?,?,?,?,?,?,?,?)}";
    public static final String SP_CU450_ACTUALIZAROT_MOVIL_SEL ="{call MtoSch.MTO_CU452_ActualizarOt_Movil_Proc(?,?,?,?,?,?,?,?,?)}";
    public static final String SP_CU461_TRAERUSUARIOSCONFIG_MOVIL_SEL = "{call MtoSch.MTO_CU461_TraerUsuariosConfiguracion_Movil_Sel(?,?)}";
    public static final String SP_CU450_BLOQUEAR_DESBLOQUEAR_OT_MOVIL_PROC ="{call MtoSch.MTO_CU452_Bloquear_DesBloquear_Ot_Movil_Sel(?,?,?,?,?)}";
    public static final String SP_CU450_ACTUALIZAROT_MOVIL_PROC ="{call MtoSch.MTO_CU452_ActualizarOt_Movil_Sel(?,?,?,?,?,?,?,?,?)}";
    public static final String SP_CU452_TRAEDETALLEOT_MOVIL_SEL  = "{call MtoSch.MTO_CU452_TraerDetalleOt_Movil_Sel(?,?)}";
    public static final String SP_CU450_SUBIRFOTOSOT_PROC  = "{call MtoSch.MTO_CU452_SubirFotoOt_Movil_Proc(?,?,?,?,?,?)}";
    public static final String SP_CU450_TRAER_ACTIVIDADCORRDEV_MOVIL_SEL ="{call MtoSch.MTO_CU461_TraerActividadCorrDev_Movil_Sel(?,?,?,?,?,?,?,?,?)}";
    public static final String SP_CU450_TRAER_PASOSCORRDEV_MOVIL_SEL ="{call MtoSch.MTO_CU461_TraerPasoCorrDev_Movil_Sel(?,?,?,?,?,?,?,?,?)}";
    public static final String SP_CU450_SUBIROTNUEVAS_MOVIL_PROC ="{call MtoSch.MTO_CU461_SubirOtNuevas_Movil_Proc(?,?,?,?,?,?,?,?)}";
    public static final String SP_CU450_GENERARCANCELAR_VALES_MOVIL_PROC ="{call MtoSch.MTO_CU461_GenerarCancelarVale_Movil_Proc(?,?,?)}";
    public static final String SP_CU450_UPDATEESTATUS_VALES_MOVIL_PROC ="{call MtoSch.MTO_CU461_ActualizarVale_Movil_Proc(?,?)}";
    public static final String SP_CU450_VALIDAROT_MOVIL_PROC = "{call MtoSch.MTO_CU450_ValidarOt_Movil_Proc(?,?,?,?,?)}";
    public static final String MTO_CU452_TRAERESTATUS_ACTUALIZACION_MOVIL_SEL = "{call MtoSch.MTO_CU452_TraerEstatusActualizacion_Movil_Sel(?)}";
    public static final String MTO_CU452_TRAEREXISTENCIAS_MOVIL_SEL = "{call MtoSch.MTO_CU461_TraerExistenciaArticulo_Movil_Sel(?,?)}";
    public static final String MTO_CU452_TRAERHISTORICOCORRECTIVO_MOVIL_SEL = "{call MtoSch.MTO_CU452_TraerHistoricoCorrectivo_Movil_Sel(?,?,?)}";
    //public static final String MTO_CU452_TRAERTOTALHISTORICOCORRECTIVO_MOVIL_SEL = "{call MtoSch.MTO_CU452_TraerTotalHistoricoCorrectivo_Movil_Sel(?)}";
    /**Seccion Columnas catUsuarios*/
    public static final String CLA_NOMINA_SQL = "ClaNomina";
    public static final String CLA_TRABAJADOR_SQL = "ClaTrabajador";
    public static final String ESRESPONSABLE_SQL = "EsResponsable";
    public static final String USER_SQL = "User";
    public static final String NOMBRE_TRABAJADOR_SQL = "NombreTrabajador";
    public static final String PASS_TRABAJADOR_SQL  = "PasswordTrabajador";
    public static final String CLA_NOMINADEPENDE_SQL = "ClaNominaDepende";
    public static final String CLA_RESPONSABLEDEPENDE_SQL = "ClaResponsableDepende";
    public static final String CLA_FUNCIONPUESTO_SQL = "ClaFuncionPuesto";
    public static final String CLA_CATEGORIA_SQL = "ClaCategoria";
    public static final String ID_PERFIL_SQL = "IdPerfil";
    public static final String EXISTENCIA_SQL = "Existencia";

    /**Seccion Columnas catUsuarios*/
    public static final String ID_OBJETO_SQL = "IdObjeto";
    public static final String PER1_SQL = "Permiso1";
    public static final String PER2_SQL = "Permiso2";
    public static final String PER3_SQL = "Permiso3";
    public static final String PER4_SQL = "Permiso4";
    public static final String PER5_SQL = "Permiso5";
    public static final String PER6_SQL = "Permiso6";
    public static final String PER7_SQL = "Permiso7";
    public static final String PER8_SQL = "Permiso8";

    /**Seccion Columnas traOt*/
    public static final String ID_OT_SQL = "IdOt";
    public static final String FECHA_PROG_OT_SQL = "FechaProgramacion";
    public static final String FECHA_INICIO_OT_SQL = "FechaInicio";
    public static final String FECHA_FIN_OT_SQL = "FechaFinal";
    public static final String DURACION_OT_SQL = "DuracionOt";
    public static final String NOM_GUIA_OT_SQL = "NomGuia";
    public static final String NOM_EQUIPO_OT_SQL = "NomEquipo";
    public static final String REQUIERE_PARO_OT_SQL = "RequiereParoSN";
    public static final String CLA_NOMINA_RESP_OT_SQL = "ClaNominaResponsable";
    public static final String CLA_TRABAJADOR_RESP_OT_SQL = "ClaTrabajadorResponsable";
    public static final String CLA_ESTATUS_OT_SQL = "ClaEstatusOt";
    public static final String NOM_ESTATUS_OT_SQL = "NomEstatusOt";
    public static final String NOM_TIPOMANTENIMIENTO_OT_SQL = "NomTipoMantenimiento";
    public static final String NOM_SIGLASTM_OT_SQL = "NomSiglasTM";
    public static final String CLA_NOMINA_VAL_OT_SQL = "ClaNominaVal";
    public static final String CLA_TRABAJADOR_VAL_OT_SQL = "ClaTrabajadorVal";

    /**Seccion de columnas de las actividades*/
    public static final String ORDEN_ACT_OT_SQL = "Orden";
    public static final String CLA_ACTIVIDAD_OT_SQL = "ClaActividad";
    public static final String NOM_ACTIVIDAD_OT_SQL = "NomOtActividad";
    public static final String TIEMPO_ESTIMADO_ACTI_OT_SQL = "TiempoEstimado";
    public static final String PROCEDIMIENTO_BASE_OT_SQL = "ProcedimientoBase";

    /**Seccion de columnas de los Pasos*/
    public static final String CLA_ACTIVIDAD_PASO_OT_SQL = "ClaActividadPaso";
    public static final String DESCRIPCION_PASO_OT_SQL = "Descripcion";
    public static final String TIEMPOREAL_PASO_OT_SQL = "TiempoRealHrs";
    public static final String ESREALIZADA_PASO_OT_SQL = "EsRealizada";
    public static final String ESPERSONALEXTERNO_PASO_OT_SQL = "EsPersonalExterno";
    public static final String CLABENEFICIARIO_PASO_OT_SQL = "ClaBeneficiario";
    public static final String RECURSO_PASO_OT_SQL = "Recurso";
    public static final String PREDECESOR_PASO_OT_SQL = "Predecesor";
    public static final String TOTAL_REGISTROS_SQL = "TotalRegistrosCat";

    /**Seccion de columnas de los Pasos*/
    public static final String CODIGO_MATE_OT_SQL = "Codigo";
    public static final String CLA_ARTICULO_MATE_OT_SQL = "ClaArticulo";
    public static final String NOMARTICULO_MATE_OT_SQL = "NomArticulo";
    public static final String ESSTOCK_MATE_OT_SQL = "EsStock";
    public static final String NOMUNIDAD_MATE_OT_SQL = "NomUnidad";
    public static final String CANTIDAD_MATE_OT_SQL = "Cantidad";
    public static final String CANTIDADREAL_MATE_OT_SQL = "CantidadReal";
    public static final String REQUIERETALLER_MATE_OT_SQL = "EsRequiereServicioTaller";
    public static final String TIEMPOTALLER_MATE_OT_SQL = "TiempoEstimadoServicioTaller";
    public static final String APLICADO_MATE_OT_SQL = "Aplicado";

    /**Seccion para el manejo de las columnas para las condiciones de seguridad**/
    public static final String CLA_CONDI_SEGURIDAD_OT_SQL = "ClaCondicionesSeguridad";
    public static final String NOM_CONDI_SEGURIDAD_OT_SQL = "NomCondicionesSeguridad";

    /**Seccion para el manejo de las columnas para las variables**/
    public static final String CLA_VARIABLE_OT_SQL = "ClaVariable";
    public static final String NOM_VARIABLE_OT_SQL = "NomVariable";
    public static final String NOM_UNIDADMEDIDAVARIABLE_OT_SQL = "NomUnidadMedidaVariable";
    public static final String VALOR_ESTANDAR_OT_SQL = "ValorEstandar";
    public static final String VALOR_MINIMO_OT_SQL = "ValorMinimo";
    public static final String VALOR_MAXIMO_OT_SQL = "ValorMaximo";
    public static final String VALOR_REAL_OT_SQL = "ValorReal";
    public static final String CLA_TIPO_VARIABLE_OT_SQL = "ClaTipoVariable";

    public static final String CLA_UBICACION_SQL = "ClaUbicacion";
    public static final String ID_USUARIO_SQL = "IdUsuario";

    public static final String CLA_GRUPO_EQUIPO_SQL = "ClaGrupoEquipo";
    public static final String CLA_EQUIPO_SQL = "ClaEquipo";
    public static final String CLA_AREA_SQL = "ClaArea";
    public static final String CLA_SUBAREA_SQL = "ClaSubArea";

    public static final String NOM_AREA_SQL = "nomArea";
    public static final String NOM_SUBAREA_SQL = "nomSubArea";

    public static final String PASS_CONFIG  = "passConfig";
    public static final String ESACERIA_CONFIG  = "esAceria";
    public static final String TOTAL_FOTOS  = "totalFotos";

    public static final String PASS_CONFIG_SQL  = "PassConfig";
    public static final String ESACERIA_CONFIG_SQL  = "EsAceria";
    public static final String TOTAL_FOTOS_SQL  = "TotalFotos";
    public static final String SE_SINCRONIZA_SN_SQL  = "SeSincronizaSN";
    public static final String HORA_SYNC_SQL  = "HoraSync";
    public static final String CONVALIDACION_SN_SQL = "ConValidacionSN";

    public static final String SE_SINCRONIZA_SN  = "seSincronizaSN";
    public static final String HORA_SYNC  = "horaSync";

    public static final String CLA_DEPTO_SQL = "ClaDepto";
    public static final String NOM_DEPTO_SQL = "NomDepto";


    public static final String CLA_ACTIVIDAD_MOVIL = "ClaActividadMovil";
    public static final String CLA_ACTIVIDAD_CREADA = "ClaActividadCreada";
    public static final String CLA_ACTIVIDAD_PASO_CREADA = "ClaActividadPasoCreada";
    public static final String ID_OT_MOVIL = "IdOtMovil";
    public static final String ID_OT_SERVER = "IdOtServer";
    public static final String EXITOSO_SN = "ExitosoSN";
    public static final String CLA_ACTIVIDAD_NUEVA_SN = "ActividadNuevaSN";
    public static final String ERROR = "Error";
    public static final String MENSAJE_ERROR = "MensajeError";

    /**CAT SISTEMAS**/
    public static final String CLA_SISTEMA_SQL = "ClaSistema";
    public static final String NOM_SISTEMA_SQL = "NomSistema";
    /**CAT SUBSISTEMAS**/
    public static final String CLA_SUBSISTEMA_SQL = "ClaSubSistema";
    public static final String NOM_SUBSISTEMA_SQL = "NomSubSistema";
    /**CAT RCMFUNCION**/
    public static final String CLA_RCMFUNCION_SQL = "ClaRcmFuncion";
    public static final String NOM_RCMFUNCION_SQL = "NomRcmFuncion";
    /**CAT FUNCION FALLA**/
    public static final String CLA_RCMFUNCIONFALLA_SQL = "ClaRcmFuncionFalla";
    public static final String NOM_RCMFUNCIONFALLA_SQL = "NomRcmFuncionFalla";
    /**CAT MODO FALLA**/
    public static final String CLA_RCMMODOFALLA_SQL = "ClaRcmModoFalla";
    public static final String NOM_RCMMODOFALLA_SQL = "DescRcmModoFalla";
    /**CAT ACTIVIDAD**/
    public static final String CLA_TIPOMANTENIMIENTO_SQL = "ClaTipoMantenimiento";
    public static final String CLA_DISCIPLINA_SQL = "ClaDisciplina";
    public static final String NOM_DISCIPLINA_SQL = "NomDisciplina";
    public static final String TIEMPO_ESTIMADO_SQL = "TiempoEstimado";
    /**REL PARO OT SQL**/
    public static final String ID_PARO_SQL = "IdParo";
    public static final String NOM_PARO_SQL = "NombreParo";
    public static final String FECHAHORAINICIO_PARO_SQL = "FechaHoraInicioParo";
    public static final String FECHAHORAFIN_PARO_SQL = "FechaHoraFinParo";

    public static final String NOM_FUNCIONPUESTO_SQL = "NomFuncionPuesto";
    public static final String NOM_CATEGORIA_SQL = "NomCategoria";
    public static final String DIAS_GRACIA_SQL = "DiasGracia";
    public static final String ESTATUS_SQL = "Estatus";
    public static final String CLA_BENEFICIARIO_SQL = "ClaBeneficiario";

    /**Seccion de parametros entre actividades*/
    public static final String CLASS_PARAMETROS = "Parametros";
    public static final String CLASS_USUARIO = "Usuario";
    public static final String CLASS_OT = "Ot";
    public static final String CLASS_ACTIVIDAD = "Actividad";
    public static final String CLASS_USUARIO_LOGEADO = "UsuarioLogeado";
    public static final String CLASS_FILTROS = "Filtros";
    public static final String CLASS_PANTALLA = "Pantalla";
    public static final String CLASS_PANTALLA_CONTROL = "PantallaControl";
    public static final String CLASS_OTCARGADAS = "OtCargadasTab.class";
    public static final String CLASS_OTDISPONIBLES= "OtDisponiblesTab.class";
    public static final String CLASS_OTCORRDERI= "OtCorrectivasDerivadasTab.class";
    public static final String BAN_ESDETALLE = "EsDetalla";
    public static final String BAN_VERTODO = "VerTodo";
    public static final String BAN_VERPENDIENTE = "VerPendiente";
    public static final String BAN_EXPANDIDOSN = "ExpandidoSN";
    public static final String BAN_POSICIONOT = "PosicionOt";
    public static final String BAN_POSICIONTAB = "PosicionTab";
    public static final String CLASS_OTPASOS = "OtPasosTab.class";
    public static final String CLASS_OTREFACCIONES = "OtRefaccionesTab.class";
    public static final String CLASS_OTHERRAPERSONAL = "OtHerramientaPersonalTab.class";
    public static final String CLASS_OTHERRAESPECIAL = "OtHerramientaEspecialTab.class";
    public static final String CLASS_OTEQUIPOSEGURIDAD = "OtEquipoSeguridadTab.class";
    public static final String CLASS_OTCONDICIONESSEGUR = "OtCondicionesSeguridadTab.class";
    public static final String CLASS_OTVARIABLES = "OtVariablesTab.class";
    public static final String CLASS_OTFOTOS = "OtFotosTab.class";

    public static final String CLASS_HISTORICOMATE = "HisMaterialesTab.class";
    public static final String CLASS_HISTORICOACTI = "HisActividadesTab.class";

    public static final String CLASS_OTCARGADAS_SYNC = "OtCargadasTab";
    public static final String CLASS_OTCORRDERI_SYNC = "OtCorrectivasDerivadasTab";

    public static final String OBJETO_DEPTO = "objetoDepto";
    public static final String OBJETO_AREA = "objetoArea";
    public static final String OBJETO_SUBAREA = "objetoSubArea";
    public static final String OBJETO_EQUIPO = "objetoEquipo";

    public static final String CLASS_ACTPROCEDIMINETOBASE = "OtProcedimientoBaseTab.class";

    public static final double DIMEN_TITU_ACTIVIDAD = 4.0;
    public static final double DIMEN_TITU = 3.0;
    public static final double DIMEN_SUBTI = 2.5;
    public static final double DIMEN_BOTON = 2.5;
    public static final double DIMEN_ENCABEZADO_LAYOUT = 2.5;
    public static final double DIMEN_ENCABEZADO_LAYOUT_DET = 2.5;
    public static final double DIMEN_ROW_LIST_ENCA = 12;
    public static final double DIMEN_ROW_LIST_TITU = 2.5;
    public static final double DIMEN_ROW_LIST_DET = 2.0;
    public static final double DIMEN_TAB = 2.5;
    public static final double DIMEN_GRAL = 2.5;
    public static final double DIMEN_MODAL = 2.5;
    public static final double DIMEN_HEIGHT_TAB = 15;
    public static final double DIMEN_CHECK_VER = 2.3;
    public static final String PATH_TO_APK = "CadenaToApk";
    public static final int OPEN_NEW_ACTIVITY = 123456;

    public static final String DM_OTMATERIAL = "OtMaterialesDM";
    public static final String DM_OTHMTAPERSONAL = "OtHmtaPersonalDM";
    public static final String DM_OTEQUIPOESPECIAL = "OtEquipoEspeDM";

    public static final String TAB_OTREFACCIONES = "OtRefaccionesTab";
    public static final String TAB_HMTAPERSONAL = "OtHerramientaPersonalTab";
    public static final String TAB_HMTAESPECIAL = "OtHerramientaEspecialTab";

    public static final String TITLE_PASO = "Paso:";
    public static final String TITLE_MATERIAL = "Material:";
    public static final String TITLE_VARIABLE = "Variable:";

    public static final String TODOS = "TODOS";
    public static final String MULTIPLE = "MULTIPLE";
    public static final String NINGUNO = "NINGUNO";

    public static final String PAS_DEFAULT = "DEACERO";

    public static final Integer ALARM_ID = 120;

    public static final Integer TOTAL_REGISTROS = 2000;

    public static final Integer TOTAL_REGISTROS_HIS = 15000;

    public static final Integer CLA_ESTATUS_OT_ENPROCESO = 2;
    public static final String NOM_ESTATUS_OT_ENPROCESO = "En proceso";

    public static final Integer CLA_ESTATUS_OT_PROGRAMADA = 7;
    public static final String NOM_ESTATUS_OT_PROGRAMADA = "Programada";

    public static final Integer CLA_ESTATUS_OT_CERRADA = 3;
    public static final String NOM_ESTATUS_OT_CERRADA = "Cerrada";
    public static final String DESC_NUEVA = "NUEVA";

    public static final String NOMEQUIPO_JSON = "nomequipo";
    public static final String NOMGUIA_JSON = "nomguia";
    public static final String CLADEPTO_JSON = "cladepto";
    public static final String CLAUBICACION_JSON = "claubicacion";
    public static final String NOMESTATUSOT_JSON = "nomestatusot";
    public static final String CLANOMINAVAL_JSON = "clanominaval";
    public static final String IDOT_JSON = "idot";
    public static final String CLATRABAJADORRESPONSABLE_JSON = "clatrabajadorresponsable";
    public static final String CLASUBAREA_JSON = "clasubarea";
    public static final String CLAEQUIPO_JSON = "claequipo";
    public static final String FECHAINICIO_JSON = "fechainicio";
    public static final String NOMSIGLASTM_JSON = "nomsiglastm";
    public static final String REQUIEREPAROSN_JSON = "requiereparosn";
    public static final String NOMTIPOMANTENIMIENTO_JSON = "nomtipomantenimiento";
    public static final String FECHAFINAL_JSON = "fechafinal";
    public static final String DURACIONOT_JSON = "duracionot";
    public static final String CLAESTATUSOT_JSON = "claestatusot";
    public static final String CLATRABAJADORVAL_JSON = "clatrabajadorval";
    public static final String FECHAPROGRAMACION_JSON = "fechaprogramacion";
    public static final String CLAAREA_JSON = "claarea";
    public static final String CLANOMINARESPONSABLE_JSON = "clanominaresponsable";
    public static final String ID_PARO_JSON = "idparo";
    public static final String DIAS_GRACIA_JSON = "diasgracia";
    public static final String ESTATUS_JSON = "estatus";

    public static final String FECHA_DESCARGA_JSON = "fechadescarga";
    public static final String SE_DESCARGA_JSON = "sedescargasn";
    public static final String CLA_NOMINA_CARGA_JSON = "clanominacarga";
    public static final String CLA_TRABAJADOR_CARGA_JSON = "clatrabajadorcarga";
    public static final String ES_RESPONABLE_CARGA_JSON = "esresponablecarga";

    public static final String MENSAJEACTUALIZACION = "MensajeActualizacion";
    public static final String HAYACTUALIZACIONSN = "HayActualizacionSN";

    public static final String DESC_SIN_VALE = "SIN VALE";
    public static final String DESC_GENE_VALE = "GENERANDO VALE";
    public static final String DESC_CANCEL_VALE = "CANCELANDO VALE";
    public static final Integer CLA_ESTATUS_VALE_CERRADO_SURTIDO = 8;

    public static final String CLACONFI_CFG = "claConfiguracion";
    public static final String SERVIDOR_CFG = "servidorBaseDatos";
    public static final String INSTANCIA_CFG = "instancia";
    public static final String PUERTO_CFG = "puerto";
    public static final String USUARIO_CFG = "usuario";
    public static final String PASSSERVER_CFG = "passServer";
    public static final String NOMDB_CFG = "nombreBaseDatos";
    public static final String UBICACION_CFG = "ubicacion";
    public static final String OBJETO_CFG = "objecto";
    public static final String SERVIDORCARP_CFG = "servidorCarpeta";
    public static final String NOMCARP_CFG = "nombreCarpeta";
    public static final String DOMINIO_CFG = "dominio";
    public static final String USUARIOCARP_CFG = "usuarioCarpeta";
    public static final String PASSCARP_CFG = "passCarpeta";

    public static final String MAC_CFG = "direccionMac";
    public static final String CLAUBICACION_CFG = "claUbicacion";
    public static final String ENCRIPTADO_CFG = "encriptadoSN";

    /**Seccion para Indicadores**/
    public static final String TOTAL_ACT = "TotalActividades";
    public static final String ACTIVIDAD_REAL = "ActividadRealizada";
    public static final String ACTIVIDADES_REAL = "ActividadesRealizadas";
    public static final String TOTAL_PASOS = "TotalPasos";
    public static final String TOTAL_REALIZADAS = "TotalRealizadas";
}

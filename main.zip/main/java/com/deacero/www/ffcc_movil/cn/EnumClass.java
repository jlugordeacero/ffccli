package com.deacero.www.ffcc_movil.cn;

/**
 * Created by AROUCHETT on 05/01/2016.
 */
public enum EnumClass {
    CLASSCONSULTA(1),
    CLASSCONSULTACONFI(2),
    CLASSMAIN(3),
    CLASSACTIVIDADES(4),
    CLASSSEGUIMIENTO(5),
    CLASSCONTROL(6),
    CLASSNUEVAOT(7),
    CLASSCONSULTANUEVAOT(8),
    CLASSCORRECTIVADERI(9);

    private int status;

    private EnumClass(int s) {
        status = s;
    }

    public int getStatus() {
        return status;
    }
}

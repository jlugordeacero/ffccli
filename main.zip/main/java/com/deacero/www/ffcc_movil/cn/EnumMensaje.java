package com.deacero.www.ffcc_movil.cn;

/**
 * Created by AROUCHETT on 17/11/2015.
 */
public enum EnumMensaje {
    //SINWIFI
    //SINCONEX
    //SINSINCRO
    //EXITO

    SINWIFI(1), SINCONEX(2), SINSINCRO(3), EXITO(4), NOEXISTEOT(5), ERRORESTATUS(6);

    private int status;

    private EnumMensaje(int s) {
        status = s;
    }

    public int getStatus() {
        return status;
    }
}

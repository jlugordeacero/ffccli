package com.deacero.www.ffcc_movil;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class BDFFCCMovil extends SQLiteOpenHelper {
    private static BDFFCCMovil sInstance;
    // Database Info
    private static final String DATABASE_NAME = "FFCCMovil";
    private static final int DATABASE_VERSION = 1;
    // Table Names
    private static final String TABLE_FFCCImageCarro = "FFCCImageCarro";
    // Post Table Columns TABLE_FFCCImageCarro
    private static final String KEY_POST_ID = "idImg";
    private static final String KEY_POST_ID_INSPECCION = "idInspeccion";
    private static final String KEY_POST_ID_CFGINSPECCION = "idCfgInspeccion";
    private static final String KEY_POST_DIR_IMG = "DirImg";
    private static final String KEY_POST_BLOB_IMG = "DataImg";

    public BDFFCCMovil(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static synchronized BDFFCCMovil getInstance(Context context) {
        // Use the application context, which will ensure that you
        // don't accidentally leak an Activity's context.
        // See this article for more information: http://bit.ly/6LRzfx
        if (sInstance == null) {
            sInstance = new BDFFCCMovil(context.getApplicationContext());
        }
        return sInstance;
    }
    // Called when the database connection is being configured.
    // Configure database settings for things like foreign key support, write-ahead logging, etc.
    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }
    //----------------------------------------------------TABLAS
    String FFCCTraUsuarioMovilVw = "CREATE TABLE FFCCTraUsuarioMovilVw(ClaUbicacion INTEGER not null," +
            "idUsuario INTEGER PRIMARY KEY not null," +
            "ClaEmpleado INTEGER, " +
            "NombreUsuario varchar(152), " +
            "Contrasena varchar(4000), " +
            "Email varchar(50), " +
            "loginUserName varchar(20), " +
            "BajaLogica INTEGER not null," +
            "Token TEXT )";
    //PRIMARY KEY (ClaUbicacion, idUsuario)
    //carros situados   ESTA TABLA NO SE UTILIZA, ESTA INFO LA AGREGO EN TraInspeccionCarro
    String FFCCBitSituado = "CREATE TABLE FFCCBitSituado(IdBitSituado INTEGER PRIMARY KEY not null," +
            "Placa varchar(15) not null," +
            "ClaUbicacionOrigen INTEGER , " +
            "ClaUbicacionDestino INTEGER , " +
            "FechaETA datetime , " +
            "FechaETAOriginal datetime , " +
            "FechaSituado datetime , " +
            "TieneEntrada INTEGER , " +
            "TieneSituado INTEGER , " +
            "ClaFerroviaria INTEGER , " +
            "STCCMaterial INTEGER , " +
            "Peso numeric(19,2) , " +
            "FechaDocumentacion datetime , " +
            "NombrePcMod varchar(64) , " +
            "ClaUsuarioMod INTEGER not null  ,"+
            "FechaUltimaMod datetime," +
            "Inspeccionado INTEGER DEFAULT 0 )";//aqui con inspeccionado
                                        //     2 = no se puede editar y ha sido guardado
                                        //     1 = muestra en la lista para hacer inspeccion
                                      ///      0 = no ha sido inspeccionado

    ////entradas  o salidas,,, FFCCCatTipoInspeccion  solo se utiliza 1 que son entradas
    String FFCCCatTipoInspeccion = "CREATE TABLE FFCCCatTipoInspeccion  (ClaTipoInspeccion INTEGER PRIMARY KEY not null," +
            "NomTipoInspeccion varchar(500) not null," +
            "BajaLogica INTEGER not null, " +
            "FechaBajaLogica datetime , " +
            "ClaUsuarioMod INTEGER not null, " +
            "FechaUltimaMod datetime not null, " +
            "NombrePcMod varchar(64) not null )";

    //configuraciones,,, FFCCCatConfigInspeccion  solo se utilizan para Ubicacion 7-> Corresponde aceria celaya
    //y solo el tipo de inspeccion es 1 que corresponde a entradas
    String FFCCCatConfigInspeccion = "CREATE TABLE FFCCCatConfigInspeccion  (IdConfigInspeccion INTEGER PRIMARY KEY not null," +
            "ClaUbicacion INTEGER not null," +
            "ClaTipoInspeccion INTEGER not null, " +
            "Version INTEGER not null , " +
            "Activo INTEGER not null, " +
            "ClaUsuarioMod INTEGER not null, " +
            "FechaUltimaMod datetime not null, " +
            "NombrePcMod varchar(64) not null )";
    //configuraciones nombres de las configuraciones,,, FFCCCatConfigInspeccionDet
    String FFCCCatConfigInspeccionDet = "CREATE TABLE FFCCCatConfigInspeccionDet  (IdConfigInspeccionDet INTEGER ," +
            "IdConfigInspeccion INTEGER ," +
            "ClaUbicacion INTEGER ," +
            "Version INTEGER  , " +
            "NomConfigInspeccionDet varchar(500)  , " +
            "RechazaCarro INTEGER , " +
            "PuedeReutilizar INTEGER , " +
            "Orden INTEGER, " +
            "BajaLogica INTEGER , " +
            "FechaBajaLogica datetime , " +
            "NomCortoConfigInspeccionDet char(3) DEFAULT 'NA', " +
            "EsTapa INTEGER," +
            "ClaTipoInspeccion INTEGER, " +
            "PRIMARY KEY (IdConfigInspeccionDet, IdConfigInspeccion) )";
    //NO UTILIZO LA TABLA DE BitSituado, TODO LO HAGO EN TraInspeccionCarro  TENGO QUE CARGAR LA CONFIGURACION DE LA INSPECCION PARA PODER USAR ESTA TABLA
    //Aqui se debe precargar Una Configuracion para Cada Ubicacion 7,?,?
    String FFCCTraInspeccionCarro = "CREATE TABLE FFCCTraInspeccionCarro (IdInspeccionCarro INTEGER PRIMARY KEY AUTOINCREMENT," +
            "ClaUbicacion INTEGER not null," +
            "ClaCarro INTEGER ," +
            "PlacaCarro varchar(15) not null," +
            "IdConfigInspeccion INTEGER ," +
            "ClaTipoInspeccion INTEGER ," +
            "Rechaza INTEGER ," +
            "Reutiliza INTEGER ," +
            "FechaUltimaMod DATETIME ," +
            "ClaUsuarioMod INTEGER ," +
            "NombrePcMod VARCHAR(64) ," +
            "FechaInspeccion DATETIME ," +
            "DireccionMAC VARCHAR(40)," +
            "DirImg TEXT," +
            "Inspeccionado INTEGER DEFAULT 0 ," +
            "IdBitSituado INTEGER, " +
            "AlturaInterna INTEGER, " +
            "AnchoInterno INTEGER, " +
            "LongitudInterna INTEGER," +
            "PesoMaximo INTEGER ," +
            "idImg INTEGER," +
            "Observacion TEXT)";//aqui con inspeccionado
                                                //     2 = no se muestra en la lista y ha sido guardado
                                                //     1 = muestra en la lista para hacer inspeccion
                                                ///      0 = no ha sido inspeccionado
    //
    String FFCCTraInspeccionCarroDet = "CREATE TABLE FFCCTraInspeccionCarroDet (IdInspeccionCarroDet INTEGER PRIMARY KEY AUTOINCREMENT," +
            "IdInspeccionCarro INTEGER," +
            "IdConfigInspeccionDet INTEGER," +
            "NomInspeccion VARCHAR(500)," +
            "Valor INTEGER," +
            "RechazaVacio INTEGER," +
            "PuedeReutilizar INTEGER," +
            "FechaUltimaMod DATETIME ," +
            "ClaUsuarioMod INTEGER ," +
            "NombrePcMod VARCHAR(64))";

    //
    String FFCCCatDimensionRechazo = "CREATE TABLE FFCCCatDimensionRechazo (ClaUbicacion INTEGER ," +
            "ClaTipoUnidad INTEGER," +
            "MaximoCarga NUMERIC(4,2)," +
            "Largo NUMERIC(4,2)," +
            "Ancho NUMERIC(4,2)," +
            "Alto NUMERIC(4,2)," +
            "BajaLogica INTEGER," +
            "FechaBajaLogica DATETIME ," +
            "FechaUltimaMod DATETIME ," +
            "ClaUsuarioMod INTEGER ," +
            "NombrePcMod VARCHAR(64)," +
            "PRIMARY KEY (ClaUbicacion, ClaTipoUnidad))";

    String FFCCCatVia = "CREATE TABLE FFCCCatVia (ClaUbicacion INTEGER ," +
            "ClaVia INTEGER," +
            "NomVia VARCHAR(100)," +
            "Alias VARCHAR(100)," +
            "RecibeTodo INTEGER," +
            "BajaLogica INTEGER," +
            "FechaBajaLogica DATETIME ," +
            "FechaUltimaMod DATETIME ," +
            "ClaUsuarioMod INTEGER ," +
            "NombrePcMod VARCHAR(64)," +
            "PRIMARY KEY (ClaUbicacion, ClaVia))";

    String FFCCClienteInterno = "CREATE TABLE FFCCClienteInterno (ClaUbicacion INTEGER ," +
            "ClaClienteInterno INTEGER," +
            "NomClienteInterno VARCHAR(100)," +
            "ClaVia INTEGER," +
            "BajaLogica INTEGER," +
            "PRIMARY KEY (ClaUbicacion, ClaClienteInterno))";

    //CfgLoteoUnidad
    String FFCCCfgLoteoUnidad = "CREATE TABLE FFCCCfgLoteoUnidad(ClaUbicacion INTEGER," +
            "ClaVia INTEGER," +
            "ClaTipoUnidad INTEGER," +
            "CargadoVacio CHAR(1), " +
            "EsDefault INTEGER )";

    //CfgLoteoMaterial
    String FFCCCfgLoteoMaterial = "CREATE TABLE FFCCCfgLoteoMaterial(ClaUbicacion INTEGER," +
            "ClaVia INTEGER," +
            "ClaTipoUnidad INTEGER," +
            "ClaTipoInventario INTEGER," +
            "ClaFamilia INTEGER," +
            "ClaTipoMaterial INTEGER )";

    //tabla que almacena el loteo de las unidades
    String FfccTraLoteoUnidadEnc = "CREATE TABLE FfccTraLoteoUnidadEnc (IdLoteoUnidadEnc INTEGER PRIMARY KEY AUTOINCREMENT," +
            "ClaUbicacion INTEGER," +
            "ClaViaOrigen INTEGER," +
            "FechaLoteo DATETIME DEFAULT (datetime('now','localtime'))," +
            "DireccionMAC VARCHAR(40)," +
            "FechaUltimaMod DATETIME DEFAULT (datetime('now','localtime')) ," +
            "NombrePcMod VARCHAR(64)," +
            "ClaUsuarioMod INTEGER," +
            "ClaUsuario INTEGER," +
            "Hora DATETIME DEFAULT (datetime('now','localtime'))," +
            "Estatus INTEGER DEFAULT(0))";//DEFAULT 0-> No loteo,  1->Termino el Loteo y esta listo para ser enviado API, 2->se envio correctamente

    String FfccTraLoteoUnidadDet = "CREATE TABLE FfccTraLoteoUnidadDet (IdLoteoUnidadEnc INTEGER ," +
            "IdLoteoUnidadDet INTEGER," +
            "ClaViaDestino INTEGER," +
            "ClaCarro   INTEGER," +
            "Placa VARCHAR(15)," +
            "EsCargado INTEGER ," +
            "ClaTipoMaterial INTEGER ," +
            "FechaUltimaMod DATETIME DEFAULT (datetime('now','localtime'))," +
            "NombrePcMod VARCHAR(64)," +
            "ClaUsuarioMod INTEGER ," +
            "EstatusDet INTEGER DEFAULT(0) ," +
            "NombreMaterial VARCHAR(250)," +
            "PRIMARY KEY (IdLoteoUnidadEnc,IdLoteoUnidadDet))"; ///el EstatusDet es para validar que se envio el loteo

    // vista con todos los carros FfccCatCarroVw  ES UNA MEZCLA ENTRE CatCarro y TraControlUnidad
    String FfccCatCarroVw = "CREATE TABLE FfccCatCarroVw (" +
            "ClaCarro INTEGER ," +
            "Placa VARCHAR(15)," +
            "ClaTipoCarro INTEGER," +
            "PesoMaximo   INTEGER," +
            "LongitudInterna INTEGER," +
            "AnchoInterno INTEGER ," +
            "AlturaInterna INTEGER ," +
            "FechaUltimaMod DATETIME DEFAULT (datetime('now','localtime'))," +
            "NombrePcMod VARCHAR(64)," +
            "ClaUsuarioMod INTEGER," +
            "IdControlUnidad INTEGER," +
            "EsVacio INTEGER," +
            "ClaVia INTEGER," +
            "FechaEntrada DATETIME," +
            "FechaSalida DATETIME," +
            "ClaMaterial INTEGER," +
            "ClaFamilia INTEGER," +
            "NomMaterial VARCHAR(250)," +
            "EstatusColocado INTEGER DEFAULT(0)," +
            "ClaUbicacion INTEGER," +
            "EstatusEsLoteado INTEGER DEFAULT(0)," +
            "ClaTipoUnidad INTEGER," +
            "IdInspeccionEntrada INTEGER," +
            "IdInspeccionSalida INTEGER  )";///en cero no ha sido colocado en 1 cuando ha sido colocado
                                                    ///en cero no ha sido retirado en 1 cuando ha sido retirado
    //EstatusEsLoteado 0 -> no esta loteado
    //                 1 -> esta en un loteo pendiente
    //                  se regresa a 0 cuando se termine de lotear

    String FfccCatTipoMaterialVw = "CREATE TABLE FfccCatTipoMaterialVw (ClaTipoMaterial INTEGER ," +
            "NombreTipoMaterial VARCHAR(50))";

    //crear tabla TraControlUnidad   Solo se add con ClaEstatusCarro = 4   que es Listo para Carga
    String FfccTraControlUnidad = "CREATE TABLE FfccTraControlUnidad (IdControlUnidad INTEGER ," +
            "ClaUbicacion INTEGER," +
            "ClaCarro INTEGER," +
            "PlacaCarro VARCHAR(100)," +
            "ClaEstatusCarro   INTEGER," +
            "FechaEntrada DATETIME," +
            "FechaSalida DATETIME," +
            "EstatusColocado INTEGER DEFAULT 0)";  //EstatusColocado  0->No_colocado(),  1->Colocado(No aparece en colocar Carros)

    ///////tabla que almacena el tipo de unidad
    String FFCCCatTipoUnidadVw = "CREATE TABLE FFCCCatTipoUnidadVw (ClaUbicacion INTEGER ," +
            "ClaTipoUnidad INTEGER," +
            "NomTipoUnidad VARCHAR(250)," +
            "Placas  VARCHAR(250)," +
            "BajaLogica   INTEGER," +
            "FechaBajaLogica INTEGER," +
            "PRIMARY KEY (ClaUbicacion, ClaTipoUnidad))";

    ///////tabla TEMPORAL que almacena el tipo de unidad
    String CREATETipoUnidadTEMPORAL = "CREATE TABLE TipoUnidadTEMPORAL (ClaTipoUnidad INTEGER," +
            "Placa  VARCHAR(250))";
    String DROPTipoUnidadTEMPORAL = "DROP TABLE IF EXISTS TipoUnidadTEMPORAL";

    //tablas para las solicitudes de servicio
    String FFCCTraSolicitudServicio = "CREATE TABLE FFCCTraSolicitudServicio (IdTraSolicitudServicio INTEGER ," +
            "ClaUbicacion INTEGER," +
            "ClaConfServicios INTEGER," +
            "ClaConfVentana INTEGER," +
            "ClaVia INTEGER," +
            "Duracion   INTEGER," +
            "Unidad   INTEGER," +
            "Hora   DATETIME," +
            "HoraRegistro DATETIME," +
            "FechaCaptura DATETIME," +
            "ClaClienteInterno INTEGER," +
            "EsCarga INTEGER," +
            "BajaLogica INTEGER," +
            "FechaBajaLogica DATETIME," +
            " EstatusDiseno INTEGER DEFAULT(0)," +
            " IdColocacion INTEGER DEFAULT(0)," +
            " IdRetiro INTEGER, " +
            " PRIMARY KEY (ClaUbicacion, IdTraSolicitudServicio))";///cuando se haya confirmado el diseño se pondra en 1 y no se podra ver
    //esta tabla es el detalle de solicitud de servicio
    String FFCCTraSolicitudServicioDet = "CREATE TABLE FFCCTraSolicitudServicioDet (IdTraSolicitudServicio INTEGER ," +
            "IdTraSolicitudServicioDet INTEGER," +
            "ClaUbicacion INTEGER," +
            "ClaTipoUnidad INTEGER, " +
            "Cantidad INTEGER, " +
            "TapasRequeridas INTEGER," +
            "NomMaterial VARCHAR(150))";
    //
    String FfccCarrosColocados = "CREATE TABLE FfccCarrosColocados (ClaCarroColocado INTEGER NOT NULL," +
            "IdTraSolicitudServicio INTEGER ," +
            "ClaUbicacion INTEGER NOT NULL," +
            "ClaConfServicios INTEGER," +
            "ClaConfVentana INTEGER," +
            "DireccionMAC VARCHAR(40)," +
            "EstatusColocacion INTEGER DEFAULT 0," +
            "FechaConfirmaColocacion DATETIME DEFAULT (datetime('now','localtime')), " +
            "FechaInicial DATETIME," +
            "FechaFinal DATETIME," +
            "IDColocacionServidor INTEGER," +
            "ClaUsuarioMod INTEGER ," +
            "PRIMARY KEY (ClaUbicacion, ClaCarroColocado))";//EstatusColocacion 1 no se ha confirmado en DISEÑO-SERVICIO -> en 1 se envian API
                                            //2 ha sido confirmado EN DISEÑO-SERVICIO             ->
                                            //3 para las colocaciones que hayan termiando          ->  en 3 se envian API
                            //4 para los que hayan sido enviados  y que ya no se enviaran          -> ya no se envian
                                 //                  ///toma la hora default del sistema
    //
    String FfccCarrosColocadosDet = "CREATE TABLE FfccCarrosColocadosDet (ClaCarroColocadoDet INTEGER NOT NULL," +
            "ClaCarroColocado INTEGER NOT NULL," +
            "EsCarga INTEGER DEFAULT 0," +
            "EsTapa INTEGER DEFAULT 0," +
            "IdControlUnidad INTEGER," +
            "ClaCarro INTEGER," +
            "PlacaCarro VARCHAR(100)," +
            "ClaUsuarioMod INTEGER," +
            "ClaUbicacion INTEGER NOT NULL," +
            "NombrePcMod VARCHAR(64) ," +
            "PRIMARY KEY (ClaUbicacion, ClaCarroColocadoDet,ClaCarroColocado)," +
            "FOREIGN KEY (ClaUbicacion,ClaCarroColocado) REFERENCES FfccCarrosColocados(ClaUbicacion,ClaCarroColocado))";

    String FFCCTraRetiroClienteInterno = "CREATE TABLE FFCCTraRetiroClienteInterno (IdRetiroClienteInterno INTEGER NOT NULL," +
            "ClaUbicacion INTEGER NOT NULL," +
            "IdTraCarroColocado INTEGER," +
            "EstatusRetiro INTEGER DEFAULT 0," +
            "EstatusEvaluacionRetiro INTEGER DEFAULT 0," +
            "FechaRetiro DATETIME ," +
            "IDColocacionServidor INTEGER," +
            "ClaUsuarioMod INTEGER," +
            " NombrePcMod VARCHAR(64)," +
            "IDRetiroServidor INTEGER," +
            "PRIMARY KEY (ClaUbicacion, IdRetiroClienteInterno))";//EstatusRetiro 0 no se ha terminado retiro
    //1  ha sido terminado retiro y se enviara a la API
    //2 no se enviara a la API

    String FFCCTraRetiroClienteInternoDet = "CREATE TABLE FFCCTraRetiroClienteInternoDet (IdRetiroClienteInternoDet INTEGER NOT NULL," +
            "ClaUbicacion INTEGER NOT NULL," +
            "IdRetiroClienteInterno INTEGER NOT NULL," +
            "EsTapa INTEGER DEFAULT 0," +
            "EsCargado INTEGER DEFAULT 0," +
            "ClaCarro INTEGER," +
            "PlacaCarro VARCHAR(100)," +
            "FechaUltimaMod DATETIME DEFAULT (datetime('now','localtime'))," +
            "ClaUsuarioMod INTEGER," +
            "NombrePcMod VARCHAR(64)," +
            "PRIMARY KEY (ClaUbicacion, IdRetiroClienteInternoDet,IdRetiroClienteInterno)," +
            "FOREIGN KEY (ClaUbicacion,IdRetiroClienteInterno) REFERENCES FFCCTraRetiroClienteInterno(ClaUbicacion,IdRetiroClienteInterno))";

    String FFCCCfgEvaluacionRetiroDet = "CREATE TABLE FFCCCfgEvaluacionRetiroDet(IdCfgEvaluacionRetiroDet INTEGER, " +
            "ClaUbicacion INTEGER," +
            "NomCfgElavuacionRetiroDet VARCHAR(100)," +
            "Valor INTEGER," +
            "BajaLogica INTEGER DEFAULT 0," +
            "FechaBajaLogica DATETIME DEFAULT (datetime('now','localtime'))," +
            "PRIMARY KEY(ClaUbicacion,IdCfgEvaluacionRetiroDet) )";

    String FFCCTraEvaluacionRetiroCI = "CREATE TABLE FFCCTraEvaluacionRetiroCI (ClaUbicacion INTEGER not null," +
            "IdTraEvaluacionRetiroCI INTEGER not null," +
            "IdRetiroClienteInterno INTEGER ," +
            "Fecha DATETIME DEFAULT (datetime('now','localtime'))," +
            "EstatusEvaluacion INTEGER DEFAULT 0," +
            "FechaUltimaMod DATETIME DEFAULT (datetime('now','localtime')) ," +
            "ClaUsuarioMod INTEGER ," +
            "NombrePcMod VARCHAR(64) ," +
            "PRIMARY KEY(ClaUbicacion,IdTraEvaluacionRetiroCI))";///en nombrepcmod guardo la mac
    //EstatusEvaluacion en 0 cuando no se ha guardado
    //EstatusEvaluacion en 1 cuando se guardo y esta lista para enviarse
    //EstatusEvaluacion en 2 cuando ya se envio correctamente

    //
    String FFCCTraEvaluacionRetiroCIDet = "CREATE TABLE FFCCTraEvaluacionRetiroCIDet (ClaUbicacion INTEGER not null," +
            "IdTraEvaluacionRetiroCIDet INTEGER not null," +
            "IdTraEvaluacionRetiroCI INTEGER," +
            "IdCfgEvaluacionRetiroDet INTEGER," +
            "Valor INTEGER DEFAULT 0," +
            "FechaUltimaMod DATETIME DEFAULT (datetime('now','localtime'))," +
            "ClaUsuarioMod INTEGER ," +
            "NombrePcMod VARCHAR(64)," +
            " PRIMARY KEY(ClaUbicacion,IdTraEvaluacionRetiroCIDet,IdTraEvaluacionRetiroCI)," +
            " FOREIGN KEY (ClaUbicacion,IdTraEvaluacionRetiroCI) REFERENCES FFCCTraEvaluacionRetiroCI(ClaUbicacion,IdTraEvaluacionRetiroCI))";

    String FFCCTurno = "CREATE TABLE FFCCTurno (ClaUbicacion INTEGER not null," +
            "ClaTurno INTEGER not null," +
            "Descripcion VARCHAR(200)," +
            "HoraEntrada DATETIME DEFAULT (datetime('now','localtime'))," +
            "HoraSalida DATETIME DEFAULT (datetime('now','localtime'))," +
            " PRIMARY KEY(ClaUbicacion,ClaTurno))";

    String FFCCEquipo = "CREATE TABLE FFCCEquipo (ClaUbicacion INTEGER not null," +
            "ClaEquipo INTEGER not null," +
            "NomEquipo VARCHAR(200)," +
            " PRIMARY KEY(ClaUbicacion,ClaEquipo))";

    String  FFCCTraOT = "CREATE TABLE FFCCTraOT (IdOt INTEGER not null,"+ //0
            "Fecha DATETIME,"+ //1
            "ClaEquipo INTEGER,"+ //2
            "ClaveEquipo VARCHAR(350),"+ //3
            "ClaSistema INTEGER,"+ //4
            "NomSistema VARCHAR(300),"+ //5
            "ClaSubsistema INTEGER,"+ //6
            "NomSubsistema VARCHAR(300),"+ //7
            "ClaActividad INTEGER,"+ //8
            "ClaActividadPaso INTEGER,"+ //9
            "NomActividad VARCHAR(400),"+ //10
            "EsRealizada INTEGER,"+ //11
            "TiempoEstimado INTEGER,"+ //12
            "TiempoRealHrs INTEGER,"+ //13
            "RecursoAsignado INTEGER,"+ //14
            "ClaVariable INTEGER,"+ //15
            "NomVariable VARCHAR(300),"+ //16
            "NomUnidadMedidaVariable VARCHAR(50),"+ //17
            "ValorEstandar INTEGER,"+ //18
            "ValorMinimo INTEGER,"+ //19
            "ValorMaximo INTEGER,"+ //20
            "ValorReal INTEGER,"+ //21
            "ClaReferenciaCumple INTEGER,"+ //22
            "NomReferenciaCumple VARCHAR(50),"+ //23
            "ClaOpcionFija INTEGER,"+ //24
            "NomOpcionFija VARCHAR(300),"+ //25
            "Referencia INTEGER,"+ //26
            "ClaTipoVariable INTEGER,"+ //27
            "ValorEstandar1 INTEGER,"+ //28
            "ClaTurno INTEGER,"+ //29
            "ClaEstatusOt INTEGER DEFAULT 1,"+ //30
            "GeneraDerivada INTEGER DEFAULT 0,"+ //31
            " PRIMARY KEY(IdOt,ClaActividad))";


    // Called when the database is created for the FIRST time.
    // If a database already exists on disk with the same DATABASE_NAME, this method will NOT be called.
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_POST_TABLE_FFCCImageCarro = "CREATE TABLE " + TABLE_FFCCImageCarro +
                "(" +
                KEY_POST_ID + " INTEGER NOT NULL," +
                KEY_POST_ID_INSPECCION + " INTEGER ," +
                KEY_POST_DIR_IMG + " TEXT," +
                KEY_POST_BLOB_IMG + " BLOB," +
                KEY_POST_ID_CFGINSPECCION + " INTEGER " +
                ")";
        db.execSQL(CREATE_POST_TABLE_FFCCImageCarro);

        db.execSQL(FFCCTraUsuarioMovilVw);
        db.execSQL(FFCCBitSituado);
        db.execSQL(FFCCCatTipoInspeccion);
        db.execSQL(FFCCCatConfigInspeccion);
        db.execSQL(FFCCCatConfigInspeccionDet);//
        db.execSQL(FFCCTraInspeccionCarro);
        db.execSQL(FFCCTraInspeccionCarroDet);
        db.execSQL(FFCCCatDimensionRechazo);
        db.execSQL(FFCCCatVia);
        db.execSQL(FFCCClienteInterno);
        db.execSQL(FFCCCfgLoteoUnidad);
        db.execSQL(FFCCCfgLoteoMaterial);
        db.execSQL(FfccTraLoteoUnidadEnc);
        db.execSQL(FfccTraLoteoUnidadDet);
        db.execSQL(FfccCatCarroVw);
        db.execSQL(FfccCatTipoMaterialVw);
        db.execSQL(FfccTraControlUnidad);
        db.execSQL(FFCCCatTipoUnidadVw);
        db.execSQL(FFCCTraSolicitudServicio);
        db.execSQL(FFCCTraSolicitudServicioDet);
        db.execSQL(FfccCarrosColocados);///tabla que se llena mediante la app Diseño servicio
        db.execSQL(FfccCarrosColocadosDet);

        db.execSQL(FFCCTraRetiroClienteInterno);
        db.execSQL(FFCCTraRetiroClienteInternoDet);

        db.execSQL(FFCCCfgEvaluacionRetiroDet);
        db.execSQL(FFCCTraEvaluacionRetiroCI);///
        db.execSQL(FFCCTraEvaluacionRetiroCIDet);

        db.execSQL(FFCCTurno);
        db.execSQL(FFCCEquipo);
        db.execSQL(FFCCTraOT);


            //////////////////////// FFCCCatTipoInspeccion   1-Entrada    2-Salida
        db.execSQL("INSERT INTO FFCCCatTipoInspeccion (" +
                "ClaTipoInspeccion,NomTipoInspeccion,BajaLogica,FechaBajaLogica,ClaUsuarioMod,FechaUltimaMod,NombrePcMod) " +
                "VALUES(1,'Entrada',0,'',0,'2018-03-15 17:07:36.163','Carga Inicial')");
        db.execSQL("INSERT INTO FFCCCatTipoInspeccion (" +
                "ClaTipoInspeccion,NomTipoInspeccion,BajaLogica,FechaBajaLogica,ClaUsuarioMod,FechaUltimaMod,NombrePcMod) " +
                "VALUES(2,'Salida',0,'',0,'2018-03-15 17:07:36.163','Carga Inicial')");
        ///add la config actual con la que se esta trabajando para aceria celaya
        db.execSQL("INSERT INTO FFCCCatConfigInspeccion (" +
                "IdConfigInspeccion,ClaUbicacion,ClaTipoInspeccion,Version,Activo,ClaUsuarioMod,FechaUltimaMod,NombrePcMod) " +
                "VALUES(6,7,1,5,1,100012500,'2018-05-03 17:41:44.263','302CGARCIA')");
        db.execSQL("INSERT INTO FFCCCatConfigInspeccion (" +
                "IdConfigInspeccion,ClaUbicacion,ClaTipoInspeccion,Version,Activo,ClaUsuarioMod,FechaUltimaMod,NombrePcMod) " +
                "VALUES(9,7,1,5,1,100012500,'2018-05-03 17:41:44.263','302CGARCIA')");

        db.execSQL("INSERT INTO FFCCCatConfigInspeccion (" +
                "IdConfigInspeccion,ClaUbicacion,ClaTipoInspeccion,Version,Activo,ClaUsuarioMod,FechaUltimaMod,NombrePcMod) " +
                "VALUES(7,1,1,5,1,100012500,'2018-05-03 17:41:44.263','302CGARCIA')");//ramos
        db.execSQL("INSERT INTO FFCCCatConfigInspeccion (" +
                "IdConfigInspeccion,ClaUbicacion,ClaTipoInspeccion,Version,Activo,ClaUsuarioMod,FechaUltimaMod,NombrePcMod) " +
                "VALUES(8,7,22,5,1,100012500,'2018-05-03 17:41:44.263','302CGARCIA')");

        //generar los insert de las columnas FFCCCatConfigInspeccionDet
        db.execSQL("INSERT INTO FFCCCatConfigInspeccionDet (" +
                "IdConfigInspeccionDet,IdConfigInspeccion,ClaUbicacion,Version,NomConfigInspeccionDet,RechazaCarro," +
                "PuedeReutilizar,Orden,BajaLogica,FechaBajaLogica,NomCortoConfigInspeccionDet, ClaTipoInspeccion) " +
                "VALUES(15,6,7,5,'Cargado',0,1,1,0,'','CAR',1)");
       /* db.execSQL("INSERT INTO FFCCCatConfigInspeccionDet (" +
                "IdConfigInspeccionDet,IdConfigInspeccion,ClaUbicacion,Version,NomConfigInspeccionDet,RechazaCarro," +
                "PuedeReutilizar,Orden,BajaLogica,FechaBajaLogica,NomCortoConfigInspeccionDet) " +
                "VALUES(16,6,7,5,'Escaleras',0,1,2,0,'','ESC')");
        db.execSQL("INSERT INTO FFCCCatConfigInspeccionDet (" +
                "IdConfigInspeccionDet,IdConfigInspeccion,ClaUbicacion,Version,NomConfigInspeccionDet,RechazaCarro," +
                "PuedeReutilizar,Orden,BajaLogica,FechaBajaLogica,NomCortoConfigInspeccionDet) " +
                "VALUES(17,6,7,5,'Acopladores',0,1,3,0,'','')");
        db.execSQL("INSERT INTO FFCCCatConfigInspeccionDet (" +
                "IdConfigInspeccionDet,IdConfigInspeccion,ClaUbicacion,Version,NomConfigInspeccionDet,RechazaCarro," +
                "PuedeReutilizar,Orden,BajaLogica,FechaBajaLogica,NomCortoConfigInspeccionDet) " +
                "VALUES(18,6,7,5,'Ruedas',1,0,4,0,'','RUE')");
        db.execSQL("INSERT INTO FFCCCatConfigInspeccionDet (" +
                "IdConfigInspeccionDet,IdConfigInspeccion,ClaUbicacion,Version,NomConfigInspeccionDet,RechazaCarro," +
                "PuedeReutilizar,Orden,BajaLogica,FechaBajaLogica,NomCortoConfigInspeccionDet) " +
                "VALUES(19,6,7,5,'Carro Sucio',1,0,5,0,'','SUC')");
        db.execSQL("INSERT INTO FFCCCatConfigInspeccionDet (" +
                "IdConfigInspeccionDet,IdConfigInspeccion,ClaUbicacion,Version,NomConfigInspeccionDet,RechazaCarro," +
                "PuedeReutilizar,Orden,BajaLogica,FechaBajaLogica,NomCortoConfigInspeccionDet) " +
                "VALUES(20,6,7,5,'Carro con Aceite',1,0,6,0,'','ACE')");
        db.execSQL("INSERT INTO FFCCCatConfigInspeccionDet (" +
                "IdConfigInspeccionDet,IdConfigInspeccion,ClaUbicacion,Version,NomConfigInspeccionDet,RechazaCarro," +
                "PuedeReutilizar,Orden,BajaLogica,FechaBajaLogica,NomCortoConfigInspeccionDet) " +
                "VALUES(21,6,7,5,'Falta de Tags',0,1,7,0,'','TAG')");
        db.execSQL("INSERT INTO FFCCCatConfigInspeccionDet (" +
                "IdConfigInspeccionDet,IdConfigInspeccion,ClaUbicacion,Version,NomConfigInspeccionDet,RechazaCarro," +
                "PuedeReutilizar,Orden,BajaLogica,FechaBajaLogica,NomCortoConfigInspeccionDet) " +
                "VALUES(22,6,7,5,'Mangueras de Aire',0,1,8,0,'','MA')");
        db.execSQL("INSERT INTO FFCCCatConfigInspeccionDet (" +
                "IdConfigInspeccionDet,IdConfigInspeccion,ClaUbicacion,Version,NomConfigInspeccionDet,RechazaCarro," +
                "PuedeReutilizar,Orden,BajaLogica,FechaBajaLogica,NomCortoConfigInspeccionDet) " +
                "VALUES(23,6,7,5,'Liba de Acoplador',0,1,9,0,'','LAC')");
        db.execSQL("INSERT INTO FFCCCatConfigInspeccionDet (" +
                "IdConfigInspeccionDet,IdConfigInspeccion,ClaUbicacion,Version,NomConfigInspeccionDet,RechazaCarro," +
                "PuedeReutilizar,Orden,BajaLogica,FechaBajaLogica,NomCortoConfigInspeccionDet) " +
                "VALUES(24,6,7,5,'Palanca de Angular',0,1,10,0,'','PAN')");
        db.execSQL("INSERT INTO FFCCCatConfigInspeccionDet (" +
                "IdConfigInspeccionDet,IdConfigInspeccion,ClaUbicacion,Version,NomConfigInspeccionDet,RechazaCarro," +
                "PuedeReutilizar,Orden,BajaLogica,FechaBajaLogica,NomCortoConfigInspeccionDet) " +
                "VALUES(25,6,7,5,'Tapa',0,1,11,0,'','TAP')");
        db.execSQL("INSERT INTO FFCCCatConfigInspeccionDet (" +
                "IdConfigInspeccionDet,IdConfigInspeccion,ClaUbicacion,Version,NomConfigInspeccionDet,RechazaCarro," +
                "PuedeReutilizar,Orden,BajaLogica,FechaBajaLogica,NomCortoConfigInspeccionDet) " +
                "VALUES(26,6,7,5,'Pasamanos',0,1,12,0,'','PAS')");
        db.execSQL("INSERT INTO FFCCCatConfigInspeccionDet (" +
                "IdConfigInspeccionDet,IdConfigInspeccion,ClaUbicacion,Version,NomConfigInspeccionDet,RechazaCarro," +
                "PuedeReutilizar,Orden,BajaLogica,FechaBajaLogica,NomCortoConfigInspeccionDet) " +
                "VALUES(27,6,7,5,'Estribos',0,1,13,0,'','EST')");
        db.execSQL("INSERT INTO FFCCCatConfigInspeccionDet (" +
                "IdConfigInspeccionDet,IdConfigInspeccion,ClaUbicacion,Version,NomConfigInspeccionDet,RechazaCarro," +
                "PuedeReutilizar,Orden,BajaLogica,FechaBajaLogica,NomCortoConfigInspeccionDet) " +
                "VALUES(28,6,7,5,'Cuerpo del Carro',0,1,14,0,'','CUC')");
        db.execSQL("INSERT INTO FFCCCatConfigInspeccionDet (" +
                "IdConfigInspeccionDet,IdConfigInspeccion,ClaUbicacion,Version,NomConfigInspeccionDet,RechazaCarro," +
                "PuedeReutilizar,Orden,BajaLogica,FechaBajaLogica,NomCortoConfigInspeccionDet) " +
                "VALUES(29,6,7,5,'Volante de Freno',0,1,15,0,'','FRE')");*/

        //insert conf rechazo preliminares
       /* db.execSQL("INSERT INTO FFCCCatDimensionRechazo (ClaUbicacion, ClaTipoUnidad, MaximoCarga, Largo, Ancho, Alto, BajaLogica, FechaBajaLogica, FechaUltimaMod, NombrePcMod, ClaUsuarioMod) " +
                "VALUES (7, 0, NULL, NULL, NULL, NULL, 0, NULL,'2018-08-21 16:23:44.413', '302MRODRIGUEZC', 2914553)");
        db.execSQL("INSERT INTO FFCCCatDimensionRechazo (ClaUbicacion, ClaTipoUnidad, MaximoCarga, Largo, Ancho, Alto, BajaLogica, FechaBajaLogica, FechaUltimaMod, NombrePcMod, ClaUsuarioMod) " +
                "VALUES (7, 1, 90.00, NULL, NULL, NULL, 0, NULL,'2018-08-21 16:10:15.627', '302MRODRIGUEZC', 2914553)");
        db.execSQL("INSERT INTO FFCCCatDimensionRechazo (ClaUbicacion, ClaTipoUnidad, MaximoCarga, Largo, Ancho, Alto, BajaLogica, FechaBajaLogica, FechaUltimaMod, NombrePcMod, ClaUsuarioMod) " +
                "VALUES (7, 2, 120.00, NULL, 10.00, 45.00, 0, '2018-08-21 16:13:57.617', '2018-08-21 16:11:33.743', '302MRODRIGUEZC', 2914553)");
        db.execSQL("INSERT INTO FFCCCatDimensionRechazo (ClaUbicacion, ClaTipoUnidad, MaximoCarga, Largo, Ancho, Alto, BajaLogica, FechaBajaLogica, FechaUltimaMod, NombrePcMod, ClaUsuarioMod) " +
                "VALUES (7, 4, 15.00, NULL, NULL, NULL, 1, '2018-09-14 17:08:18.523', '2018-08-21 16:30:21.873', '302MRODRIGUEZC', 2914553)");*/

        //FFCCCatVia
        db.execSQL("INSERT INTO FFCCCatVia (ClaUbicacion, ClaVia, NomVia, Alias, RecibeTodo, BajaLogica, FechaBajaLogica, FechaUltimaMod, NombrePcMod, ClaUsuarioMod) " +
                "VALUES (7, 1, 'Prueba 1', '1', 0, 0, NULL, '2018-08-28 09:28:46.583', '302MRODRIGUEZC', 2914553)");
       /* db.execSQL("INSERT INTO FFCCCatVia (ClaUbicacion, ClaVia, NomVia, Alias, RecibeTodo, BajaLogica, FechaBajaLogica, FechaUltimaMod, NombrePcMod, ClaUsuarioMod) " +
                "VALUES (7, 2, 'salida', '2', 0, 0, NULL, '2018-08-28 09:28:46.583', '302MRODRIGUEZC', 2914553)");
        db.execSQL("INSERT INTO FFCCCatVia (ClaUbicacion, ClaVia, NomVia, Alias, RecibeTodo, BajaLogica, FechaBajaLogica, FechaUltimaMod, NombrePcMod, ClaUsuarioMod) " +
                "VALUES (7, 3, 'via embarques', '3', 0, 0, NULL, '2018-08-28 09:28:46.583', '302MRODRIGUEZC', 2914553)");
        db.execSQL("INSERT INTO FFCCCatVia (ClaUbicacion, ClaVia, NomVia, Alias, RecibeTodo, BajaLogica, FechaBajaLogica, FechaUltimaMod, NombrePcMod, ClaUsuarioMod) " +
                "VALUES (7, 4, 'via industriales', '4', 0, 0, NULL, '2018-08-28 09:28:46.583', '302MRODRIGUEZC', 2914553)");
        db.execSQL("INSERT INTO FFCCCatVia (ClaUbicacion, ClaVia, NomVia, Alias, RecibeTodo, BajaLogica, FechaBajaLogica, FechaUltimaMod, NombrePcMod, ClaUsuarioMod) " +
                "VALUES (7, 5, 'Chatarra 1a', '5a', 0, 0, NULL, '2018-08-28 09:28:46.583', '302MRODRIGUEZC', 2914553)");*/

        //insert FfccCatTipoMaterialVw;
        /*db.execSQL("INSERT INTO FfccCatTipoMaterialVw (ClaTipoMaterial, NombreTipoMaterial) " +
                "VALUES (1,'Carbon Vituminoso')");
        db.execSQL("INSERT INTO FfccCatTipoMaterialVw (ClaTipoMaterial, NombreTipoMaterial) " +
                "VALUES (2,'Fierro para construcción')");*/

        //insert tipo unidad  CARGA INICIAL
       /* db.execSQL("INSERT INTO FFCCCatTipoUnidadVw (ClaUbicacion, ClaTipoUnidad,NomTipoUnidad,Placas,BajaLogica,FechaBajaLogica) " +
                "VALUES (7,0,'General',NULL,0, NULL)");
        db.execSQL("INSERT INTO FFCCCatTipoUnidadVw (ClaUbicacion, ClaTipoUnidad,NomTipoUnidad,Placas,BajaLogica,FechaBajaLogica) " +
                "VALUES (7,1,'Privado','CIGX,DEAX',0, NULL)");*/
      /*  db.execSQL("INSERT INTO FFCCCatTipoUnidadVw (ClaUbicacion, ClaTipoUnidad,NomTipoUnidad,Placas,BajaLogica,FechaBajaLogica) " +
                "VALUES (7,2,'Pública Alta/Exp','GNTX,FXE93,CITX',0, NULL)");
        db.execSQL("INSERT INTO FFCCCatTipoUnidadVw (ClaUbicacion, ClaTipoUnidad,NomTipoUnidad,Placas,BajaLogica,FechaBajaLogica) " +
                "VALUES (7,3,'Pública Nacional Mediana','FXE91',0, NULL)");
        db.execSQL("INSERT INTO FFCCCatTipoUnidadVw (ClaUbicacion, ClaTipoUnidad,NomTipoUnidad,Placas,BajaLogica,FechaBajaLogica) " +
                "VALUES (7,4,'Pública Nacional Chica','FSRR,TFM',0, NULL)");*/

        db.execSQL("INSERT INTO FFCCCfgEvaluacionRetiroDet (IdCfgEvaluacionRetiroDet,ClaUbicacion, NomCfgElavuacionRetiroDet, Valor) "+
        " VALUES(1,7,'Carros Completos',0)");//,
       /* db.execSQL("INSERT INTO FFCCCfgEvaluacionRetiroDet (IdCfgEvaluacionRetiroDet,ClaUbicacion, NomCfgElavuacionRetiroDet, Valor) "+
                " VALUES(2,7,'Carros Salteados',0)");
        db.execSQL("INSERT INTO FFCCCfgEvaluacionRetiroDet (IdCfgEvaluacionRetiroDet,ClaUbicacion, NomCfgElavuacionRetiroDet, Valor) "+
                " VALUES(3,7,'Entregados en Tiempo',0)");*/
    }




    // Called when the database needs to be upgraded.
    // This method will only be called if a database already exists on disk with the same DATABASE_NAME,
    // but the DATABASE_VERSION is different than the version of the database that exists on disk.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion != newVersion) {
            System.out.println(oldVersion+ " ---------------------------------- ENTRO ON UPGRADE ----------------------------- "  +newVersion);
            // Simplest implementation is to drop all old tables and recreate them
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_FFCCImageCarro);
            db.execSQL("DROP TABLE IF EXISTS FFCCTraUsuarioMovilVw");
            db.execSQL("DROP TABLE IF EXISTS FFCCBitSituado");
            db.execSQL("DROP TABLE IF EXISTS FFCCCatTipoInspeccion");
            db.execSQL("DROP TABLE IF EXISTS FFCCCatConfigInspeccion");
            db.execSQL("DROP TABLE IF EXISTS FFCCCatConfigInspeccionDet");
            db.execSQL("DROP TABLE IF EXISTS FFCCTraInspeccionCarro");
            db.execSQL("DROP TABLE IF EXISTS FFCCTraInspeccionCarroDet");
            db.execSQL("DROP TABLE IF EXISTS FFCCCatDimensionRechazo");
            db.execSQL("DROP TABLE IF EXISTS FFCCCatVia");
            db.execSQL("DROP TABLE IF EXISTS FFCCClienteInterno");
            db.execSQL("DROP TABLE IF EXISTS FFCCCfgLoteoUnidad");
            db.execSQL("DROP TABLE IF EXISTS FFCCCfgLoteoMaterial");
            db.execSQL("DROP TABLE IF EXISTS FfccTraLoteoUnidadEnc");
            db.execSQL("DROP TABLE IF EXISTS FfccTraLoteoUnidadDet");
            db.execSQL("DROP TABLE IF EXISTS FfccCatCarroVw");
            db.execSQL("DROP TABLE IF EXISTS FfccCatTipoMaterialVw");
            db.execSQL("DROP TABLE IF EXISTS FFCCCatTipoUnidadVw");

            db.execSQL("DROP TABLE IF EXISTS FFCCTraSolicitudServicio");
            db.execSQL("DROP TABLE IF EXISTS FFCCTraSolicitudServicioDet");

            db.execSQL("DROP TABLE IF EXISTS FfccTraControlUnidad");
            db.execSQL("DROP TABLE IF EXISTS FfccCarrosColocados");
            db.execSQL("DROP TABLE IF EXISTS FfccCarrosColocadosDet");

            db.execSQL("DROP TABLE IF EXISTS FFCCTraRetiroClienteInterno");
            db.execSQL("DROP TABLE IF EXISTS FFCCTraRetiroClienteInternoDet");

            db.execSQL("DROP TABLE IF EXISTS FFCCCfgEvaluacionRetiro");
            db.execSQL("DROP TABLE IF EXISTS FFCCCfgEvaluacionRetiroDet");

            db.execSQL("DROP TABLE IF EXISTS FFCCTraEvaluacionRetiroCI");
            db.execSQL("DROP TABLE IF EXISTS FFCCTraEvaluacionRetiroCIDet");

            db.execSQL("DROP TABLE IF EXISTS FFCCTurno");
            db.execSQL("DROP TABLE IF EXISTS FFCCEquipo");
            db.execSQL("DROP TABLE IF EXISTS FFCCTraOT");

            onCreate(db);
        }
    }

    //.......------------------.................-------------------................--------------------
    public Cursor getUserXLoginUser(String loginUser ){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {loginUser};
        return db.rawQuery("SELECT * FROM FFCCTraUsuarioMovilVw WHERE loginUserName = ?", args);
    }

    public void updateUserMovil(String ClaEmpleado,String NombreUsuario,String Contrasena,String Email,String loginUserName, String Token){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraUsuarioMovilVw SET ClaEmpleado=? ,NombreUsuario=?,Contrasena=? ,Email=?, loginUserName=?, Token=?" +
                " WHERE loginUserName=?");
        stmt.bindString(1, ClaEmpleado);
        stmt.bindString(2, NombreUsuario);
        stmt.bindString(3, Contrasena);
        stmt.bindString(4, Email);
        stmt.bindString(5, loginUserName);
        stmt.bindString(6, Token);
        stmt.bindString(7, loginUserName);
        stmt.execute();
        db.close();
    }

    public void updateUserMovilToken(String loginUserName, String Token, String ClaUbicacion){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraUsuarioMovilVw SET Token=?" +
                " WHERE loginUserName=?" +
                " AND ClaUbicacion = ?");
        stmt.bindString(1, Token);
        stmt.bindString(2, loginUserName);
        stmt.bindString(3, ClaUbicacion);
        stmt.execute();
        db.close();
    }



    public void insertUserMovil(String ClaUbi,String idUsuario,String ClaEmpleado,String NombreUsuario,String Contrasena,String Email, String loginUserName, String BajaLogica, String Token){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor Mc;
        String[] args2 = {idUsuario};
        Mc = db.rawQuery("SELECT * FROM FFCCTraUsuarioMovilVw WHERE idUsuario = ?",args2);

        Log.e("insert: ",""+idUsuario);
        if(Mc.getCount()==0){//lo inserta porque no existe el usuario
            SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCTraUsuarioMovilVw (ClaUbicacion,idUsuario,ClaEmpleado,NombreUsuario," +
                    "Contrasena,Email,loginUserName,BajaLogica,Token)" +
                    " VALUES(?,?,?,?,?,?,?,?,?) " );
            stmt.bindString(1, ClaUbi);
            stmt.bindString(2, idUsuario);
            stmt.bindString(3, ClaEmpleado);
            stmt.bindString(4, NombreUsuario);
            stmt.bindString(5, Contrasena);
            stmt.bindString(6, Email);
            stmt.bindString(7, loginUserName);
            stmt.bindString(8, BajaLogica);
            stmt.bindString(9, Token);
            stmt.execute();
        }
        Mc.close();
        db.close();
    }

    ////////////////// CLIENTE INTERNO /////////////////
    public Cursor getClienteInternoUbi(String ClaUbicacion, String ClaVia){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion, ClaVia};
        return db.rawQuery("SELECT * FROM FFCCClienteInterno WHERE ClaUbicacion = ? AND ClaVia = ?", args);
    }

    public Cursor getClienteInterno(String ClaUbicacion, String ClaClienteInterno){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion, ClaClienteInterno};
        return db.rawQuery("SELECT * FROM FFCCClienteInterno WHERE ClaUbicacion = ? " +
                " AND ClaClienteInterno = ?", args);
    }

    public void InsertClienteInterno(String ClaUbicacion, String ClaClienteInterno, String NomClienteInterno, String ClaVia,String BajaLogica){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCClienteInterno( ClaUbicacion,ClaClienteInterno,NomClienteInterno,ClaVia,BajaLogica) " +
                " VALUES(?,?,?,?,?) ");
        stmt.bindString(1, ClaUbicacion);
        stmt.bindString(2, ClaClienteInterno);
        stmt.bindString(3, NomClienteInterno);
        stmt.bindString(4, ClaVia);
        stmt.bindString(5, BajaLogica);
        stmt.execute();
        db.close();
    }

    public void UpdateClienteInterno(String ClaUbicacion, String ClaClienteInterno, String NomClienteInterno, String ClaVia,String BajaLogica){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCClienteInterno SET NomClienteInterno=? " +
                " ,ClaVia= ? " +
                " ,BajaLogica= ? " +
                " WHERE ClaUbicacion= ?" +
                " AND ClaClienteInterno = ? ");
        stmt.bindString(1, NomClienteInterno);
        stmt.bindString(2, ClaVia);
        stmt.bindString(3, BajaLogica);
        stmt.bindString(4, ClaUbicacion);
        stmt.bindString(5, ClaClienteInterno);
        stmt.execute();
        db.close();
    }

    //////////////////////////////


///////////////////////////////////////////////

    public Cursor getViaxClaViaClaUbicacion(String ClaUbicacion, String ClaVia){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion, ClaVia};
        return db.rawQuery("SELECT * FROM FFCCCatVia WHERE ClaUbicacion = ? " +
                " AND ClaVia = ?", args);
    }

    public void InsertVias(String ClaUbicacion, String ClaVia, String NomVia, String Alias, String BajaLogica){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCCatVia( ClaUbicacion,ClaVia,NomVia,Alias,BajaLogica) " +
                " VALUES(?,?,?,?,?) ");
        stmt.bindString(1, ClaUbicacion);
        stmt.bindString(2, ClaVia);
        stmt.bindString(3, NomVia);
        stmt.bindString(4, Alias);
        stmt.bindString(5, BajaLogica);
        stmt.execute();
        db.close();
    }

    public void UpdateVias(String ClaUbicacion, String ClaVia, String NomVia, String Alias, String BajaLogica){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCCatVia SET NomVia=? " +
                " ,Alias= ? " +
                " ,BajaLogica= ? " +
                " WHERE ClaUbicacion= ?" +
                " AND ClaVia = ? ");
        stmt.bindString(1, NomVia);
        stmt.bindString(2, Alias);
        stmt.bindString(3, BajaLogica);
        stmt.bindString(4, ClaUbicacion);
        stmt.bindString(5, ClaVia);
        stmt.execute();
        db.close();
    }
///////////////////////////////////////////////

////////////////////////////TURNOS///////////////////

    public Cursor getTurnoxClaUbicacion(String ClaUbicacion, String ClaTurno){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion, ClaTurno};
        return db.rawQuery("SELECT * FROM FFCCTurno WHERE ClaUbicacion = ? " +
                " AND ClaTurno = ?", args);
    }

    public Cursor getTurnoxClaUbicacionAll(String ClaUbicacion){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion};
        return db.rawQuery("SELECT * FROM FFCCTurno WHERE ClaUbicacion = ? ", args);
    }

    public void InsertTurno(String ClaUbicacion,String ClaTurno,String Descripcion,String HoraEntrada,String HoraSalida){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCTurno(ClaUbicacion,ClaTurno,Descripcion,HoraEntrada,HoraSalida) " +
                " VALUES(?,?,?,?,?) ");
        stmt.bindString(1, ClaUbicacion);
        stmt.bindString(2, ClaTurno);
        stmt.bindString(3, Descripcion);
        stmt.bindString(4, HoraEntrada);
        stmt.bindString(5, HoraSalida);
        stmt.execute();
        db.close();
    }

    public void UpdateTurno(String ClaUbicacion,String ClaTurno,String Descripcion,String HoraEntrada,String HoraSalida){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTurno SET Descripcion=? " +
                " ,HoraEntrada= ? " +
                " ,HoraSalida= ? " +
                " WHERE ClaUbicacion= ?" +
                " AND ClaTurno = ? ");
        stmt.bindString(1, Descripcion);
        stmt.bindString(2, HoraEntrada);
        stmt.bindString(3, HoraSalida);
        stmt.bindString(4, ClaUbicacion);
        stmt.bindString(5, ClaTurno);
        stmt.execute();
        db.close();
    }
///////////////////////////////////////////////

    ////////////////////////////DESCARGA OT///////////////////

    public Cursor getOT(String IdOt, String ClaActividad){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {IdOt, ClaActividad};
        return db.rawQuery("SELECT * FROM FFCCTraOT WHERE IdOt = ? " +
                " AND ClaActividad = ?", args);
    }

    public Cursor getOTIndividual(String ClaTurno, String ClaEquipo, String Fecha){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaTurno, ClaEquipo,Fecha, "1"};
        return db.rawQuery("SELECT * FROM FFCCTraOT WHERE ClaTurno = ? " +
                " AND ClaEquipo = ?"+
                " AND Fecha = ?" +
                " AND ClaEstatusOt = ?" +
                "AND EsRealizada = 0" , args);
        /*return db.rawQuery("SELECT * FROM FFCCTraOT ", null);*/
    }

    public Cursor getOTIndividualPost(String ClaTurno, String ClaEquipo, String Fecha){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaTurno, ClaEquipo,Fecha};
        return db.rawQuery("SELECT * FROM FFCCTraOT WHERE ClaTurno = ? " +
                " AND ClaEquipo = ?"+
                " AND Fecha = ?" +
                " AND EsRealizada = 1" , args);
        /*return db.rawQuery("SELECT * FROM FFCCTraOT ", null);*/
    }

    public Cursor getOTRealizada(String EsRealizada){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = { EsRealizada};
        return db.rawQuery("SELECT * FROM FFCCTraOT WHERE EsRealizada = ?", args);
    }

    public void DeleteOT(String Fecha, String ClaTurno, String ClaEquipo){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("DELETE FROM FFCCTraOT WHERE Fecha = ? " +
                " AND ClaTurno = ? " +
                " AND ClaEquipo = ? " );
        stmt.bindString(1, Fecha);
        stmt.bindString(2, ClaTurno);
        stmt.bindString(3, ClaEquipo);
        stmt.execute();
        db.close();
    }

    public void InsertOT(String IdOt,
                         String Fecha,
                         String ClaEquipo,
                         String ClaveEquipo,
                         String ClaSistema,
                         String NomSistema,
                         String ClaSubsistema,
                         String NomSubsistema,
                         String ClaActividad,
                         String ClaActividadPaso,
                         String NomActividad,
                         String EsRealizada,
                         String TiempoEstimado,
                         String TiempoRealHrs,
                         String RecursoAsignado,
                         String ClaVariable,
                         String NomVariable,
                         String NomUnidadMedidaVariable,
                         String ValorEstandar,
                         String ValorMinimo,
                         String ValorMaximo,
                         String ValorReal,
                         String ClaReferenciaCumple,
                         String NomReferenciaCumple,
                         String ClaOpcionFija,
                         String NomOpcionFija,
                         String Referencia,
                         String ClaTipoVariable,
                         String ValorEstandar1,
                         String ClaTurno,
                         String ClaEstatusOt){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCTraOT(IdOt," +
                "                         Fecha," +
                "                         ClaEquipo," +
                "                         ClaveEquipo," +
                "                         ClaSistema," +
                "                         NomSistema," +
                "                         ClaSubsistema," +
                "                         NomSubsistema," +
                "                         ClaActividad," +
                "                         ClaActividadPaso," +
                "                         NomActividad," +
                "                         EsRealizada," +
                "                         TiempoEstimado," +
                "                         TiempoRealHrs," +
                "                         RecursoAsignado," +
                "                         ClaVariable," +
                "                         NomVariable," +
                "                         NomUnidadMedidaVariable," +
                "                         ValorEstandar," +
                "                         ValorMinimo," +
                "                         ValorMaximo," +
                "                         ValorReal," +
                "                         ClaReferenciaCumple," +
                "                         NomReferenciaCumple," +
                "                         ClaOpcionFija," +
                "                         NomOpcionFija," +
                "                         Referencia," +
                "                         ClaTipoVariable," +
                "                         ValorEstandar1," +
                "                         ClaTurno," +
                "                         ClaEstatusOt) " +
                " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");
        stmt.bindString(1, IdOt);
        stmt.bindString(2, Fecha);
        stmt.bindString(3, ClaEquipo);
        stmt.bindString(4, ClaveEquipo);
        stmt.bindString(5, ClaSistema);
        stmt.bindString(6, NomSistema);
        stmt.bindString(7, ClaSubsistema);
        stmt.bindString(8, NomSubsistema);
        stmt.bindString(9, ClaActividad);
        stmt.bindString(10, ClaActividadPaso);
        stmt.bindString(11, NomActividad);
        stmt.bindString(12, EsRealizada);
        stmt.bindString(13, TiempoEstimado);
        stmt.bindString(14, TiempoRealHrs);
        stmt.bindString(15, RecursoAsignado);
        stmt.bindString(16, ClaVariable);
        stmt.bindString(17, NomVariable);
        stmt.bindString(18, NomUnidadMedidaVariable);
        stmt.bindString(19, ValorEstandar);
        stmt.bindString(20, ValorMinimo);
        stmt.bindString(21, ValorMaximo);
        stmt.bindString(22, ValorReal);
        stmt.bindString(23, ClaReferenciaCumple);
        stmt.bindString(24, NomReferenciaCumple);
        stmt.bindString(25, ClaOpcionFija);
        stmt.bindString(26, NomOpcionFija);
        stmt.bindString(27, Referencia);
        stmt.bindString(28, ClaTipoVariable);
        stmt.bindString(29, ValorEstandar1);
        stmt.bindString(30, ClaTurno);
        stmt.bindString(31, ClaEstatusOt);
        stmt.execute();
        db.close();
    }

    public void UpdateOT(String IdOt,
                         String Fecha,
                         String ClaEquipo,
                         String ClaveEquipo,
                         String ClaSistema,
                         String NomSistema,
                         String ClaSubsistema,
                         String NomSubsistema,
                         String ClaActividad,
                         String ClaActividadPaso,
                         String NomActividad,
                         String EsRealizada,
                         String TiempoEstimado,
                         String TiempoRealHrs,
                         String RecursoAsignado,
                         String ClaVariable,
                         String NomVariable,
                         String NomUnidadMedidaVariable,
                         String ValorEstandar,
                         String ValorMinimo,
                         String ValorMaximo,
                         String ValorReal,
                         String ClaReferenciaCumple,
                         String NomReferenciaCumple,
                         String ClaOpcionFija,
                         String NomOpcionFija,
                         String Referencia,
                         String ClaTipoVariable,
                         String ValorEstandar1,
                         String ClaTurno){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraOT SET Fecha=?,"+
                "ClaEquipo=?,"+
                "ClaveEquipo=?,"+
                "ClaSistema=?,"+
                "NomSistema=?,"+
                "ClaSubsistema=?,"+
                "NomSubsistema=?,"+
                "NomActividad=?,"+
                "EsRealizada=?,"+
                "TiempoEstimado=?,"+
                "TiempoRealHrs=?,"+
                "RecursoAsignado=?,"+
                "ClaVariable=?,"+
                "NomVariable=?,"+
                "NomUnidadMedidaVariable=?,"+
                "ValorEstandar=?,"+
                "ValorMinimo=?,"+
                "ValorMaximo=?,"+
                "ValorReal=?,"+
                "ClaReferenciaCumple=?,"+
                "NomReferenciaCumple=?,"+
                "ClaOpcionFija=?,"+
                "NomOpcionFija=?,"+
                "Referencia=?,"+
                "ClaTipoVariable=?,"+
                "ValorEstandar1=?,"+
                "ClaTurno=?"+
                " WHERE IdOt= ?" +
                " AND ClaActividad = ?" +
                " AND ClaActividadPaso=? ");
        stmt.bindString(1, Fecha);
        stmt.bindString(2, ClaEquipo);
        stmt.bindString(3, ClaveEquipo);
        stmt.bindString(4, ClaSistema);
        stmt.bindString(5, NomSistema);
        stmt.bindString(6, ClaSubsistema);
        stmt.bindString(7, NomSubsistema);
        stmt.bindString(8, NomActividad);
        stmt.bindString(9, EsRealizada);
        stmt.bindString(10, TiempoEstimado);
        stmt.bindString(11, TiempoRealHrs);
        stmt.bindString(12, RecursoAsignado);
        stmt.bindString(13, ClaVariable);
        stmt.bindString(14, NomVariable);
        stmt.bindString(15, NomUnidadMedidaVariable);
        stmt.bindString(16, ValorEstandar);
        stmt.bindString(17, ValorMinimo);
        stmt.bindString(18, ValorMaximo);
        stmt.bindString(19, ValorReal);
        stmt.bindString(20, ClaReferenciaCumple);
        stmt.bindString(21, NomReferenciaCumple);
        stmt.bindString(22, ClaOpcionFija);
        stmt.bindString(23, NomOpcionFija);
        stmt.bindString(24, Referencia);
        stmt.bindString(25, ClaTipoVariable);
        stmt.bindString(26, ValorEstandar1);
        stmt.bindString(27, ClaTurno);
        stmt.bindString(28, IdOt);
        stmt.bindString(29, ClaActividad);
        stmt.bindString(30, ClaActividadPaso);
        stmt.execute();
        db.close();
    }

    public void updateOTActItem(String IdOt,
                                String ClaActividad,
                                String ClaActividadPaso,
                                String EsRealizada){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraOT SET EsRealizada=? " +
                " WHERE IdOt= ?" +
                " AND ClaActividad = ?" +
                " AND ClaActividadPaso=? ");
        stmt.bindString(1, EsRealizada);
        stmt.bindString(2, IdOt);
        stmt.bindString(3, ClaActividad);
        stmt.bindString(4, ClaActividadPaso);
        stmt.execute();
        db.close();
    }

    public void updateOTActItemValor(String IdOt,
                                String ClaActividad,
                                String ClaActividadPaso,
                                String ValorReal){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraOT SET ValorReal=? " +
                " WHERE IdOt= ?" +
                " AND ClaActividad = ?" +
                " AND ClaActividadPaso=? ");
        stmt.bindString(1, ValorReal);
        stmt.bindString(2, IdOt);
        stmt.bindString(3, ClaActividad);
        stmt.bindString(4, ClaActividadPaso);
        stmt.execute();
        db.close();
    }

    public void updateOTActItemDerivada(String IdOt,
                                     String ClaActividad,
                                     String ClaActividadPaso,
                                     String GeneraDerivada){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraOT SET GeneraDerivada=? " +
                " WHERE IdOt= ?" +
                " AND ClaActividad = ?" +
                " AND ClaActividadPaso=? ");
        stmt.bindString(1, GeneraDerivada);
        stmt.bindString(2, IdOt);
        stmt.bindString(3, ClaActividad);
        stmt.bindString(4, ClaActividadPaso);
        stmt.execute();
        db.close();
    }

    public void updateOTEstatusIndi(String IdOt,
                                String ClaActividad,
                                String ClaActividadPaso,
                                String ClaEstatusOt) {
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraOT SET ClaEstatusOt=? " +
                " WHERE IdOt= ?" +
                " AND ClaActividad = ?" +
                " AND ClaActividadPaso = ?" );
        stmt.bindString(1, ClaEstatusOt);
        stmt.bindString(2, IdOt);
        stmt.bindString(3, ClaActividad);
        stmt.bindString(4, ClaActividadPaso);
        stmt.execute();
        db.close();
    }

    public void updateOTEstatus(String IdOt,
                                String ClaEstatusOt) {
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraOT SET ClaEstatusOt=? " +
                " WHERE IdOt= ?" );
        stmt.bindString(1, ClaEstatusOt);
        stmt.bindString(2, IdOt);
        stmt.execute();
        db.close();
    }

    public void updateOTDelete(String IdOt) {
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("DELETE FROM FFCCTraOT " +
                " WHERE IdOt= ?" );
        stmt.bindString(1, IdOt);
        stmt.execute();
        db.close();
    }
///////////////////////////////////////////////


////////////////////////////Equipos///////////////////

    public Cursor getEquipoxClaUbicacion(String ClaUbicacion, String ClaEquipo){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion, ClaEquipo};
        return db.rawQuery("SELECT * FROM FFCCEquipo WHERE ClaUbicacion = ? " +
                " AND ClaEquipo = ?", args);
    }

    public Cursor getEquipoxClaUbicacionAll(String ClaUbicacion){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion};
        return db.rawQuery("SELECT * FROM FFCCEquipo WHERE ClaUbicacion = ? " , args);
    }

    public void InsertEquipo(String ClaUbicacion,String ClaEquipo,String NomEquipo){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCEquipo(ClaUbicacion,ClaEquipo,NomEquipo) " +
                " VALUES(?,?,?) ");
        stmt.bindString(1, ClaUbicacion);
        stmt.bindString(2, ClaEquipo);
        stmt.bindString(3, NomEquipo);
        stmt.execute();
        db.close();
    }

    public void UpdateEquipo(String ClaUbicacion,String ClaEquipo,String NomEquipo){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCEquipo SET NomEquipo=? " +
                " WHERE ClaUbicacion= ?" +
                " AND ClaEquipo = ? ");
        stmt.bindString(1, NomEquipo);
        stmt.bindString(2, ClaUbicacion);
        stmt.bindString(3, ClaEquipo);
        stmt.execute();
        db.close();
    }
///////////////////////////////////////////////

    //////////////////////////////////CATCARRO/////////////
    public Cursor getCatCarro(String Placa, String ClaUbicacion){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {Placa, ClaUbicacion};
        return db.rawQuery("SELECT * FROM FfccCatCarroVw WHERE Placa = ? AND ClaUbicacion = ?", args);
    }

    public void InsertCatCarro(String ClaCarro, String Placa, String PesoMaximo, String LongitudInterna, String AnchoInterno, String AlturaInterna
            ,String IdControlUnidad,String EsVacio,String ClaVia, String ClaMaterial, String ClaFamilia, String NomMaterial, String FechaEntrada, String FechaSalida, String ClaUbicacion, String ClaTipoUnidad, String IdInspeccionEntrada, String IdInspeccionSalida){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FfccCatCarroVw (ClaCarro,Placa,PesoMaximo,LongitudInterna,AnchoInterno,AlturaInterna,IdControlUnidad, EsVacio, ClaVia, ClaMaterial, ClaFamilia, NomMaterial, FechaEntrada, FechaSalida, ClaUbicacion, ClaTipoUnidad,IdInspeccionEntrada,IdInspeccionSalida) " +
                " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");
        stmt.bindString(1, ClaCarro);
        stmt.bindString(2, Placa);
        stmt.bindString(3, PesoMaximo);
        stmt.bindString(4, LongitudInterna);
        stmt.bindString(5, AnchoInterno);
        stmt.bindString(6, AlturaInterna);
        stmt.bindString(7, IdControlUnidad);
        stmt.bindString(8, EsVacio);
        stmt.bindString(9, ClaVia);
        stmt.bindString(10, ClaMaterial);
        stmt.bindString(11, ClaFamilia);
        stmt.bindString(12, NomMaterial);
        stmt.bindString(13, FechaEntrada);
        stmt.bindString(14, FechaSalida);
        stmt.bindString(15, ClaUbicacion);
        stmt.bindString(16, ClaTipoUnidad);
        stmt.bindString(17, IdInspeccionEntrada);
        stmt.bindString(18, IdInspeccionSalida);
        stmt.execute();
        db.close();
    }

    public void UpdateCatCarro(String ClaCarro, String Placa, String PesoMaximo, String LongitudInterna, String AnchoInterno, String AlturaInterna
    ,String IdControlUnidad ,String EsVacio,String ClaVia, String ClaMaterial, String ClaFamilia, String NomMaterial, String FechaEntrada,
                               String FechaSalida, String ClaUbicacion, String ClaTipoUnidad, String IdInspeccionEntrada, String IdInspeccionSalida){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FfccCatCarroVw SET PesoMaximo = ?,LongitudInterna = ?, AnchoInterno=?,AlturaInterna=?, EsVacio=?, " +
                "ClaVia = ?, ClaMaterial=?, ClaFamilia=? , NomMaterial =?, FechaEntrada = ? , FechaSalida = ?, ClaTipoUnidad = ?, IdInspeccionEntrada=?, IdInspeccionSalida=?" +
                " WHERE ClaCarro =? AND Placa = ? AND IdControlUnidad = ? AND ClaUbicacion = ? AND EstatusEsLoteado = 0");
        stmt.bindString(1, PesoMaximo);//
        stmt.bindString(2, LongitudInterna);
        stmt.bindString(3, AnchoInterno);
        stmt.bindString(4, AlturaInterna);
        stmt.bindString(5, EsVacio);
        stmt.bindString(6, ClaVia);
        stmt.bindString(7, ClaMaterial);
        stmt.bindString(8, ClaFamilia);
        stmt.bindString(9, NomMaterial);
        stmt.bindString(10, FechaEntrada);
        stmt.bindString(11, FechaSalida);
        stmt.bindString(12, ClaTipoUnidad);
        stmt.bindString(13, IdInspeccionEntrada);
        stmt.bindString(14, IdInspeccionSalida);
        stmt.bindString(15, ClaCarro);
        stmt.bindString(16, Placa);
        stmt.bindString(17, IdControlUnidad);
        stmt.bindString(18, ClaUbicacion);
        stmt.execute();
        db.close();
    }

    public void updateRetiroEsCarga(String ClaColocado, String ClaColocadoDet, String ClaUbicacion, String Valor){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraRetiroClienteInternoDet SET EsCargado = ? " +
                " WHERE ClaUbicacion =? AND IdRetiroClienteInternoDet = ? AND IdRetiroClienteInterno = ? ");
        stmt.bindString(1, Valor);
        stmt.bindString(2, ClaUbicacion);
        stmt.bindString(3, ClaColocadoDet);
        stmt.bindString(4, ClaColocado);
        stmt.execute();
        db.close();
    }

    public void updateRetiroEsTapa(String IdRetiro, String IdRetiroDet, String ClaUbicacion, String Valor){
            SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraRetiroClienteInternoDet SET EsTapa = ? " +
                " WHERE ClaUbicacion =? AND IdRetiroClienteInternoDet = ? AND IdRetiroClienteInterno = ? ");
        stmt.bindString(1, Valor);
        stmt.bindString(2, ClaUbicacion);
        stmt.bindString(3, IdRetiroDet);
        stmt.bindString(4, IdRetiro);
        stmt.execute();
        db.close();
    }

    public void updateCargadoColocadoEsCarga(String ClaColocado, String ClaColocadoDet, String ClaUbicacion, String Valor){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FfccCarrosColocadosDet SET EsCarga = ? " +
                " WHERE ClaUbicacion =? AND ClaCarroColocadoDet = ? AND ClaCarroColocado = ? ");
        stmt.bindString(1, Valor);
        stmt.bindString(2, ClaUbicacion);
        stmt.bindString(3, ClaColocadoDet);
        stmt.bindString(4, ClaColocado);
        stmt.execute();
        db.close();
    }

    public void updateCargadoColocadoEsTapa(String ClaColocado, String ClaColocadoDet, String ClaUbicacion, String Valor){
            SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FfccCarrosColocadosDet SET EsTapa = ? " +
                " WHERE ClaUbicacion =? AND ClaCarroColocadoDet = ? AND ClaCarroColocado = ? ");
        stmt.bindString(1, Valor);
        stmt.bindString(2, ClaUbicacion);
        stmt.bindString(3, ClaColocadoDet);
        stmt.bindString(4, ClaColocado);
        stmt.execute();
        db.close();
    }
///////////////////////////////////////////////

    ////////////////////////////////// CAPTURA SOLICITUDES DE SERVICIO /////////////
    public Cursor getCapturasServicio(String ClaUbicacion, String IdTraSolicitudServicio){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion, IdTraSolicitudServicio};
        return db.rawQuery("SELECT * FROM FFCCTraSolicitudServicio WHERE ClaUbicacion = ? " +
                " AND IdTraSolicitudServicio = ?", args);
    }

    public Cursor getCapturasServicioDet(String IdTraSolicitudServicio, String IdTraSolicitudServicioDet, String ClaUbicacion){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {IdTraSolicitudServicio, IdTraSolicitudServicioDet, ClaUbicacion};
        return db.rawQuery("SELECT * FROM FFCCTraSolicitudServicioDet WHERE IdTraSolicitudServicio = ? " +
                " AND IdTraSolicitudServicioDet = ? AND ClaUbicacion = ?", args);
    }

    public void InsertCapturasServicio(String FechaCaptura,String ClaConfVentana,String ClaConfServicios,String IdTraSolicitudServicio,String ClaUbicacion,String ClaClienteInterno,String ClaVia, String Duracion, String Unidad, String Hora, String HoraRegistro,String EsCarga,String BajaLogica, String IdColocacion, String IdRetiro){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCTraSolicitudServicio(IdTraSolicitudServicio,ClaUbicacion,ClaConfServicios,ClaConfVentana,ClaVia,Duracion, Unidad, Hora, HoraRegistro,FechaCaptura, ClaClienteInterno, EsCarga, BajaLogica, IdColocacion, IdRetiro) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        stmt.bindString(1, IdTraSolicitudServicio);
        stmt.bindString(2, ClaUbicacion);
        stmt.bindString(3, ClaConfServicios);
        stmt.bindString(4, ClaConfVentana);
        stmt.bindString(5, ClaVia);
        stmt.bindString(6, Duracion);
        stmt.bindString(7, Unidad);
        stmt.bindString(8, Hora);
        stmt.bindString(9, HoraRegistro);
        stmt.bindString(10, FechaCaptura);
        stmt.bindString(11, ClaClienteInterno);
        stmt.bindString(12, EsCarga);
        stmt.bindString(13, BajaLogica);
        stmt.bindString(14, IdColocacion);
        stmt.bindString(15, IdRetiro);
        stmt.execute();
        db.close();
    }

    public void InsertCapturasServicioDet(String IdTraSolicitudServicio,String  IdTraSolicitudServicioDet,String ClaTipoUnidad,String Cantidad,String TapasRequeridas, String ClaUbicacion, String NomMaterial){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCTraSolicitudServicioDet(IdTraSolicitudServicio, IdTraSolicitudServicioDet, ClaTipoUnidad, Cantidad, TapasRequeridas, ClaUbicacion, NomMaterial) VALUES(?,?,?,?,?,?,?)");
        stmt.bindString(1, IdTraSolicitudServicio);
        stmt.bindString(2, IdTraSolicitudServicioDet);
        stmt.bindString(3, ClaTipoUnidad);
        stmt.bindString(4, Cantidad);
        stmt.bindString(5, TapasRequeridas);
        stmt.bindString(6,ClaUbicacion);
        stmt.bindString(7,NomMaterial);
        stmt.execute();
        db.close();
    }

    public void UpdateCapturasServicio(String ClaConfServicios,String ClaConfVentana,String ClaVia,String Duracion,String Unidad,String Hora,String HoraRegistro, String FechaCaptura, String ClaClienteInterno, String EsCarga, String BajaLogica, String IdTraSolicitudServicio, String ClaUbicacion, String IdColocacion, String IdRetiro){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraSolicitudServicio SET ClaConfServicios = ?,ClaConfVentana = ?, ClaVia = ?, Duracion = ?, Unidad = ?, Hora = ?, HoraRegistro = ?,FechaCaptura = ?, ClaClienteInterno = ?, EsCarga = ?, BajaLogica = ?, IdColocacion = ?, IdRetiro = ? WHERE IdTraSolicitudServicio = ? AND ClaUbicacion = ? ");
        stmt.bindString(1, ClaConfServicios);
        stmt.bindString(2, ClaConfVentana);
        stmt.bindString(3, ClaVia);
        stmt.bindString(4, Duracion);
        stmt.bindString(5, Unidad);
        stmt.bindString(6, Hora);
        stmt.bindString(7, HoraRegistro);
        stmt.bindString(8, FechaCaptura);
        stmt.bindString(9, ClaClienteInterno);
        stmt.bindString(10, EsCarga);
        stmt.bindString(11, BajaLogica);
        stmt.bindString(12, IdColocacion);
        stmt.bindString(13, IdRetiro);
        stmt.bindString(14, IdTraSolicitudServicio);
        stmt.bindString(15, ClaUbicacion);
        stmt.execute();
        db.close();
    }

    public void UpdateCapturasServicioDet(String ClaTipoUnidad,String Cantidad,String TapasRequeridas,String IdTraSolicitudServicio, String IdTraSolicitudServicioDet){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraSolicitudServicioDet SET ClaTipoUnidad = ?, Cantidad = ?, TapasRequeridas = ? WHERE IdTraSolicitudServicio = ? AND IdTraSolicitudServicioDet = ?");
        stmt.bindString(1, ClaTipoUnidad);
        stmt.bindString(2, Cantidad);
        stmt.bindString(3, TapasRequeridas);
        stmt.bindString(4, IdTraSolicitudServicio);
        stmt.bindString(5, IdTraSolicitudServicioDet);
        stmt.execute();
        db.close();
    }

    public void DeleteCapturasServicioDet(String IdTraSolicitudServicio){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("DELETE FROM FFCCTraSolicitudServicioDet  WHERE IdTraSolicitudServicio = ?");
        stmt.bindString(1, IdTraSolicitudServicio);
        stmt.execute();
        db.close();
    }
///////////////////////////////////////////////


    ////////////////////////////////// CFG EVALUACION CI /////////////
    public Cursor getCapturasCfgEvaluacionCI(String ClaUbicacion, String IdCfgEvaluacionRetiroDet){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion, IdCfgEvaluacionRetiroDet};
        return db.rawQuery("SELECT * FROM FFCCCfgEvaluacionRetiroDet WHERE ClaUbicacion = ? " +
                " AND IdCfgEvaluacionRetiroDet = ?", args);
    }

    public void InsertCfgEvaluacionCI(String ClaUbicacion,String IdCfgEvaluacionRetiroDet,String NomCfgElavuacionRetiroDet,String Valor,String BajaLogica){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCCfgEvaluacionRetiroDet(ClaUbicacion,IdCfgEvaluacionRetiroDet,NomCfgElavuacionRetiroDet,Valor,BajaLogica) VALUES(?,?,?,?,?)");
        stmt.bindString(1, ClaUbicacion);
        stmt.bindString(2, IdCfgEvaluacionRetiroDet);
        stmt.bindString(3, NomCfgElavuacionRetiroDet);
        stmt.bindString(4, Valor);
        stmt.bindString(5, BajaLogica);
        stmt.execute();
        db.close();
    }

    public void UpdateCfgEvaluacionCI(String ClaUbicacion,String IdCfgEvaluacionRetiroDet,String NomCfgElavuacionRetiroDet,String Valor,String BajaLogica){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCCfgEvaluacionRetiroDet SET NomCfgElavuacionRetiroDet = ?,Valor = ?, BajaLogica = ? WHERE IdCfgEvaluacionRetiroDet = ? AND ClaUbicacion = ? ");
        stmt.bindString(1, NomCfgElavuacionRetiroDet);
        stmt.bindString(2, Valor);
        stmt.bindString(3, BajaLogica);
        stmt.bindString(4, IdCfgEvaluacionRetiroDet);
        stmt.bindString(5, ClaUbicacion);
        stmt.execute();
        db.close();
    }

///////////////////////////////////////////////

    ////////////////////////////////// CAPTURA SOLICITUDES DE SERVICIO /////////////
    public Cursor getColocacionesAPI(String ClaUbicacion,String IdTraSolicitudServicio){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion, IdTraSolicitudServicio};
        return db.rawQuery("SELECT * FROM FfccCarrosColocados WHERE ClaUbicacion = ? " +
                " AND IdTraSolicitudServicio = ?" , args);
    }

   /* public Cursor DeleteColocacionDetAPI(String ClaCarroColocado, String ClaUbicacion){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("DELETE FROM FfccCarrosColocadosDet WHERE ClaCarroColocado = ? AND ClaUbicacion = ? ");
        stmt.bindString(1, ClaCarroColocado);
        stmt.bindString(2, ClaUbicacion);
        stmt.execute();
        db.close();
    }*/

    public int ExisteServicioVentana(String ClaUbicacion, String IdTraSolicitudServicio){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {IdTraSolicitudServicio,ClaUbicacion};
        Cursor c6;
        c6 = db.rawQuery("SELECT ifnull(ClaConfServicios,0), ifnull(ClaConfVentana,0) FROM FFCCTraSolicitudServicio WHERE IdTraSolicitudServicio = ? AND ClaUbicacion = ?",args);
       int tam = 0;
        if(c6.getCount()>0) {
           c6.moveToFirst();
           System.out.println("*************"+c6.getString(0)+":"+c6.getString(0)+"***************");
           tam = c6.getCount();
       }
       c6.close();
       // db.close();
        return tam;
    }


    public String getServicioVentana(String ClaUbicacion, String IdTraSolicitudServicio,SQLiteDatabase db){
        String[] args = {ClaUbicacion,IdTraSolicitudServicio};


        Cursor c;
        c = db.rawQuery("SELECT ifnull(ClaConfServicios,0), ifnull(ClaConfVentana,0) FROM FFCCTraSolicitudServicio WHERE  ClaUbicacion = ? AND IdTraSolicitudServicio = ? ",args);
        String data = "0:0";
        if(c.getCount()>0) {
            c.moveToFirst();
            System.out.println("*************" + c.getString(0) + ":" + c.getString(1) + "***************");
            data = c.getString(0)+":"+c.getString(1);
        }
        return data;
    }

    public void InsertColocacionAPI(String ClaCarroColocado,String IdTraSolicitudServicio,String ClaUbicacion,String DireccionMAC,String EstatusColocacion,String FechaConfirmaColocacion,String FechaInicial,String FechaFinal,String IDColocacionServidor,String ClaUsuarioMod){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FfccCarrosColocados(ClaCarroColocado,IdTraSolicitudServicio,ClaUbicacion,ClaConfServicios,ClaConfVentana,DireccionMAC,EstatusColocacion,FechaConfirmaColocacion,FechaInicial,FechaFinal,IDColocacionServidor,ClaUsuarioMod) " +
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)");
        stmt.bindString(1, ClaCarroColocado);
        stmt.bindString(2, IdTraSolicitudServicio);
        stmt.bindString(3, ClaUbicacion);
        String[] args = this.getServicioVentana(ClaUbicacion,IdTraSolicitudServicio,db).split(":");
        stmt.bindString(4, ""+args[0]);
        stmt.bindString(5, ""+args[1]);
        stmt.bindString(6, DireccionMAC);
        stmt.bindString(7, EstatusColocacion);
        stmt.bindString(8, FechaConfirmaColocacion);
        stmt.bindString(9, FechaInicial);
        stmt.bindString(10, FechaFinal);
        stmt.bindString(11, IDColocacionServidor);
        stmt.bindString(12, ClaUsuarioMod);
        stmt.execute();
        db.close();
    }


    public void InsertColocacionDetAPI(String ClaCarroColocado,String ClaCarroColocadoDet,String ClaUbicacion2,String IdControlUnidad,String ClaCarro,String PlacaCarro,String EsTapa,String EsVacio,String NombrePcMod2,String ClaUsuarioMod2){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FfccCarrosColocadosDet(ClaCarroColocado,ClaCarroColocadoDet,EsCarga,EsTapa,IdControlUnidad,ClaCarro,PlacaCarro,ClaUsuarioMod,ClaUbicacion,NombrePcMod) " +
                " VALUES(?,?,?,?,?,?,?,?,?,?)");
        stmt.bindString(1, ClaCarroColocado);
        stmt.bindString(2, ClaCarroColocadoDet);
        stmt.bindString(3, EsVacio);
        stmt.bindString(4, EsTapa);
        stmt.bindString(5, IdControlUnidad);
        stmt.bindString(6, ClaCarro);
        stmt.bindString(7, PlacaCarro);
        stmt.bindString(8, ClaUsuarioMod2);
        stmt.bindString(9, ClaUbicacion2);
        stmt.bindString(10, NombrePcMod2);
        stmt.execute();
        db.close();
    }


    public void EliminaColocacionDetAPI(String ClaCarroColocado, String ClaUbicacion){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("DELETE FROM FfccCarrosColocadosDet " +
                " WHERE ClaCarroColocado = ? AND ClaUbicacion = ?");
        stmt.bindString(1, ClaCarroColocado);
        stmt.bindString(2, ClaUbicacion);
        stmt.execute();
        db.close();
    }

    public void UpdateIDSqlServerColcacion(String idSqliteColocacion, String ClaUbicacion, String IDColocacionServidor, String EstatusColocacion){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FfccCarrosColocados SET IDColocacionServidor = ?, EstatusColocacion=? WHERE ClaUbicacion = ? AND ClaCarroColocado = ?");
        stmt.bindString(1, IDColocacionServidor);
        stmt.bindString(2, EstatusColocacion);
        stmt.bindString(3, ClaUbicacion);
        stmt.bindString(4, idSqliteColocacion);
        stmt.execute();
        db.close();
    }

///////////////////////////////////////////////

    //////////////////////////////////DIMENSIONES RECHAZO/////////////
    public Cursor getDimensionRechazo(String ClaUbicacion, String ClaTipoUnidad){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion, ClaTipoUnidad};
        return db.rawQuery("SELECT * FROM FFCCCatDimensionRechazo WHERE ClaUbicacion = ? " +
                " AND ClaTipoUnidad = ?", args);
    }

    public void InsertDimensionRechazo(String ClaUbicacion,String ClaTipoUnidad,String MaximoCarga,String Largo,String Ancho,String Alto,String BajaLogica){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCCatDimensionRechazo (ClaUbicacion, ClaTipoUnidad, MaximoCarga, Largo, Ancho, Alto, BajaLogica)" +
                " VALUES (?,?,?,?,?,?,?)");
        stmt.bindString(1, ClaUbicacion);
        stmt.bindString(2, ClaTipoUnidad);
        stmt.bindString(3, MaximoCarga);
        stmt.bindString(4, Largo);
        stmt.bindString(5, Ancho);
        stmt.bindString(6, Alto);
        stmt.bindString(7, BajaLogica);
        stmt.execute();
        db.close();
    }

    public void UpdateDimensionRechazo(String ClaUbicacion,String ClaTipoUnidad,String MaximoCarga,String Largo,String Ancho,String Alto,String BajaLogica){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCCatDimensionRechazo SET MaximoCarga = ?, Largo = ?, Ancho = ?, Alto = ?, BajaLogica = ? WHERE ClaUbicacion = ? AND ClaTipoUnidad = ?");
        stmt.bindString(1, MaximoCarga);
        stmt.bindString(2, Largo);
        stmt.bindString(3, Ancho);
        stmt.bindString(4, Alto);
        stmt.bindString(5, BajaLogica);
        stmt.bindString(6, ClaUbicacion);
        stmt.bindString(7, ClaTipoUnidad);
        stmt.execute();
        db.close();
    }
///////////////////////////////////////////////

    //////////////////////////////////Tipo Material/////////////
    public Cursor getAllTipoMaterial(){
        SQLiteDatabase db = this.getReadableDatabase();
        //String[] args = {ClaTipoMaterial};
        return db.rawQuery("SELECT * FROM FfccCatTipoMaterialVw", null);
    }

    public Cursor getTipoMaterial(String ClaTipoMaterial){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaTipoMaterial};
        return db.rawQuery("SELECT * FROM FfccCatTipoMaterialVw WHERE ClaTipoMaterial = ? ", args);
    }

    public void InsertTipoMaterial(String ClaTipoMaterial,String NombreTipoMaterial){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FfccCatTipoMaterialVw (ClaTipoMaterial, NombreTipoMaterial) VALUES(?,?) ");
        stmt.bindString(1, ClaTipoMaterial);
        stmt.bindString(2, NombreTipoMaterial);
        stmt.execute();
        db.close();
    }

    public void UpdateTipoMaterial(String ClaTipoMaterial,String NombreTipoMaterial){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FfccCatTipoMaterialVw SET ClaTipoMaterial=?, NombreTipoMaterial=? WHERE ClaTipoMaterial=? ");
        stmt.bindString(1, NombreTipoMaterial);
        stmt.bindString(2, ClaTipoMaterial);
        stmt.execute();
        db.close();
    }
///////////////////////////////////////////////

    //////////////////////////////////TIPO UNIDAD/////////////

    public Cursor getTipoUnidad(String ClaUbicacion, String ClaTipoUnidad){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion, ClaTipoUnidad};
        return db.rawQuery("SELECT * FROM FFCCCatTipoUnidadVw WHERE ClaUbicacion = ? " +
                " AND ClaTipoUnidad = ?", args);
    }

    public String getNameTipoUnidad(String ClaUbicacion, String ClaTipoUnidad){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c;
        String TipoUnidad="";
        String[] args = {ClaTipoUnidad};
        c = db.rawQuery("SELECT * FROM FFCCCatTipoUnidadVw WHERE  ClaTipoUnidad = ?", args);
        /*c = db.rawQuery("SELECT * FROM FFCCCatTipoUnidadVw WHERE ClaUbicacion = ? " +
                " AND ClaTipoUnidad = ?", args);*/
        if(c.moveToFirst()){
            do{
                if(c.getCount()>0){
                    TipoUnidad = c.getString(2);
                }else{
                    TipoUnidad = "No encontrado";
                }
            }while(c.moveToNext());
        }
        c.close();
        //db.close();
        return TipoUnidad;
    }

    public void InsertTipoUnidad(String ClaUbicacion,String ClaTipoUnidad,String NomTipoUnidad,String Placas,String BajaLogica){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCCatTipoUnidadVw (ClaUbicacion,ClaTipoUnidad,NomTipoUnidad,Placas,BajaLogica) " +
                " VALUES(?,?,?,?,?)");
        stmt.bindString(1, ClaUbicacion);
        stmt.bindString(2, ClaTipoUnidad);
        stmt.bindString(3, NomTipoUnidad);
        stmt.bindString(4, Placas);
        stmt.bindString(5, BajaLogica);
        stmt.execute();
        db.close();
    }

    public void UpdateTipoUnidad(String ClaUbicacion,String ClaTipoUnidad,String NomTipoUnidad,String Placas,String BajaLogica){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCCatTipoUnidadVw SET NomTipoUnidad=?, Placas=? , BajaLogica=?" +
                " WHERE ClaUbicacion=? AND ClaTipoUnidad=? ");
        stmt.bindString(1, NomTipoUnidad);
        stmt.bindString(2, Placas);
        stmt.bindString(3, BajaLogica);
        stmt.bindString(4, ClaUbicacion);
        stmt.bindString(5, ClaTipoUnidad);
        stmt.execute();
        db.close();
    }
///////////////////////////////////////////////
    public void addEncLoteo(String ClaUbicacion, String ClaViaOrigen, String DireccionMAC, String NombrePcMod, String ClaUsuarioMod, String ClaUsuario){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FfccTraLoteoUnidadEnc (ClaUbicacion, ClaViaOrigen, DireccionMAC,  NombrePcMod, ClaUsuarioMod, ClaUsuario) " +
                " VALUES(?,?,?,?,?,?) ");
        stmt.bindString(1, ClaUbicacion);
        stmt.bindString(2, ClaViaOrigen);
        stmt.bindString(3, DireccionMAC);
        stmt.bindString(4, DireccionMAC);
        stmt.bindString(5, ClaUsuarioMod);
        stmt.bindString(6, ClaUsuario);
        stmt.execute();
        db.close();
    }

    public void addDetLoteo(String IdLoteoUnidadEnc, String IdLoteoUnidadDet, String ClaViaDestino, String ClaCarro, String Placa, String EsCargado, String ClaTipoMaterial, String DireccionMAC, String ClaUsuarioMod, String NombreMaterial){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FfccTraLoteoUnidadDet (IdLoteoUnidadEnc,IdLoteoUnidadDet, ClaViaDestino, ClaCarro, Placa, EsCargado, ClaTipoMaterial, NombrePcMod, ClaUsuarioMod, NombreMaterial) " +
                " VALUES(?,?,?,?,?,?,?,?,?,?) ");
        stmt.bindString(1, IdLoteoUnidadEnc);
        stmt.bindString(2, IdLoteoUnidadDet);
        stmt.bindString(3, ClaViaDestino);
        stmt.bindString(4, ClaCarro);
        stmt.bindString(5, Placa);
        stmt.bindString(6, EsCargado);
        stmt.bindString(7, ClaTipoMaterial);
        stmt.bindString(8, DireccionMAC);
        stmt.bindString(9, ClaUsuarioMod);
        stmt.bindString(10, NombreMaterial);
        stmt.execute();
        db.close();
    }

    public Cursor checkViaLoteo(String ViaOrigen, String EstatusLoteo){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ViaOrigen, EstatusLoteo};
        return db.rawQuery("SELECT IdLoteoUnidadEnc FROM FfccTraLoteoUnidadEnc WHERE ClaViaOrigen = ? AND Estatus = ?", args);
    }

    public String MaxLoteoEnc(){
        Cursor c4;
        SQLiteDatabase db = this.getWritableDatabase();
        c4 = db.rawQuery("SELECT COALESCE(max(IdLoteoUnidadEnc),0) as IdLoteoEnc FROM FfccTraLoteoUnidadEnc", null);
        c4.moveToFirst();
        String maximo = c4.getString(c4.getColumnIndex("IdLoteoEnc"));
        c4.close();
        CloseDB();
        return maximo;
    }

    public String MaxLoteoDet(String LoteoEnc){
        Cursor c5;
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args2 = {LoteoEnc};
        c5 = db.rawQuery("SELECT COALESCE(max(IdLoteoUnidadDet),0)+1 as IdLoteoDet FROM FfccTraLoteoUnidadDet WHERE IdLoteoUnidadEnc = ?", args2);
        c5.moveToFirst();
        String maximo = c5.getString(c5.getColumnIndex("IdLoteoDet"));
        c5.close();
        CloseDB();
        return maximo;
    }

    public void AddLoteo(String ClaUbicacion, String ClaViaOrigen, String FechaLoteo, String DireccionMAC, String ClaUsuarioMod, String ClaUsuario, String ClaViaDestino, String ClaTipoMaterial, String ClaCarro, String Placa, String EsCargado, String NombreMaterial){
        SQLiteDatabase db = this.getWritableDatabase();
        //si hay un loteo en la ViaOrigen con estatus = 0 se agrega al loteo actual
        Cursor c;
       c = this.checkViaLoteo(ClaViaOrigen,"0");
       c.moveToFirst();
        if(c.getCount() > 0){
            System.out.println("IF");
            //"SELECT IdLoteoUnidadEnc FROM FfccTraLoteoUnidadEnc WHERE ClaViaOrigen = ? AND Estatus = ?"
            //Log.e("NoAddLoteo: ",""+c.getString(0));
           // Log.e("VALORESDET:: ",""+c.getString(0)+" - "+MaxLoteoDet(c.getString(0)) +" - "+ClaViaDestino+" - "+ ClaCarro+" - "+ Placa+" - "+ EsCargado+" - "+ClaTipoMaterial+" - "+ DireccionMAC+" - "+ClaUsuarioMod);
            addDetLoteo(c.getString(0),MaxLoteoDet(c.getString(0)) ,ClaViaDestino, ClaCarro, Placa, EsCargado,ClaTipoMaterial, DireccionMAC,ClaUsuarioMod, NombreMaterial);
        }else{//si no hay un loteo en la via origen con estatus 0 se genera un nuevo IdLoteoEnc
            System.out.println("ELSE");
           // Log.e("Loteo:: ",""+ClaUbicacion+"-"+ClaViaOrigen);
           // Log.e("VALORESENC:: ",""+ClaUbicacion+" - "+ClaViaOrigen+" - "+DireccionMAC+" - "+DireccionMAC+" - "+ClaUsuarioMod+" - "+ClaUsuario);
            addEncLoteo(ClaUbicacion,ClaViaOrigen,DireccionMAC,DireccionMAC,ClaUsuarioMod, ClaUsuario);
           // Log.e("VALORESDET:: ",""+MaxLoteoEnc()+" - "+MaxLoteoDet(MaxLoteoEnc()) +" - "+ClaViaDestino+" - "+ ClaCarro+" - "+ Placa+" - "+ EsCargado+" - "+ClaTipoMaterial+" - "+ DireccionMAC+" - "+ClaUsuarioMod);
            addDetLoteo(MaxLoteoEnc(),MaxLoteoDet(MaxLoteoEnc()) ,ClaViaDestino, ClaCarro, Placa, EsCargado,ClaTipoMaterial, DireccionMAC,ClaUsuarioMod, NombreMaterial);
        }
        c.close();
        db.close();
    }

    public void updateEstatusLoteo(String ClaUbicacion,String ClaViaOrigen, String EstatusLoteo, String IdLoteoUnidadEnc){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FfccTraLoteoUnidadEnc SET Estatus=? " +
                " WHERE ClaUbicacion= ? AND ClaViaOrigen=? AND IdLoteoUnidadEnc= ?");
        stmt.bindString(1, EstatusLoteo);
        stmt.bindString(2, ClaUbicacion);
        stmt.bindString(3, ClaViaOrigen);
        stmt.bindString(4, IdLoteoUnidadEnc);
        stmt.execute();
        db.close();
    }

    public void UpdateCatCarrosLoteo(String ClaVia,String EsVacio, String Placa){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FfccCatCarroVw SET EsVacio=? " +
                " ,ClaVia = ? " +
                " WHERE Placa= ?  ");
        stmt.bindString(1, EsVacio);
        stmt.bindString(2, ClaVia);
        stmt.bindString(3, Placa);
        stmt.execute();
        db.close();
    }

    public void UpdCatCarroLoteo(String ClaVia,String EsVacio, String Placa, String Estatus){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FfccCatCarroVw SET EsVacio=? " +
                " ,ClaVia = ?" +
                " ,EstatusEsLoteado = ? " +
                " WHERE Placa= ?  ");
        stmt.bindString(1, EsVacio);
        stmt.bindString(2, ClaVia);
        stmt.bindString(3, Estatus);
        stmt.bindString(4, Placa);
        stmt.execute();
        db.close();
    }

    //////////////////////////////////CFGLOTEOUnidad/////////////
    public Cursor getCfgLoteoUnidad(String ClaUbicacion,String ClaVia,String ClaTipoUnidad){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion,ClaVia, ClaTipoUnidad};
        return db.rawQuery("SELECT * FROM FFCCCfgLoteoUnidad WHERE ClaUbicacion = ? " +
                " AND ClaVia = ?" +
                " AND ClaTipoUnidad = ?", args);
    }

    public void InsertCfgLoteoUnidad(String ClaUbicacion,String ClaVia,String ClaTipoUnidad,String CargadoVacio,String EsDefault){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCCfgLoteoUnidad (ClaUbicacion,ClaVia,ClaTipoUnidad,CargadoVacio,EsDefault) " +
                " VALUES(?,?,?,?,?) ");
        stmt.bindString(1, ClaUbicacion);
        stmt.bindString(2, ClaVia);
        stmt.bindString(3, ClaTipoUnidad);
        stmt.bindString(4, CargadoVacio);
        stmt.bindString(5, EsDefault);
        stmt.execute();
        db.close();
    }

    public void UpdateCfgLoteoUnidad(String ClaUbicacion,String ClaVia,String ClaTipoUnidad,String CargadoVacio,String EsDefault){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCCfgLoteoUnidad SET CargadoVacio=?, EsDefault=? " +
                " WHERE ClaUbicacion=?" +
                "   AND ClaVia =? " +
                " AND ClaTipoUnidad =? ");
        stmt.bindString(1, CargadoVacio);
        stmt.bindString(2, EsDefault);
        stmt.bindString(3, ClaUbicacion);
        stmt.bindString(4, ClaVia);
        stmt.bindString(5, ClaTipoUnidad);
        stmt.execute();
        db.close();
    }
///////////////////////////////////////////////

    //////////////////////////////////CFGLOTEOMaterial/////////////
    public Cursor getCfgLoteoMaterial(String ClaUbicacion,String ClaVia,String ClaTipoUnidad){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion,ClaVia, ClaTipoUnidad};
        return db.rawQuery("SELECT * FROM FFCCCfgLoteoMaterial WHERE ClaUbicacion = ? " +
                " AND ClaVia = ?" +
                " AND ClaTipoUnidad = ?", args);
    }

    public void InsertCfgLoteoMaterial(String ClaUbicacion,String ClaVia,String ClaTipoUnidad,String ClaTipoInventario,String ClaFamilia,String ClaTipoMaterial){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCCfgLoteoMaterial(ClaUbicacion,ClaVia,ClaTipoUnidad,ClaTipoInventario,ClaFamilia,ClaTipoMaterial) " +
                " VALUES(?,?,?,?,?,?)");
        stmt.bindString(1, ClaUbicacion);
        stmt.bindString(2, ClaVia);
        stmt.bindString(3, ClaTipoUnidad);
        stmt.bindString(4, ClaTipoInventario);
        stmt.bindString(5, ClaFamilia);
        stmt.bindString(6, ClaTipoMaterial);
        stmt.execute();
        db.close();
    }

    public void UpdateCfgLoteoMaterial(String ClaUbicacion,String ClaVia,String ClaTipoUnidad,String ClaTipoInventario,String ClaFamilia,String ClaTipoMaterial){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCCfgLoteoMaterial  SET ClaTipoInventario=?, ClaFamilia=?, ClaTipoMaterial=? " +
                " WHERE ClaUbicacion=?" +
                "   AND ClaVia =? " +
                " AND ClaTipoUnidad =? ");
        stmt.bindString(1, ClaTipoInventario);
        stmt.bindString(2, ClaFamilia);
        stmt.bindString(3, ClaTipoMaterial);
        stmt.bindString(4, ClaUbicacion);
        stmt.bindString(5, ClaVia);
        stmt.bindString(6, ClaTipoUnidad);
        stmt.execute();
        db.close();
    }
///////////////////////////////////////////////

    public Cursor getCatConfigInspeccionDet(String ClaUbicacion, String IdConfigInspeccionDet, String IdConfigInspeccion){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion, IdConfigInspeccionDet, IdConfigInspeccion};
        return db.rawQuery("SELECT * FROM FFCCCatConfigInspeccionDet WHERE ClaUbicacion = ? " +
                " AND IdConfigInspeccionDet = ? "+
                " AND IdConfigInspeccion = ?", args);
    }

    public void InsertCatConfigInspeccionDet(String IdConfigInspeccionDet, String IdConfigInspeccion, String ClaUbicacion,String NomConfigInspeccionDet, String RechazaCarro, String PuedeReutilizar, String Orden, String BajaLogica, String ClaTipoInspeccion){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCCatConfigInspeccionDet (IdConfigInspeccionDet,IdConfigInspeccion,ClaUbicacion,NomConfigInspeccionDet,RechazaCarro,PuedeReutilizar,Orden,BajaLogica, ClaTipoInspeccion)" +
                " VALUES(?,?,?,?,?,?,?,?,?) " );
        stmt.bindString(1, IdConfigInspeccionDet);
        stmt.bindString(2, IdConfigInspeccion);
        stmt.bindString(3, ClaUbicacion);
        stmt.bindString(4, NomConfigInspeccionDet);
        stmt.bindString(5, RechazaCarro);
        stmt.bindString(6, PuedeReutilizar);
        stmt.bindString(7, Orden);
        stmt.bindString(8, BajaLogica);
        stmt.bindString(9, ClaTipoInspeccion);
        stmt.execute();
        db.close();
    }

    public void UpdateCatConfigInspeccionDet(String IdConfigInspeccionDet, String IdConfigInspeccion, String ClaUbicacion,String NomConfigInspeccionDet, String RechazaCarro, String PuedeReutilizar, String Orden, String BajaLogica, String ClaTipoInspeccion){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCCatConfigInspeccionDet SET NomConfigInspeccionDet=? , RechazaCarro=?, PuedeReutilizar=?, Orden=?, BajaLogica=?, ClaTipoInspeccion = ? " +
                " WHERE IdConfigInspeccionDet=? " +
                " AND IdConfigInspeccion =? " +
                " AND ClaUbicacion =? " );
        stmt.bindString(1, NomConfigInspeccionDet);
        stmt.bindString(2, RechazaCarro);
        stmt.bindString(3, PuedeReutilizar);
        stmt.bindString(4, Orden);
        stmt.bindString(5, BajaLogica);
        stmt.bindString(6, ClaTipoInspeccion);
        stmt.bindString(7, IdConfigInspeccionDet);
        stmt.bindString(8, IdConfigInspeccion);
        stmt.bindString(9, ClaUbicacion);
        stmt.execute();
        db.close();
    }



    public Cursor getColumNameConf(String BajaLogica, String ClaUbicacion, String ClaTipoInspeccion, String StatusActivo){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {BajaLogica,ClaUbicacion,ClaTipoInspeccion};
        return db.rawQuery("SELECT DI.Orden as NumReg,  " +
                " DI.Orden as Orden, " +
                " DI.NomConfigInspeccionDet, " +
                " DI.IdConfigInspeccion, " +
                " DI.RechazaCarro, " +
                " DI.PuedeReutilizar, " +
                " DI.IdConfigInspeccionDet " +
                " FROM FFCCCatConfigInspeccionDet DI " +
                " WHERE DI.BajaLogica = ? " +
                " AND DI.ClaUbicacion = ? " +
                " AND DI.ClaTipoInspeccion = ?",args);
    }


    public Integer checkPlacaTraInspeccionCarro(String ClaCarro, String PlacaCarro){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c;
        String[] args = {ClaCarro, PlacaCarro};
        c = db.rawQuery("SELECT * FROM FFCCTraInspeccionCarro " +
                "WHERE ClaCarro = ? AND PlacaCarro = ?",args);
            int total = c.getCount();
            c.close();
        return total;
    }

   /* public void InsertarInspeccionPlaca(String ClaUbicacion,String ClaCarro,String PlacaCarro,String IdConfigInspeccion,String ClaTipoInspeccion,String Rechaza,String Reutiliza,String FechaUltimaMod,String ClaUsuarioMod,String NombrePcMod,String FechaInspeccion,String DireccionMAC){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("INSERT INTO FFCCTraInspeccionCarro(" +
                "ClaUbicacion,ClaCarro,PlacaCarro,IdConfigInspeccion,ClaTipoInspeccion,Rechaza,Reutiliza,FechaUltimaMod,ClaUsuarioMod,NombrePcMod,FechaInspeccion,DireccionMAC) " +
                "VALUES("+ClaUbicacion+
                ","+ClaCarro+
                ","+"'"+PlacaCarro+"'"+
                ","+""+IdConfigInspeccion+""+
                ","+""+ClaTipoInspeccion+""+
                ","+""+Rechaza+""+
                ","+""+Reutiliza+""+
                ","+"'"+FechaUltimaMod+"'"+
                ","+""+ClaUsuarioMod+""+
                ","+"'"+NombrePcMod+"'"+
                ","+"'"+FechaInspeccion+"'"+
                ","+"'"+DireccionMAC+"'"+")");
    }*/

    public String getMaxTraInspecCarro(String IdPlaca, String PlacaCarro, String ClaTipoInspeccion, String Inspeccionado){
        Cursor c;
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {IdPlaca, PlacaCarro, ClaTipoInspeccion, Inspeccionado};
        c = db.rawQuery("SELECT max(IdInspeccionCarro) as IDINSCARRO FROM FFCCTraInspeccionCarro" +
                " WHERE ClaCarro = ?" +
                " AND PlacaCarro = ? " +
                " AND ClaTipoInspeccion = ?" +
                " AND Inspeccionado = ?", args);
        c.moveToFirst();
        String maximo = c.getString(c.getColumnIndex("IDINSCARRO"));
                c.close();
        CloseDB();
        return maximo;
    }

    public int existeDetalleInspeccion(String IdInspeccionCarro){
        Cursor c5;
        SQLiteDatabase db = this.getWritableDatabase();
        String[] arg = { IdInspeccionCarro};
        c5 =db.rawQuery("SELECT * FROM FFCCTraInspeccionCarroDet WHERE IdInspeccionCarro = ? ",arg);
        int total = c5.getCount();
        c5.close();
        db.close();
        return total;
    }

    public String InsertarConfiguracionesPlacaDetalle(String ClaCarro, String PlacaCarro, String IdInspeccionCarro, String Valor,String BajaLogica,String StatusActivo, String ClaTipoInspeccion){
        Cursor c2,c3;
        SQLiteDatabase db = this.getWritableDatabase();
        c3 = getSituadoXIDXPLACA(ClaCarro,PlacaCarro,ClaTipoInspeccion);
        c3.moveToFirst();
        if (c3.getCount()>0){
                            String ClaUbicacion2 = c3.getString(1);
                            String FechaUltimaMod2 = c3.getString(8);
           // Log.e("fechamod-----------> ",FechaUltimaMod2+" --");
                            String ClaUsuarioMod2 = c3.getString(9);
                            String NombrePcMod2 = c3.getString(10);
                            String ClaTipoInspeccion2 = c3.getString(5);
            System.out.println("ClaTipoInspeccion2 ******* "+ClaTipoInspeccion2);
            c2 = getColumNameConf(BajaLogica,ClaUbicacion2,ClaTipoInspeccion2,StatusActivo);
            c2.moveToFirst();
            for (int x = 0; x < c2.getCount(); x++) {
                //Log.e("InsertaDetalle-","--"+c2.getString(3));
                SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCTraInspeccionCarroDet (IdInspeccionCarro,IdConfigInspeccionDet,NomInspeccion,Valor,RechazaVacio,PuedeReutilizar) " +
                        " VALUES(?,?,?,?,?,?) " );
                stmt.bindString(1, IdInspeccionCarro);
                stmt.bindString(2, c2.getString(6));
                stmt.bindString(3, c2.getString(2));
                stmt.bindString(4, Valor);
                stmt.bindString(5, c2.getString(4));
                stmt.bindString(6, c2.getString(5));
                /*stmt.bindString(7, ClaUsuarioMod2);
                stmt.bindString(8, NombrePcMod2);*/
                stmt.execute();
                //Log.e("ADD----------->",IdInspeccionCarro+"--"+c2.getString(4));
                c2.moveToNext();
                //Log.e("ADD----------->",IdInspeccionCarro+"--"+c2.getString(2));
            }
            c2.close();
            c3.close();
            return "exito";
        }else{
            c3.close();
            return "fallo";
        }
    }

    public void updateTraInsCarroDet(String IdInspeccionCarro, String IdConfigInspeccion, String IdConfigInspeccionDet, String Valor, int RechazaCarro, int ValorRechazaCarro){
        SQLiteDatabase db = this.getWritableDatabase();
        //Log.e("ValorActualizado--",Valor+"...");
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraInspeccionCarroDet SET Valor=? " +
                " WHERE IdInspeccionCarro=?" +
                " AND IdConfigInspeccionDet =? " );
        stmt.bindString(1, Valor);
        stmt.bindString(2, IdInspeccionCarro);
        stmt.bindString(3, IdConfigInspeccionDet);
        stmt.execute();

        int value = 1;
        if(RechazaCarro==value) {
          //  Log.e("rechazaCarro--",value+"...");
            updateRechazaCarro(IdInspeccionCarro, IdConfigInspeccion, ValorRechazaCarro);
        }
    }
    public void updateRechazaCarro(String IdInspeccionCarro,String IdConfigInspeccion, int RechazaCarro){
       // Log.e("IdInsCarro","--"+IdInspeccionCarro);
        //Log.e("UPDATERECHAZACARRO","--"+IdConfigInspeccion);
        SQLiteDatabase db = this.getWritableDatabase();
//////falta acomodar este codigo para que valide cuando aun haya rechazados no se actualice el status
        Cursor c;
        String[] args = {IdInspeccionCarro,"1","1"};
        c =  db.rawQuery("SELECT * FROM FFCCTraInspeccionCarroDet " +
                " WHERE IdInspeccionCarro =  ? " +
                " AND Valor=  ? " +
                " AND RechazaVacio = ?",args);
        c.moveToFirst();

        if (c.getCount()>0){
            Log.e("entroif","--"+IdInspeccionCarro);
            SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraInspeccionCarro SET Rechaza=? " +
                    " WHERE IdInspeccionCarro =?" +
                    " AND IdConfigInspeccion =? " );
            stmt.bindString(1, "1");
            stmt.bindString(2, IdInspeccionCarro);
            stmt.bindString(3, IdConfigInspeccion);
            stmt.execute();
        }else {
            Log.e("noentroif","--"+IdInspeccionCarro);
            SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraInspeccionCarro SET Rechaza=? " +
                    " WHERE IdInspeccionCarro =?" +
                    " AND IdConfigInspeccion =? " );
            stmt.bindString(1, "0");
            stmt.bindString(2, IdInspeccionCarro);
            stmt.bindString(3, IdConfigInspeccion);
            stmt.execute();
        }
    }

  /*  public Integer checkValueTraInsCarroDet(String IdInspeccionCarro, String IdConfigInspeccionDet){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c;
        String[] args = {IdInspeccionCarro,IdConfigInspeccionDet};
        c =  db.rawQuery("SELECT * FROM FFCCTraInspeccionCarroDet " +
                " WHERE IdInspeccionCarro =  ? " +
                " AND IdConfigInspeccionDet =  ? ",args);
        c.moveToFirst();
        Log.e("","ID.....->"+IdInspeccionCarro+" ----IDCONF....->"+IdConfigInspeccionDet+" VALOR-->"+String.valueOf(c.getInt(4)));
        return c.getInt(4);
    }*/

    /*public Cursor getSituado(int ClaUbicacionDestino, int TieneEntrada, int Inspeccionado, String Placa){
        SQLiteDatabase db = this.getWritableDatabase();
        //String[] args = {ClaUbicacionDestino,TieneEntrada};
        return db.rawQuery("SELECT * FROM FFCCBitSituado " +
                " WHERE ClaUbicacionDestino =  " +ClaUbicacionDestino+
                " AND TieneEntrada =  "+ TieneEntrada+
                " AND Inspeccionado = "+ Inspeccionado+
                " AND Placa like '%"+Placa+"%'",null);
    }*/

    public Cursor getSituado(String Inspeccionado, String Placa, String ClaTipoInspeccion) throws Exception {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {Inspeccionado,Placa, ClaTipoInspeccion};
        return db.rawQuery("SELECT * FROM FFCCTraInspeccionCarro " +
                " WHERE Inspeccionado = ?"+
                " AND PlacaCarro like '%'||?||'%'" +
                " AND ClaTipoInspeccion = ? ",args);
    }

    public Cursor getDataConfigInspeccionCARRO(String ClaUbicacion, String ClaCarro, String PlacaCarro, String IdConfigInspeccion, String IdInspeccionCarro, String ClaTipoInspeccion){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c;
        String[] args = {ClaUbicacion, ClaCarro, PlacaCarro, IdConfigInspeccion,IdInspeccionCarro, ClaTipoInspeccion};
        c =  db.rawQuery("SELECT * FROM FFCCTraInspeccionCarro " +
                " WHERE ClaUbicacion = ?" +
                " AND ClaCarro = ? "+
                " AND PlacaCarro =  ?"+
                " AND IdConfigInspeccion =  ? "+
                " AND IdInspeccionCarro = ?" +
                " AND ClaTipoInspeccion = ?",args);
        c.moveToFirst();
        String[] args2 = {c.getString(0)};
        //Log.e("getDataConfigIns","--IdConfInsCarr--"+c.getString(0)+"--IdConfIns--"+IdConfigInspeccion);

        return db.rawQuery("SELECT * FROM FFCCTraInspeccionCarroDet " +
                " WHERE IdInspeccionCarro =  ? " ,args2);
    }


   /* public boolean addImgPlaca(String id ,String placa, String dir) {
        SQLiteDatabase db = this.getWritableDatabase();
        try{
            String qry = "UPDATE FFCCTraInspeccionCarro SET DirImg='"+dir+"'"+
                    " WHERE ClaCarro = " + id+
                    " AND PlacaCarro = '" + placa+"'";
            db.execSQL(qry);
            return true;
        } catch(SQLException e){
            e.printStackTrace();
            return false;
        }
    }*/

    public Cursor getImagenesSituado(String ClaCarro ,String PlacaCarro, String IdInspeccionCarro){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {ClaCarro,PlacaCarro,IdInspeccionCarro};
        return db.rawQuery("SELECT * FROM FFCCTraInspeccionCarro" +
                " WHERE ClaCarro= ?" +
                " AND PlacaCarro = ?" +
                " AND IdInspeccionCarro = ?",args);
    }

    public Cursor getImagenesInspeccion(String IdInspeccionCarro, String idInspeccionCfgDet){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {IdInspeccionCarro, idInspeccionCfgDet};
        return db.rawQuery("SELECT * FROM FFCCImageCarro" +
                " WHERE idInspeccion = ?" +
                " AND idCfgInspeccion = ?" ,args);
    }

    public Cursor getImagenesInspeccion2(String IdInspeccionCarro ){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {IdInspeccionCarro};
        return db.rawQuery("SELECT * FROM FFCCImageCarro" +
                " WHERE idInspeccion = ?" ,args);
    }

  /*  public Cursor getImagenesInspeccionxImg(String IdInspeccionCarro,int  IdImg){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {IdInspeccionCarro};
        return db.rawQuery("SELECT * FROM FFCCImageCarro" +
                " WHERE idInspeccion = ?" ,args);
    }*/

    public boolean DeleteImgInspeccion(String idInspeccion, String idImg){
        SQLiteDatabase db = this.getWritableDatabase();
        try{
            SQLiteStatement stmt = db.compileStatement("DELETE FROM FFCCImageCarro  " +
                    "  WHERE idInspeccion =?" +
                    " AND idImg = ? " );
            stmt.bindString(1, idInspeccion);
            stmt.bindString(2, idImg);
            stmt.execute();
            return true;
        } catch(SQLException e){
            e.printStackTrace();
            return false;
        }
    }


    public boolean insertImg(String idInspeccion , String dir, String CfgPhoto) {
        SQLiteDatabase db = this.getWritableDatabase();
        int id=1;
        Cursor c;
        String[] args = {idInspeccion};
        Log.e("ins: ", ""+idInspeccion);
        c = db.rawQuery("SELECT coalesce(max(abs(idImg)),0)+1  FROM FFCCImageCarro WHERE idInspeccion = ?",args);
        c.moveToFirst();
        id = c.getInt(0);
        Log.e("img: ", ""+id);
        c.close();
        ContentValues cv = new ContentValues();
        cv.put("idImg",id);
        cv.put("idInspeccion",idInspeccion);
        cv.put("DirImg",dir);
        cv.put("idCfgInspeccion",CfgPhoto);
        try{       //SQLite.insertOrThrow().
                db.insertOrThrow("FFCCImageCarro",null,cv);
                return true;
            } catch(SQLException e){
            e.printStackTrace();
            return false;
        }
    }

    public Cursor getImagenes(){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM FFCCImageCarro",null);
    }

    /*public Cursor getSituadoXID(String IdBitSituado){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {IdBitSituado};
        return db.rawQuery("SELECT * FROM FFCCBitSituado  WHERE IdBitSituado = ?", args);
    }*/

    public Cursor getSituadoXID(String PlacaCarro, String ClaUbicacion, String ClaTipoInspeccion){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {PlacaCarro, ClaUbicacion, ClaTipoInspeccion};
        return db.rawQuery("SELECT * FROM FFCCTraInspeccionCarro  WHERE PlacaCarro = ?" +
                " AND ClaUbicacion = ?" +
                " AND ClaTipoInspeccion = ?", args);
    }

    public Cursor getSituadoXIDXPLACA(String ClaCarro, String PlacaCarro, String ClaTipoInspeccion){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {ClaCarro,PlacaCarro,ClaTipoInspeccion};
        return db.rawQuery("SELECT * FROM FFCCTraInspeccionCarro  WHERE ClaCarro = ?" +
                " AND PlacaCarro = ? " +
                " AND  ClaTipoInspeccion= ?", args);
    }

   /* public String getImagePath(String id, String placa){
        String imagePath = "";
        SQLiteDatabase db = this.getWritableDatabase();
        String select_query = "SELECT DirImg FROM FFCCTraInspeccionCarro" +
                " WHERE ClaCarro= " + id +
                " AND PlacaCarro = '" + placa + "'";
        Cursor cursor = db.rawQuery(select_query,null);
        int iCoolerPicPath = cursor.getColumnIndex("DirImg");
        for (cursor.moveToLast(); !  cursor.isBeforeFirst(); cursor.moveToPrevious()){
            imagePath=cursor.getString(iCoolerPicPath);
        }
        return imagePath;
    }*/


    public void updateBitSituado(String IdBitSituado, String ClaCarro, String Placa,String ClaUbicacionDestino , String AlturaInterna, String AnchoInterno, String LongitudInterna, String PesoMaximo, String ClaTipoInspeccion){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraInspeccionCarro SET PlacaCarro=? " +
                " , ClaUbicacion=? " +
                " , AlturaInterna=? " +
                " , AnchoInterno =? " +
                " , LongitudInterna =? " +
                " , PesoMaximo =? " +
                " WHERE ClaCarro=? " +
                " AND PlacaCarro =? "+
                " AND ClaTipoInspeccion =? " );
        stmt.bindString(1, Placa);
        stmt.bindString(2, ClaUbicacionDestino);
        stmt.bindString(3, AlturaInterna);
        stmt.bindString(4, AnchoInterno);
        stmt.bindString(5, LongitudInterna);
        stmt.bindString(6, PesoMaximo);
        stmt.bindString(7, ClaCarro);
        stmt.bindString(8, Placa);
        stmt.bindString(9, ClaTipoInspeccion);
        stmt.execute();
        db.close();
    }

    public String getIdConfigInspeccion2(String ClaUbicacion){
            Cursor c;
            SQLiteDatabase db = this.getWritableDatabase();
            String[] args = {ClaUbicacion};
            c = db.rawQuery("SELECT max(IdConfigInspeccion) as IDMAXIMO FROM FFCCCatConfigInspeccionDet WHERE ClaUbicacion = ?", args);
            c.moveToFirst();
            String maximo = c.getString(c.getColumnIndex("IDMAXIMO"));
            c.close();
            CloseDB();
            return maximo;
    }

    public String getIdConfigInspeccion(String ClaUbicacion, String ClaTipoInspeccion){
        Cursor c;
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {ClaUbicacion,ClaTipoInspeccion};
        c = db.rawQuery("SELECT max(IdConfigInspeccion) as IDMAXIMO FROM FFCCCatConfigInspeccionDet WHERE ClaUbicacion = ? AND ClaTipoInspeccion =?", args);
        c.moveToFirst();
        String maximo = c.getString(c.getColumnIndex("IDMAXIMO"));
        c.close();
        CloseDB();
        return maximo;
    }


    public Integer validaPlacaBitSituado(String PlacaNueva){
        Cursor c;
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {PlacaNueva};//
        c = db.rawQuery("SELECT count(*) as TOTAL FROM FFCCTraInspeccionCarro WHERE PlacaCarro = ?", args);
        c.moveToFirst();
        int maximo = c.getInt(c.getColumnIndex("TOTAL"));
        c.close();
        CloseDB();
        return maximo;
    }

    public Integer validaPlacaBitSituadoTipoInspeccion(String PlacaNueva, String ClaTipoInspeccion, String Inspeccionado){
        Cursor c;
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {PlacaNueva,ClaTipoInspeccion,Inspeccionado};//
        c = db.rawQuery("SELECT count(*) as TOTAL FROM FFCCTraInspeccionCarro WHERE PlacaCarro = ? AND ClaTipoInspeccion = ? AND Inspeccionado >= ?", args);
        c.moveToFirst();
        int maximo = c.getInt(c.getColumnIndex("TOTAL"));
        c.close();
        CloseDB();
        return maximo;
    }

    public String getDataPlacaCarro(String PlacaNueva){
        Cursor c;
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {PlacaNueva};//
        c = db.rawQuery("SELECT IFNULL(v.NomVia,'Via Indefinida') FROM FfccCatCarroVw c" +
                " JOIN FFCCCatVia v " +
                " ON c.ClaVia = v.ClaVia" +
                " AND c.ClaUbicacion = v.ClaUbicacion" +
                            " WHERE c.Placa = ?", args);
        String resultado = "No encontro nada";
        if(c.getCount()>0){
            c.moveToFirst();
            resultado = "Esta Loteado en "+c.getString(0);
        }
        c.close();
        CloseDB();
        return " "+resultado;
    }


    public Integer getFoundCarro(String PlacaNueva){
        Cursor c;
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {PlacaNueva};//
        c = db.rawQuery("SELECT count(*) as TOTAL FROM FfccCatCarroVw WHERE Placa = ?", args);
        c.moveToFirst();
        int maximo = c.getInt(c.getColumnIndex("TOTAL"));
        c.close();
        CloseDB();
        return maximo;
    }



    public String insertBitSituado(String IdBitSituado, String ClaCarro, String Placa,String ClaUbicacionDestino ,String IdConfigInspeccion,String ClaTipoInspeccion,String Rechaza, String Reutiliza, String AlturaInterna, String AnchoInterno, String LongitudInterna, String PesoMaximo, String MAC, String Inspeccionado){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCTraInspeccionCarro (IdBitSituado,ClaCarro,PlacaCarro,ClaUbicacion,IdConfigInspeccion,ClaTipoInspeccion,Rechaza,Reutiliza, AlturaInterna,AnchoInterno,LongitudInterna,PesoMaximo,DireccionMAC, Inspeccionado) " +
                " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) "  );
        stmt.bindString(1, IdBitSituado);
        stmt.bindString(2, ClaCarro);
        stmt.bindString(3, Placa);
        stmt.bindString(4, ClaUbicacionDestino);
        stmt.bindString(5, IdConfigInspeccion);
        stmt.bindString(6, ClaTipoInspeccion);
        stmt.bindString(7, Rechaza);
        stmt.bindString(8, Reutiliza);
        stmt.bindString(9, AlturaInterna);
        stmt.bindString(10, AnchoInterno);
        stmt.bindString(11, LongitudInterna);
        stmt.bindString(12, PesoMaximo);
        stmt.bindString(13, MAC);
        stmt.bindString(14, Inspeccionado);

        try
        {
            stmt.execute();
            db.close();
            return "Se ha agregado correctamente la placa "+Placa;

        }
        catch (SQLiteException myException)
        {

            db.close();
            return "No se pudo agregar la placa " + Placa + " ERROR: "+myException.toString();
        }

    }

    public void updateEstatusSituado(String IdInspeccionCarro, String Placa, String Valor, String ClaTipoInspeccion){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraInspeccionCarro SET Inspeccionado=? " +
                " WHERE PlacaCarro =?" +
                "  AND IdInspeccionCarro=? " +
                " AND  ClaTipoInspeccion = ?"  );
        stmt.bindString(1, Valor);
        stmt.bindString(2, Placa);
        stmt.bindString(3, IdInspeccionCarro);
        stmt.bindString(4, ClaTipoInspeccion);
        stmt.execute();
        db.close();
    }

    public void DeleteSituado(String IdInspeccionCarro, String ClaTipoInspeccion){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt1 = db.compileStatement("DELETE FROM FFCCImageCarro " +
                " WHERE idInspeccion=? "  );

        stmt1.bindString(1, IdInspeccionCarro);
        SQLiteStatement stmt = db.compileStatement("DELETE FROM FFCCTraInspeccionCarroDet " +
                " WHERE IdInspeccionCarro=? "  );
        stmt.bindString(1, IdInspeccionCarro);

        SQLiteStatement stmt2 = db.compileStatement("DELETE FROM FFCCTraInspeccionCarro " +
                " WHERE IdInspeccionCarro=? " +
                " AND ClaTipoInspeccion = ?"  );
        stmt2.bindString(1, IdInspeccionCarro);
        stmt2.bindString(2, ClaTipoInspeccion);

        stmt1.execute();
        stmt.execute();
        stmt2.execute();
        db.close();
    }

    public void DeleteSituadoDetyFoto(String IdInspeccionCarro, String Estatus){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt1 = db.compileStatement("DELETE FROM FFCCImageCarro " +
                " WHERE idInspeccion=? "  );
        stmt1.bindString(1, IdInspeccionCarro);

        SQLiteStatement stmt = db.compileStatement("DELETE FROM FFCCTraInspeccionCarroDet " +
                " WHERE IdInspeccionCarro=? "  );
        stmt.bindString(1, IdInspeccionCarro);

        SQLiteStatement stmt2 = db.compileStatement("UPDATE FFCCTraInspeccionCarro SET Inspeccionado= ?" +
                " WHERE IdInspeccionCarro=? "  );
        stmt2.bindString(1, Estatus);
        stmt2.bindString(2, IdInspeccionCarro);

        stmt1.execute();
        stmt.execute();
        stmt2.execute();
        db.close();
    }

    public void updateIDColocacionSQLServer(String IdColocacionSQLITE,String IdColocacionSQLServer){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FfccCarrosColocados SET IDColocacionServidor=? " +
                " WHERE ClaCarroColocado=?"  );
        stmt.bindString(1, IdColocacionSQLServer);
        stmt.bindString(2, IdColocacionSQLITE);
        stmt.execute();

        SQLiteStatement stmt2 = db.compileStatement("UPDATE FFCCTraRetiroClienteInterno SET IDColocacionServidor=? " +
                " WHERE IdTraCarroColocado=?"  );
        stmt2.bindString(1, IdColocacionSQLServer);
        stmt2.bindString(2, IdColocacionSQLITE);
        stmt2.execute();
        db.close();
    }

    public void updateEstatusColocacion(String IdColocacionSQLITE,String Estatus){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FfccCarrosColocados SET EstatusColocacion=? " +
                " WHERE ClaCarroColocado=? "  );
        // AND EXISTS(SELECT 1 FROM FfccCarrosColocados WHERE ClaCarroColocado = ? AND EstatusColocacion=3 )
       stmt.bindString(1, Estatus);
        stmt.bindString(2, IdColocacionSQLITE);
        //stmt.bindString(3, IdColocacionSQLITE);
        stmt.execute();
    }

    public void updateFechaInspeccion(String IdInspeccionCarro,String ClaCarro, String Placa, String ClaUsuario, String FechaInspe){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraInspeccionCarro SET FechaInspeccion=?, ClaUsuarioMod=? " +
                " WHERE ClaCarro=?" +
                " AND PlacaCarro =?" +
                "  AND IdInspeccionCarro=? "  );
        stmt.bindString(1, FechaInspe);
        stmt.bindString(2, ClaUsuario);
        stmt.bindString(3, ClaCarro);
        stmt.bindString(4, Placa);
        stmt.bindString(5, IdInspeccionCarro);
        stmt.execute();
        db.close();
    }

    public void EliminaBitSituado(String Placa){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {Placa};
        Cursor c = db.rawQuery("SELECT * FROM FFCCTraInspeccionCarro WHERE PlacaCarro=?",args);
        if(c.getCount()>0) {
            c.moveToFirst();
            SQLiteStatement stmt = db.compileStatement("DELETE FROM FFCCTraInspeccionCarro " +
                    " WHERE PlacaCarro=?");
            stmt.bindString(1, c.getString(0));

            SQLiteStatement stmt2 = db.compileStatement("DELETE FROM FFCCTraInspeccionCarroDet " +
                    " WHERE IdInspeccionCarro=?");
            stmt2.bindString(1, c.getString(0));

            stmt2.execute();
            stmt.execute();
        }
        c.close();
        db.close();
    }

    public void EliminaCatCarro(String Placa){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("DELETE FROM FfccCatCarroVw " +
                " WHERE Placa=?"  );
        stmt.bindString(1, Placa);
        stmt.execute();
        db.close();
    }

    public Cursor getVia(String ClaUbicacion){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion};
        return db.rawQuery("SELECT * FROM FFCCCatVia WHERE ClaUbicacion = ?", args);
    }

    public Cursor getViaConCI(String ClaUbicacion){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion};
        return db.rawQuery("SELECT v.ClaUbicacion,v.ClaVia,v.NomVia " +
                " FROM FFCCCatVia v " +
                " JOIN FFCCClienteInterno c" +
                " ON v.ClaUbicacion = c.ClaUbicacion" +
                " AND v.ClaVia = c.ClaVia " +
                " WHERE v.ClaUbicacion = ?" +
                " GROUP BY  v.ClaUbicacion, v.ClaVia, v.NomVia ", args);
    }

    public Cursor getViaExcluye(String ClaUbicacion, String ViaNoMostrar){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion, ViaNoMostrar};
        return db.rawQuery("SELECT * FROM FFCCCatVia WHERE ClaUbicacion = ? AND ClaVia NOT IN(?)", args);
    }

    public Cursor getLoteoUnidadEnc(String ClaViaOrigen, String ClaUbicacion, String Estatus) throws Exception {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {ClaViaOrigen,ClaUbicacion, Estatus};
        return db.rawQuery("SELECT * FROM FfccTraLoteoUnidadEnc " +
                " WHERE ClaViaOrigen = ?"+
                " AND ClaUbicacion = ?" +
                " AND Estatus = ?",args);
    }

    public Cursor getLoteoUnidadEncDet(String ClaUbicacion, String Estatus) throws Exception {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {ClaUbicacion, Estatus};
        return db.rawQuery("SELECT e.IdLoteoUnidadEnc," +
                "                       e.ClaUbicacion," +
                "                       e.ClaViaOrigen," +
                "                       d.IdLoteoUnidadDet," +
                "                       d.ClaCarro, " +
                "                       d.Placa," +
                "                       d.EsCargado, " +
                "                       d.ClaTipoMaterial, " +
                "                       d.ClaViaDestino" +
                " FROM FfccTraLoteoUnidadEnc e " +
                " JOIN FfccTraLoteoUnidadDet d " +
                " ON e.IdLoteoUnidadEnc = d.IdLoteoUnidadEnc" +
                " WHERE e.ClaUbicacion = ?" +
                " AND e.Estatus = ?",args);
    }

    public Cursor getLoteoUnidadEncAPI( String ClaUbicacion, String Estatus) {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {ClaUbicacion, Estatus};
        return db.rawQuery("SELECT * FROM FfccTraLoteoUnidadEnc " +
                " WHERE ClaUbicacion = ?" +
                " AND Estatus = ?",args);
    }

    public Cursor getLoteoUnidadDet(String IdLoteoUnidadEnc){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {IdLoteoUnidadEnc};
        return db.rawQuery("SELECT D.IdLoteoUnidadEnc, D.IdLoteoUnidadDet, D.ClaCarro, D.Placa, D.EsCargado, D.ClaTipoMaterial, D.ClaViaDestino, " +
                "V.NomVia, D.NombreMaterial FROM FFCCTraLoteoUnidadDet D " +
                "LEFT JOIN FFCCCatVia V " +
                "ON V.ClaVia = D.ClaViaDestino " +
                "WHERE D.IdLoteoUnidadEnc = ?" ,args);
    }

    public Cursor getLoteoUnidadDetAPI(String IdLoteoUnidadEnc, String EstatusLoteoDet){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {IdLoteoUnidadEnc, EstatusLoteoDet};
        return db.rawQuery("SELECT * FROM FFCCTraLoteoUnidadDet D " +
                "WHERE IdLoteoUnidadEnc = ?" +
                " AND EstatusDet = ?" ,args);
    }

    public void updateEstatusLoteoEnc(String IdLoteoUnidadEnc, String EstatusLoteo, String ClaUbicacion){
        SQLiteDatabase db4 = this.getWritableDatabase();
        SQLiteStatement stmt = db4.compileStatement("UPDATE FfccTraLoteoUnidadEnc SET Estatus=? " +
                " WHERE IdLoteoUnidadEnc =?" +
                " AND ClaUbicacion =?"  );
        stmt.bindString(1, EstatusLoteo);
        stmt.bindString(2, IdLoteoUnidadEnc);
        stmt.bindString(3, ClaUbicacion);
        stmt.execute();
      /* String qry = "UPDATE FfccTraLoteoUnidadEnc SET Estatus="+EstatusLoteo+"  WHERE IdLoteoUnidadEnc ="+IdLoteoUnidadEnc+"  AND ClaUbicacion ="+ClaUbicacion;
        db4.execSQL(qry);*/
        db4.close();
    }
    public void updateEstatusLoteoDet(String IdLoteoUnidadEnc, String IdLoteoUnidadDet, String EstatusLoteo){
        SQLiteDatabase db3 = this.getWritableDatabase();
        SQLiteStatement stmt = db3.compileStatement("UPDATE FfccTraLoteoUnidadDet SET EstatusDet=? " +
                " WHERE IdLoteoUnidadEnc =?" +
                " AND IdLoteoUnidadDet =?"  );
        stmt.bindString(1, EstatusLoteo);
        stmt.bindString(2, IdLoteoUnidadEnc);
        stmt.bindString(3, IdLoteoUnidadDet);
        stmt.execute();
        db3.close();
    }

    public boolean DeleteLoteoDet(String IdLoteoEnc, String IdLoteoDet){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {IdLoteoEnc, IdLoteoDet};
        return db.delete("FfccTraLoteoUnidadDet", "IdLoteoUnidadEnc = ? AND IdLoteoUnidadDet = ?", args) > 0;
    }


    public void UpdateViaDestino(String LoteoEnc, String LoteoDet, String ViaDestino){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FfccTraLoteoUnidadDet SET ClaViaDestino=? " +
                " WHERE IdLoteoUnidadEnc=?" +
                " AND IdLoteoUnidadDet =?"  );
        stmt.bindString(1, ViaDestino);
        stmt.bindString(2, LoteoEnc);
        stmt.bindString(3, LoteoDet);
        stmt.execute();
        db.close();
    }

    public Cursor getCatCarroVw(String Placa,String ClaVia, String FormaBusqueda) throws Exception {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {Placa,ClaVia};
        if (FormaBusqueda.equals("1")){
            System.out.println("busca por via OR PLACA");
            return db.rawQuery("SELECT * FROM FfccCatCarroVw " +
                    " WHERE  Placa like '%'||?||'%'"
                    + " AND (ClaVia = ? OR ClaVia IS NULL)" +
                    " AND EstatusEsLoteado <= 1 OR EstatusEsLoteado IS NULL",args);//=0
        }else{  //busca por via
            System.out.println("busca por via");
            return db.rawQuery("SELECT * FROM FfccCatCarroVw " +
                    " WHERE Placa like '%'||?||'%'"
                    + " AND (ClaVia = ?  )" +
                    " AND EstatusEsLoteado <= 1 OR EstatusEsLoteado IS NULL",args);//=0
        }
    }

    public void ActualizaEstatusLoteoFFCCCarro(String IdControlUnidad, String Placa, String EstatusEsLoteado){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FfccCatCarroVw SET EstatusEsLoteado = ?" +
                " WHERE IdControlUnidad = ? AND Placa = ?");//Placa
        stmt.bindString(1, EstatusEsLoteado);
        stmt.bindString(2, IdControlUnidad);
        stmt.bindString(3, Placa);
        stmt.execute();
        db.close();
    }

    public void ActualizaEstatusLoteoFFCCCarro2(String Placa, String EstatusEsLoteado){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FfccCatCarroVw SET EstatusEsLoteado = ?" +
                " WHERE Placa = ?");
        stmt.bindString(1, EstatusEsLoteado);
        stmt.bindString(2, Placa);
        stmt.execute();
        db.close();
    }

    public void InsertarFfccCatCarroVw(String ClaCarro,String Placa,String ClaTipoCarro,String PesoMaximo,String LongitudInterna,String AnchoInterno,
                                       String AlturaInterna,String FechaUltimaMod,String NombrePcMod,String ClaUsuarioMod, String IdControlUnidad, String EsVacio, String ClaVia, String FechaEntrada, String FechaSalida, String ClaUbicacion){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args={Placa};
        Cursor count;
        count = db.rawQuery("select * from FfccCatCarroVw WHERE Placa = ?",args);
        if(count.getCount()==0) {
            SQLiteStatement stmt = db.compileStatement("INSERT INTO FfccCatCarroVw(ClaCarro, Placa,ClaTipoCarro,PesoMaximo,LongitudInterna,AnchoInterno,AlturaInterna, FechaUltimaMod, NombrePcMod, ClaUsuarioMod, IdControlUnidad, EsVacio, ClaVia, FechaEntrada, FechaSalida,ClaUbicacion) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            stmt.bindString(1, ClaCarro);
            stmt.bindString(2, Placa);
            stmt.bindString(3, ClaTipoCarro);
            stmt.bindString(4, PesoMaximo);
            stmt.bindString(5, LongitudInterna);
            stmt.bindString(6, AnchoInterno);
            stmt.bindString(7, AlturaInterna);
            stmt.bindString(8, FechaUltimaMod);
            stmt.bindString(9, NombrePcMod);
            stmt.bindString(10, ClaUsuarioMod);
            stmt.bindString(11, IdControlUnidad);
            stmt.bindString(12, EsVacio);
            stmt.bindString(13, ClaVia);
            stmt.bindString(14, FechaEntrada);
            stmt.bindString(15, FechaSalida);
            stmt.bindString(16, ClaUbicacion);
            stmt.execute();
        }
        count.close();
        db.close();
    }

    //public FFCCTraSolicitudServicio
    public Cursor getViaColocarServicio(String ClaUbicacion, String Via, String FechaCaptura,String ClienteInterno){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion, Via, FechaCaptura,"1","0",ClienteInterno};
        return db.rawQuery("SELECT V.IdTraSolicitudServicio, " +
                "   V.ClaUbicacion, " +
                "   V.ClaConfServicios, " +
                "   V.ClaConfVentana, " +
                "   V.ClaVia, " +
                "   V.Duracion, " +
                "   V.Unidad, " +
                "   V.Hora, " +
                "   V.HoraRegistro, " +
                "   V.ClaClienteInterno, " +
                "   V.EsCarga, " +
                "   C.NomVia, " +
                "   I.NomClienteInterno " +
                " FROM FFCCTraSolicitudServicio V " +
                " LEFT JOIN FFCCCatVia C " +
                " ON V.ClaVia = C.ClaVia " +
                " AND V.ClaUbicacion = C.ClaUbicacion " +
                " LEFT JOIN FFCCClienteInterno I " +
                " ON V.ClaClienteInterno = I.ClaClienteInterno " +
                " AND V.ClaUbicacion = I.ClaUbicacion " +
                " WHERE V.ClaUbicacion = ? " +
                "   AND V.ClaVia = ? " +
                "   AND V.FechaCaptura = ? " +
                "   AND V.BajaLogica != ? " +
                "   AND V.EstatusDiseno = ? " +
                "   AND V.ClaClienteInterno = ? ", args);///estatus diseño en 0 porque no ha sido confirmado en la panatalla de diseño
    }//

    public Cursor getEquipoRequerido( String IdTraSolicitudServicio){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = { IdTraSolicitudServicio};
        return db.rawQuery("SELECT D.IdTraSolicitudServicioDet,D.ClaTipoUnidad,D.Cantidad,D.TapasRequeridas,C.NomTipoUnidad, D.NomMaterial " +
                " FROM FFCCTraSolicitudServicioDet D" +
                " JOIN FFCCCatTipoUnidadVw C " +
                " ON D.ClaTipoUnidad = C.ClaTipoUnidad " +
                " WHERE D.IdTraSolicitudServicio = ?" , args);

        //" AND D.ClaUbicacion = C.ClaUbicacion " +
    }


    public Cursor getSolicitudes(String ClaUbicacion, String FechaCaptura, String BajaLogica){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaUbicacion,FechaCaptura,BajaLogica};
        return db.rawQuery("SELECT V.IdTraSolicitudServicio,V.ClaUbicacion,V.ClaConfVentana,V.ClaVia,I.ClaClienteInterno, " +
                " V.Hora ,V.HoraRegistro,  I.NomClienteInterno, IFNULL(cc.ClaCarroColocado,0), IFNULL(re.IdRetiroClienteInterno,0) " +
                " , CASE   WHEN  IFNULL(V.IdRetiro,0) > 0 AND IFNULL(V.IdColocacion,0) > 0 THEN 'Retiro' " +
                "          WHEN IFNULL(V.IdColocacion,0) > 0 THEN 'Colocado'" +
                "          ELSE 'Solicitud'  END" +
                ",V.IdColocacion" +
                ",V.IdRetiro " +
                " FROM FFCCTraSolicitudServicio V" +
                " LEFT JOIN FFCCCatVia C " +
                " ON V.ClaVia = C.ClaVia" +
                " AND V.ClaUbicacion = C.ClaUbicacion " +
                " LEFT JOIN FFCCClienteInterno I" +
                " ON V.ClaClienteInterno = I.ClaClienteInterno" +
                " AND V.ClaUbicacion = I.ClaUbicacion" +
                " LEFT JOIN FfccCarrosColocados cc" +
                " ON cc.ClaUbicacion = V.ClaUbicacion" +
                " AND cc.IdTraSolicitudServicio = V.IdTraSolicitudServicio" +
                " AND cc.ClaConfServicios = V.ClaConfServicios" +
                " AND cc.ClaConfVentana = V.ClaConfVentana " +
                " LEFT JOIN FFCCTraRetiroClienteInterno re" +
                " ON re.ClaUbicacion = cc.ClaUbicacion" +
                " AND re.IdTraCarroColocado = cc.ClaCarroColocado " +
                " WHERE V.ClaUbicacion = ? " +
                " AND V.FechaCaptura = ? " +
                " AND V.BajaLogica != ?" , args);///estatus diseño en 0 porque no ha sido confirmado en la panatalla de diseño
    }

    public Cursor getFfccTraControlUnidad(String Placa, String Estatus) throws Exception {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {Placa};//Estatus
        return db.rawQuery("SELECT c.ClaCarro,c.Placa,c.IdControlUnidad, c.EsVacio, c.ClaVia, Cast (( JulianDay(Date('now'))- JulianDay(strftime('%Y-%m-%d', c.FechaEntrada)) ) As Integer)  ,( Date('now')- strftime('%Y-%m-%d', c.FechaEntrada) ) , v.NomVia, c.ClaUbicacion, t.NomTipoUnidad  " +
                " FROM FfccCatCarroVw c " +
                " LEFT JOIN FFCCCatVia v "+
                " ON c.ClaVia = v.ClaVia" +
                " AND c.ClaUbicacion = v.ClaUbicacion "+
                " LEFT JOIN FFCCCatTipoUnidadVw t "+
                " ON t.ClaTipoUnidad = c.ClaTipoUnidad"+
                " WHERE c.Placa like '%'||?||'%'"+

                " ORDER BY c.FechaEntrada, c.ClaVia, c.Placa  " ,args);
        //quite la validacion del estatus podran agregar la misma placa en varios diseños colocaciones retiros a la vez
        // " AND c.EstatusColocado != ?" +
    }

    public void ActualizaEstatusTraControlUnidad(String Estatus, String IdControlUnidad, String ClaUbicacion, String Placa){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FfccCatCarroVw SET EstatusColocado = ? " +
                " WHERE ClaUbicacion = ? AND Placa = ?");
        stmt.bindString(1, Estatus);
        stmt.bindString(2, ClaUbicacion);
        stmt.bindString(3, Placa);
        stmt.execute();
        db.close();
    }
    public void ActualizaEstatusTraControlUnidad2(String Estatus, String IdControlUnidad, String ClaUbicacion, String ClaCarro){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FfccCatCarroVw SET EstatusColocado = ? " +
                " WHERE IdControlUnidad = ? AND ClaUbicacion = ? AND ClaCarro = ?");
        stmt.bindString(1, Estatus);
        stmt.bindString(2, IdControlUnidad);
        stmt.bindString(3, ClaUbicacion);
        stmt.bindString(4, ClaCarro);
        stmt.execute();
        db.close();
    }



    //funcion para validar si ya se registro Un ID para IdTraSolicitudServicio, ClaUbicacion, ClaConfServicios, ClaConfVentana
    public Cursor getId_FfccCarrosColocados(String IdTraSolicitudServicio, String ClaUbicacion, String ClaConfServicios, String ClaConfVentana) throws Exception {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {IdTraSolicitudServicio, ClaUbicacion, ClaConfServicios, ClaConfVentana};
        System.out.println(" ------ IdTraSolicitudServicio-"+IdTraSolicitudServicio+"  ClaUbicacion-"+ClaUbicacion+" ClaConfServicios-"+ClaConfServicios+ " -ClaConfVentana-"+ClaConfVentana);
        return db.rawQuery("SELECT ClaCarroColocado FROM FfccCarrosColocados " +
                " WHERE IdTraSolicitudServicio = ? " +
                " AND ClaUbicacion = ?" +
                " AND ClaConfServicios = ?" +
                " AND ClaConfVentana = ?" ,args);
    }

    public Cursor ExistePlacaEnColocacion(String PlacaCarro, String ClaCarroColocado){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {PlacaCarro, ClaCarroColocado};
        return db.rawQuery("SELECT ClaCarroColocado, PlacaCarro FROM FfccCarrosColocadosDet " +
                " WHERE PlacaCarro = ? " +
                " AND ClaCarroColocado = ?"  ,args);
    }

    public Cursor ExistePlacaEnRetiro(String PlacaCarro, String IdRetiro){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {PlacaCarro, IdRetiro};
        return db.rawQuery("SELECT IdRetiroClienteInterno, PlacaCarro FROM FFCCTraRetiroClienteInternoDet " +
                " WHERE PlacaCarro = ? " +
                " AND IdRetiroClienteInterno = ?"  ,args);
    }


    public void ADD_FfccCarrosColocados(String ClaCarroColocado,String IdTraSolicitudServicio,String ClaUbicacion,String ClaConfServicios,String ClaConfVentana,String DireccionMAC,String EstatusColocacion, String ClaUsuarioMod){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FfccCarrosColocados (ClaCarroColocado,IdTraSolicitudServicio,ClaUbicacion,ClaConfServicios,ClaConfVentana,DireccionMAC,EstatusColocacion,ClaUsuarioMod) " +
                " VALUES (?,?,?,?,?,?,?,?) ");
        System.out.println(ClaCarroColocado+"  CLAVE ENC  ");
        System.out.println("IdTraSolicitudServicio-"+IdTraSolicitudServicio+"  ClaUbicacion-"+ClaUbicacion+" ClaConfServicios-"+ClaConfServicios+ " -ClaConfVentana-"+ClaConfVentana+" -ClaUsuarioMod"+ClaUsuarioMod);
        stmt.bindString(1, ClaCarroColocado);
        stmt.bindString(2, IdTraSolicitudServicio);
        stmt.bindString(3, ClaUbicacion);
        stmt.bindString(4, ClaConfServicios);
        stmt.bindString(5, ClaConfVentana);
        stmt.bindString(6, DireccionMAC);
        stmt.bindString(7, EstatusColocacion);
        stmt.bindString(8, ClaUsuarioMod);
        stmt.execute();
        db.close();
    }

    public void ADD_FfccCarrosRetirados(String ClaCarroColocado,String IdTraSolicitudServicio,String ClaUbicacion,String ClaConfServicios,String ClaConfVentana,String DireccionMAC,String EstatusColocacion, String ClaUsuarioMod){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FfccCarrosColocados (IdRetiroClienteInterno,IdTraSolicitudServicio,ClaUbicacion,ClaConfServicios,ClaConfVentana,DireccionMAC,EstatusColocacion,ClaUsuarioMod) " +
                " VALUES (?,?,?,?,?,?,?,?) ");
        System.out.println(ClaCarroColocado+"  CLAVE ENC  ");
        System.out.println("IdTraSolicitudServicio-"+IdTraSolicitudServicio+"  ClaUbicacion-"+ClaUbicacion+" ClaConfServicios-"+ClaConfServicios+ " -ClaConfVentana-"+ClaConfVentana+" -ClaUsuarioMod"+ClaUsuarioMod);
        stmt.bindString(1, ClaCarroColocado);
        stmt.bindString(2, IdTraSolicitudServicio);
        stmt.bindString(3, ClaUbicacion);
        stmt.bindString(4, ClaConfServicios);
        stmt.bindString(5, ClaConfVentana);
        stmt.bindString(6, DireccionMAC);
        stmt.bindString(7, EstatusColocacion);
        stmt.bindString(8, ClaUsuarioMod);
        stmt.execute();
        db.close();
    }


    public void INSERT_FfccRetiroCliente(String IdRetiroClienteInterno,String ClaUbicacion,String IdTraCarroColocado,String IDColocacionServidor,String ClaUsuarioMod,String NombrePcMod) {
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCTraRetiroClienteInterno (IdRetiroClienteInterno," +
                "ClaUbicacion,IdTraCarroColocado,IDColocacionServidor,ClaUsuarioMod,NombrePcMod) " +
                " VALUES (?,?,?,?,?,?) ");
        System.out.println(IdRetiroClienteInterno + "  IDRetiro ENC  ");
        System.out.println("IdRetiroClienteInterno-" + IdRetiroClienteInterno + "  ClaUbicacion-" + ClaUbicacion + " IdTraCarroColocado-" + IdTraCarroColocado + " -IDColocacionServidor-" + IDColocacionServidor + " -ClaUsuarioMod" + ClaUsuarioMod + "  -NombrePcMod-" + NombrePcMod);
        stmt.bindString(1, IdRetiroClienteInterno);
        stmt.bindString(2, ClaUbicacion);
        stmt.bindString(3, IdTraCarroColocado);
        stmt.bindString(4, IDColocacionServidor);
        stmt.bindString(5, ClaUsuarioMod);
        stmt.bindString(6, NombrePcMod);
        stmt.execute();
        db.close();
    }

    public String getMax_FfccCarrosColocadosDet(){
        Cursor c;
        SQLiteDatabase db = this.getWritableDatabase();
        //String[] args = {ClaCarroColocado};
        c = db.rawQuery("SELECT ifnull(max(ClaCarroColocadoDet),0)+1 as IDMAXIMO FROM FfccCarrosColocadosDet", null);
        c.moveToFirst();
        String maximo = c.getString(c.getColumnIndex("IDMAXIMO"));
        c.close();
        db.close();
        return maximo;
    }

    public String getMax_FfccCarrosRetiradosDet(String IdRetiro, String  ClaUbicacion){
        Cursor c;
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {IdRetiro,ClaUbicacion};
        c = db.rawQuery("SELECT ifnull(max(IdRetiroClienteInternoDet),0)+1 as IDMAXIMO FROM FFCCTraRetiroClienteInternoDet WHERE IdRetiroClienteInterno = ? AND ClaUbicacion= ?", args);
        c.moveToFirst();
        String maximo = c.getString(c.getColumnIndex("IDMAXIMO"));
        c.close();
        db.close();
        return maximo;
    }

    public String getMax_FfccCarrosColocadosSQLite(String ClaCarroColocadoSQLServer){
        Cursor c;
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {ClaCarroColocadoSQLServer};
        c = db.rawQuery("SELECT ifnull(ClaCarroColocado,0) as IDMAXIMO FROM FfccCarrosColocados WHERE IDColocacionServidor = ?", args);
        c.moveToFirst();
        String maximo = c.getString(c.getColumnIndex("IDMAXIMO"));
        c.close();
        db.close();
        return maximo;
    }

    public String getCantidadColocadasDet(String ClaUbicacion,String ClaCarroColocado){
        Cursor c5;
        SQLiteDatabase db2 = this.getReadableDatabase();
        String[] args = {ClaCarroColocado, ClaUbicacion};
        c5 = db2.rawQuery("SELECT * FROM FfccCarrosColocadosDet " +
                "WHERE ClaCarroColocado = ? AND ClaUbicacion = ?", args);
        int maximo = c5.getCount();
        c5.close();
        db2.close();
        return String.valueOf(maximo);
    }

    public String getCantidadRetiradasDet(String ClaUbicacion,String ClaRetirada){
        Cursor c6;
        System.out.println("RETIRADA--------------------------- "+ClaRetirada);
        SQLiteDatabase db6 = this.getReadableDatabase();
        String[] args = {ClaRetirada, ClaUbicacion};
        c6 = db6.rawQuery("SELECT * FROM FFCCTraRetiroClienteInternoDet " +
                "WHERE IdRetiroClienteInterno = ? AND ClaUbicacion = ?", args);
        int maximo = c6.getCount();
        c6.close();
        db6.close();
        return String.valueOf(maximo);
    }

    public void ADD_FfccCarrosColocadosDet(String ClaCarroColocadoDet,String ClaCarroColocado,String IdControlUnidad,String ClaCarro,String PlacaCarro, String ClaUbicacion){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FfccCarrosColocadosDet (ClaCarroColocadoDet,ClaCarroColocado,IdControlUnidad,ClaCarro,PlacaCarro,ClaUbicacion) " +
                " VALUES (?,?,?,?,?,?) ");
        System.out.println(ClaCarroColocado+"  CLAVE ENC   y DET  "+ ClaCarroColocadoDet);
        stmt.bindString(1, ClaCarroColocadoDet);
        stmt.bindString(2, ClaCarroColocado);
        stmt.bindString(3, IdControlUnidad);
        stmt.bindString(4, ClaCarro);
        stmt.bindString(5, PlacaCarro);
        stmt.bindString(6, ClaUbicacion);
        stmt.execute();
        db.close();
    }

    public void ADD_FfccCarrosRetiradosDet(String IdRetiroClienteInternoDet,String ClaUbicacion,String IdRetiroClienteInterno,String ClaCarro,String PlacaCarro, String EsCargado, String EsTapa){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCTraRetiroClienteInternoDet (IdRetiroClienteInternoDet,ClaUbicacion,IdRetiroClienteInterno,ClaCarro,PlacaCarro,EsCargado,EsTapa) " +
                " VALUES (?,?,?,?,?,?,?) ");
        //System.out.println(ClaCarroColocado+"  CLAVE ENC   y DET  "+ ClaCarroColocadoDet);
        stmt.bindString(1, IdRetiroClienteInternoDet);
        stmt.bindString(2, ClaUbicacion);
        stmt.bindString(3, IdRetiroClienteInterno);
        stmt.bindString(4, ClaCarro);
        stmt.bindString(5, PlacaCarro);
        stmt.bindString(6, EsCargado);
        stmt.bindString(7, EsTapa);
        stmt.execute();
        db.close();
    }

    public String getMax_FfccCarrosColocadosFOrdet(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c;
        //String[] args = {IdPlaca, PlacaCarro};
        c = db.rawQuery("SELECT ifnull(max(ClaCarroColocado),1) as IDMAXIMO FROM FfccCarrosColocados", null);
        c.moveToFirst();
        String maximo = c.getString(c.getColumnIndex("IDMAXIMO"));
        c.close();
        db.close();
        return maximo;
    }

    public String getMax_FfccCarrosColocados(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c;
        //String[] args = {IdPlaca, PlacaCarro};
        c = db.rawQuery("SELECT ifnull(max(ClaCarroColocado),0)+1 as IDMAXIMO FROM FfccCarrosColocados", null);
        c.moveToFirst();
        String maximo = c.getString(c.getColumnIndex("IDMAXIMO"));
        c.close();
        db.close();
        return maximo;
    }

    public String getMax_FfccCarrosColocadosSQLiteUNO(String ClaCarroColocadoSQLServer){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c;
        String[] args = { ClaCarroColocadoSQLServer};
        c = db.rawQuery("SELECT ifnull(ClaCarroColocado,0) as IDMAXIMO FROM FfccCarrosColocados WHERE IDColocacionServidor = ?", args);
        c.moveToFirst();
        String maximo = c.getString(c.getColumnIndex("IDMAXIMO"));
        c.close();
        db.close();
        return maximo;
    }

    public Cursor getFfccCarrosColocados(String IdTraSolicitudServicio, String ClaUbicacion, String ClaConfServicios, String ClaConfVentana) throws Exception {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {IdTraSolicitudServicio, ClaUbicacion, ClaConfServicios, ClaConfVentana};
        return db.rawQuery("SELECT t2.IdControlUnidad, t2.ClaCarro, t2.PlacaCarro, t2.ClaCarroColocadoDet, t2.ClaCarroColocado, t2.EsCarga, t2.EsTapa FROM FfccCarrosColocados t1 " +
                " JOIN  FfccCarrosColocadosDet t2"+
                " ON  t1.ClaCarroColocado = t2.ClaCarroColocado" +
                " WHERE t1.IdTraSolicitudServicio = ?" +
                " AND t1.ClaUbicacion = ?"+
                " AND t1.ClaConfServicios = ? "+
                " AND t1.ClaConfVentana = ?",args);
    }

    public Cursor getFfccCarrosRetirados(String IdRetiro, String ClaUbicacion) throws Exception {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {IdRetiro, ClaUbicacion};
        return db.rawQuery("SELECT t1.ClaUbicacion, t2.IdRetiroClienteInternoDet, t2.ClaCarro, t2.PlacaCarro, t1.IdTraCarroColocado, t1.IDColocacionServidor ,t2.EsCargado  ,t2.EsTapa  " +
                " FROM FFCCTraRetiroClienteInterno t1 " +
                " JOIN  FFCCTraRetiroClienteInternoDet t2"+
                " ON  t1.IdRetiroClienteInterno = t2.IdRetiroClienteInterno" +
                " AND t1.ClaUbicacion = t2.ClaUbicacion " +
                " WHERE t1.IdRetiroClienteInterno = ?" +
                " AND t1.ClaUbicacion = ?",args);
    }

    //actualizar el estatusColocacion a 1
    public void ActualizaEstatusColocarCarro(String Estatus, String IdTraSolicitudServicio, String ClaUbicacion, String ClaConfServicios, String ClaConfVentana){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FfccCarrosColocados SET EstatusColocacion = ? " +
                " WHERE IdTraSolicitudServicio = ?" +
                " AND ClaUbicacion = ? " +
                " AND ClaConfServicios = ?" +
                " AND ClaConfVentana = ?  ");
        stmt.bindString(1, Estatus);
        stmt.bindString(2, IdTraSolicitudServicio);
        stmt.bindString(3, ClaUbicacion);
        stmt.bindString(4, ClaConfServicios);
        stmt.bindString(5, ClaConfVentana);
        stmt.execute();
        db.close();
    }

    public void ActualizaEstatusDisenoServicio(String Estatus, String IdTraSolicitudServicio, String ClaUbicacion, String ClaConfServicios, String ClaConfVentana){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraSolicitudServicio SET EstatusDiseno = ? " +
                " WHERE IdTraSolicitudServicio = ?" +
                " AND ClaUbicacion = ? " +
                " AND ClaConfServicios = ?" +
                " AND ClaConfVentana = ?  ");
        stmt.bindString(1, Estatus);
        stmt.bindString(2, IdTraSolicitudServicio);
        stmt.bindString(3, ClaUbicacion);
        stmt.bindString(4, ClaConfServicios);
        stmt.bindString(5, ClaConfVentana);
        stmt.execute();
        db.close();
    }

    public void ActualizaEstatusDisenoServicio2(String Estatus, String IdTraSolicitudServicio, String ClaUbicacion){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraSolicitudServicio SET EstatusDiseno = ? " +
                " WHERE IdTraSolicitudServicio = ?" +
                " AND ClaUbicacion = ? " );
        stmt.bindString(1, Estatus);
        stmt.bindString(2, IdTraSolicitudServicio);
        stmt.bindString(3, ClaUbicacion);
        stmt.execute();
        db.close();
    }
    //
    public void deleteFfccCarrosColocadosDet(String ClaCarroColocadoDet, String PlacaCarro, String IdControlUnidad){
            SQLiteDatabase db = this.getWritableDatabase();
            SQLiteStatement stmt = db.compileStatement("DELETE FROM FfccCarrosColocadosDet " +
                    " WHERE ClaCarroColocadoDet = ?" +
                    "  AND PlacaCarro = ? ");
            stmt.bindString(1, ClaCarroColocadoDet);
            stmt.bindString(2, PlacaCarro);
            stmt.execute();
            db.close();
    }

    public void deleteFfccCarrosColocadosDet2(String ClaCarroColocadoDet, String ClaCarroColocado, String IdControlUnidad){
            SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("DELETE FROM FfccCarrosColocadosDet " +
                " WHERE ClaCarroColocadoDet = ?" +
                "  AND ClaCarroColocado = ? " +
                " AND IdControlUnidad = ? ");
        stmt.bindString(1, ClaCarroColocadoDet);
        stmt.bindString(2, ClaCarroColocado);
        stmt.bindString(3, IdControlUnidad);
        stmt.execute();
        db.close();
    }

    public void deleteFfccCarrosRetiradosDet(String ClaRetiroDet, String ClaRetiro){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("DELETE FROM FFCCTraRetiroClienteInternoDet " +
                " WHERE IdRetiroClienteInternoDet = ?" +
                " AND IdRetiroClienteInterno = ? " );
        System.out.println("************* det "+ClaRetiroDet+" - enc "+ClaRetiro);
        stmt.bindString(1, ClaRetiroDet);
        stmt.bindString(2, ClaRetiro);
        stmt.execute();

        String[] args = {ClaRetiroDet,ClaRetiro};
        Cursor c = db.rawQuery("SELECT * FROM FFCCTraRetiroClienteInternoDet WHERE IdRetiroClienteInternoDet= ? AND IdRetiroClienteInterno=? ",args);
        if (c.getCount()>0){
            c.moveToFirst();
            for(int x = 0; x < c.getCount(); x++){
                System.out.println("******* det "+c.getString(0)+" ubi "+c.getString(1)+" enc"+ c.getString(2));
            }
        }
        c.close();

        db.close();
    }

    public Cursor getServicioColocacion(String EstatusColocacion ,String Via, String FechaColocacion, String ClienteInterno){
        SQLiteDatabase db = this.getWritableDatabase();

       // System.out.println("FECHA PARAMETRO :::::::::::::::::::: "+FechaColocacion);
        String[] args = {"1",EstatusColocacion,Via,FechaColocacion, ClienteInterno};
        return db.rawQuery(" SELECT t2.IdTraSolicitudServicio, t2.ClaUbicacion, t2.ClaConfServicios, t2.ClaConfVentana, " +
                " t2.ClaUbicacion, t2.Duracion, t2.Unidad, strftime('%H:%M',t2.Hora), t2.HoraRegistro, " +
                " t1.ClaCarroColocado, t1.FechaConfirmaColocacion, t1.FechaInicial, t1.FechaFinal, " +
                " t1.ClaCarroColocado , t1.IDColocacionServidor ,t2.ClaClienteInterno, ci.NomClienteInterno, v.NomVia" +
                " FROM FfccCarrosColocados t1 " +
                " JOIN  FFCCTraSolicitudServicio t2 " +
                " ON t1.IdTraSolicitudServicio = t2.IdTraSolicitudServicio " +
                " AND t1.ClaUbicacion = t2.ClaUbicacion " +
                " LEFT JOIN FFCCClienteInterno ci" +
                " ON  ci.ClaClienteInterno = t2.ClaClienteInterno " +
                " AND ci.ClaUbicacion = t2.ClaUbicacion " +
                " LEFT JOIN FFCCCatVia v " +
                " ON v.ClaVia = t2.ClaVia " +
                " AND  v.ClaUbicacion = t2.ClaUbicacion  " +
                " WHERE t1.EstatusColocacion IN( ?,?) " +
                " AND t2.ClaVia = ? " +
                " AND strftime('%Y-%m-%d',t2.FechaCaptura) = ? " +
                " AND t2.ClaClienteInterno = ? "+
                " AND t2.IdColocacion IN (0) "+
                " GROUP BY t1.IdTraSolicitudServicio,t1.ClaUbicacion ", args);
    }

    public void getServicioColocacionTEST(String EstatusColocacion ,String Via, String ClienteInterno){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cc;
        String[] args = {EstatusColocacion,Via, ClienteInterno};
        cc= db.rawQuery(" SELECT t2.IdTraSolicitudServicio, t2.ClaUbicacion, t2.ClaConfServicios, t2.ClaConfVentana, " +
                " t2.ClaUbicacion, t2.Duracion, t2.Unidad, t2.Hora, t2.HoraRegistro, " +
                " t1.ClaCarroColocado, strftime('%Y-%m-%d',t1.FechaConfirmaColocacion), t1.FechaInicial, t1.FechaFinal, t1.ClaCarroColocado , t1.IDColocacionServidor ,t2.ClaClienteInterno, ci.NomClienteInterno, v.NomVia" +
                " FROM FfccCarrosColocados t1" +
                " JOIN  FFCCTraSolicitudServicio t2 " +
                " ON t1.IdTraSolicitudServicio = t2.IdTraSolicitudServicio" +
                " AND t1.ClaUbicacion = t2.ClaUbicacion " +
                " LEFT JOIN FFCCClienteInterno ci" +
                " ON  ci.ClaClienteInterno = t2.ClaClienteInterno" +
                " AND ci.ClaUbicacion = t2.ClaUbicacion " +
                " LEFT JOIN FFCCCatVia v" +
                " ON v.ClaVia = t2.ClaVia " +
                " AND  v.ClaUbicacion = t2.ClaUbicacion  " +
                " WHERE t1.EstatusColocacion = ? " +
                " AND t2.ClaVia = ? " +
                " AND t2.ClaClienteInterno = ? "+
                " GROUP BY t1.IdTraSolicitudServicio,t1.ClaUbicacion ", args);
        cc.moveToFirst();
        for (int x = 0; x < cc.getCount(); x++){
            System.out.println("ClaCarroColocado: "+cc.getString(9)+" Fecha Coloc: "+cc.getString(10)+" IDServidorSQL:"+cc.getString(14));
            cc.moveToNext();
        }
    }

    public Cursor getColocacionesTESTTTT(){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery(" SELECT * FROM FfccCarrosColocados " , null);
    }

    public Cursor getColocacionesTESTTTT2(){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery(" SELECT * FROM FfccCarrosColocadosDet " , null);
    }

    public Cursor getColocacionesDiseno(String EstatusColocacion){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {EstatusColocacion};
        return db.rawQuery("SELECT * FROM FfccCarrosColocados WHERE EstatusColocacion = ? AND IDColocacionServidor IS NULL ",args);
        //solo retornare aquellos con estatus de no enviados el estatus 3 es cuando ya se enviaron y se guardaron correctamente
    }

    public Cursor getColocaciones(String EstatusColocacion){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {EstatusColocacion};
        return db.rawQuery("SELECT * FROM FfccCarrosColocados WHERE EstatusColocacion = ? ",args);
        //solo retornare aquellos con estatus de no enviados el estatus 3 es cuando ya se enviaron y se guardaron correctamente
    }

    public Cursor getColocacionesDet(String ClaCarroColocado, String ClaUbicacion){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {ClaCarroColocado, ClaUbicacion};
        return db.rawQuery("SELECT * FROM FfccCarrosColocadosDet WHERE ClaCarroColocado = ? AND ClaUbicacion = ? ",args);
        //solo retornare aquellos con estatus de no enviados el estatus 3 es cuando ya se enviaron y se guardaron correctamente
    }

    public void SetDateIniFfccCarrosColocados(String Fecha,String ClaCarroColocado, String IdTraSolicitudServicio, String ClaUbicacion, String ClaConfServicios, String ClaConfVentana){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FfccCarrosColocados SET FechaInicial =?" +
                " WHERE IdTraSolicitudServicio=? " +
                " AND ClaUbicacion =? " +
                " AND ClaConfServicios=? " +
                " AND ClaConfVentana =? " +
                " AND ClaCarroColocado = ? ");
        stmt.bindString(1, Fecha);
        stmt.bindString(2, IdTraSolicitudServicio);
        stmt.bindString(3, ClaUbicacion);
        stmt.bindString(4, ClaConfServicios);
        stmt.bindString(5, ClaConfVentana);
        stmt.bindString(6, ClaCarroColocado);
        stmt.execute();
        db.close();
    }

    public void SetDateFinFfccCarrosColocados(String Fecha,String ClaCarroColocado, String IdTraSolicitudServicio, String ClaUbicacion, String ClaConfServicios, String ClaConfVentana){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FfccCarrosColocados SET FechaConfirmaColocacion=?, FechaFinal =?" +
                " WHERE IdTraSolicitudServicio=? " +
                " AND ClaUbicacion =? " +
                " AND ClaConfServicios=? " +
                " AND ClaConfVentana =? " +
                " AND ClaCarroColocado = ? ");
        stmt.bindString(1, Fecha);
        stmt.bindString(2, Fecha);
        stmt.bindString(3, IdTraSolicitudServicio);
        stmt.bindString(4, ClaUbicacion);
        stmt.bindString(5, ClaConfServicios);
        stmt.bindString(6, ClaConfVentana);
        stmt.bindString(7, ClaCarroColocado);
        stmt.execute();
        db.close();
    }

    public String getViaDisenoServ(String ClaCarro, String IdControlUnidad){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {ClaCarro, IdControlUnidad};
        String Resultado="null";
        Cursor c;
        c= db.rawQuery("SELECT t1.IdTraSolicitudServicio, t1.ClaUbicacion, t1.ClaConfServicios, t1.ClaConfVentana FROM FfccCarrosColocados t1" +
                " JOIN FfccCarrosColocadosDet t2 " +
                " ON t1.ClaCarroColocado = t2.ClaCarroColocado " +
                " AND t1.ClaUbicacion = t2.ClaUbicacion" +
                " WHERE t2.ClaCarro = ? " +
                " AND t2.IdControlUnidad = ? ",args);
       // System.out.println("---------param--------- "+ClaCarro+"-"+IdControlUnidad);
        if(c.getCount()>0){
            c.moveToFirst();
            //System.out.println("---------c1---------- "+c.getString(1)+"-"+c.getString(2)+"-"+c.getString(3));
            String[] args2 = {c.getString(0),c.getString(1),c.getString(2),c.getString(3)};
            Cursor c2;
            c2 = db.rawQuery("SELECT ifnull(t2.NomVia, 'null') FROM FFCCTraSolicitudServicio t1" +
                    " JOIN FFCCCatVia t2" +
                    " ON t1.ClaVia = t2.ClaVia" +
                    " AND t1.ClaUbicacion = t2.ClaUbicacion" +
                    " WHERE t1.IdTraSolicitudServicio = ? " +
                    " AND t1.ClaUbicacion = ? " +
                    " AND t1.ClaConfServicios = ? " +
                    " AND t1.ClaConfVentana = ? ",args2);

            if(c2.getCount()>0){
                c2.moveToFirst();
                //System.out.println("---------c2---------- "+c2.getString(0));
                Resultado = c2.getString(0);
            }
            c2.close();
        }
        c.close();
        db.close();
        return Resultado;
    }


public String getMax_FFCCTraRetiroClienteInterno(){
    SQLiteDatabase db = this.getWritableDatabase();
    Cursor c;
    //String[] args = {IdPlaca, PlacaCarro};
    c = db.rawQuery("SELECT ifnull(max(IdRetiroClienteInterno),0)+1 as IDMAXIMO FROM FFCCTraRetiroClienteInterno", null);
    c.moveToFirst();
    String maximo = c.getString(c.getColumnIndex("IDMAXIMO"));
    c.close();
    return maximo;
}

    public String getMax_FFCCTraRetiroClienteInternoDet(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c;
        //String[] args = {IdPlaca, PlacaCarro};
        c = db.rawQuery("SELECT ifnull(max(IdRetiroClienteInternoDet),0)+1 as IDMAXIMO FROM FFCCTraRetiroClienteInternoDet", null);
        c.moveToFirst();
        String maximo = c.getString(c.getColumnIndex("IDMAXIMO"));
        c.close();
        return maximo;
    }

    public String getMax_FFCCTraRetiroClienteInternoParaDet(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c;
        //String[] args = {IdPlaca, PlacaCarro};
        c = db.rawQuery("SELECT ifnull(max(IdRetiroClienteInterno),0) as IDMAXIMO FROM FFCCTraRetiroClienteInterno", null);
        c.moveToFirst();
        String maximo = c.getString(c.getColumnIndex("IDMAXIMO"));
        c.close();
        return maximo;
    }

    public void CopiarColocacionTOClienteInterno(String IdTraCarroColocado, String ClaUbicacion){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c;
        String[] args = {IdTraCarroColocado, ClaUbicacion};
        c = db.rawQuery("SELECT * FROM FfccCarrosColocados WHERE ClaCarroColocado = ? AND ClaUbicacion = ? ",args);

        if(c.getCount()>0){
            c.moveToFirst();/////////upd cabecera
            SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCTraRetiroClienteInterno (IdRetiroClienteInterno,ClaUbicacion,IdTraCarroColocado,IDColocacionServidor,ClaUsuarioMod,NombrePcMod) " +
                    " VALUES(?,?,?,?,?,?) ");
            System.out.println("ENC "+this.getMax_FFCCTraRetiroClienteInterno());
            stmt.bindString(1, this.getMax_FFCCTraRetiroClienteInterno());//IDRetiroClienteInterno
            stmt.bindString(2, c.getString(2));
            stmt.bindString(3, c.getString(0));
            String idservColocacion="";
            if(c.getString(10) == null || c.getString(10).isEmpty()){
                idservColocacion="0";
            }else{
                idservColocacion=c.getString(10);
            }
            stmt.bindString(4, idservColocacion);
            stmt.bindString(5, c.getString(11));
            stmt.bindString(6, c.getString(5));
            stmt.execute();

            Cursor c2;
            String[] args2 = {c.getString(0)};
            c2 = db.rawQuery("SELECT * FROM FfccCarrosColocadosDet WHERE ClaCarroColocado  = ?",args2);
            System.out.println("COUNT "+c2.getCount());
            if(c2.getCount()>0){
                c2.moveToFirst();
                for (int x = 0; x < c2.getCount(); x++){/////////////upd DETALLE
                    SQLiteStatement stmt2 = db.compileStatement("INSERT INTO FFCCTraRetiroClienteInternoDet (IdRetiroClienteInternoDet,ClaUbicacion,IdRetiroClienteInterno,EsTapa,EsCargado,ClaCarro,PlacaCarro,ClaUsuarioMod,NombrePcMod) " +
                            " VALUES(?,?,?,?,?,?,?,?,?) ");
                    System.out.println(this.getMax_FFCCTraRetiroClienteInternoParaDet()+"ENC   DET"+this.getMax_FFCCTraRetiroClienteInternoDet());
                    stmt2.bindString(1, this.getMax_FFCCTraRetiroClienteInternoDet());//IDRetiroClienteInternoDet
                    stmt2.bindString(2, c2.getString(8));
                    stmt2.bindString(3, this.getMax_FFCCTraRetiroClienteInternoParaDet());//IDRetiroClienteInterno
                    String EsTapa="",EsCarga="",ClaUsuarioMod="",NombrePcMod="";
                    if(c2.getString(3) == null || c2.getString(3).isEmpty()){
                        EsTapa="0";
                    }else{
                        EsTapa=c2.getString(3);
                    }
                    stmt2.bindString(4, EsTapa);
                    if(c2.getString(2) == null || c2.getString(2).isEmpty()){
                        EsCarga="0";
                    }else{
                        EsCarga=c2.getString(2);
                    }
                    stmt2.bindString(5, EsCarga);
                    stmt2.bindString(6, c2.getString(5));
                    stmt2.bindString(7, c2.getString(6));
                    if(c2.getString(7) == null || c2.getString(7).isEmpty()){
                        ClaUsuarioMod="0";
                    }else{
                        ClaUsuarioMod=c2.getString(7);
                    }
                    stmt2.bindString(8, ClaUsuarioMod);
                    stmt2.bindString(9, c.getString(5));//falta acomodar esto
                    stmt2.execute();
                    c2.moveToNext();
                }
            }
            c2.close();
        }
        c.close();
        //test checar registros
        db.close();
    }


    public void CopiarColocacionTOClienteInterno2(String IdTraCarroColocado, String ClaUbicacion, String IDColocacionServidor){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c;
        String[] args = {IdTraCarroColocado, ClaUbicacion};
        c = db.rawQuery("SELECT * FROM FfccCarrosColocados WHERE ClaCarroColocado = ? AND ClaUbicacion = ? ",args);

        if(c.getCount()>0){
            c.moveToFirst();/////////upd cabecera

            String[] args3 = {IdTraCarroColocado,IDColocacionServidor, ClaUbicacion};
            Cursor c3 = db.rawQuery("SELECT * FROM FFCCTraRetiroClienteInterno WHERE IdTraCarroColocado=? AND IDColocacionServidor=? AND ClaUbicacion=?",args3);
            if(c3.getCount()>0){
                c3.moveToFirst();
                System.out.println("YAAA EXISTE ESTE RETIRO  " +IdTraCarroColocado +" -- "+IDColocacionServidor+" -- "+ ClaUbicacion);

            }else{
                c3.moveToFirst();
                System.out.println("NOOO EXISTE ESTE RETIRO  " +IdTraCarroColocado +" -- "+IDColocacionServidor+" -- "+ ClaUbicacion);


            SQLiteStatement stmt = db.compileStatement("INSERT INTO FFCCTraRetiroClienteInterno (IdRetiroClienteInterno,ClaUbicacion,IdTraCarroColocado,IDColocacionServidor,ClaUsuarioMod,NombrePcMod) " +
                    " VALUES(?,?,?,?,?,?) ");
            System.out.println("ENC "+this.getMax_FFCCTraRetiroClienteInterno());
            stmt.bindString(1, this.getMax_FFCCTraRetiroClienteInterno());//IDRetiroClienteInterno
            stmt.bindString(2, c.getString(2));
            stmt.bindString(3, c.getString(0));
            String idservColocacion="";
            if(c.getString(10) == null || c.getString(10).isEmpty()){
                idservColocacion="0";
            }else{
                idservColocacion=c.getString(10);
            }
            stmt.bindString(4, idservColocacion);
            stmt.bindString(5, c.getString(11));
            stmt.bindString(6, c.getString(5));
            stmt.execute();

            Cursor c2;
            String[] args2 = {c.getString(0)};
            c2 = db.rawQuery("SELECT * FROM FfccCarrosColocadosDet WHERE ClaCarroColocado  = ?",args2);
            System.out.println("COUNT "+c2.getCount());
            if(c2.getCount()>0){
                c2.moveToFirst();
                for (int x = 0; x < c2.getCount(); x++){/////////////upd DETALLE
                    SQLiteStatement stmt2 = db.compileStatement("INSERT INTO FFCCTraRetiroClienteInternoDet (IdRetiroClienteInternoDet,ClaUbicacion,IdRetiroClienteInterno,EsTapa,EsCargado,ClaCarro,PlacaCarro,ClaUsuarioMod,NombrePcMod) " +
                            " VALUES(?,?,?,?,?,?,?,?,?) ");
                    System.out.println(this.getMax_FFCCTraRetiroClienteInternoParaDet()+"ENC   DET"+this.getMax_FFCCTraRetiroClienteInternoDet());
                    stmt2.bindString(1, this.getMax_FFCCTraRetiroClienteInternoDet());//IDRetiroClienteInternoDet
                    stmt2.bindString(2, c2.getString(8));
                    stmt2.bindString(3, this.getMax_FFCCTraRetiroClienteInternoParaDet());//IDRetiroClienteInterno
                    String EsTapa="",EsCarga="",ClaUsuarioMod="",NombrePcMod="";
                    if(c2.getString(3) == null || c2.getString(3).isEmpty()){
                        EsTapa="0";
                    }else{
                        EsTapa=c2.getString(3);
                    }
                    stmt2.bindString(4, EsTapa);
                    if(c2.getString(2) == null || c2.getString(2).isEmpty()){
                        EsCarga="0";
                    }else{
                        EsCarga=c2.getString(2);
                    }
                    stmt2.bindString(5, EsCarga);
                    stmt2.bindString(6, c2.getString(5));
                    stmt2.bindString(7, c2.getString(6));
                    if(c2.getString(7) == null || c2.getString(7).isEmpty()){
                        ClaUsuarioMod="0";
                    }else{
                        ClaUsuarioMod=c2.getString(7);
                    }
                    stmt2.bindString(8, ClaUsuarioMod);
                    stmt2.bindString(9, c.getString(5));//falta acomodar esto
                    stmt2.execute();
                    c2.moveToNext();
                }
            }
            c2.close();


            }


        }
        c.close();
        //test checar registros
        db.close();
    }

    public void SetDateFechaRetiro(String FechaRetiro,String IdRetiroClienteInterno, String ClaUbicacion){
        SQLiteDatabase db = this.getWritableDatabase();
        System.out.println("FechaRetiro-------"+FechaRetiro);
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraRetiroClienteInterno SET FechaRetiro =?" +
                " WHERE IdRetiroClienteInterno=? " +
                " AND ClaUbicacion =? " );
        stmt.bindString(1, FechaRetiro);
        stmt.bindString(2, IdRetiroClienteInterno);
        stmt.bindString(3, ClaUbicacion);
        stmt.execute();
        db.close();
    }

    public Cursor getServicioRetiroClienteInterno(String EstatusRetiro ,String Via, String FechaRetiro, String ClaClienteInterno){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args = {EstatusRetiro,Via,FechaRetiro, ClaClienteInterno};
        return db.rawQuery(" SELECT c1.IdRetiroClienteInterno, c1.ClaUbicacion, c1.IdTraCarroColocado, c1.IDColocacionServidor," +
                " t1.FechaConfirmaColocacion, t2.Unidad, c1.FechaRetiro, t3.NomVia, " +
                " t2.ClaClienteInterno, t2.IdTraSolicitudServicio, t2.ClaConfServicios, t2.ClaConfVentana, ci.NomClienteInterno, c1.ClaUsuarioMod, c1.EstatusRetiro" +
                " FROM  FFCCTraRetiroClienteInterno c1 " +
                " JOIN FfccCarrosColocados t1" +
                " ON t1.ClaCarroColocado = c1.IdTraCarroColocado " +
                " JOIN  FFCCTraSolicitudServicio t2 " +
                " ON t1.IdTraSolicitudServicio = t2.IdTraSolicitudServicio" +
                " AND t1.ClaUbicacion = t2.ClaUbicacion " +
                " LEFT JOIN FFCCCatVia t3 " +//
                " ON t2.ClaVia = t3.ClaVia " +
                " AND t2.ClaUbicacion = t3.ClaUbicacion " +//
                " LEFT JOIN FFCCClienteInterno ci "+
                " ON ci.ClaClienteInterno = t2.ClaClienteInterno " +
                " AND ci.ClaUbicacion = t2.ClaUbicacion "+
                " WHERE c1.EstatusRetiro <= ? " +
                " AND t2.ClaVia = ? " +
                " AND strftime('%Y-%m-%d',t2.FechaCaptura) = ? " +
                " AND t2.ClaClienteInterno = ? " +
                " GROUP BY  t2.IdTraSolicitudServicio,t2.ClaUbicacion", args);
        //  " AND strftime('%Y-%m-%d',t1.FechaConfirmaColocacion) = ? " +
        //   " AND t1.FechaConfirmaColocacion BETWEEN ? AND '"+ FechaRetiro+" 23:59:59'" +
    }

    public void FFCCSplitFn(String Clave,String Cadena, String delimitador){
        String Cadena2[] = Cadena.split(delimitador);
        for(String Cadenas : Cadena2){
            InsertTempTipoUnidad(Clave,Cadenas.trim());
        }
    }

    public void InsertTempTipoUnidad(String Clave, String Placa){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("INSERT INTO TipoUnidadTEMPORAL (ClaTipoUnidad,Placa)" +
                " VALUES(?,?) ");
        stmt.bindString(1, Clave);
        stmt.bindString(2, Placa);
        stmt.execute();
        db.close();
    }

    public String getTipoUnidadFn(String Placa){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL(DROPTipoUnidadTEMPORAL);
        db.execSQL(CREATETipoUnidadTEMPORAL);
        String nClaTipoUnidad ="";
        Cursor c, c2;
        c =  db.rawQuery("SELECT ClaTipoUnidad,Placas FROM FFCCCatTipoUnidadVw ",null);
        c.moveToFirst();
        if(c.getCount()>0){
            for (int w = 0; w<c.getCount(); w++){
                FFCCSplitFn(""+c.getString(0),""+c.getString(1),",");
                c.moveToNext();
            }
        }

        c.close();
        db.close();
        SQLiteDatabase db2 = this.getWritableDatabase();

       String[] args = {Placa,Placa};
       c2 = db2.rawQuery("select CASE WHEN substr(?,1, LENGTH(Placa))=Placa THEN ClaTipoUnidad " +
               " ELSE 0 END from TipoUnidadTEMPORAL " +
               " WHERE CASE WHEN substr(?,1, LENGTH(Placa))=Placa THEN ClaTipoUnidad " +
               " ELSE 0 END != 0",args);
       c2.moveToFirst();

       if(c2.getCount()>0) {
           nClaTipoUnidad = c2.getString(0);
       }else{
           nClaTipoUnidad = "0";
       }

        c2.close();
        db2.close();
        return nClaTipoUnidad;
    }

    //////////////////////// API RETIROS/////////////////////////////////

    public Cursor getRetirosAPI(String EstatusRetiro){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {EstatusRetiro};
        return db.rawQuery("SELECT * FROM FFCCTraRetiroClienteInterno WHERE EstatusRetiro = ? ",args);
        //solo retornare aquellos con estatus de no enviados el estatus 3 es cuando ya se enviaron y se guardaron correctamente
    }

    public Cursor getEditarRetirosAPI(String EstatusRetiro, String EstatusRetiro2){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {EstatusRetiro,EstatusRetiro2};
        return db.rawQuery("SELECT * FROM FFCCTraRetiroClienteInterno WHERE EstatusRetiro IN (?,?) ",args);
        //solo retornare aquellos con estatus de no enviados el estatus 3 es cuando ya se enviaron y se guardaron correctamente
    }



    public Cursor getRetirosDetAPI(String IdClienteRetiro, String ClaUbicacion){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {IdClienteRetiro, ClaUbicacion};
        return db.rawQuery("SELECT * FROM FFCCTraRetiroClienteInternoDet WHERE IdRetiroClienteInterno = ? AND ClaUbicacion = ? ",args);
        //solo retornare aquellos con estatus de no enviados el estatus 3 es cuando ya se enviaron y se guardaron correctamente
    }

    public void updateEstatusRetiro(String IdClienteRetiro,String ClaUbicacion, String Estatus, String IdRetiroServidor){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraRetiroClienteInterno SET EstatusRetiro = ? ,IDRetiroServidor = ?" +
                " WHERE IdRetiroClienteInterno = ?" +
                " AND ClaUbicacion = ?"  );
        stmt.bindString(1, Estatus);
        stmt.bindString(2, IdRetiroServidor);
        stmt.bindString(3, IdClienteRetiro);
        stmt.bindString(4, ClaUbicacion);
        stmt.execute();
        db.close();
    }

    public void updateEstatusRetiro2(String IdClienteRetiro,String ClaUbicacion, String Estatus){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraRetiroClienteInterno SET EstatusRetiro = ? " +
                " WHERE IdRetiroClienteInterno = ?" +
                " AND ClaUbicacion = ?"  );
        stmt.bindString(1, Estatus);
        stmt.bindString(2, IdClienteRetiro);
        stmt.bindString(3, ClaUbicacion);
        stmt.execute();
        db.close();
    }

    public String getIdColocacionSQLserverRetiro(String ClaUbicacion, String IdRetiroSqlite){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data;
        String[] args = {ClaUbicacion, IdRetiroSqlite};
        System.out.println(ClaUbicacion+"  ********************************** "+IdRetiroSqlite);
        data = db.rawQuery("SELECT ifnull(IDRetiroServidor,0) FROM FFCCTraRetiroClienteInterno " +
                "WHERE ClaUbicacion= ? AND IdRetiroClienteInterno= ?",args);

        String idRetirosqlserver="0";
        if(data.getCount()>0){
            data.moveToFirst();
            idRetirosqlserver = data.getString(0);
        }
        data.close();
        db.close();
        System.out.println("********************************************* "+idRetirosqlserver);
        return idRetirosqlserver;
    }


    public String getIdSQLiteRetiro(String ClaUbicacion, String IdRetiroSQLServer){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data2;
        String[] args = {ClaUbicacion, IdRetiroSQLServer};
        System.out.println(ClaUbicacion+"  **********************************-- "+IdRetiroSQLServer);
        data2 = db.rawQuery("SELECT ifnull(IdRetiroClienteInterno,0) FROM FFCCTraRetiroClienteInterno " +
                "WHERE ClaUbicacion= ? AND IDRetiroServidor= ?",args);

        String idRetirosqlite="0";
        if(data2.getCount()>0){
            data2.moveToFirst();
            idRetirosqlite = data2.getString(0);
        }
        data2.close();
        db.close();
        System.out.println("*********************************************/// "+idRetirosqlite);
        return idRetirosqlite;
    }

    public String getIdRetiroSQLite(String ClaUbicacion, String IdTraEvaluacionRetiroCI){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data2;
        String[] args = {ClaUbicacion, IdTraEvaluacionRetiroCI};
        System.out.println(ClaUbicacion+"  *ubicacion********************************IdTraEvaluacionRetiroCI*-- "+IdTraEvaluacionRetiroCI);
        data2 = db.rawQuery("SELECT ifnull(IdRetiroClienteInterno,0) FROM FFCCTraEvaluacionRetiroCI " +
                "WHERE ClaUbicacion= ? AND IdTraEvaluacionRetiroCI= ?",args);

        String idRetirosqlite="0";
        if(data2.getCount()>0){
            data2.moveToFirst();
            idRetirosqlite = data2.getString(0);
        }
        data2.close();
        db.close();
        System.out.println("*********************************************/// "+idRetirosqlite);
        return idRetirosqlite;
    }

    //////////////////////////////////////////////////////////FIN API RETIROS

    //////////////////////// API Evaluacion RETIROS/////////////////////////////////

    public Cursor getEvaluacionRetirosAPI(String EstatusEvaluacion){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {EstatusEvaluacion};
        return db.rawQuery("SELECT * FROM FFCCTraEvaluacionRetiroCI WHERE EstatusEvaluacion = ? ",args);
        //solo retornare aquellos con estatus de no enviados el estatus 3 es cuando ya se enviaron y se guardaron correctamente
    }

    public Cursor getEvaluacionRetirosDetAPI(String IdTraEvaluacionRetiroCI, String ClaUbicacion){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {IdTraEvaluacionRetiroCI, ClaUbicacion};
        return db.rawQuery("SELECT * FROM FFCCTraEvaluacionRetiroCIDet WHERE IdTraEvaluacionRetiroCI = ? AND ClaUbicacion = ? ",args);
    }

    public void updateEstatusEvalaucionRetiro(String IdTraEvaluacionRetiroCI,String Estatus){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraEvaluacionRetiroCI SET EstatusEvaluacion = ? " +
                " WHERE IdTraEvaluacionRetiroCI = ?"  );
        stmt.bindString(1, Estatus);
        stmt.bindString(2, IdTraEvaluacionRetiroCI);
        stmt.execute();
        db.close();
    }

    //////////////////////////////////////////////////////////FIN API evaluacion RETIROS



    public Cursor getDataCfgEvaluacionRetiro(String ClaUbicacion){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args2 = {ClaUbicacion};
        return db.rawQuery("SELECT * FROM FFCCCfgEvaluacionRetiroDet WHERE ClaUbicacion = ?",args2);
    }

    public String IDmaximoFFCCTraEvaluacionRetiroCI(String ClaUbicacion, String IdRetiro){
        SQLiteDatabase dbenc = this.getReadableDatabase();
        String[] args = {ClaUbicacion};
        Cursor cc = dbenc.rawQuery("SELECT IFNULL(MAX(IdTraEvaluacionRetiroCI),0)+1 FROM FFCCTraEvaluacionRetiroCI WHERE ClaUbicacion = ?",args);
        String Maximo="";
        if(cc.getCount()>0){
            cc.moveToFirst();
            Maximo=cc.getString(0);
        }
        cc.close();
        dbenc.close();
        System.out.println("MAXIMO***** "+Maximo);
        return ""+Maximo;
    }

    public String IDmaximoFFCCTraEvaluacionRetiroCI2(String ClaUbicacion, String IdRetiro){
        SQLiteDatabase dbenc = this.getReadableDatabase();
        String[] args = {ClaUbicacion,IdRetiro};
        Cursor cc = dbenc.rawQuery("SELECT IFNULL(MAX(IdTraEvaluacionRetiroCI),0) FROM FFCCTraEvaluacionRetiroCI WHERE ClaUbicacion = ? AND IdRetiroClienteInterno = ?",args);
        String Maximo="";
        if(cc.getCount()>0){
            cc.moveToFirst();
            Maximo=cc.getString(0);
        }
        cc.close();
        dbenc.close();
        return ""+Maximo;
    }
    
    public String IDmaximoFFCCTraEvaluacionRetiroCIDet(String ClaUbicacion, String IdRetiro, String IdTraEvaluacionRetiroCI){
        SQLiteDatabase dbDet = this.getReadableDatabase();
        String[] args = {ClaUbicacion,IdRetiro, IdTraEvaluacionRetiroCI};
        Cursor cc = dbDet.rawQuery("SELECT IFNULL(MAX(c2.IdTraEvaluacionRetiroCIDet),0)+1 FROM FFCCTraEvaluacionRetiroCIDet c2" +
                " JOIN  FFCCTraEvaluacionRetiroCI c1" +
                " ON c2.ClaUbicacion = c1.ClaUbicacion" +
                " AND c2.IdTraEvaluacionRetiroCI = c1.IdTraEvaluacionRetiroCI " +
                "WHERE c2.ClaUbicacion = ? AND c1.IdRetiroClienteInterno = ? AND c1.IdTraEvaluacionRetiroCI = ?",args);
        String Maximo="";
        if(cc.getCount()>0){
            cc.moveToFirst();
            Maximo=cc.getString(0);
        }
        cc.close();
        dbDet.close();
        return ""+Maximo;
    }

    public void InsertFFCCTraEvaluacionRetiroCI(String ClaUbicacion, String IdTraEvaluacionRetiroCI, String IdRetiroClienteInterno, String ClaUsuarioMod, String NombrePcMod){
        SQLiteDatabase dbI = this.getWritableDatabase();
        SQLiteStatement stmtI = dbI.compileStatement("INSERT INTO FFCCTraEvaluacionRetiroCI(ClaUbicacion,IdTraEvaluacionRetiroCI,IdRetiroClienteInterno,ClaUsuarioMod,NombrePcMod) " +
                " VALUES(?,?,?,?,?) "  );
        System.out.println("******** ClaUbicacion "+ClaUbicacion+" IdTraEvaluacionRetiroCI "+IdTraEvaluacionRetiroCI+" IdRetiroClienteInterno "+IdRetiroClienteInterno);
        stmtI.bindString(1, ClaUbicacion);
        stmtI.bindString(2, IdTraEvaluacionRetiroCI);
        stmtI.bindString(3, IdRetiroClienteInterno);
        stmtI.bindString(4, ClaUsuarioMod);
        stmtI.bindString(5, NombrePcMod);
        stmtI.execute();
        dbI.close();
    }

    public void InsertFFCCTraEvaluacionRetiroCIDet(String ClaUbicacion,String IdTraEvaluacionRetiroCIDet,String IdTraEvaluacionRetiroCI,String IdCfgEvaluacionRetiroDet,String ClaUsuarioMod,String NombrePcMod){
        SQLiteDatabase dbI2 = this.getWritableDatabase();
        SQLiteStatement stmt2 = dbI2.compileStatement("INSERT INTO FFCCTraEvaluacionRetiroCIDet(ClaUbicacion,IdTraEvaluacionRetiroCIDet,IdTraEvaluacionRetiroCI,IdCfgEvaluacionRetiroDet,ClaUsuarioMod,NombrePcMod) " +
                " VALUES(?,?,?,?,?,?) "  );
        System.out.println("---- ClaUbicacion "+ClaUbicacion+" IdTraEvaluacionRetiroCIDet "+IdTraEvaluacionRetiroCIDet+" IdTraEvaluacionRetiroCI "+IdTraEvaluacionRetiroCI+" IdCfgEvaluacionRetiroDet "+IdCfgEvaluacionRetiroDet);
        stmt2.bindString(1, ClaUbicacion);
        stmt2.bindString(2, IdTraEvaluacionRetiroCIDet);
        stmt2.bindString(3, IdTraEvaluacionRetiroCI);
        stmt2.bindString(4, IdCfgEvaluacionRetiroDet);
        stmt2.bindString(5, ClaUsuarioMod);
        stmt2.bindString(6, NombrePcMod);
        stmt2.execute();
        dbI2.close();
    }

    public void generarTraEvaluacionRetiro(String IdRetiro, String ClaUbicacion, String NombrePcMod, String ClaUsuarioMod){
        SQLiteDatabase db = this.getReadableDatabase();
        String[] args = {IdRetiro, ClaUbicacion};
        Cursor c2 = db.rawQuery("SELECT * FROM FFCCTraEvaluacionRetiroCI WHERE IdRetiroClienteInterno = ? AND ClaUbicacion = ? ",args);
        if(c2.getCount()>0){
            c2.moveToFirst();
            System.out.printf("DATA **********  "+ c2.getString(0));
        }else{
            Cursor cx = this.getDataCfgEvaluacionRetiro(ClaUbicacion);
            cx.moveToFirst();
            if(cx.getCount()>0){
                System.out.println("INTERNOS ******* "+ClaUbicacion+" - "+IdRetiro);
                System.out.println("INTERNOS ******* "+this.IDmaximoFFCCTraEvaluacionRetiroCI(ClaUbicacion,IdRetiro));
               this.InsertFFCCTraEvaluacionRetiroCI(ClaUbicacion,this.IDmaximoFFCCTraEvaluacionRetiroCI(ClaUbicacion,IdRetiro),IdRetiro,ClaUsuarioMod,NombrePcMod);
               String idEnc = IDmaximoFFCCTraEvaluacionRetiroCI2(ClaUbicacion,IdRetiro);
                for(int x = 0; x < cx.getCount(); x++){//add detalle
                    this.InsertFFCCTraEvaluacionRetiroCIDet(ClaUbicacion,this.IDmaximoFFCCTraEvaluacionRetiroCIDet(ClaUbicacion,IdRetiro,idEnc),idEnc,cx.getString(0),ClaUsuarioMod,NombrePcMod);
                    cx.moveToNext();
                }
            }
            cx.close();
        }
        c2.close();
        db.close();
    }


    public Cursor getDataTraEvaluacionRetiro(String ClaUbicacion, String IdRetiro){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] args2 = {ClaUbicacion,IdRetiro};
        return db.rawQuery("SELECT c2.ClaUbicacion, c2.IdTraEvaluacionRetiroCIDet, c2.IdTraEvaluacionRetiroCI, c2.IdCfgEvaluacionRetiroDet,c3.NomCfgElavuacionRetiroDet, c2.Valor, c2.ClaUsuarioMod, c2.NombrePcMod, c1.IdRetiroClienteInterno" +
                " FROM FFCCTraEvaluacionRetiroCI c1 " +
                " JOIN  FFCCTraEvaluacionRetiroCIDet c2 " +
                " ON c1.ClaUbicacion = c2.ClaUbicacion" +
                " JOIN FFCCCfgEvaluacionRetiroDet c3" +
                " ON c2.IdCfgEvaluacionRetiroDet = c3.IdCfgEvaluacionRetiroDet " +
                " AND c2.ClaUbicacion = c3.ClaUbicacion  " +
                " AND c1.IdTraEvaluacionRetiroCI = c2.IdTraEvaluacionRetiroCI " +
                " WHERE c1.ClaUbicacion = ? AND c1.IdRetiroClienteInterno= ?",args2);
    }

    public void updateTraEvaluacionRetiro(String Valor, String ClaUsuarioMod, String NombrePcMod, String ClaUbicacion, String IdTraEvaluacionRetiroCI , String IdTraEvaluacionRetiroCIDet, String IdCfgEvaluacionRetiroDet){
        SQLiteDatabase dbI2 = this.getWritableDatabase();
        SQLiteStatement stmt2 = dbI2.compileStatement("UPDATE FFCCTraEvaluacionRetiroCIDet " +
                " SET  Valor = ?, ClaUsuarioMod = ?,NombrePcMod = ? " +
                " WHERE ClaUbicacion = ? AND IdTraEvaluacionRetiroCI= ? AND IdTraEvaluacionRetiroCIDet= ? " +
                " AND IdCfgEvaluacionRetiroDet = ?"  );
        stmt2.bindString(1, Valor);
        stmt2.bindString(2, ClaUsuarioMod);
        stmt2.bindString(3, NombrePcMod);
        stmt2.bindString(4, ClaUbicacion);
        stmt2.bindString(5, IdTraEvaluacionRetiroCI);
        stmt2.bindString(6, IdTraEvaluacionRetiroCIDet);
        stmt2.bindString(7, IdCfgEvaluacionRetiroDet);
        stmt2.execute();
        dbI2.close();
    }

    public void updateEstatusTraEvaluacionRetiro(String Valor, String ClaUbicacion, String IdRetiroClienteInterno){
        SQLiteDatabase dbI2 = this.getWritableDatabase();
        SQLiteStatement stmt2 = dbI2.compileStatement("UPDATE FFCCTraEvaluacionRetiroCI " +
                " SET EstatusEvaluacion = ? " +
                " WHERE ClaUbicacion = ? AND IdRetiroClienteInterno = ? "  );
        stmt2.bindString(1, Valor);
        stmt2.bindString(2, ClaUbicacion);
        stmt2.bindString(3, IdRetiroClienteInterno);
        stmt2.execute();
        dbI2.close();
    }

    public String getEstatusEvaluacion( String ClaUbicacion, String IdRetiroClienteInterno){
        SQLiteDatabase dbI2 = this.getWritableDatabase();
        String[] args = {ClaUbicacion,IdRetiroClienteInterno};
        Cursor c = dbI2.rawQuery("SELECT IFNULL(EstatusEvaluacion,0) FROM FFCCTraEvaluacionRetiroCI " +
                " WHERE ClaUbicacion = ? AND IdRetiroClienteInterno = ? "  , args);
        String Valor = "0";
        if(c.getCount()>0){
            c.moveToFirst();
            Valor = c.getString(0);
            c.close();
        }
        dbI2.close();
        return Valor;
    }

    public String getObservaciones(String IdInspeccionCarro){
      SQLiteDatabase dbI2 = this.getWritableDatabase();
      String[] args = {IdInspeccionCarro};
      Cursor cc = dbI2.rawQuery(" SELECT ifnull(Observacion,'') FROM FFCCTraInspeccionCarro WHERE IdInspeccionCarro = ?",args);
        String Valor = " ";
        if(cc.getCount()>0){
            cc.moveToFirst();
            Valor = cc.getString(0);
            cc.close();
        }
        dbI2.close();
        return Valor;
    }

    public void UpdateObservaciones(String Observaciones,String IdInspeccionCarro){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraInspeccionCarro SET Observacion = ?" +
                " WHERE IdInspeccionCarro = ? "  );
        stmt.bindString(1, Observaciones);
        stmt.bindString(2, IdInspeccionCarro);
        stmt.execute();
        db.close();
    }

    public void UpdateEvaluacionCI(String ClaUbicacion,String Valor,String IdTraEvaluacionRetiroCI, String IdCfgEvaluacionRetiroDet){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraEvaluacionRetiroCIDet SET Valor = ?" +
                " WHERE IdTraEvaluacionRetiroCI = ? " +
                " AND ClaUbicacion = ? " +
                " AND IdCfgEvaluacionRetiroDet = ? " );
        stmt.bindString(1, Valor);
        stmt.bindString(2, IdTraEvaluacionRetiroCI);
        stmt.bindString(3, ClaUbicacion);
        stmt.bindString(4, IdCfgEvaluacionRetiroDet);
        stmt.execute();
        db.close();
    }


    public void UpdateEstatusCarro(String IdInspeccionCarro, String Valor){
        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteStatement stmt = db.compileStatement("UPDATE FFCCTraInspeccionCarro SET Rechaza = ?" +
                " WHERE IdInspeccionCarro = ? " );
        stmt.bindString(1, Valor);
        stmt.bindString(2, IdInspeccionCarro);
        stmt.execute();
        db.close();
    }

    public void CloseDB(){
        SQLiteDatabase db = this.getReadableDatabase(); db.close();
        SQLiteDatabase ds = this.getWritableDatabase(); ds.close();
    }

}
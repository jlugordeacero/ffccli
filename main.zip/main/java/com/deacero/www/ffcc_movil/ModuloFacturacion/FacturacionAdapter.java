package com.deacero.www.ffcc_movil.ModuloFacturacion;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.deacero.www.ffcc_movil.R;

import java.util.ArrayList;

public class FacturacionAdapter extends RecyclerView.Adapter<FacturacionAdapter.ViewHoldeFactura>{
    private ArrayList<Facturacion> listaFacturados;
    public FacturacionAdapter(ArrayList<Facturacion> listaFacturados) {
        this.listaFacturados = listaFacturados;
    }

    @NonNull
    @Override
    public ViewHoldeFactura onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list_facturacion,null,false);
        return new ViewHoldeFactura(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHoldeFactura ViewHoldeFactura, final int i) {
        ViewHoldeFactura.Placa.setText(listaFacturados.get(i).getPlaca());
        ViewHoldeFactura.Destino.setText(listaFacturados.get(i).getDestino());
        ViewHoldeFactura.Cliente.setText(listaFacturados.get(i).getCliente());
        ViewHoldeFactura.PaisDestino.setText(listaFacturados.get(i).getPaisDestino());
        ViewHoldeFactura.Material.setText(listaFacturados.get(i).getMaterial());
    }

    @Override
    public int getItemCount() {
        return listaFacturados.size();
    }

    public class ViewHoldeFactura extends RecyclerView.ViewHolder {
        TextView Placa, Destino, Cliente,PaisDestino ,Material;

        public ViewHoldeFactura(@NonNull View itemView) {
            super(itemView);
            Placa=(TextView) itemView.findViewById(R.id.txtPlaca);
            Destino=(TextView) itemView.findViewById(R.id.txtDestino);
            Cliente=(TextView) itemView.findViewById(R.id.txtCliente);
            PaisDestino=(TextView) itemView.findViewById(R.id.txtPaisDestino);
            Material=(TextView) itemView.findViewById(R.id.txtMaterial);
        }
    }
}

package com.deacero.www.ffcc_movil.ModuloFacturacion;

public class Facturacion {
    private String Placa, Destino, Cliente, PaisDestino, Material;

    public Facturacion(String placa, String destino, String cliente, String paisDestino, String material) {
        Placa = placa;
        Destino = destino;
        Cliente = cliente;
        PaisDestino = paisDestino;
        Material = material;
    }

    public String getPlaca() {
        return Placa;
    }

    public void setPlaca(String placa) {
        Placa = placa;
    }

    public String getDestino() {
        return Destino;
    }

    public void setDestino(String destino) {
        Destino = destino;
    }

    public String getCliente() {
        return Cliente;
    }

    public void setCliente(String cliente) {
        Cliente = cliente;
    }

    public String getPaisDestino() {
        return PaisDestino;
    }

    public void setPaisDestino(String paisDestino) {
        PaisDestino = paisDestino;
    }

    public String getMaterial() {
        return Material;
    }

    public void setMaterial(String material) {
        Material = material;
    }
}

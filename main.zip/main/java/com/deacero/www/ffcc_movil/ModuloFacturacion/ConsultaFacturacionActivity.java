package com.deacero.www.ffcc_movil.ModuloFacturacion;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.deacero.www.ffcc_movil.BDFFCCMovil;
import com.deacero.www.ffcc_movil.R;
import com.deacero.www.ffcc_movil.metodos.AuthenticationWS2;
import com.deacero.www.ffcc_movil.metodos.GetFacturacionWS;

import java.util.ArrayList;

public class ConsultaFacturacionActivity extends AppCompatActivity implements View.OnClickListener {
    ///////BD
    BDFFCCMovil objBD= new BDFFCCMovil(this); //hace la conexión
    private Cursor c, c2;
    public ArrayList<Facturacion> listFact = new ArrayList<Facturacion>();
    public RecyclerView recyclerFacturacion;
    public FacturacionAdapter adp = new FacturacionAdapter(listFact);

    //DATOS SESSION USUARIO
    private String idUsuario,ClaEmpleado,NombreUsuario,loginUserName, ClaUbicacionLogin, MAC, token, Password;
    private Toast toast;
    private EditText editTextManiobra;
    public ImageButton imgBotonConsultaManiobra;

    private  String DirIp="";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pre_facturacion_activity);
        //vars
        idUsuario = getIntent().getExtras().getString("idUsuario");
        ClaEmpleado = getIntent().getExtras().getString("ClaEmpleado");
        NombreUsuario = getIntent().getExtras().getString("NombreUsuario");
        loginUserName = getIntent().getExtras().getString("loginUserName");
        ClaUbicacionLogin = getIntent().getExtras().getString("ClaUbicacion");
        token = getIntent().getExtras().getString("token");
        MAC = getIntent().getExtras().getString("DireccionMAC");

        recyclerFacturacion =(RecyclerView)findViewById(R.id.recyclerFacturacion);

        recyclerFacturacion.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        editTextManiobra = (EditText) findViewById(R.id.txtNumeroManiobra);
        imgBotonConsultaManiobra = (ImageButton) findViewById(R.id.imgBuscarPlaca);
        imgBotonConsultaManiobra.setOnClickListener(this);


        recyclerFacturacion.setAdapter(adp);


    }



    @Override
    public void onRestart() {
        super.onRestart(); //Toast.makeText(this,"restart ins",Toast.LENGTH_SHORT).show();
       // recyclerFacturacion.removeAllViewsInLayout();
        //listFact.clear();
        //recyclerFacturacion.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        //consulta();
        //FacturacionAdapter sit = new FacturacionAdapter(listFact);
        //recyclerFacturacion.setAdapter(sit);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.imgBuscarPlaca:
                        if(editTextManiobra.getText().length()>=3) {
                            recyclerFacturacion.removeAllViewsInLayout();
                            listFact.clear();
                            c = objBD.getUserXLoginUser(loginUserName);
                            if (c.getCount() > 0) {
                                c.moveToFirst();
                                Password = c.getString(4);
                            }
                            c.close();
                            AuthenticationWS2 AuthWS = new AuthenticationWS2(ConsultaFacturacionActivity.this, getString(R.string.ip_authentication), loginUserName, Password, MAC, "0");
                            AuthWS.execute("");


                            c2 = objBD.getUserXLoginUser(loginUserName);
                            if (c2.getCount() > 0) {
                                c2.moveToFirst();
                                token = c2.getString(8);
                            }
                            c2.close();
                            objBD.close();

                            GetFacturacionWS fact = new GetFacturacionWS(ConsultaFacturacionActivity.this, token, getString(R.string.IpGetFacturacion), ClaUbicacionLogin, editTextManiobra.getText().toString(), listFact, adp);
                            fact.execute();


                            System.out.println("EJECUTO ADAPTADOR");
                            recyclerFacturacion.setAdapter(adp);
                        } else{
                            if (toast!= null) { toast.cancel(); }
                            toast = Toast.makeText(getApplicationContext(),"Ingrese al menos 3 carácteres.", Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                        }


                break;
        }
    }
}
